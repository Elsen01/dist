module.exports = {
  type: process.env.TYPEORM_TYPE,
  host: process.env.TYPEORM_HOST,
  dialect: process.env.TYPEORM_DIALECT,
  username: process.env.TYPEORM_USERNAME,
  password: process.env.TYPEORM_PASSWORD,
  database: process.env.TYPEORM_DATABASE,
  port: process.env.TYPEORM_PORT,
  synchronize: false,
  logging: false,
  migrationsRun: process.env.TYPEORM_RUN === true,
  options: {
    encrypt: true,
  },
  entities: ['**/*.entity.js'],
  migrations: ['dist/migrations/*.js'],
  cli: {
    entitiesDir: 'src/entity',
    migrationsDir: 'src/migrations',
  },
};

import { IDocumentedEndpoint } from '../shared/interfaces/swagger.interface';

export const GET_BODY_INFO: IDocumentedEndpoint = {
  OPERATION: {
    description:
      'Get all `Body region` and `Body parts` within the system. All users roles are allowed to perform this action',
  },
  SUCCESS: {
    description: '`Success` Body info are returned',
  },
  FORBIDDEN: {
    description: '`API` User has no permissions to get body info',
  },
  FAILURE: {
    description: '`API` Select entity from the database failed',
  },
};

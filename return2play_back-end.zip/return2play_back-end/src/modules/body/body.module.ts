import { BodyRepository } from './body.repository';
import { Module } from '@nestjs/common';
import { BodyService } from './body.service';
import { BodyController } from './body.controller';
import { TypeOrmModule } from '@nestjs/typeorm';
import { SharedModule } from '../shared/shared.module';

@Module({
  providers: [BodyService],
  controllers: [BodyController],
  imports: [TypeOrmModule.forFeature([BodyRepository]), SharedModule],
})
export class BodyModule {}

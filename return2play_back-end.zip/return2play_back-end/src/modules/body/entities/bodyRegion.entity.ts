import { BodyPartEntity } from './bodyPart.entity';
import { Column, CreateDateColumn, Entity, OneToMany, PrimaryGeneratedColumn, UpdateDateColumn } from 'typeorm';
import { OtherInjuryEntity } from '../../injuries/entities/otherInjury.entity';

@Entity('body_regions')
export class BodyRegionEntity {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ length: 255 })
  name: string;

  @OneToMany(() => BodyPartEntity, (bodyPart) => bodyPart.bodyRegion)
  bodyParts: BodyPartEntity[];

  @OneToMany(() => OtherInjuryEntity, (otherInjuries) => otherInjuries.bodyRegion)
  otherInjuries: OtherInjuryEntity[];

  @CreateDateColumn({ name: 'created_at' })
  createdAt: Date;

  @UpdateDateColumn({ name: 'updated_at' })
  updatedAt: Date;
}

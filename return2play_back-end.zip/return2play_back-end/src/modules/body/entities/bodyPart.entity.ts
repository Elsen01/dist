import {
  Column,
  CreateDateColumn,
  Entity,
  JoinColumn,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm';
import { OtherInjuryEntity } from '../../injuries/entities/otherInjury.entity';
import { BodyRegionEntity } from './bodyRegion.entity';

@Entity('body_parts')
export class BodyPartEntity {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ length: 255 })
  name: string;

  @ManyToOne(() => BodyRegionEntity, (bodyRegion) => bodyRegion.bodyParts)
  @JoinColumn({ name: 'body_region_id', referencedColumnName: 'id' })
  bodyRegion: BodyRegionEntity;

  @OneToMany(() => OtherInjuryEntity, (otherInjuries) => otherInjuries.bodyPart)
  otherInjuries: OtherInjuryEntity[];

  @CreateDateColumn({ name: 'created_at' })
  createdAt: Date;

  @UpdateDateColumn({ name: 'updated_at' })
  updatedAt: Date;
}

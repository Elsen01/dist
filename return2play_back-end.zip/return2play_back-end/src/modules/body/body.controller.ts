import { BodyService } from './body.service';
import { Controller, Get, UseGuards } from '@nestjs/common';
import { BodyRegionEntity } from './entities/bodyRegion.entity';
import {
  ApiBearerAuth,
  ApiForbiddenResponse,
  ApiOkResponse,
  ApiOperation,
  ApiTags,
  ApiUnprocessableEntityResponse,
} from '@nestjs/swagger';
import { CognitoGuard } from '../shared/guards/cognito.guard';
import { RolesGuard } from '../shared/guards/roles.guard';
import { Roles } from '../shared/decorators/roles.decorator';
import { ALL_ROLES } from '../users/types';
import { GET_BODY_INFO } from './swagger';

@ApiTags('Body')
@UseGuards(CognitoGuard, RolesGuard)
@Roles(...ALL_ROLES)
@ApiBearerAuth()
@Controller('body')
export class BodyController {
  constructor(private service: BodyService) {}

  @ApiOperation(GET_BODY_INFO.OPERATION)
  @ApiOkResponse(GET_BODY_INFO.SUCCESS)
  @ApiForbiddenResponse(GET_BODY_INFO.FORBIDDEN)
  @ApiUnprocessableEntityResponse(GET_BODY_INFO.FAILURE)
  @Get()
  async findBodyRegionsAndParts(): Promise<BodyRegionEntity[]> {
    return await this.service.findBodyRegionsAndParts();
  }
}

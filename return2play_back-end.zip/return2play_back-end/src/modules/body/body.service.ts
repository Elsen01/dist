import { BodyRepository } from './body.repository';
import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { BodyRegionEntity } from './entities/bodyRegion.entity';

@Injectable()
export class BodyService {
  constructor(
    @InjectRepository(BodyRepository)
    private bodyRepo: BodyRepository
  ) {}

  async findBodyRegionsAndParts(): Promise<BodyRegionEntity[]> {
    return await this.bodyRepo.findBodyRegionsAndParts();
  }
}

import { UnprocessableEntityException } from '@nestjs/common';
import { AbstractRepository, EntityRepository } from 'typeorm';
import { BodyRegionEntity } from './entities/bodyRegion.entity';

@EntityRepository(BodyRegionEntity)
export class BodyRepository extends AbstractRepository<BodyRegionEntity> {
  async findBodyRegionsAndParts(): Promise<BodyRegionEntity[]> {
    return await this.createQueryBuilder('bodyRegion')
      .leftJoinAndSelect('bodyRegion.bodyParts', 'bodyPart')
      .getMany()
      .catch((err) => {
        throw new UnprocessableEntityException(err.message);
      });
  }
}

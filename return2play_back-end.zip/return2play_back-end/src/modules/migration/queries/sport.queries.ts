export const GET_ALL_SPORTS_QUERY = `
SELECT id, sport_name AS name
FROM myh_sport;
`;

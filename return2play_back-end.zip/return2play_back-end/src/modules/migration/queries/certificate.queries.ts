export const GET_ALL_CERTIFICATES_QUERY = (injuryIds: string[]): string => `
SELECT
    ic.certificate_id AS id,
    ic.certificate AS certificate,
    null AS newPlayStatus,
    ic.injury_id AS injuryId,
    d.first_name AS doctorFirstName,
    d.last_name AS doctorLastName,
    ic.date_of_issue AS appointmentDate
FROM myh_injury_certificates ic
    LEFT JOIN myh_doctor d ON d.doctor_id = ic.issued_by
WHERE ${injuryIds.length ? `ic.injury_id IN (${injuryIds.join(',')})` : 'false'};
`;

export const GET_USERS_QUERY = (limit: number, page: number): string => `
SELECT DISTINCT p.person_id        AS id,
                p.email_address    AS email,
                p.first_name       AS firstName,
                p.last_name        AS lastName,
                'Active'           AS status,
                COALESCE(
                        CASE
                            WHEN (p.gender = 'male') THEN 'Male'
                            WHEN (p.gender = 'female') THEN 'Female'
                            END,
                        null)      AS gender,
                p.birthdate        AS birthday,
                NOW()              AS createdAt,
                COALESCE(
                        CASE
                            WHEN (
                                    p.category = 'Adult Player'
                                    OR p.category = 'Child'
                                    OR p.person_id IN (SELECT related_person_id FROM myh_person_relationship)
                                    OR p.parent_id OR p.parent_email_address
                                    OR p.child_relationship_confirmed = 1
                                    OR p.safe_to_begin_grtp_from
                                    OR p.safe_to_return_to_play_from
                                    OR p.remain_in_grtp
                                    OR p.grtp_stage_2_date
                                ) THEN 'players'
                            WHEN (p.category = 'Administrator') THEN 'organization_admins'
                            WHEN (p.category = 'Coach') THEN 'staff_users'
                        END,
                        'parents') AS role
FROM (
         SELECT p.*,
                suc.*,
                rank() over (partition by p.email_address ORDER BY su.category_id) AS role_rank,
                rank() over (partition by p.email_address ORDER BY p.gender DESC) AS gender_rank
         FROM myh_person p
                  LEFT JOIN myh_signup su ON su.person_id = p.person_id
                  LEFT JOIN myh_signup_category suc on su.category_id = suc.category_id
         WHERE p.person_id != 0) p
WHERE role_rank = 1
    AND gender_rank = 1
    OR (person_id IN (SELECT relationship_owner_person_id FROM myh_person_relationship)
        OR person_id IN (SELECT related_person_id FROM myh_person_relationship))
LIMIT ${limit} OFFSET ${page * limit};
`;

export const GET_ALL_PLAYERS_QUERY = (userIds: string[]): string => `
SELECT userId, yearGroup, membership, socsId, membershipExpirationDate
FROM (SELECT DISTINCT p.person_id                                                           AS userId,
                      COALESCE(CONCAT('U', TIMESTAMPDIFF(YEAR, p.birthdate, NOW())), 'N/A') AS yearGroup,
                      IF(o.org_type_id = 1, 'School Member', 'Regular Member')              AS membership,
                      p.birthdate                                                           AS birthdate,
                      api.alternate_person_id                                               AS socsId,
                      rank() over (partition by p.person_id order by su.org_id)             AS org_rank,
                      rank() over (partition by p.person_id order by api.modified_date)     AS socs_rank,
                      IF(DATE_FORMAT(p.membership_expires, '%Y-%m-%d') = '0000-00-00', NULL, p.membership_expires)  AS membershipExpirationDate
      FROM myh_person p
      LEFT JOIN myh_signup su on su.person_id = p.person_id
      LEFT JOIN myh_organisation o on o.org_id = su.org_id
      LEFT JOIN myh_alternate_person_id api ON api.person_id = p.person_id
      WHERE (su.category_id = 2
                OR su.category_id = 6
                OR p.person_id IN (SELECT related_person_id FROM myh_person_relationship)
                OR p.parent_id OR p.parent_email_address
                OR p.child_relationship_confirmed = 1
                OR p.safe_to_begin_grtp_from
                OR p.safe_to_return_to_play_from
                OR p.remain_in_grtp
                OR p.grtp_stage_2_date
                )) u
WHERE org_rank = 1 AND socs_rank = 1
    AND ${userIds.length ? `userId IN (${userIds.join(',')})` : 'false'};
`;
export const GET_ALL_DOCTORS_QUERY = `
SELECT d.gmc_registration_number AS gmc,
       d.doctor_id               AS userId,
       null                      AS bio,
       null                      AS picture
FROM myh_doctor d;
`;

export const GET_ALL_DOCTOR_USERS_QUERY = `
SELECT d.doctor_id    AS id,
       d.email        AS email,
       d.first_name   AS firstName,
       d.last_name    AS lastName,
       'Active'       AS status,
       null           AS gender,
       null           AS birthday,
       d.created_date AS createdAt,
       'doctors'      AS role
FROM myh_doctor d;
`;

export const GET_ALL_REPORTERS_QUERY = `
SELECT p.person_id                       AS id,
       CONCAT(p.first_name, p.last_name) AS name
FROM myh_person p
    INNER JOIN myh_injury i ON i.logged_by = p.person_id
GROUP BY p.person_id, p.email_address;
`;

export const GET_RELATIONS_QUERY = (userIds: string[]): string => `
SELECT r.relationship_owner_person_id AS parentId,
       r.related_person_id            AS playerId
FROM myh_person_relationship r
WHERE r.related_person_id IN (SELECT id FROM (
    SELECT DISTINCT p.person_id        AS id,
                p.email_address    AS email,
                p.first_name       AS firstName,
                p.last_name        AS lastName,
                'Active'           AS status,
                COALESCE(
                        CASE
                            WHEN (p.gender = 'male') THEN 'Male'
                            WHEN (p.gender = 'female') THEN 'Female'
                            END,
                        null)      AS gender,
                p.birthdate        AS birthday,
                NOW()              AS createdAt,
                COALESCE(
                        CASE
                            WHEN (p.category = 'Administrator') THEN 'organization_admins'
                            WHEN (p.category = 'Coach') THEN 'staff_users'
                            WHEN (
                                    p.category = 'Adult Player' OR
                                    p.category = 'Child' OR
                                    p.person_id IN (SELECT related_person_id FROM myh_person_relationship)
                                ) THEN 'players'
                            END,
                        'parents') AS role
FROM (
         SELECT p.*,
                suc.*,
                rank() over (partition by p.email_address ORDER BY su.category_id) AS role_rank,
                rank() over (partition by p.email_address ORDER BY p.gender DESC)  AS gender_rank
         FROM myh_person p
                  LEFT JOIN myh_signup su ON su.person_id = p.person_id
                  LEFT JOIN myh_signup_category suc on su.category_id = suc.category_id
         WHERE p.person_id != 0) p
WHERE role_rank = 1
    AND gender_rank = 1
   OR (person_id IN (SELECT relationship_owner_person_id FROM myh_person_relationship)
    OR person_id IN (SELECT related_person_id FROM myh_person_relationship))
    ) a WHERE a.role = 'players')
    AND ${userIds.length ? `r.relationship_owner_person_id IN (${userIds.join(',')})` : 'false'}
    AND ${userIds.length ? `r.related_person_id IN (${userIds.join(',')})` : 'false'}
`;

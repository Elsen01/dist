export const GET_ALL_SYMPTOMS_QUERY = `
SELECT
    sl.symptom_lookup_id AS id,
    sl.description_for_senior_form AS name
FROM myh_symptom_lookup sl
WHERE sl.description_for_senior_form IS NOT NULL;
`;

export const GET_ALL_RED_FLAG_SYMPTOMS_QUERY = `
SELECT
    rfs.symptom_id AS id,
    rfs.symptom AS name
FROM myh_red_flag_symptoms rfs;
`;

export const GET_ALL_INJURIES_SYMPTOMS_QUERY = (injuryIds: string[]): string => `
SELECT 
    pasi.item_id AS id,
    pasi.symptom_lookup_id AS symptomId,
    COALESCE(pasi.symptom_zero_to_six_measure, 0) AS value,
    pasi.symptom_record_id AS injuryId
FROM myh_pre_appt_symptom_item pasi
    LEFT JOIN myh_pre_appt_symptom_record pasr ON pasr.id = pasi.symptom_record_id
WHERE ${injuryIds.length ? `pasr.injury_id IN (${injuryIds.join(',')})` : 'false'};
`;

export const GET_ALL_INJURIES_RED_FLAG_SYMPTOMS_QUERY = (injuryIds: string[]): string => `
SELECT 
    sri.symptom_record_item_id AS id,
    sri.symptom_id AS redFlagSymptomId,
    sri.symptom_record_id AS injuryId,
    sri.symptom_present AS isPresent
FROM myh_symptom_record_item sri
WHERE sri.symptom_id != 0
    AND sri.symptom_id IN (SELECT rfs.symptom_id FROM myh_red_flag_symptoms rfs)
    AND ${injuryIds.length ? `sri.injury_id IN (${injuryIds.join(',')})` : 'false'};
`;

export const GET_ALL_INJURIES_OTHER_SYMPTOMS_QUERY = (injuryIds: string[], otherSymptomId: string): string => `
SELECT
    IF(pasr.how_different_to_usual_self = 'N/A', 'Not applicable', pasr.how_different_to_usual_self) AS value,
    pasr.id AS injuryId,
    '${otherSymptomId}' AS otherSymptomId,
    null AS id
FROM myh_pre_appt_symptom_record pasr
WHERE pasr.how_different_to_usual_self IS NOT NULL
    AND ${injuryIds.length ? `pasr.injury_id IN (${injuryIds.join(',')})` : 'false'};
`;

export const GET_ALL_INJURIES_BINARY_SYMPTOMS_QUERY = (
  injuryIds: string[],
  worseMentallyId: string,
  worsePhysicallyId: string
): string => `
(
    SELECT
        pasr.worse_when_mentally_active AS isPresent,
        pasr.id AS injuryId,
        '${worseMentallyId}' AS binarySymptomId,
        null AS id
    FROM myh_pre_appt_symptom_record pasr
    WHERE ${injuryIds.length ? `pasr.injury_id IN (${injuryIds.join(',')})` : 'false'}
)
UNION
(
    SELECT
        pasr.worse_when_physically_active AS isPresent,
        pasr.id AS injuryId,
        '${worsePhysicallyId}' AS binarySymptomId,
        null AS id
    FROM myh_pre_appt_symptom_record pasr
    WHERE ${injuryIds.length ? `pasr.injury_id IN (${injuryIds.join(',')})` : 'false'}
);
`;

// explaining WHERE: there are 2 rows out of 51k where injury_id is NULL
// and the only injury reference is to concussion
// omiting these two records I save myself a lot of time joining whole lotta shit and getting needed data
export const GET_ALL_CONCUSSION_SYMPTOMS_QUERY = (injuryIds: string[]): string => `
SELECT
    sr.id AS id,
    sr.injury_id AS injuryId,
    IFNULL(sr.created_date, NOW()) AS createdAt,
    SUM(si.symptom_zero_to_six_measure) AS score
FROM myh_pre_appt_symptom_record sr
    LEFT JOIN myh_pre_appt_symptom_item si on sr.id = si.symptom_record_id
WHERE ${injuryIds.length ? `sr.injury_id IN (${injuryIds.join(',')})` : 'false'}
GROUP BY sr.id, sr.injury_id, sr.created_date
UNION
SELECT
    sr.symptom_record_id AS id,
    sr.injury_id AS injuryId,
    NOW() AS createdAt,
    0 AS score
FROM myh_symptom_record sr
    LEFT JOIN myh_symptom_record_item si on sr.symptom_record_id = si.symptom_record_id
WHERE si.injury_id IS NOT NULL AND sr.injury_id IS NOT NULL
    AND ${injuryIds.length ? `sr.injury_id IN (${injuryIds.join(',')})` : 'false'};
`;

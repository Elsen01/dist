import { snakeCase } from 'lodash';

export const INSERT_QUERY = (tableName: string, values: Record<string, any>[]): string => {
  const keys = Object.keys(values[0]);
  const snakeKeys = keys.map((key) => (key === 'isPresent' ? '"isPresent"' : snakeCase(key)));

  const valuesSql = values.map((value) => {
    const valueParamsSql = Object.values(value).map((param) => `$$${param}$$`);
    let valueSql = `(${valueParamsSql.join(', ')})`;
    valueSql = valueSql.replace(/\$\$null\$\$/g, 'null');

    return valueSql;
  });

  // console.log(`INSERT INTO ${tableName} (${snakeKeys.join(',')})\nVALUES ${valuesSql.join(',\n')};`);
  return `INSERT INTO ${tableName} (${snakeKeys.join(',')}) VALUES ${valuesSql.join(',')};`;
};

export const GET_ALL_BODY_REGIONS_QUERY = `
SELECT lookup_item_id AS id, description AS name
FROM myh_lookup_tables
WHERE lookup_type_id = 3;
`;

export const GET_ALL_BODY_PARTS_QUERY = `
SELECT body_part_id AS id, name
FROM myh_injury_body_part;
`;

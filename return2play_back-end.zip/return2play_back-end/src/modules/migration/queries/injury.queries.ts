import { SUPER_USER_ID } from '../../shared/constants';

export const GET_ALL_INJURIES_QUERY = (userIds: string[]): string => `
SELECT inj.injury_id                                        AS id,
       IF(inj.concussion_flag = 1, 'Concussion', 'Other')   AS injuryGroup,
       CAST(inj.date_of_injury AS CHAR)                     AS accidentDate,
       IF(inc.sports_injury_flag = 1, 'Sport', 'Non-sport') AS activityType,
       inj.person_id                                        AS playerId,
       inc.logged_by                                        AS reporterId,
       lt.description                                       AS injuredAt,
       CASE
           WHEN (ps.status_value = 'Safe to play') THEN 'Safe to play'
           WHEN (ps.status_value = 'Reduced level of activity') THEN 'Reduced level of activity'
           WHEN (ps.status_value = 'Concussed - Graduated Return to Play') THEN 'Reduced level of activity'
           WHEN (ps.status_value = 'Remain in GRTP') THEN 'Reduced level of activity'
           WHEN (ps.status_value = 'Not Safe to Play') THEN 'Not safe to play'
           WHEN (ps.status_value = 'Concussed - 2 weeks rest') THEN 'Not safe to play'
           WHEN (ps.status_value = 'Concussed - Need re-review') THEN 'Not safe to play'
           WHEN (ps.status_value = 'Concussed - Referred for further medical care') THEN 'Not safe to play'
           WHEN (inj.cancellation_reason IS NOT NULL) THEN 'Cleared'
           ELSE 'Cleared'
        END
                                                            AS playStatus,
       'Active'                                             AS status,
        NOW()                                               AS createdAt
FROM myh_injury inj
         LEFT JOIN myh_incident inc ON inj.incident_id = inc.incident_id
         LEFT JOIN myh_lookup_tables lt ON inc.non_sport_injury_location_id = lt.lookup_item_id
         LEFT JOIN myh_person_status ps ON ps.person_status_id = inj.player_injury_status_id
         LEFT JOIN myh_signup su ON inj.person_id = su.person_id
WHERE ${userIds.length ? `inj.person_id IN (${userIds.join(',')})` : 'false'} 
    AND ${userIds.length ? `inj.logged_by IN (${userIds.join(',')})` : 'false'} 
    AND su.category_id IN (2, 6)
UNION
SELECT inj.injury_id                                        AS id,
       IF(inj.concussion_flag = 1, 'Concussion', 'Other')   AS injuryGroup,
       CAST(inj.date_of_injury AS CHAR)                     AS accidentDate,
       IF(inc.sports_injury_flag = 1, 'Sport', 'Non-sport') AS activityType,
       inj.person_id                                        AS playerId,
       '${SUPER_USER_ID}'                                   AS reporterId,
       lt.description                                       AS injuredAt,
       CASE
           WHEN (ps.status_value = 'Safe to play') THEN 'Safe to play'
           WHEN (ps.status_value = 'Reduced level of activity') THEN 'Reduced level of activity'
           WHEN (ps.status_value = 'Concussed - Graduated Return to Play') THEN 'Reduced level of activity'
           WHEN (ps.status_value = 'Remain in GRTP') THEN 'Reduced level of activity'
           WHEN (ps.status_value = 'Not Safe to Play') THEN 'Not safe to play'
           WHEN (ps.status_value = 'Concussed - 2 weeks rest') THEN 'Not safe to play'
           WHEN (ps.status_value = 'Concussed - Need re-review') THEN 'Not safe to play'
           WHEN (ps.status_value = 'Concussed - Referred for further medical care') THEN 'Not safe to play'
           WHEN (inj.cancellation_reason IS NOT NULL) THEN 'Cleared'
           ELSE 'Cleared'
        END
                                                            AS playStatus,
       'Active'                                             AS status,
        NOW()                                               AS createdAt
FROM myh_injury inj
         LEFT JOIN myh_incident inc ON inj.incident_id = inc.incident_id
         LEFT JOIN myh_lookup_tables lt ON inc.non_sport_injury_location_id = lt.lookup_item_id
         LEFT JOIN myh_person_status ps ON ps.person_status_id = inj.player_injury_status_id
         LEFT JOIN myh_signup su ON inj.person_id = su.person_id
WHERE ${userIds.length ? `inj.person_id IN (${userIds.join(',')})` : 'false'} 
    AND ${userIds.length ? `inj.logged_by NOT IN (${userIds.join(',')})` : 'false'} 
    AND su.category_id IN (2, 6)
`;

export const GET_ALL_SPORT_INJURIES_QUERY = (injuryIds: string[]): string => `
WITH fucking_with_clause AS (
    SELECT distinct injury_id
    FROM myh_injury i
             INNER JOIN (
        SELECT s.person_id
        FROM myh_signup s
        WHERE org_id IN (SELECT o.org_id FROM myh_organisation o)
        GROUP BY s.person_id
        HAVING COUNT(org_id) = 1
    ) u on i.person_id = u.person_id
             LEFT JOIN myh_incident inc ON i.incident_id = inc.incident_id
             LEFT JOIN myh_concussion con ON con.person_id = inc.person_id AND con.date_of_injury = inc.date_of_incident
    WHERE inc.sports_injury_flag = 1
      AND con.org_id IS NULL
)
SELECT id,
       injuryId,
       matchTraining,
       playSide,
       mouthGuard,
       protectiveHeadgear,
       timePeriod,
       sportId,
       organizationId
FROM (SELECT DISTINCT null                                                         AS id,
                      inj.injury_id                                                AS injuryId,
                      lt.description                                               AS matchTraining,
                      null                                                         AS playSide,
                      con.mouthguard_used                                          AS mouthGuard,
                      con.headgear_used                                            AS protectiveHeadgear,
                      null                                                         AS timePeriod,
                      s.id                                                         AS sportId,
                      CASE
                          WHEN (con.org_id) THEN con.org_id
                          WHEN (inj.injury_id IN (SELECT injury_id FROM fucking_with_clause)
                              AND su.org_id IN (SELECT org_id FROM myh_organisation)) THEN su.org_id
                          ELSE NULL
                        END
                                                                                   AS organizationId,
                      COALESCE(coi.cause_id, '2')                                  AS mechanismId,
                      rank() over (partition by injury_id ORDER BY su.org_id DESC) AS org_rank
      FROM myh_injury inj
               LEFT JOIN myh_incident inc ON inj.incident_id = inc.incident_id
               LEFT JOIN myh_concussion con ON con.person_id = inc.person_id
          AND con.date_of_injury = inc.date_of_incident
          AND con.logged_by = inc.logged_by
               LEFT JOIN myh_lookup_tables lt ON inc.sport_injury_context_id = lt.lookup_item_id
               LEFT JOIN myh_sport s ON inc.sport_id = s.id
               LEFT JOIN myh_cause_of_injury coi ON con.cause_id = coi.cause_id
               LEFT JOIN myh_signup su ON su.person_id = inj.person_id
      WHERE inc.sports_injury_flag = 1) inj_ranked
WHERE org_rank = 1
    AND ${injuryIds.length ? `injuryId IN (${injuryIds.join(',')})` : 'false'};
`;

export const GET_ALL_OTHER_INJURIES_QUERY = (injuryIds: string[]): string => `
SELECT
    null AS id,
    inj.injury_id AS injuryId,
    TRIM(lt_cat.description) AS category,
    IF(lt_type.description = 'Soft tissue injury' OR lt_type.description = 'Other', 'null', lt_type.description) AS type,
    lt_body_side.description AS bodySide,
    inj.injury_location_region_id AS bodyRegionId,
    inj.injury_body_part_id AS bodyPartId
FROM myh_injury inj
    LEFT JOIN myh_incident inc ON inj.incident_id = inc.incident_id
    LEFT JOIN myh_concussion con ON con.person_id = inc.person_id AND con.date_of_injury = inc.date_of_incident
    LEFT JOIN myh_lookup_tables lt_cat ON inj.injury_category_id = lt_cat.lookup_item_id
    LEFT JOIN myh_lookup_tables lt_type ON inj.injury_type_id = lt_type.lookup_item_id
    LEFT JOIN myh_lookup_tables lt_body_side ON inj.injury_location_side_id = lt_body_side.lookup_item_id
    LEFT JOIN myh_cause_of_injury coi ON con.cause_id = coi.cause_id
WHERE (
    lt_cat.description IS NOT NULL AND
    lt_type.description IS NOT NULL AND
    lt_body_side.description IS NOT NULL AND
    inj.injury_location_region_id IS NOT NULL AND
    inj.injury_body_part_id IS NOT NULL AND
    inj.injury_body_part_id != 0 AND
    ${injuryIds.length ? `inj.injury_id IN (${injuryIds.join(',')})` : 'false'}
);
`;

export const GET_ALL_INJURY_MECHANISMS_QUERY = `
SELECT CASE
           WHEN c.mechanism = 'Collision' THEN 'Accidental collision'
           WHEN c.mechanism = 'Tackle' THEN 'Tackling Player'
           ELSE c.mechanism
       END        AS name,
       c.cause_id AS id
FROM myh_cause_of_injury c;
`;

export const GET_NOTES_QUERY = (injuryIds: string[]): string => `
SELECT n.injury_id                                                                AS injuryId,
       n.notes                                                                    AS text,
       IF(n.created_by IN (SELECT person_id FROM myh_person), n.created_by, null) AS authorId,
       n.created_date                                                             AS createdAt,
       null                                                                       AS id
FROM myh_notes n
WHERE ${injuryIds.length ? `n.injury_id IN (${injuryIds.join(',')})` : 'false'};
`;

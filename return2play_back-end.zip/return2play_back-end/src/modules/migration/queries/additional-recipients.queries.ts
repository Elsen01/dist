export const GET_ALL_ADDITIONAL_RECIPIENTS_QUERY = (userIds: string[]): string => `
SELECT SUBSTRING_INDEX(ar.name, ' ', 1)              AS firstName,
       SUBSTR(ar.name, POSITION(' ' IN ar.name) + 1) AS lastName,
       ar.email_address                              AS email,
       ar.person_id                                  AS playerId,
       ar.info                                       AS additionalInfo,
       NOW()                                         AS createdAt,
       'Active'                                      AS status
FROM myh_additional_recipients ar
         INNER JOIN myh_person p ON ar.person_id = p.person_id
         INNER JOIN myh_signup ms on ar.person_id = ms.person_id
WHERE ms.category_id IN (2, 6)
    AND ${userIds.length ? `ar.person_id IN (${userIds.join(',')})` : 'false'};
`;

export const GET_ALL_ORGS_QUERY = `
SELECT DISTINCT
       org.org_id                                      AS id,
       org.org_name                                    AS name,
       org.email,
       REPLACE(org.phone, '+44', '')                   AS phone,
       org.website,
       NOW()                                           AS createdAt,
       org.address_line1                               AS address1,
       org.address_line2                               AS address2,
       org.postcode,
       org.town,
       org.county,
       org.country,
       IF(org_t.org_type = 'School', 'School', 'Club') AS type
FROM myh_organisation org
         LEFT JOIN myh_organisation_type org_t ON org.org_type_id = org_t.org_type_id
         LEFT JOIN myh_signup su on org.org_id = su.org_id`;

export const GET_ORGS_USERS_QUERY = (userIds: string[]): string => `
SELECT DISTINCT
    su.person_id AS userId,
    su.org_id    AS organizationId
FROM myh_signup su
WHERE ${userIds.length ? `su.person_id IN (${userIds.join(',')})` : 'false'}
    AND su.org_id IN (SELECT o.org_id FROM myh_organisation o)`;

export const GET_ALL_SOCS_ORGS_QUERY = `
SELECT DISTINCT
       org.org_id                                      AS id,
       org.org_name                                    AS name,
       org.email,
       REPLACE(org.phone, '+44', '')                   AS phone,
       org.website,
       NOW()                                           AS createdAt,
       org.address_line1                               AS address1,
       org.address_line2                               AS address2,
       org.postcode,
       org.town,
       org.county,
       org.country,
       IF(org_t.org_type = 'School', 'School', 'Club') AS type
FROM myh_organisation org
         LEFT JOIN myh_organisation_type org_t ON org.org_type_id = org_t.org_type_id
         LEFT JOIN myh_signup su on org.org_id = su.org_id
WHERE org.socs_enabled;
`;

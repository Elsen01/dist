import { uniqBy } from 'lodash';
import { QueryRunner } from 'typeorm';
import { BodyRepository } from '../body/body.repository';
import { DoctorRepository } from '../doctors/doctor.repository';
import { SportRepository } from '../sports/sport.repository';
import { SymptomRepository } from '../symptoms/symptom.repository';
import { GET_ALL_BODY_PARTS_QUERY, GET_ALL_BODY_REGIONS_QUERY } from './queries/body.queries';
import { GET_ALL_INJURY_MECHANISMS_QUERY } from './queries/injury.queries';
import { GET_ALL_SPORTS_QUERY } from './queries/sport.queries';
import { GET_ALL_RED_FLAG_SYMPTOMS_QUERY, GET_ALL_SYMPTOMS_QUERY } from './queries/symptom.queries';
import { GET_ALL_DOCTOR_USERS_QUERY } from './queries/user.queries';

export class MigrationMapper {
  constructor(private readonly dumpDbRunner: QueryRunner, private readonly existentDbRunner: QueryRunner) {}

  public async getSymptomsMap(): Promise<Map<string, string>> {
    const existentSymptomsAll = await this.existentDbRunner.manager
      .getCustomRepository(SymptomRepository)
      .findSymptomsLists();
    const existentSymptoms = existentSymptomsAll.symptoms;
    const dumpSymptoms = await this.dumpDbRunner.manager.query(GET_ALL_SYMPTOMS_QUERY);

    return this.getIdMap(dumpSymptoms, existentSymptoms);
  }

  public async getRedFlagSymptomsMap(): Promise<Map<string, string>> {
    const existentSymptomsAll = await this.existentDbRunner.manager
      .getCustomRepository(SymptomRepository)
      .findSymptomsLists();
    const existentSymptoms = existentSymptomsAll.redFlagSymptoms;
    const dumpSymptoms = await this.dumpDbRunner.manager.query(GET_ALL_RED_FLAG_SYMPTOMS_QUERY);

    return this.getIdMap(dumpSymptoms, existentSymptoms);
  }

  public async getSportsMap(): Promise<Map<string, string>> {
    const existentSports = await this.existentDbRunner.manager.getCustomRepository(SportRepository).findSportList();
    const dumpSports = await this.dumpDbRunner.manager.query(GET_ALL_SPORTS_QUERY);

    return this.getIdMap(dumpSports, existentSports);
  }

  public async getBodyRegionsMap(): Promise<Map<string, string>> {
    const existentBodyRegions = await this.existentDbRunner.manager
      .getCustomRepository(BodyRepository)
      .findBodyRegionsAndParts();
    const dumpBodyRegions = await this.dumpDbRunner.manager.query(GET_ALL_BODY_REGIONS_QUERY);

    return this.getIdMap(dumpBodyRegions, existentBodyRegions);
  }

  public async getBodyPartsMap(): Promise<Map<string, string>> {
    const existentBodyRegions = await this.existentDbRunner.manager
      .getCustomRepository(BodyRepository)
      .findBodyRegionsAndParts();
    const existentBodyParts = existentBodyRegions.flatMap(({ bodyParts }) => bodyParts);

    const dumpBodyParts = await this.dumpDbRunner.manager.query(GET_ALL_BODY_PARTS_QUERY);

    return this.getIdMap(dumpBodyParts, existentBodyParts);
  }

  public async getDoctorsMap(): Promise<Map<string, string>> {
    const [existentDoctors] = await this.existentDbRunner.manager
      .getCustomRepository(DoctorRepository)
      .findMany({ limit: 1000, page: 0 });
    const existentDoctorsMapped = existentDoctors.map((doctor) => {
      return { id: doctor.user.id, name: doctor.user.email };
    });

    const dumpDoctors = await this.dumpDbRunner.manager.query(GET_ALL_DOCTOR_USERS_QUERY);
    const dumpDoctorsMapped = dumpDoctors.map((doctor) => {
      return { id: doctor.id, name: doctor.email };
    });

    return this.getIdMap(dumpDoctorsMapped, existentDoctorsMapped);
  }

  public async getMechanismsMap(): Promise<Map<string, string>> {
    const existentSports = await this.existentDbRunner.manager.getCustomRepository(SportRepository).findSportList();
    let existentMechanisms = existentSports.flatMap(({ injuryMechanisms }) => injuryMechanisms);
    existentMechanisms = uniqBy(existentMechanisms, (mechanism) => mechanism.name);

    const dumpMechanisms = await this.dumpDbRunner.manager.query(GET_ALL_INJURY_MECHANISMS_QUERY);

    return this.getIdMap(dumpMechanisms, existentMechanisms);
  }

  private getIdMap<T extends { id: string; name: string }>(keyArray: T[], valueArray: T[]): Map<string, string> {
    const map = new Map<string, string>();
    keyArray.forEach((keyObj) => {
      const valObj = valueArray.find((val) => {
        const valName = val.name.replace(/[^\w!?]/g, '');
        const keyName = keyObj.name.replace(/[^\w!?]/g, '');

        return valName.toLowerCase() === keyName.toLowerCase();
      });

      if (keyObj && valObj) {
        map.set(keyObj.id, valObj.id);
      }
    });

    return map;
  }
}

import { Body, Controller, Post, Query } from '@nestjs/common';
import { ApiExcludeEndpoint } from '@nestjs/swagger';
import { ConnectionOptions } from 'typeorm';
import { PaginationDto } from '../shared/shared.dto';
import { MigrationService } from './migration.service';

@Controller('migrate')
export class MigrationController {
  constructor(private service: MigrationService) {}

  @ApiExcludeEndpoint()
  @Post()
  async migrate(@Body() body: ConnectionOptions, @Query() pagination: PaginationDto): Promise<any> {
    return this.service.migrateChunk(body, pagination.limit, pagination.page);
  }
}

/* eslint-disable no-console */
/* eslint-disable prefer-const */
import { QueryRunner } from 'typeorm';
import { v4 as uuid4, validate } from 'uuid';
import { isNull } from 'lodash';
import { IPlayer, IRelation, IUser } from './interfaces/user.interfaces';
import { IAdditionalRecipient } from './interfaces/additional-recipient.interfaces';
import { IAssessment, ICertificate } from './interfaces/certificate.interfaces';
import { IInjury, INote, IOtherInjury, ISportInjury } from './interfaces/injury.interfaces';
import { MigrationReadChunk, MigrationWriteChunk } from './interfaces/migration.interfacecs';
import { IOrganization, IUserOrganization } from './interfaces/organization.interfaces';
import {
  IBinarySymptom,
  IConcussionSymptom,
  IOtherSymptom,
  IRedFlagSymptom,
  ISymptom,
} from './interfaces/symptom.interfaces';
import { MigrationMapper } from './migration.mapper';
import { GET_ALL_ADDITIONAL_RECIPIENTS_QUERY } from './queries/additional-recipients.queries';
import { GET_ALL_CERTIFICATES_QUERY } from './queries/certificate.queries';
import {
  GET_ALL_INJURIES_QUERY,
  GET_ALL_OTHER_INJURIES_QUERY,
  GET_ALL_SPORT_INJURIES_QUERY,
  GET_NOTES_QUERY,
} from './queries/injury.queries';
import { GET_ALL_ORGS_QUERY, GET_ALL_SOCS_ORGS_QUERY, GET_ORGS_USERS_QUERY } from './queries/organization.queries';
import {
  GET_ALL_CONCUSSION_SYMPTOMS_QUERY,
  GET_ALL_INJURIES_BINARY_SYMPTOMS_QUERY,
  GET_ALL_INJURIES_OTHER_SYMPTOMS_QUERY,
  GET_ALL_INJURIES_RED_FLAG_SYMPTOMS_QUERY,
  GET_ALL_INJURIES_SYMPTOMS_QUERY,
} from './queries/symptom.queries';
import { GET_ALL_PLAYERS_QUERY, GET_RELATIONS_QUERY, GET_USERS_QUERY } from './queries/user.queries';
import { INSERT_QUERY } from './queries/shared.queries';
import { UnprocessableEntityException } from '@nestjs/common';
import { S3BucketManager } from '../shared/helpers/s3bucket/s3bucket.manager';
import { HOUR_MS, PDF_FORMAT } from '../shared/constants';
import { SymptomRepository } from '../symptoms/symptom.repository';
import { UserRole } from '../users/types';
import { OrganizationRepository } from '../organizations/organizations.repository';
import { SortOptions } from '../organizations/types';

export class MigrationManager {
  private static instance: MigrationManager;

  private constructor(
    private readonly dumpDbRunner: QueryRunner,
    private readonly existentDbRunner: QueryRunner,
    private readonly mapper: MigrationMapper,
    private readonly s3Bucket: S3BucketManager
  ) {}

  public static getManagerInstance(
    dumpDbRunner: QueryRunner,
    existentDbRunner: QueryRunner,
    mapper: MigrationMapper,
    s3Bucket: S3BucketManager
  ): MigrationManager {
    return MigrationManager.instance
      ? MigrationManager.instance
      : new MigrationManager(dumpDbRunner, existentDbRunner, mapper, s3Bucket);
  }

  public async readChunk(page: number, limit: number): Promise<MigrationReadChunk> {
    console.log('less go');
    const users: IUser[] = await this.dumpDbRunner.manager.query(GET_USERS_QUERY(limit, page));
    const userIds = users.map(({ id }) => id);

    const players: IPlayer[] = await this.dumpDbRunner.manager.query(GET_ALL_PLAYERS_QUERY(userIds));

    const relations: IRelation[] = await this.dumpDbRunner.manager.query(GET_RELATIONS_QUERY(userIds));

    const additionalRecipients: IAdditionalRecipient[] = await this.dumpDbRunner.manager.query(
      GET_ALL_ADDITIONAL_RECIPIENTS_QUERY(userIds)
    );

    const organizations: IOrganization[] = await this.dumpDbRunner.manager.query(GET_ALL_ORGS_QUERY);

    const organizationsUsers: IUserOrganization[] = await this.dumpDbRunner.manager.query(
      GET_ORGS_USERS_QUERY(userIds)
    );

    const injuries: IInjury[] = await this.dumpDbRunner.manager.query(GET_ALL_INJURIES_QUERY(userIds));
    const injuriesIds = injuries.map(({ id }) => id);

    const otherInjuries: IOtherInjury[] = await this.dumpDbRunner.manager.query(
      GET_ALL_OTHER_INJURIES_QUERY(injuriesIds)
    );

    const sportInjuries: ISportInjury[] = await this.dumpDbRunner.manager.query(
      GET_ALL_SPORT_INJURIES_QUERY(injuriesIds)
    );

    const notes: INote[] = await this.dumpDbRunner.manager.query(GET_NOTES_QUERY(injuriesIds));

    const injuriesSymptoms: ISymptom[] = await this.dumpDbRunner.manager.query(
      GET_ALL_INJURIES_SYMPTOMS_QUERY(injuriesIds)
    );

    const injuriesRedFlagSymptoms: IRedFlagSymptom[] = await this.dumpDbRunner.manager.query(
      GET_ALL_INJURIES_RED_FLAG_SYMPTOMS_QUERY(injuriesIds)
    );

    const existentSymptoms = await this.existentDbRunner.manager
      .getCustomRepository(SymptomRepository)
      .findSymptomsLists();
    const howDifferentToUsualSelfId = existentSymptoms.otherSymptoms[0].id;
    const injuriesOtherSymptoms: IOtherSymptom[] = await this.dumpDbRunner.manager.query(
      GET_ALL_INJURIES_OTHER_SYMPTOMS_QUERY(injuriesIds, howDifferentToUsualSelfId)
    );

    const worseMentallyId = existentSymptoms.binarySymptoms.find(
      ({ name }) => name === 'Do symptoms get worse with mental activity?'
    ).id;
    const worsePhysicallyId = existentSymptoms.binarySymptoms.find(
      ({ name }) => name === 'Do symptoms get worse with physical activity?'
    ).id;
    const injuriesBinarySymptoms: IBinarySymptom[] = await this.dumpDbRunner.manager.query(
      GET_ALL_INJURIES_BINARY_SYMPTOMS_QUERY(injuriesIds, worseMentallyId, worsePhysicallyId)
    );

    const injuriesConcussionSymptoms: IConcussionSymptom[] = await this.dumpDbRunner.manager.query(
      GET_ALL_CONCUSSION_SYMPTOMS_QUERY(injuriesIds)
    );

    const certificates: ICertificate[] = await this.dumpDbRunner.manager.query(GET_ALL_CERTIFICATES_QUERY(injuriesIds));
    console.log('select ended');

    return {
      users,
      players,
      relations,
      organizations,
      organizationsUsers,
      injuries,
      otherInjuries,
      sportInjuries,
      notes,
      injuriesSymptoms,
      injuriesConcussionSymptoms,
      injuriesRedFlagSymptoms,
      injuriesOtherSymptoms,
      injuriesBinarySymptoms,
      additionalRecipients,
      certificates,
    };
  }

  public async map(chunk: MigrationReadChunk): Promise<MigrationWriteChunk> {
    let {
      users,
      players,
      relations,
      organizations,
      organizationsUsers,
      injuries,
      additionalRecipients,
      otherInjuries,
      sportInjuries,
      notes,
      injuriesSymptoms,
      injuriesConcussionSymptoms,
      injuriesRedFlagSymptoms,
      injuriesOtherSymptoms,
      injuriesBinarySymptoms,
      certificates,
    } = chunk;

    chunk.injuriesSymptoms = await this.mapSymptoms(injuriesSymptoms);
    otherInjuries = await this.mapOtherInjuries(otherInjuries);
    injuriesRedFlagSymptoms = await this.mapRedFlagSymptoms(injuriesRedFlagSymptoms);
    sportInjuries = await this.mapSportInjuries(sportInjuries);
    console.log('maps done');

    users.forEach((user) => {
      const oldId = user.id;
      user.id = uuid4();

      if (user.role === UserRole.Parent) {
        this.replaceFieldValue(relations, 'parentId', oldId, user.id);
      }
      if (user.role === UserRole.Player) {
        this.replaceFieldValue(relations, 'playerId', oldId, user.id);
        this.replaceFieldValue(players, 'userId', oldId, user.id);
        this.replaceFieldValue([...injuries, ...additionalRecipients], 'playerId', oldId, user.id);
      }
      this.replaceFieldValue(organizationsUsers, 'userId', oldId, user.id);
      this.replaceFieldValue(injuries, 'reporterId', oldId, user.id);
      this.replaceFieldValue(notes, 'authorId', oldId, user.id);
    });
    console.log('users mapped');

    chunk.relations = relations.filter((r) => validate(r.playerId) && validate(r.parentId));

    organizations.forEach((org) => {
      const socsOrg = {
        2: '8b82b009-64c0-485b-bc81-c8a4b55e9908',
        23: '91ffb89a-f3ce-4db2-b46d-94bc2979a232',
        180: '63cf5938-bc79-4280-8e0e-880b2e18dd35',
        114: '90766039-2192-444b-be7e-fcf793adf6d9',
        189: '7fa7c1ca-e700-45ef-ab4b-c38813430320',
        375: '16c0bb74-3d10-482b-8b10-8bcd5b891bfe',
        330: '698ad326-6a00-4215-bccf-c3a7e6c7c986',
        96: 'ba911f0e-07ac-4322-b2bf-b97da1612b47',
        53: '2210ccce-849e-400b-addf-e3cf831e8b71',
        204: 'f895e361-8429-4804-a034-9f9ac1386119',
        79: '471ef29e-7cdc-43e1-8fda-3a15ffe9d4b5',
        541: '13bb0630-d975-4ff8-9332-a4ef62566d86',
        86: '0b65c0c5-ed42-4c58-ba87-bec2ff4493c1',
        560: 'cfd410ad-4755-4da7-90e9-41438f625709',
        51: '3989ae27-eb8e-4644-84d4-6af1caf4030b',
      };

      const socsOldIds = [
        '2',
        '23',
        '180',
        '114',
        '189',
        '375',
        '330',
        '96',
        '53',
        '204',
        '79',
        '541',
        '86',
        '560',
        '51',
      ];

      const oldId = org.id;

      const socsIndex = socsOldIds.indexOf(oldId);

      org.id = socsIndex === -1 ? uuid4() : socsOrg[socsOldIds[socsIndex]];

      this.replaceFieldValue([...organizationsUsers, ...sportInjuries], 'organizationId', oldId, org.id);
    });
    console.log('orgs mapped');

    injuries.forEach((injury) => {
      const oldId = injury.id;
      injury.id = uuid4();

      this.replaceFieldValue(
        [...otherInjuries, ...sportInjuries, ...injuriesConcussionSymptoms, ...certificates, ...notes],
        'injuryId',
        oldId,
        injury.id
      );
    });

    injuriesConcussionSymptoms.forEach((symptom) => {
      const oldId = symptom.id;
      symptom.id = uuid4();

      this.replaceFieldValue(
        [...injuriesSymptoms, ...injuriesRedFlagSymptoms, ...injuriesOtherSymptoms, ...injuriesBinarySymptoms],
        'injuryId',
        oldId,
        symptom.id
      );
    });

    console.log('injuries mapped');
    [
      ...otherInjuries,
      ...sportInjuries,
      ...injuriesSymptoms,
      ...injuriesRedFlagSymptoms,
      ...injuriesOtherSymptoms,
      ...injuriesBinarySymptoms,
      ...certificates,
      ...notes,
    ].forEach((entity) => {
      entity.id = uuid4();
    });

    [...users, ...organizations, ...injuries, ...additionalRecipients, ...injuriesConcussionSymptoms, ...notes].forEach(
      (entity) => (entity.createdAt = new Date(new Date(entity.createdAt).getTime() + HOUR_MS * 3).toISOString())
    );

    users.forEach((user) => (user.birthday = new Date(new Date(user.birthday).getTime() + HOUR_MS * 3).toISOString()));

    players.forEach(
      (user) =>
        (user.membershipExpirationDate = new Date(
          new Date(user.membershipExpirationDate).getTime() + HOUR_MS * 3
        ).toISOString())
    );

    const assessments = await this.mapCertificates(certificates);
    assessments.forEach(
      (assessment) =>
        (assessment.appointmentDate = new Date(
          new Date(assessment.appointmentDate).getTime() + HOUR_MS * 3
        ).toISOString())
    );

    const resChunk = (chunk as unknown) as MigrationWriteChunk;
    resChunk.assessments = assessments;
    console.log('dates mapped');

    return resChunk;
  }

  private async mapSportInjuries(sportInjuries: ISportInjury[]): Promise<ISportInjury[]> {
    const sportsMap = await this.mapper.getSportsMap();
    const mechanismsMap = await this.mapper.getMechanismsMap();

    sportInjuries.forEach((injury) => {
      injury.sportId = sportsMap.get(injury.sportId);
      injury.mechanismId = mechanismsMap.get(injury.mechanismId) || null;
    });

    return sportInjuries;
  }

  private async mapOtherInjuries(otherInjuries: IOtherInjury[]): Promise<IOtherInjury[]> {
    const partsMap = await this.mapper.getBodyPartsMap();
    const regionsMap = await this.mapper.getBodyRegionsMap();
    otherInjuries.forEach((injury) => {
      injury.bodyPartId = partsMap.get(injury.bodyPartId);
      injury.bodyRegionId = regionsMap.get(injury.bodyRegionId);
    });

    return otherInjuries;
  }

  private async mapSymptoms(injuriesSymptoms: ISymptom[]): Promise<ISymptom[]> {
    const symptomMap = await this.mapper.getSymptomsMap();

    const newSymptoms = injuriesSymptoms.map((symptom) => {
      const existentSymptomId = symptomMap.get(symptom.symptomId);
      if (existentSymptomId) {
        symptom.symptomId = existentSymptomId;

        return symptom;
      } else return null;
    });

    return newSymptoms.filter((symptom) => symptom);
  }

  private async mapRedFlagSymptoms(injuryRedFlagSymptoms: IRedFlagSymptom[]): Promise<IRedFlagSymptom[]> {
    const redFlagSymptomMap = await this.mapper.getRedFlagSymptomsMap();
    injuryRedFlagSymptoms.forEach((symptom) => {
      symptom.redFlagSymptomId = redFlagSymptomMap.get(symptom.redFlagSymptomId);
    });

    return injuryRedFlagSymptoms;
  }

  private async mapCertificates(certificates: ICertificate[]): Promise<IAssessment[]> {
    return Promise.all(
      certificates.map(async (assessment) => {
        const s3Path = `assessments/certificates/${new Date().getTime()}__${assessment.id}.pdf`;

        const buffer = assessment.certificate;
        const certificateLink = await this.s3Bucket.upload(s3Path, PDF_FORMAT, { buffer });

        // eslint-disable-next-line @typescript-eslint/no-unused-vars
        const { certificate, ...assessmentBody } = assessment;

        return { ...assessmentBody, certificateLink };
      })
    );
  }

  private replaceFieldValue<T>(arrayToMap: T[], fieldNameToChange: string, oldValue: string, newValue: string): T[] {
    arrayToMap.forEach((entity) => {
      if (!isNull(entity[fieldNameToChange]) && entity[fieldNameToChange].toString() === oldValue.toString()) {
        entity[fieldNameToChange] = newValue;
      }
    });

    return arrayToMap;
  }

  public async write(chunk: MigrationWriteChunk): Promise<void> {
    await this.existentDbRunner.startTransaction();

    try {
      await this.existentDbRunner.manager.query(INSERT_QUERY('users', chunk.users));
      console.log('users done');

      if (chunk.players.length) {
        await this.existentDbRunner.manager.query(INSERT_QUERY('players', chunk.players));
      }
      console.log('players done');

      if (chunk.relations.length) {
        await this.existentDbRunner.manager.query(INSERT_QUERY('players_parents', chunk.relations));
      }
      console.log('relations done');

      if (chunk.organizations.length) {
        await this.existentDbRunner.manager.query(INSERT_QUERY('organizations', chunk.organizations));
      }
      console.log('orgs done');

      if (chunk.organizationsUsers.length) {
        await this.existentDbRunner.manager.query(INSERT_QUERY('organizations_users', chunk.organizationsUsers));
      }
      console.log('org users done');

      if (chunk.injuries.length) {
        await this.existentDbRunner.manager.query(INSERT_QUERY('injuries', chunk.injuries));
      }
      console.log('injuries done');
      if (chunk.otherInjuries.length) {
        await this.existentDbRunner.manager.query(INSERT_QUERY('other_injuries', chunk.otherInjuries));
      }
      console.log('other injuries done');

      if (chunk.sportInjuries.length) {
        await this.existentDbRunner.manager.query(INSERT_QUERY('sport_injuries', chunk.sportInjuries));
      }
      console.log('sport injuries done');

      if (chunk.injuriesConcussionSymptoms.length) {
        await this.existentDbRunner.manager.query(
          INSERT_QUERY('injury_concussion_symptoms', chunk.injuriesConcussionSymptoms)
        );
      }
      console.log('concussion symptoms done');

      if (chunk.injuriesSymptoms.length) {
        await this.existentDbRunner.manager.query(INSERT_QUERY('injury_symptoms', chunk.injuriesSymptoms));
      }
      console.log('symptoms done');

      if (chunk.injuriesRedFlagSymptoms.length) {
        await this.existentDbRunner.manager.query(
          INSERT_QUERY('injury_red_flag_symptoms', chunk.injuriesRedFlagSymptoms)
        );
      }
      console.log('red flag symptoms done');

      if (chunk.injuriesOtherSymptoms.length) {
        await this.existentDbRunner.manager.query(INSERT_QUERY('injury_other_symptoms', chunk.injuriesOtherSymptoms));
      }
      console.log('other symptoms done');

      if (chunk.injuriesBinarySymptoms.length) {
        await this.existentDbRunner.manager.query(INSERT_QUERY('injury_binary_symptoms', chunk.injuriesBinarySymptoms));
      }
      console.log('binary symptoms done');

      if (chunk.notes.length) {
        await this.existentDbRunner.manager.query(INSERT_QUERY('notes', chunk.notes));
      }
      console.log('notes done');

      if (chunk.additionalRecipients.length) {
        await this.existentDbRunner.manager.query(INSERT_QUERY('additional_recepients', chunk.additionalRecipients));
      }
      console.log('recipients done');

      if (chunk.assessments.length) {
        await this.existentDbRunner.manager.query(INSERT_QUERY('external_assessments', chunk.assessments));
      }
      console.log('all done!!');

      await this.existentDbRunner.commitTransaction();
    } catch (err) {
      await this.existentDbRunner.rollbackTransaction();
      throw new UnprocessableEntityException(err.message);
    } finally {
      await this.existentDbRunner.release();
    }
  }

  public async updateSOCS(): Promise<void> {
    const socsOrgs: IOrganization[] = await this.dumpDbRunner.query(GET_ALL_SOCS_ORGS_QUERY);
    const [orgs] = await this.existentDbRunner.manager
      .getCustomRepository(OrganizationRepository)
      .findMany('', { limit: null, page: 0, sort: SortOptions.Created });

    let newOrgs = orgs.map((org) => {
      const matchOrg = socsOrgs.find((socsOrg) => socsOrg.name === org.name);
      if (matchOrg) {
        org.isSocs = true;
        org.socsId = matchOrg.id;

        return org;
      }
    });
    newOrgs = newOrgs.filter((org) => org);

    await this.existentDbRunner.manager.getCustomRepository(OrganizationRepository).saveMany(newOrgs);
  }
}

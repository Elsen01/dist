import { SymptomGradation } from '../../symptoms/types';

export interface ISymptom {
  id: string;
  symptomId: string;
  injuryId: string;
  value: SymptomGradation | null;
}

export interface IRedFlagSymptom {
  id: string;
  redFlagSymptomId: string;
  isPresent: boolean;
  injuryId: string;
}

export interface IOtherSymptom {
  id: string;
  otherSymptomId: string;
  value: string;
  injuryId: string;
}

export interface IBinarySymptom {
  id: string;
  binarySymptomId: string;
  isPresent: boolean;
  injuryId: string;
}

export interface IConcussionSymptom {
  id: string;
  createdAt: string;
  injuryId: string;
  score: number;
}

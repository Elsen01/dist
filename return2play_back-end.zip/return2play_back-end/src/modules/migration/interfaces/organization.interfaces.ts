export interface IOrganization {
  id: string;
  name: string;
  email: string;
  phone: string;
  website: string;
  createdAt: string;
  address1: string;
  address2: string;
  postcode: string;
  town: string;
  county: string;
  country: string;
  type: string;
}

export interface IUserOrganization {
  userId: string;
  organizationId: string;
}

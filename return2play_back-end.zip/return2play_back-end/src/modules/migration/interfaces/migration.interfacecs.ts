import { IAdditionalRecipient } from './additional-recipient.interfaces';
import { IAssessment, ICertificate } from './certificate.interfaces';
import { IInjury, INote, IOtherInjury, ISportInjury } from './injury.interfaces';
import { IOrganization, IUserOrganization } from './organization.interfaces';
import { IBinarySymptom, IConcussionSymptom, IOtherSymptom, IRedFlagSymptom, ISymptom } from './symptom.interfaces';
import { IPlayer, IRelation, IUser } from './user.interfaces';

export interface MigrationReadChunk {
  users: IUser[];
  players: IPlayer[];
  relations: IRelation[];
  organizations: IOrganization[];
  organizationsUsers: IUserOrganization[];
  injuries: IInjury[];
  otherInjuries: IOtherInjury[];
  sportInjuries: ISportInjury[];
  notes: INote[];
  injuriesSymptoms: ISymptom[];
  injuriesConcussionSymptoms: IConcussionSymptom[];
  injuriesRedFlagSymptoms: IRedFlagSymptom[];
  injuriesOtherSymptoms: IOtherSymptom[];
  injuriesBinarySymptoms: IBinarySymptom[];
  additionalRecipients: IAdditionalRecipient[];
  certificates: ICertificate[];
}

export interface MigrationWriteChunk {
  users: IUser[];
  players: IPlayer[];
  relations: IRelation[];
  organizations: IOrganization[];
  organizationsUsers: IUserOrganization[];
  injuries: IInjury[];
  otherInjuries: IOtherInjury[];
  sportInjuries: ISportInjury[];
  notes: INote[];
  injuriesSymptoms: ISymptom[];
  injuriesConcussionSymptoms: IConcussionSymptom[];
  injuriesRedFlagSymptoms: IRedFlagSymptom[];
  injuriesOtherSymptoms: IOtherSymptom[];
  injuriesBinarySymptoms: IBinarySymptom[];
  additionalRecipients: IAdditionalRecipient[];
  assessments: IAssessment[];
}

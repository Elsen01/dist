import { DecidedOutcome } from '../../assessments/types';

export interface ICertificate {
  id: string;
  certificate: Buffer;
  newPlayStatus: DecidedOutcome;
  injuryId: string;
  doctorFirstName: string;
  doctorLastName: string;
  appointmentDate: string;
}

export interface IAssessment {
  id: string;
  certificateLink: string;
  newPlayStatus: DecidedOutcome;
  injuryId: string;
  doctorFirstName: string;
  doctorLastName: string;
  appointmentDate: string;
}

import { PlayStatus } from '../../injuries/types';
import { Membership } from '../../players/types';
import { Gender, UserRole, UserStatus } from '../../users/types';

export interface IUser {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
  gender: Gender;
  role: UserRole;
  birthday: string;
  status: UserStatus;
  createdAt: string;
}

export interface IPlayer {
  userId: string;
  yearGroup: number;
  membership?: Membership;
  playStatus: PlayStatus;
  socsId: string;
  membershipExpirationDate: string;
}

export interface IRelation {
  playerId: string;
  parentId: string;
}

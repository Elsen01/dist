import { RecipientStatus } from '../../additional-recipients/types/recipient.types';

export interface IAdditionalRecipient {
  id: string;
  playerId: string;
  email: string;
  firstName: string;
  lastName: string;
  additionalInfo?: string;
  status: RecipientStatus;
  createdAt: string;
}

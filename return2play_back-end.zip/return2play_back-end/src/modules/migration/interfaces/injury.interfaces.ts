import { TimePeriod } from 'aws-sdk/clients/budgets';
import { ActivityType } from 'aws-sdk/clients/workdocs';
import {
  BodySide,
  InjuredAt,
  InjuryCategory,
  InjuryGroup,
  InjuryStatus,
  InjuryType,
  MatchTraining,
  PlaySide,
  PlayStatus,
} from '../../injuries/types';

export interface IInjury {
  id: string;
  injuryGroup: InjuryGroup;
  accidentDate: string;
  activityType: ActivityType;
  playerId: string;
  reporterId: string;
  injuredAt: InjuredAt;
  playStatus: PlayStatus;
  status: InjuryStatus;
  createdAt: string;
}

export interface ISportInjury {
  id: string;
  injuryId: string;
  matchTraining: MatchTraining;
  playSide: PlaySide;
  mouthGuard: boolean;
  protectiveHeadgear: boolean;
  timePeriod: TimePeriod;
  sportId: string;
  organizationId: string;
  mechanismId: string;
}

export interface IOtherInjury {
  id: string;
  injuryId: string;
  category: InjuryCategory;
  type: InjuryType;
  bodySide: BodySide;
  bodyRegionId: string;
  bodyPartId: string;
}

export interface INote {
  id: string;
  injuryId: string;
  createdAt: string;
  authorId: string;
  text: string;
}

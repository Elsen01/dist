import { Injectable, UnprocessableEntityException } from '@nestjs/common';
import { createConnection, ConnectionOptions, Connection } from 'typeorm';
import { S3BucketManager } from '../shared/helpers/s3bucket/s3bucket.manager';
import { MigrationManager } from './migration.manager';
import { MigrationMapper } from './migration.mapper';

@Injectable()
export class MigrationService {
  private dumpDbConnection: Connection;

  constructor(private readonly existentDbConnection: Connection, private readonly s3Bucket: S3BucketManager) {}

  async migrateChunk(options: ConnectionOptions, limit: number, page: number): Promise<void> {
    try {
      this.dumpDbConnection = await createConnection(options);

      const dumpDbRunner = this.dumpDbConnection.createQueryRunner();
      const existentDbRunner = this.existentDbConnection.createQueryRunner();

      const migrationMapper = new MigrationMapper(dumpDbRunner, existentDbRunner);
      const migrationManager = MigrationManager.getManagerInstance(
        dumpDbRunner,
        existentDbRunner,
        migrationMapper,
        this.s3Bucket
      );

      const readChunk = await migrationManager.readChunk(page, limit);
      const writeChunk = await migrationManager.map(readChunk);
      await migrationManager.write(writeChunk);
      await migrationManager.updateSOCS();
    } catch (err) {
      // eslint-disable-next-line no-console
      console.log(err);
      throw new UnprocessableEntityException(err.message);
    } finally {
      await this.dumpDbConnection.close();
    }
  }
}

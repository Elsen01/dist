import { UserEntity } from './../users/entities/user.entity';
import { getEntityInstance } from './../shared/utils/common.utils';
import { RoleManager } from './../shared/helpers/accessManager/role.manager';
import { AbstractRepository, EntityRepository } from 'typeorm';
import { NoteEntity } from './entities/note.entity';
import { InjuryEntity } from '../injuries/entities/injury.entity';
import { UnprocessableEntityException } from '@nestjs/common';

@EntityRepository(NoteEntity)
export class NoteRepository extends AbstractRepository<NoteEntity> {
  private readonly roleManager = RoleManager.getInstance();
  async create(text: string, isSensitive: boolean, injury: InjuryEntity): Promise<void> {
    const author = getEntityInstance(this.roleManager.userId, UserEntity);

    await this.repository.save({ text, isSensitive, injury, author }).catch((err) => {
      throw new UnprocessableEntityException(err.message);
    });
  }

  async createForAttendStatus(text: string, injury: InjuryEntity): Promise<void> {
    const author = getEntityInstance(this.roleManager.userId, UserEntity);

    await this.repository.save({ text, injury, author }).catch((err) => {
      throw new UnprocessableEntityException(err.message);
    });
  }
}

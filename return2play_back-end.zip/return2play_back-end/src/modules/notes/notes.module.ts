import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { InjuryRepository } from '../injuries/injury.repository';
import { SharedModule } from '../shared/shared.module';
import { NoteRepository } from './note.repository';
import { NotesController } from './notes.controller';
import { NotesService } from './notes.service';

@Module({
  controllers: [NotesController],
  providers: [NotesService],
  imports: [TypeOrmModule.forFeature([InjuryRepository, NoteRepository]), SharedModule],
})
export class NotesModule {}

import { NotesService } from './notes.service';
import { Body, Controller, HttpCode, HttpStatus, Post, UseGuards } from '@nestjs/common';
import {
  ApiBearerAuth,
  ApiForbiddenResponse,
  ApiNoContentResponse,
  ApiNotFoundResponse,
  ApiOperation,
  ApiTags,
  ApiUnprocessableEntityResponse,
} from '@nestjs/swagger';
import { Roles } from '../shared/decorators/roles.decorator';
import { CognitoGuard } from '../shared/guards/cognito.guard';
import { RolesGuard } from '../shared/guards/roles.guard';
import { ALL_ROLES } from '../users/types';
import { CreateNoteBody } from './dtos/create-note.dto';
import { CREATE_ONE } from './swagger';

@ApiTags('Notes')
@UseGuards(CognitoGuard, RolesGuard)
@Roles(...ALL_ROLES)
@ApiBearerAuth()
@Controller('notes')
export class NotesController {
  constructor(private service: NotesService) {}

  @ApiOperation(CREATE_ONE.OPERATION)
  @ApiNoContentResponse(CREATE_ONE.SUCCESS)
  @ApiForbiddenResponse(CREATE_ONE.FORBIDDEN)
  @ApiUnprocessableEntityResponse(CREATE_ONE.FAILURE)
  @ApiNotFoundResponse(CREATE_ONE.INJURY_NOT_FOUND)
  @HttpCode(HttpStatus.NO_CONTENT)
  @Post()
  create(@Body() body: CreateNoteBody): Promise<void> {
    return this.service.create(body);
  }
}

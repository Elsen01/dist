import { CreateNoteBody } from './dtos/create-note.dto';
import { NoteRepository } from './note.repository';
import { ForbiddenException, Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { InjuryRepository } from '../injuries/injury.repository';

@Injectable()
export class NotesService {
  constructor(
    @InjectRepository(InjuryRepository)
    private injuryRepo: InjuryRepository,
    @InjectRepository(NoteRepository)
    private noteRepo: NoteRepository
  ) {}

  async create(note: CreateNoteBody): Promise<void> {
    const injury = await this.injuryRepo.findInjury({ id: note.injuryId });

    if (!injury) {
      throw new NotFoundException('Injury not found');
    }

    const isHasAccessToPlayer = await this.injuryRepo.isHasAccessToPlayer(injury.user.id);

    if (!isHasAccessToPlayer) {
      throw new ForbiddenException('User does not have access to create note injury for this player');
    }

    return await this.noteRepo.create(note.text, note.isSensitive, injury);
  }

  async createForAttendStatus(id: string, text: string): Promise<void> {
    const injury = await this.injuryRepo.findInjury({ id });

    if (!injury) {
      throw new NotFoundException('Injury not found');
    }

    const isHasAccessToPlayer = await this.injuryRepo.isHasAccessToPlayer(injury.user.id);

    if (!isHasAccessToPlayer) {
      throw new ForbiddenException('User does not have access to create note injury for this player');
    }

    return await this.noteRepo.createForAttendStatus(text, injury);
  }
}

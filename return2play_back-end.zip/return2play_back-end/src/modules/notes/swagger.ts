import { IDocumentedEndpoint } from '../shared/interfaces/swagger.interface';

export const CREATE_ONE: IDocumentedEndpoint = {
  OPERATION: {
    description:
      'Add a new `Note` within the system to existing `Injury`. All users roles are allowed to perform this action',
  },
  SUCCESS: {
    description: '`Success` Note was added',
  },
  INJURY_NOT_FOUND: {
    description: '`API` Provided injury do not exist',
  },
  FORBIDDEN: {
    description: '`API` User has no permissions to add note to this player',
  },
  FAILURE: {
    description: '`API` Saved entity to the database failed',
  },
};

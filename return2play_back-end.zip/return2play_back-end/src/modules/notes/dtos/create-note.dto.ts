import { IsBoolean, IsOptional, IsString, IsUUID } from 'class-validator';

export class CreateNoteBody {
  @IsUUID()
  injuryId: string;

  @IsString()
  text: string;

  @IsBoolean()
  @IsOptional()
  isSensitive?: boolean;
}

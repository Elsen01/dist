import { IsBoolean, IsOptional, IsString, IsUUID, MaxLength } from 'class-validator';

export class UpdateNoteBody {
  @IsUUID()
  injuryId: string;

  @IsString()
  @MaxLength(1000)
  text: string;

  @IsBoolean()
  @IsOptional()
  attendStatus?: string;
}

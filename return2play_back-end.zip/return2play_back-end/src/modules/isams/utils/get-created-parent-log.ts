import { UserEntity } from '../../users/entities/user.entity';
import { formatParentData } from './format-parent-data';

export function getCreatedParentLog(parent: Partial<UserEntity>): string {
  return `[CREATED] parent:\n${formatParentData(parent)}`;
}

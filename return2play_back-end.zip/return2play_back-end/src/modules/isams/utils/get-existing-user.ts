import { IsamsPlayer } from './get-isams-players';
import { UserEntity } from '../../users/entities/user.entity';
import isSameDay from 'date-fns/isSameDay';

export function getExistingUser(
  isamsPlayer: IsamsPlayer,
  existingUsers: ReadonlyArray<UserEntity>,
  organizationId: string
): UserEntity | null {
  if (!existingUsers.length) {
    return null;
  }

  const existingUser = getExistingUserFromOrganization(
    isamsPlayer,
    existingUsers.filter(({ organizations }) =>
      organizations.some((organization) => organization.id === organizationId)
    )
  );

  if (existingUser) {
    return existingUser;
  }

  return getExistingUserFromAllOlrganizations(isamsPlayer, existingUsers);
}

function getExistingUserFromOrganization(
  isamsPlayer: IsamsPlayer,
  existingUsers: ReadonlyArray<UserEntity>
): UserEntity | null {
  if (!existingUsers.length) {
    return null;
  }

  let existingUser = findByFNLNEMAILGENDERDOB(isamsPlayer, existingUsers);

  if (existingUser) {
    return existingUser;
  }

  existingUser = findByFNLNEMAILGENDER(isamsPlayer, existingUsers);

  if (existingUser) {
    return existingUser;
  }

  existingUser = findByFNLNEMAIL(isamsPlayer, existingUsers);

  if (existingUser) {
    return existingUser;
  }

  existingUser = findByFNLN(isamsPlayer, existingUsers);

  if (existingUser) {
    return existingUser;
  }

  return findByEMAIL(isamsPlayer, existingUsers);
}

function getExistingUserFromAllOlrganizations(
  isamsPlayer: IsamsPlayer,
  existingUsers: ReadonlyArray<UserEntity>
): UserEntity | null {
  if (!existingUsers.length) {
    return null;
  }

  let existingUser = findByFNLNEMAILGENDERDOB(isamsPlayer, existingUsers);

  if (existingUser) {
    return existingUser;
  }

  existingUser = findByFNLNEMAILGENDER(isamsPlayer, existingUsers);

  if (existingUser) {
    return existingUser;
  }

  existingUser = findByFNLNEMAIL(isamsPlayer, existingUsers);

  if (existingUser) {
    return existingUser;
  }

  return findByEMAIL(isamsPlayer, existingUsers);
}

function findByFNLNEMAILGENDERDOB(
  isamsPlayer: IsamsPlayer,
  existingUsers: ReadonlyArray<UserEntity>
): UserEntity | null {
  const n = existingUsers.length;
  for (let i = 0; i < n; i++) {
    const user = existingUsers[i];

    if (
      isamsPlayer.firstName === user.firstName &&
      isamsPlayer.lastName === user.lastName &&
      isamsPlayer.email?.toLowerCase() === user.email?.toLowerCase() &&
      isamsPlayer.gender === user.gender &&
      isamsPlayer.birthday &&
      user.birthday &&
      isSameDay(new Date(isamsPlayer.birthday), new Date(user.birthday))
    ) {
      return user;
    }
  }

  return null;
}

function findByFNLNEMAILGENDER(isamsPlayer: IsamsPlayer, existingUsers: ReadonlyArray<UserEntity>): UserEntity | null {
  const n = existingUsers.length;

  for (let i = 0; i < n; i++) {
    const user = existingUsers[i];

    if (
      isamsPlayer.firstName === user.firstName &&
      isamsPlayer.lastName === user.lastName &&
      isamsPlayer.email?.toLowerCase() === user.email?.toLowerCase() &&
      isamsPlayer.gender === user.gender &&
      (!isamsPlayer.birthday || !user.birthday || isSameDay(new Date(isamsPlayer.birthday), new Date(user.birthday)))
    ) {
      return user;
    }
  }

  return null;
}

function findByFNLNEMAIL(isamsPlayer: IsamsPlayer, existingUsers: ReadonlyArray<UserEntity>): UserEntity | null {
  const n = existingUsers.length;

  for (let i = 0; i < n; i++) {
    const user = existingUsers[i];

    if (
      isamsPlayer.firstName === user.firstName &&
      isamsPlayer.lastName === user.lastName &&
      isamsPlayer.email?.toLowerCase() === user.email?.toLowerCase() &&
      (!isamsPlayer.gender || !user.gender || isamsPlayer.gender === user.gender) &&
      (!isamsPlayer.birthday || !user.birthday || isSameDay(new Date(isamsPlayer.birthday), new Date(user.birthday)))
    ) {
      return user;
    }
  }

  return null;
}

function findByFNLN(isamsPlayer: IsamsPlayer, existingUsers: ReadonlyArray<UserEntity>): UserEntity | null {
  const n = existingUsers.length;

  for (let i = 0; i < n; i++) {
    const user = existingUsers[i];

    if (
      isamsPlayer.firstName === user.firstName &&
      isamsPlayer.lastName === user.lastName &&
      (!isamsPlayer.email || !user.email || isamsPlayer.email?.toLowerCase() === user.email?.toLowerCase()) &&
      (!isamsPlayer.gender || !user.gender || isamsPlayer.gender === user.gender) &&
      (!isamsPlayer.birthday || !user.birthday || isSameDay(new Date(isamsPlayer.birthday), new Date(user.birthday)))
    ) {
      return user;
    }
  }

  return null;
}

function findByEMAIL(isamsPlayer: IsamsPlayer, existingUsers: ReadonlyArray<UserEntity>): UserEntity | null {
  const n = existingUsers.length;

  for (let i = 0; i < n; i++) {
    const user = existingUsers[i];

    if (
      isamsPlayer.email?.toLowerCase() === user.email?.toLowerCase() &&
      (!isamsPlayer.gender || !user.gender || isamsPlayer.gender === user.gender) &&
      (!isamsPlayer.birthday || !user.birthday || isSameDay(new Date(isamsPlayer.birthday), new Date(user.birthday)))
    ) {
      return user;
    }
  }

  return null;
}

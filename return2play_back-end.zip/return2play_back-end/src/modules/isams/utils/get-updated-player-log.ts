import { UserEntity } from '../../users/entities/user.entity';
import { formatPlayerData } from './format-player-data';
import get from 'lodash/get';
import set from 'lodash/set';

export function getUpdatedPlayerLog(old: UserEntity, updated: UserEntity, updatedFields: string[]): string {
  const updatedFieldsObj = {};
  const n = updatedFields.length;
  for (let i = 0; i < n; i++) {
    set(updatedFieldsObj, updatedFields[i], get(updated, updatedFields[i]));
  }

  return `[UPDATED] player:\n\n<from>:\n${formatPlayerData(old)}\n\n<to>:\n${formatPlayerData(
    updated
  )}\n\n<updated data>:\n${formatPlayerData(updatedFieldsObj)}`;
}

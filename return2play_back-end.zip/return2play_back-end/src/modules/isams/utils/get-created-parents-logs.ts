import { UserEntity } from '../../users/entities/user.entity';
import uniqBy from 'lodash/uniqBy';
import { getCreatedParentLog } from './get-created-parent-log';

export function getCreatedParentsLogs(parents: Partial<UserEntity>[]): string[] {
  const uniqueParents = uniqBy(parents, 'id');
  const arr: string[] = [];
  const n = uniqueParents.length;
  for (let i = 0; i < n; i++) {
    arr.push(getCreatedParentLog(uniqueParents[i]));
  }
  return arr;
}

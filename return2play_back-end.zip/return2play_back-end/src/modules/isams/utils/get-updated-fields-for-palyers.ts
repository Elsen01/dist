import isSameDay from 'date-fns/isSameDay';
import { UserEntity } from '../../users/entities/user.entity';

export function getUpdatedFieldsForPlayers(player1: UserEntity, player2: UserEntity): string[] {
  const arr: string[] = [];

  if (player1.firstName !== player2.firstName) {
    arr.push('firstName');
  }

  if (player1.lastName !== player2.lastName) {
    arr.push('lastName');
  }

  if (player1.email !== player2.email) {
    arr.push('email');
  }

  if (player1.gender !== player2.gender) {
    arr.push('gender');
  }

  if (
    (!player1.birthday && player2.birthday) ||
    (player1.birthday && !player2.birthday) ||
    (player1.birthday && player2.birthday && !isSameDay(new Date(player1.birthday), new Date(player2.birthday)))
  ) {
    arr.push('birthday');
  }

  if (player1.player?.yearGroup !== player2.player?.yearGroup) {
    arr.push('player.yearGroup');
  }

  if (player1.player?.socsId !== player2.player?.socsId) {
    arr.push('player.socsId');
  }

  return arr;
}

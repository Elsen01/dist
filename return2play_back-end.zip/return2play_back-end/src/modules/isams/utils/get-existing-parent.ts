import { IsamsParent } from './get-isams-parents';
import { UserEntity } from '../../users/entities/user.entity';

export function getExistingParent(
  isamsParent: IsamsParent,
  existingParents: ReadonlyArray<UserEntity>
): UserEntity | null {
  const n = existingParents.length;
  if (!n) {
    return null;
  }

  for (let i = 0; i < n; i++) {
    const existingParent = existingParents[i];
    if (
      isamsParent.firstName === existingParent.firstName &&
      isamsParent.lastName === existingParent.lastName &&
      (isamsParent.email === existingParent.email || !isamsParent.email || !existingParent.email)
    ) {
      return existingParent;
    }
  }

  for (let i = 0; i < n; i++) {
    const existingParent = existingParents[i];
    if (isamsParent.email && existingParent.email && isamsParent.email === existingParent.email) {
      return existingParent;
    }
  }

  return null;
}

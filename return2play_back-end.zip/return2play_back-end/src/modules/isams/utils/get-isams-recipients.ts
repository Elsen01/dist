import uniqWith from 'lodash/uniqWith';
import isEqual from 'lodash/isEqual';
import { IsamsData } from '../interfaces/isams-data.interface';
import { IsamsPlayer } from './get-isams-players';

export interface IsamsRecipient {
  firstName: string;
  lastName: string;
  email: string;
}

export function getIsamsRecipients(
  isamsPlayer: IsamsPlayer,
  { SchoolManager, HRManager }: IsamsData['iSAMS']
): IsamsRecipient[] {
  const arr: IsamsRecipient[] = [];

  const n = SchoolManager.Forms?.Form?.length || 0;
  for (let i = 0; i < n; i++) {
    const form = SchoolManager.Forms.Form[i];

    if (!isamsPlayer.form || isamsPlayer.form !== form['@_Id']) {
      continue;
    }

    const m = HRManager.CurrentStaff?.StaffMember?.length || 0;
    for (let j = 0; j < m; j++) {
      const staffMember = HRManager.CurrentStaff.StaffMember[j];
      if (staffMember.SchoolEmailAddress && staffMember['@_Id'] === form['@_TutorId']) {
        arr.push({
          firstName: staffMember.Forename,
          lastName: staffMember.Surname,
          email: staffMember.SchoolEmailAddress,
        });
      }
    }
  }

  const m = SchoolManager.Years?.Year?.length || 0;
  for (let i = 0; i < m; i++) {
    const year = SchoolManager.Years.Year[i];

    if (!isamsPlayer.year || isamsPlayer.year !== year['@_Id']) {
      continue;
    }

    const k = HRManager.CurrentStaff?.StaffMember?.length || 0;
    for (let j = 0; j < k; j++) {
      const staffMember = HRManager.CurrentStaff.StaffMember[j];
      if (staffMember.SchoolEmailAddress && staffMember['@_Id'] === year['@_TutorId']) {
        arr.push({
          firstName: staffMember.Forename,
          lastName: staffMember.Surname,
          email: staffMember.SchoolEmailAddress,
        });
      }
    }
  }

  return uniqWith(arr, isEqual);
}

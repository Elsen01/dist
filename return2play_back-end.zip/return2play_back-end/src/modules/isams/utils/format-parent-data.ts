import { UserEntity } from '../../users/entities/user.entity';

export function formatParentData(parent: Partial<UserEntity>): string {
  const arr: string[] = [];

  if (parent.id) {
    arr.push(`  [id]: ${parent.id}`);
  }

  if (parent.firstName) {
    arr.push(`  [firstName]: ${parent.firstName}`);
  }

  if (parent.lastName) {
    arr.push(`  [lastName]: ${parent.lastName}`);
  }

  if (parent.email) {
    arr.push(`  [email]: ${parent.email}`);
  }

  if (parent.role) {
    arr.push(`  [role]: ${parent.role}`);
  }

  return arr.join(',\n');
}

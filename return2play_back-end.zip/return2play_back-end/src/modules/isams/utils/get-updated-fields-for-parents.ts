import { UserEntity } from '../../users/entities/user.entity';

export function getUpdatedFieldsForParents(parent1: Partial<UserEntity>, parent2: Partial<UserEntity>): string[] {
  const arr: string[] = [];

  if (parent1.firstName !== parent2.firstName) {
    arr.push('firstName');
  }

  if (parent1.lastName !== parent2.lastName) {
    arr.push('lastName');
  }

  if (parent1.email !== parent2.email) {
    arr.push('email');
  }

  if (parent1.role !== parent2.role) {
    arr.push('role');
  }

  return arr;
}

import { IsamsParent } from './get-isams-parents';
import { UserEntity } from '../../users/entities/user.entity';

export function getExistingUserByParent(
  isamsParent: IsamsParent,
  existingUsers: ReadonlyArray<UserEntity>,
  organizationId: string
): UserEntity | null {
  if (!existingUsers.length) {
    return null;
  }

  const existingUser = getExistingUserFromOrganization(
    isamsParent,
    existingUsers.filter(({ organizations }) =>
      organizations.some((organization) => organization.id === organizationId)
    )
  );

  if (existingUser) {
    return existingUser;
  }

  return getExistingUserFromAllOlrganizations(isamsParent, existingUsers);
}

function getExistingUserFromOrganization(
  isamsParent: IsamsParent,
  existingUsers: ReadonlyArray<UserEntity>
): UserEntity | null {
  if (!existingUsers.length) {
    return null;
  }

  const existingUser = findByFNLNEMAIL(isamsParent, existingUsers);

  if (existingUser) {
    return existingUser;
  }

  return findByEmail(isamsParent, existingUsers);
}

function getExistingUserFromAllOlrganizations(
  isamsParent: IsamsParent,
  existingUsers: ReadonlyArray<UserEntity>
): UserEntity | null {
  if (!existingUsers.length) {
    return null;
  }

  const existingUser = findByFNLNEMAIL(isamsParent, existingUsers);

  if (existingUser) {
    return existingUser;
  }

  return findByEmail(isamsParent, existingUsers);
}

function findByFNLNEMAIL(isamsParent: IsamsParent, existingUsers: ReadonlyArray<UserEntity>): UserEntity | null {
  const n = existingUsers.length;

  for (let i = 0; i < n; i++) {
    const user = existingUsers[i];

    if (
      isamsParent.firstName === user.firstName &&
      isamsParent.lastName === user.lastName &&
      isamsParent.email?.toLowerCase() === user.email?.toLowerCase()
    ) {
      return user;
    }
  }

  return null;
}

function findByEmail(isamsParent: IsamsParent, existingUsers: ReadonlyArray<UserEntity>): UserEntity | null {
  const n = existingUsers.length;

  for (let i = 0; i < n; i++) {
    const user = existingUsers[i];

    if (isamsParent.email?.toLowerCase() === user.email?.toLowerCase()) {
      return user;
    }
  }

  return null;
}

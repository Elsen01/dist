import { UserEntity } from '../../users/entities/user.entity';
import { formatPlayerData } from './format-player-data';

export function getCreatedPlayerLog(player: UserEntity): string {
  return `[CREATED] player:\n${formatPlayerData(player)}`;
}

import { UserEntity } from '../../users/entities/user.entity';
import { formatParentData } from './format-parent-data';
import get from 'lodash/get';
import set from 'lodash/set';

export function getUpdatedParentLog(
  old: Partial<UserEntity>,
  updated: Partial<UserEntity>,
  updatedFields: string[]
): string {
  const updatedFieldsObj = {};
  const n = updatedFields.length;
  for (let i = 0; i < n; i++) {
    set(updatedFieldsObj, updatedFields[i], get(updated, updatedFields[i]));
  }

  return `[UPDATED] parent:\n\n<from>:\n${formatParentData(old)}\n\n<to>:\n${formatParentData(
    updated
  )}\n\n<updated data>:\n${formatParentData(updatedFieldsObj)}`;
}

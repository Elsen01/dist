import { AxiosError } from 'axios';
import { isAxiosError } from '../../shared/utils/is-axios-error';

export function getErrorDetails(err: Error): string {
  return isAxiosError(err)
    ? JSON.stringify({
        request: {
          ...(err as AxiosError).config,
          data: (err as AxiosError).config.data,
        },
        response: {
          data: (err as AxiosError).response.data,
          status: (err as AxiosError).response.status,
          statusText: (err as AxiosError).response.statusText,
        },
      })
    : JSON.stringify(err, Object.getOwnPropertyNames(err));
}

import { UserEntity } from '../../users/entities/user.entity';
import { formatParentData } from './format-parent-data';
import { formatPlayerData } from './format-player-data';

export function getNewParentsForPlayerLog(old: Pick<UserEntity, 'player'>, updated: UserEntity): string[] {
  if (!updated.player?.parents?.length) {
    return [];
  }
  const newParents: Partial<UserEntity>[] = [];
  const n = updated.player.parents.length;
  for (let i = 0; i < n; i++) {
    const parent = updated.player.parents[i];
    if (!old.player?.parents?.length) {
      newParents.push(parent);
      continue;
    }

    if (!old.player.parents.some((oldParent) => oldParent.id === parent.id)) {
      newParents.push(parent);
    }
  }

  return newParents.map(
    (parent) =>
      `[NEW PARENT FOR PLAYER]:\n\n<player>:\n${formatPlayerData(updated)}\n\n<parent>:\n${formatParentData(parent)}`
  );
}

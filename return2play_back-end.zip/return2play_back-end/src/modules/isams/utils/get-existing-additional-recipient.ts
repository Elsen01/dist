import { IsamsRecipient } from './get-isams-recipients';
import { AdditionalRecipientEntity } from '../../additional-recipients/entities/recipient.entity';

export function getExistingAdditionalRecipient(
  isamsRecipient: IsamsRecipient,
  existingRecipients: ReadonlyArray<AdditionalRecipientEntity>
): AdditionalRecipientEntity | null {
  const n = existingRecipients.length;
  if (!n) {
    return null;
  }

  for (let i = 0; i < n; i++) {
    const existingRecipient = existingRecipients[i];
    if (
      isamsRecipient.firstName === existingRecipient.firstName &&
      isamsRecipient.lastName === existingRecipient.lastName &&
      isamsRecipient.email === existingRecipient.email
    ) {
      return existingRecipient;
    }
  }

  return null;
}

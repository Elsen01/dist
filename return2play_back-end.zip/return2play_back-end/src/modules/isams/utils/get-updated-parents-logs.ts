import { UserEntity } from '../../users/entities/user.entity';
import uniqBy from 'lodash/uniqBy';
import { getUpdatedParentLog } from './get-updated-parent-log';
import { getUpdatedFieldsForParents } from './get-updated-fields-for-parents';

export function getUpdatedParentsLogs(parents: { old: Partial<UserEntity>; updated: Partial<UserEntity> }[]): string[] {
  const uniqueParents = uniqBy(parents, 'old.id');
  const arr: string[] = [];
  const n = uniqueParents.length;
  for (let i = 0; i < n; i++) {
    const updatedFields = getUpdatedFieldsForParents(uniqueParents[i].old, uniqueParents[i].updated);

    if (updatedFields.length) {
      arr.push(getUpdatedParentLog(uniqueParents[i].old, uniqueParents[i].updated, updatedFields));
    }
  }
  return arr;
}

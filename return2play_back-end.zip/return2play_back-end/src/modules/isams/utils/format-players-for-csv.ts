import maxBy from 'lodash/maxBy';
import { UserEntity } from '../../users/entities/user.entity';

export function formatPlayersForCSV(arr: UserEntity[]): Record<string, any>[] {
  const transformedArray = [];

  const n = arr.length;
  const maxParents = maxBy(arr, ({ player }) => player?.parents?.length || 0).player?.parents?.length || 0;
  const maxAdditionalRecepients =
    maxBy(arr, ({ player }) => player?.additionalRecepients?.length || 0).player?.additionalRecepients?.length || 0;

  for (let i = 0; i < n; i++) {
    const item = arr[i];
    const transformedItem: Record<string, any> = {
      id: item.id,
      firstName: item.firstName,
      lastName: item.lastName,
      email: item.email || '<empty email>',
      gender: item.gender,
      role: item.role,
      birthday: item.birthday,
      status: item.status,
    };

    if (item.player) {
      transformedItem.membership = item.player.membership;
      transformedItem.yearGroup = item.player.yearGroup;
      transformedItem.playStatus = item.player.playStatus;
      transformedItem.socsId = item.player.socsId;

      for (let j = 0; j < maxParents; j++) {
        const key = `parent${j + 1}`;

        const parent = item.player.parents[j];

        if (parent) {
          transformedItem[key] = `${parent.firstName} ${parent.lastName} ${parent.email || '<empty email>'} (${
            parent.id
          })`;
        } else {
          transformedItem[key] = '';
        }
      }

      for (let k = 0; k < maxAdditionalRecepients; k++) {
        const key = `additionalRecepient${k + 1}`;

        const recipient = item.player.additionalRecepients[k];

        if (recipient) {
          transformedItem[key] = ` ${recipient.firstName} ${recipient.lastName} ${
            recipient.email || '<empty email>'
          } (${recipient.id})`;
        } else {
          transformedItem[key] = '';
        }
      }
    }

    transformedArray.push(transformedItem);
  }

  return transformedArray;
}

import { IsamsData } from '../interfaces/isams-data.interface';
import { IsamsPlayer } from './get-isams-players';
import uniqWith from 'lodash/uniqWith';
import isEqual from 'lodash/isEqual';

export interface IsamsParent {
  firstName: string;
  lastName: string;
  email?: string;
}

export function getIsamsParents(
  isamsPlayer: IsamsPlayer,
  { PupilManager, SchoolManager, HRManager }: IsamsData['iSAMS']
): IsamsParent[] {
  const arr: IsamsParent[] = [];

  const n = PupilManager.Contacts?.Contact?.length || 0;
  for (let i = 0; i < n; i++) {
    const contact = PupilManager.Contacts.Contact[i];

    if (contact.CorrespondenceMailMerge === 0 && contact.MailMergeAll === 0) {
      console.log('PARENT DONT CREATED', i);
      continue;
    }
    const pupils = Array.isArray(contact.Pupils.Pupil) ? contact.Pupils.Pupil : [contact.Pupils.Pupil];
    if (pupils.some((pupil) => pupil?.['@_Id'] === isamsPlayer.id)) {
      arr.push({
        email: contact.EmailAddress,
        firstName: contact.Forename,
        lastName: contact.Surname,
      });
    }
  }

  const m = SchoolManager.BoardingHouses?.House?.length || 0;
  for (let i = 0; i < m; i++) {
    const house = SchoolManager.BoardingHouses.House[i];
    if (isamsPlayer.boardingHouseId !== house['@_Id']) {
      continue;
    }

    const k = HRManager.CurrentStaff?.StaffMember?.length || 0;
    for (let j = 0; j < k; j++) {
      const staffMember = HRManager.CurrentStaff?.StaffMember[j];
      if (
        staffMember.SchoolEmailAddress &&
        (house['@_HouseMasterId'] === staffMember['@_Id'] || house['@_AssistantHouseMasterId'] === staffMember['@_Id'])
      ) {
        arr.push({
          firstName: staffMember.Forename,
          lastName: staffMember.Surname,
          email: staffMember.SchoolEmailAddress,
        });
      }
    }
  }

  return uniqWith(arr, isEqual);
}

import format from 'date-fns/format';
import { UserEntity } from '../../users/entities/user.entity';

export function formatPlayerData(player: Partial<UserEntity>): string {
  const arr: string[] = [];

  if (player.id) {
    arr.push(`  [id]: ${player.id}`);
  }

  if (player.firstName) {
    arr.push(`  [firstName]: ${player.firstName}`);
  }

  if (player.lastName) {
    arr.push(`  [lastName]: ${player.lastName}`);
  }

  if (player.email) {
    arr.push(`  [email]: ${player.email}`);
  }

  if (player.gender) {
    arr.push(`  [gender]: ${player.gender}`);
  }

  if (player.birthday) {
    arr.push(`  [birthday]: ${format(new Date(player.birthday), 'dd/MM/yyyy')}`);
  }

  if (player.player?.yearGroup) {
    arr.push(`  [yearGroup]: ${player.player?.yearGroup}`);
  }

  if (player.player?.socsId) {
    arr.push(`  [socsId]: ${player.player?.socsId}`);
  }

  return arr.join(',\n');
}

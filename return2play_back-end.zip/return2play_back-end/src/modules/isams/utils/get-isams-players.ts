import { Gender } from '../../users/types';
import { IsamsPupil } from '../interfaces/isams-pupil.interface';
import uniqWith from 'lodash/uniqWith';
import isEqual from 'lodash/isEqual';

export interface IsamsPlayer {
  id: string;
  firstName: string;
  lastName: string;
  email?: string;
  gender?: Gender;
  birthday?: Date;
  boardingHouseId?: string;
  form?: string;
  year?: string;
  socId: string;
}
export function getIsamsPlayers(pupils: IsamsPupil[]): IsamsPlayer[] {
  const arr: IsamsPlayer[] = [];

  const n = pupils.length;
  for (let i = 0; i < n; i++) {
    const pupil = pupils[i];
    if (!arr.some(({ id }) => pupil['@_Id'] === id)) {
      arr.push({
        id: pupil['@_Id'],
        firstName: pupil.Forename,
        lastName: pupil.Surname,
        email: pupil.EmailAddress,
        gender: pupil.Gender && (pupil.Gender === 'F' ? Gender.Female : Gender.Male),
        birthday: pupil.DOB && new Date(pupil.DOB),
        boardingHouseId: pupil['@_BoardingHouseId'],
        form: pupil.Form,
        year: pupil?.NCYear && '' + pupil.NCYear,
        socId: '' + pupil.SchoolId,
      });
    }
  }

  return uniqWith(arr, isEqual);
}

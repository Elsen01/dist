import { InjectQueue } from '@nestjs/bull';
import { Inject, Injectable, Logger, LoggerService, UnprocessableEntityException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Queue } from 'bull';
import { DeepPartial, FindOneOptions, ILike, IsNull, Not, Repository } from 'typeorm';
import { XMLParser } from 'fast-xml-parser';
import bluebird from 'bluebird';
import axios, { AxiosInstance } from 'axios';
import { write } from 'fast-csv';

import {
  IsamsConfigService,
  ISAMS_COMMAND_SYNC,
  ISAMS_QUEUE_NAME,
} from '../../config/isams-config/isams-config.service';
import { OrganizationsService } from '../organizations/organizations.service';
import { getErrorDetails } from './utils/get-error-details';
import { IsamsSyncLogEntity, ISAMS_SYNC_LOG_LEVELS } from './entities/isams-sync-logs.entity';
import { IsamsSyncEntity, ISAMS_SYNC_RESULTS } from './entities/isams-sync.entity';
import { IsamsSyncData } from './interfaces/isams-sync-data.interface';
import { IsamsData } from './interfaces/isams-data.interface';
import { getIsamsPlayers, IsamsPlayer } from './utils/get-isams-players';
import { getIsamsParents, IsamsParent } from './utils/get-isams-parents';
import { getIsamsRecipients, IsamsRecipient } from './utils/get-isams-recipients';
import { UsersService } from '../users/users.service';
import { getExistingUser } from './utils/get-existing-user';
import { UserRole } from '../users/types';
import { UserEntity } from '../users/entities/user.entity';
import { calculateYearGroup } from '../shared/utils/common.utils';
import uniqBy from 'lodash/uniqBy';
import { AdditionalRecipientEntity } from '../additional-recipients/entities/recipient.entity';
import { getExistingAdditionalRecipient } from './utils/get-existing-additional-recipient';
import { v4 as uuid } from 'uuid';
import { getExistingParent } from './utils/get-existing-parent';
import { Membership } from '../players/types';
import { getExistingUserByParent } from './utils/get-existing-user-by-parent';
import { ISamsSyncFiltersQuery } from './dtos/find-sync.dto';
import { FindManyResponse } from '../shared/types';
import { ISamsSyncsSortOptions } from './types';
import { S3BucketManager } from '../shared/helpers/s3bucket/s3bucket.manager';
import { ISamsSyncLogFiltersQuery } from './dtos/find-sync-log.dto';
import { getUpdatedFieldsForPlayers } from './utils/get-updated-fields-for-palyers';
import { getUpdatedPlayerLog } from './utils/get-updated-player-log';
import { getCreatedPlayerLog } from './utils/get-created-player-log';
import { getCreatedParentsLogs } from './utils/get-created-parents-logs';
import { getNewParentsForPlayerLog } from './utils/get-new-parents-for-player-logs';
import { formatPlayersForCSV } from './utils/format-players-for-csv';
import { FileFormat } from '../shared/helpers/s3bucket/types';
import { createGzip } from 'zlib';
import axiosRetry from 'axios-retry';

@Injectable()
export class IsamsService {
  private readonly api: AxiosInstance;

  constructor(
    @InjectRepository(IsamsSyncEntity)
    private readonly syncsRepository: Repository<IsamsSyncEntity>,
    @InjectRepository(IsamsSyncLogEntity)
    private readonly logsRepository: Repository<IsamsSyncLogEntity>,
    @Inject(Logger)
    private readonly logger: LoggerService,
    private readonly organizationsService: OrganizationsService,
    @InjectQueue(ISAMS_QUEUE_NAME) private readonly queue: Queue,
    private readonly usersService: UsersService,
    private readonly configService: IsamsConfigService,
    private s3manager: S3BucketManager
  ) {
    this.api = axios.create();
    axiosRetry(this.api, configService.retryConfig);
  }

  async syncAllOrganizations(): Promise<void> {
    const organizations = await this.organizationsService.find({
      where: { iSAMSKey: Not(IsNull()), iSAMSUrl: Not(IsNull()) },
    });
    const n = organizations.length;
    for (let i = 0; i < n; i++) {
      const { id, iSAMSUrl, iSAMSKey } = organizations[i];
      try {
        await this.sendSyncMessageToQueue(id, iSAMSUrl, iSAMSKey);
      } catch (err) {
        this.logger.error(`Error during sending sync message to iSAMS sync. Error: ${err.message}`);
      }
    }
  }

  async syncOrganization({ organizationId, iSAMSKey, iSAMSUrl }: IsamsSyncData): Promise<void> {
    const filters = `<?xml version="1.0" encoding="utf-8" ?>
            <Filters>
                <MethodsToRun>
                    <Method>ContactAdvanced_GetContacts</Method>
                    <Method>Pupil_GetCurrentPupils</Method>
                    <Method>School_GetBoardingHouses</Method>
                    <Method>HumanResources_GetCurrentStaff</Method>
                    <Method>School_GetSchoolForms</Method>
                    <Method>School_GetAllYears</Method>
                </MethodsToRun>
                <PupilManager>
                    <Contacts ContactOnly="false" />
                    <ParentResponsibilities Responsibility="yes" />
                </PupilManager>
            </Filters>`;

    const url = `${this.getBatchApiURL(iSAMSUrl)}/xml.ashx?apiKey=${iSAMSKey}`;

    // START SYNC
    const sync = await this.syncsRepository.save({
      organizationId,
      startedAt: new Date(),
      filters,
    });

    await this.addSyncLog(sync.id, 'Sync is started', 'initial log');

    await this.addSyncLog(sync.id, `START getting data from iSAMS, url - ${url} `);

    // GET DATA
    let xmlData;
    try {
      xmlData = await this.getDataFromISAMS(url, filters);
      await this.syncsRepository.save({
        id: sync.id,
        receivedAt: new Date(),
      });
      await this.addSyncLog(sync.id, 'END getting data from iSAMS');
    } catch (err) {
      this.logger.error(
        `Error during getting data to sync organization '${organizationId}' from iSAMS. Error: ${err.message}`
      );
      await this.syncsRepository.save({
        id: sync.id,
        finishedAt: new Date(),
        result: ISAMS_SYNC_RESULTS.FAILED,
      });
      await this.addSyncError(sync.id, `Can't GET data from iSAMS`, err);

      return;
    }

    try {
      await this.addSyncLog(sync.id, 'START uploading XML file with data from iSAMS to AWS S3');

      const key = `ISAMS/${organizationId}-${sync.id}-${uuid()}-${uuid()}-${uuid()}-${new Date().getTime()}.xml`;
      // await this.s3manager.putObjectToS3(key, xmlData);
      const iSAMSDataUrl = await this.s3manager.upload(
        key,
        'application/xml',
        { buffer: Buffer.from(xmlData, 'utf-8') },
        'public-read'
      );

      await this.addSyncLog(sync.id, 'END uploading XML file with data from iSAMS to AWS S3');

      await this.syncsRepository.save({
        id: sync.id,
        iSAMSDataUrl,
      });
    } catch (err) {
      this.logger.error(`Error during uploading xml data from iSAMS to S3 bucket. Error: ${err.message}`);
    }

    // PARSE iSAMS XML DATA
    let data: IsamsData;
    try {
      await this.addSyncLog(sync.id, 'START parsing XML file from iSAMS');

      data = this.parseXMLData(xmlData);
      await this.addSyncLog(sync.id, 'END parsing XML file from iSAMS');
    } catch (err) {
      this.logger.error(
        `Error during parsing XML data to sync organization '${organizationId}' from iSAMS. Error: ${err.message}`
      );
      await this.syncsRepository.save({
        id: sync.id,
        finishedAt: new Date(),
        result: ISAMS_SYNC_RESULTS.FAILED,
      });
      await this.addSyncError(sync.id, `Can't PARSE XML data from iSAMS`, err);

      return;
    }

    // Check data
    if (!data.iSAMS?.PupilManager?.CurrentPupils?.Pupil) {
      await this.syncsRepository.save({
        id: sync.id,
        finishedAt: new Date(),
        result: ISAMS_SYNC_RESULTS.FAILED,
      });
      await this.addSyncError(sync.id, `Missed field 'PupilManager.CurrentPupils.Pupil' in iSAMS response data`);

      return;
    }

    const iSAMSPlayers = getIsamsPlayers(data.iSAMS.PupilManager.CurrentPupils.Pupil);
    this.logger.log(`syncOrganization --api iSAMSPlayers: ${JSON.stringify(iSAMSPlayers)}`);

    await this.addSyncLog(sync.id, `There are ${iSAMSPlayers.length} players from iSAMS`);

    try {
      const usersBeforeSync = await this.usersService.findPlayersForOrganization(organizationId);
      this.logger.log(`syncOrganization --api usersBeforeSync: ${JSON.stringify(usersBeforeSync)}`);
      const url = await this.uploadCsvReport(organizationId, sync.id, formatPlayersForCSV(usersBeforeSync), 'before');

      await this.addSyncLog(sync.id, `[CSV BEFORE SYNC] data before sync - ${url}`);
    } catch (err) {
      this.logger.error(`Error during uploading csv file with players before sync. Error: ${err.message}`);
    }

    await this.addSyncLog(sync.id, 'START sync players');
    this.logger.log(`syncOrganization --api sync.id,: ${JSON.stringify(sync.id)}`);
    this.logger.log(`syncOrganization --api organizationId: ${JSON.stringify(organizationId)}`);

    const results = await bluebird.Promise.map(
      iSAMSPlayers,
      async (iSAMSPlayer) => {
        try {
          const { success, errorMessage, error } = await this.syncPlayer(
            sync.id,
            iSAMSPlayer,
            data.iSAMS,
            organizationId
          );
          if (!success) {
            await this.addSyncError(sync.id, errorMessage, error);
            return 1;
          }
        } catch (err) {
          this.logger.error(`Error during sync iSAMS player. Error: ${err.message}`);
        }
        return 0;
      },
      { concurrency: 25 }
    );

    await this.addSyncLog(sync.id, 'END sync players');

    let failedPlayersCount = 0;
    const n = results.length;
    for (let i = 0; i < n; i++) {
      if (results[i]) {
        failedPlayersCount += 1;
      }
    }

    try {
      const usersAfterSync = await this.usersService.findPlayersForOrganization(organizationId);
      const url = await this.uploadCsvReport(organizationId, sync.id, formatPlayersForCSV(usersAfterSync), 'after');

      await this.addSyncLog(sync.id, `[CSV AFTER SYNC] data after sync - ${url}`);
    } catch (err) {
      this.logger.error(`Error during uploading csv file with players after sync. Error: ${err.message}`);
    }

    // FINISH SYNC
    await this.syncsRepository.save({
      id: sync.id,
      finishedAt: new Date(),
      result:
        failedPlayersCount === n
          ? ISAMS_SYNC_RESULTS.FAILED
          : failedPlayersCount > 0
          ? ISAMS_SYNC_RESULTS.PARTLY_SUCCESS
          : ISAMS_SYNC_RESULTS.SUCCESS,
    });
  }

  private async syncPlayer(
    syncId: IsamsSyncEntity['id'],
    isamsPlayer: IsamsPlayer,
    data: IsamsData['iSAMS'],
    organizationId: string
  ): Promise<{ success: boolean; errorMessage?: string; error?: Error }> {
    // Find parents from iSAMS data

    const isamsParents = getIsamsParents(isamsPlayer, data);

    // console.log('$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$');
    // console.log({ isamsParents });
    // console.log('$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$');

    // Find additional recipients from iSAMS data
    const isamsRecipients = getIsamsRecipients(isamsPlayer, data);

    let existingUser: UserEntity;
    try {
      const where: FindOneOptions<UserEntity>['where'] = [];

      if (isamsPlayer.email) {
        where.push({
          email: ILike(isamsPlayer.email),
          role: UserRole.Player,
        });
      }

      if (isamsPlayer.firstName) {
        where.push({
          firstName: isamsPlayer.firstName,
          role: UserRole.Player,
        });
      }

      if (isamsPlayer.lastName) {
        where.push({
          lastName: isamsPlayer.lastName,
          role: UserRole.Player,
        });
      }

      // Find existing player in DB
      const existingUsers = await this.usersService.findPlayerByEmailOrFnOrLn(isamsPlayer);

      existingUser = getExistingUser(isamsPlayer, existingUsers, organizationId);
    } catch (err) {
      const errorMessage = `Error during search existing user for iSAMS user: ${isamsPlayer.firstName} ${isamsPlayer.lastName} <${isamsPlayer.email}> (${isamsPlayer.id})`;
      this.logger.error(`${errorMessage}. Error: ${err.message}`);
      return { success: false, errorMessage, error: err };
    }
    this.logger.log(`syncPlayer1 --api syncId: ${JSON.stringify(syncId)}`);
    this.logger.log(`syncPlayer1 --api existingUser: ${JSON.stringify(existingUser)}`);
    this.logger.log(`syncPlayer1 --api isamsPlayer: ${JSON.stringify(isamsPlayer)}`);
    this.logger.log(`syncPlayer1 --api isamsParents: ${JSON.stringify(isamsParents)}`);
    this.logger.log(`syncPlayer1 --api isamsRecipients: ${JSON.stringify(isamsRecipients)}`);
    this.logger.log(`syncPlayer1 --api organizationId: ${JSON.stringify({ organizationId })}`);

    if (existingUser) {
      try {
        // Update existing user

        await this.updateUserPlayerByIsamsData(
          syncId,
          existingUser,
          isamsPlayer,
          isamsParents,
          isamsRecipients,
          organizationId
        );
      } catch (err) {
        const errorMessage = `Error during updating existing user for iSAMS user: ${isamsPlayer.firstName} ${isamsPlayer.lastName} <${isamsPlayer.email}> (${isamsPlayer.id}). R2P user id - ${existingUser.id}`;
        this.logger.error(`${errorMessage}. Error: ${err.message}`);
        return { success: false, errorMessage, error: err };
      }
    } else {
      try {
        console.log('CREATEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE');

        // Create new user
        await this.createUserPlayerByIsamsData(syncId, isamsPlayer, isamsParents, isamsRecipients, organizationId);
        return { success: true };
      } catch (err) {
        const errorMessage = `Error during creating new user for iSAMS user: ${isamsPlayer.firstName} ${isamsPlayer.lastName} <${isamsPlayer.email}> (${isamsPlayer.id})`;
        this.logger.error(`${errorMessage}. Error: ${err.message}`);
        return { success: false, errorMessage, error: err };
      }
    }

    return { success: true };
  }

  addSyncLog(syncId: IsamsSyncEntity['id'], message?: string, description?: string): Promise<IsamsSyncLogEntity> {
    return this.logsRepository.save({
      syncId,
      message,
      description,
      level: ISAMS_SYNC_LOG_LEVELS.INFO,
    });
  }

  addSyncWarning(syncId: IsamsSyncEntity['id'], message?: string, description?: string): Promise<IsamsSyncLogEntity> {
    return this.logsRepository.save({
      syncId,
      message,
      description,
      level: ISAMS_SYNC_LOG_LEVELS.WARNING,
    } as IsamsSyncLogEntity);
  }

  addSyncError(syncId: IsamsSyncEntity['id'], message?: string, err?: Error): Promise<IsamsSyncLogEntity> {
    if (!err) {
      return this.logsRepository.save({
        syncId,
        message,
        level: ISAMS_SYNC_LOG_LEVELS.ERROR,
      });
    }

    let description: string;
    const xmlParser = new XMLParser();
    try {
      const isamsError = (err as unknown) as { response?: { data: string } };
      if (isamsError.response?.data) {
        const response = xmlParser.parse(isamsError.response.data);
        description = '';
        if (response.Message?.Title) {
          description += `${response.Message.Title}.`;
        }

        if (response.Message?.Description) {
          description += (description ? ' ' : '') + `${response.Message.Description}`;
        }

        if (!description) {
          description = JSON.stringify(isamsError.response.data);
        }
      } else if (err.message) {
        description = err.message;
      }
    } catch (err) {
      this.logger.warn(`Error during parsing error for description`);
    }
    return this.logsRepository.save({
      syncId,
      message,
      description,
      errorDetails: getErrorDetails(err),
      level: ISAMS_SYNC_LOG_LEVELS.ERROR,
    });
  }

  async findMany({
    limit,
    page,
    sort,
    order,
    result,
    searchWord,
  }: ISamsSyncFiltersQuery): Promise<FindManyResponse<IsamsSyncEntity>> {
    const [data, totalItems] = await this.syncsRepository
      .createQueryBuilder('sync')
      .addSelect('sync.startedAt, sync.receivedAt, sync.result, sync.filters, sync.iSAMSDataUrl')
      .where(result ? 'sync.result = :result' : 'true', { result })
      .leftJoinAndSelect('sync.organization', 'org')
      .andWhere(searchWord ? '(org.name ILIKE :name OR org.id::text ILIKE :name)' : 'true', {
        name: `%${searchWord}%`,
      })
      .orderBy(sort === ISamsSyncsSortOptions.Organization ? `org.name` : `sync.${sort}`, order)
      .take(limit)
      .skip(limit * page)
      .getManyAndCount()
      .catch((err) => {
        throw new UnprocessableEntityException(err.message);
      });

    return { data, totalItems };
  }

  findOne(where: FindOneOptions<IsamsSyncEntity>['where']): Promise<IsamsSyncEntity> {
    return this.syncsRepository.findOne({ relations: ['organization'], where });
  }

  async findManyLogs(
    syncId: IsamsSyncEntity['id'],
    { limit, page, sort, order, level, searchWord }: ISamsSyncLogFiltersQuery
  ): Promise<FindManyResponse<IsamsSyncLogEntity>> {
    const [data, totalItems] = await this.logsRepository
      .createQueryBuilder('log')
      .addSelect('log.id, log.createdAt, log.message, log.description, log.errorDetails, log.level')
      .where('log.syncId = :syncId', { syncId })
      .andWhere(level ? 'log.level = :level' : 'true', { level })
      .andWhere(
        searchWord
          ? '(log.id::text ILIKE :searchWord OR log.message ILIKE :searchWord OR log.description ILIKE :searchWord OR log.errorDetails ILIKE :searchWord)'
          : 'true',
        {
          searchWord: `%${searchWord}%`,
        }
      )
      .orderBy(`log.${sort}`, order)
      .take(limit)
      .skip(limit * page)
      .getManyAndCount()
      .catch((err) => {
        throw new UnprocessableEntityException(err.message);
      });

    return { data, totalItems };
  }

  private async updateUserPlayerByIsamsData(
    syncId: IsamsSyncEntity['id'],
    user: UserEntity,
    isamsData: IsamsPlayer,
    isamsParents: IsamsParent[],
    isamsRecipients: IsamsRecipient[],
    organizationId: string
  ): Promise<UserEntity> {
    const birthday = isamsData.birthday ? new Date(isamsData.birthday) : user.birthday;
    console.log('UPDATEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE');

    const data: DeepPartial<UserEntity> = {
      id: user.id,
      firstName: isamsData.firstName || user.firstName,
      lastName: isamsData.lastName || user.lastName,
      email: isamsData.email || user.email,
      gender: isamsData.gender || user.gender,
      birthday: birthday,
      organizations: uniqBy([...user.organizations.map(({ id }) => ({ id })), { id: organizationId }], 'id'),
    };
    const isNotField2 = await this.usersService.isNotField(user.id);
    console.log('ISNOTFIELD222222222222222222222222222222:', isNotField2);

    const createdParents: Partial<UserEntity>[] = [];

    if (user.player) {
      const additionalRecepients: DeepPartial<AdditionalRecipientEntity>[] = user.player.additionalRecepients.map(
        ({ id }) => ({ id })
      );
      const n = isamsRecipients.length;
      for (let i = 0; i < n; i++) {
        const isamsRecipient = isamsRecipients[i];
        const existingRecipient = getExistingAdditionalRecipient(isamsRecipient, user.player.additionalRecepients);
        if (!existingRecipient) {
          additionalRecepients.push({
            id: uuid(),
            ...isamsRecipient,
          });
        }
      }

      const parents: DeepPartial<UserEntity>[] = [];

      const m = isamsParents.length;
      for (let i = 0; i < m; i++) {
        const isamsParent = isamsParents[i];
        const existingParent = getExistingParent(isamsParent, user.player.parents);
        if (!existingParent && isamsParent.email) {
          const existingUsersByParents = await this.usersService.find({
            select: ['id', 'firstName', 'lastName', 'email'],
            where: {
              email: ILike(isamsParent.email),
              role: Not(UserRole.Player),
            },
            relations: ['organizations'],
          });

          const existingUserByParent = getExistingUserByParent(isamsParent, existingUsersByParents, organizationId);
          const parentId = existingUserByParent?.id || uuid();

          if (!parents.some(({ id }) => id === parentId)) {
            const parentUser = {
              ...existingUserByParent,
              id: parentId,
              role: existingUserByParent?.role || UserRole.Parent,
              firstName: isamsParent.firstName || existingUserByParent?.firstName || '',
              lastName: isamsParent.lastName || existingUserByParent?.lastName,
              email: isamsParent.email || existingUserByParent?.email,
              organizations: uniqBy(
                [...(existingUserByParent?.organizations || []).map(({ id }) => ({ id })), { id: organizationId }],
                'id'
              ),
            };
            console.log('1-ci ife girecek PARENT:', parentUser.email, 'isNotField2:', isNotField2);

            if (isNotField2 === null) {
              parents.push(parentUser);
            }
            if (isNotField2 && !isNotField2.includes(parentUser.email.toLowerCase())) {
              parents.push(parentUser);
              console.log('1-ci defe parent pushlandi:', parents);
            }

            if (!existingUserByParent) {
              createdParents.push(parentUser as Partial<UserEntity>);
              console.log('2-ci defe parent pushlandi:', createdParents);
            }
          }
        } else if (existingParent && !parents.some(({ id }) => id === existingParent.id)) {
          const parentUser = {
            id: existingParent.id,
            firstName: isamsParent.firstName || existingParent.firstName || '',
            lastName: isamsParent.lastName || existingParent.lastName,
            email: isamsParent.email || existingParent.email,
            role: existingParent.role || UserRole.Parent,
          };
          console.log('3-ci ife girecek PARENT:', parentUser.email, 'isNotField2:', isNotField2);

          if (isNotField2 === null) {
            parents.push(parentUser);
          }
          if (isNotField2 && !isNotField2.includes(parentUser.email.toLowerCase())) {
            parents.push(parentUser);
            console.log('3-cu defe parent pushlandi:', parents);
          }
        }
      }

      const k = user.player.parents.length;
      for (let i = 0; i < k; i++) {
        const existingParent = user.player.parents[i];

        if (!parents.some(({ id }) => id === existingParent.id)) {
          console.log('4-ci ife girecek PARENT:', existingParent.email, 'isNotField2:', isNotField2);

          if (isNotField2 === null) {
            parents.push({ id: existingParent.id });
          }

          if (isNotField2 && !isNotField2.includes(existingParent.email.toLowerCase())) {
            parents.push({ id: existingParent.id });
            console.log('4-cu defe parent pushlandi:', parents);
          }
        }
      }

      console.log('&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&');
      console.log('INSERTED PARENTS:', parents);
      console.log('&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&');

      data.player = {
        userId: user.player.userId,
        yearGroup: calculateYearGroup(birthday),
        socsId: isamsData.socId || user.player.socsId,
        additionalRecepients,
        parents,
      };
    }

    this.logger.log(`updateUserPlayerByIsamsData --api data: ${JSON.stringify(data)}`);
    this.logger.log(`updateUserPlayerByIsamsData --api createdParents: ${JSON.stringify(createdParents)}`);
    this.logger.log(`updateUserPlayerByIsamsData --api user: ${JSON.stringify(user)}`);

    const updated = await this.usersService.saveOne(data);

    this.logger.log(`updateUserPlayerByIsamsData --api updated ${JSON.stringify(updated)}`);

    try {
      const updatedFields = getUpdatedFieldsForPlayers(user, updated);

      this.logger.log(`updateUserPlayerByIsamsData --api updatedFields: ${JSON.stringify(updatedFields)}`);

      if (updatedFields.length) {
        await this.addSyncLog(syncId, getUpdatedPlayerLog(user, updated, updatedFields));
      }
    } catch (err) {
      this.logger.error(`Error during creating sync log about updated player. Error: ${err.message}`);
    }

    try {
      const createdParentsLogs = getCreatedParentsLogs(createdParents);
      const newParentsForPlayerLogs = getNewParentsForPlayerLog(user, updated);
      for (const log of createdParentsLogs) {
        await this.addSyncLog(syncId, log);
      }
      for (const log of newParentsForPlayerLogs) {
        await this.addSyncLog(syncId, log);
      }
    } catch (err) {
      this.logger.error(`Error during creating logs for parents to existing player. Error: ${err.message}`);
    }

    return updated;
  }

  private async createUserPlayerByIsamsData(
    syncId: IsamsSyncEntity['id'],
    isamsData: IsamsPlayer,
    isamsParents: IsamsParent[],
    isamsRecipients: IsamsRecipient[],
    organizationId: string
  ): Promise<UserEntity> {
    const birthday = isamsData.birthday && new Date(isamsData.birthday);

    const data: DeepPartial<UserEntity> = {
      id: uuid(),
      firstName: isamsData.firstName,
      lastName: isamsData.lastName,
      email: isamsData.email,
      gender: isamsData.gender,
      role: UserRole.Player,
      birthday,
      organizations: [{ id: organizationId }],
    };

    const additionalRecepients: DeepPartial<AdditionalRecipientEntity>[] = isamsRecipients.map((item) => ({
      ...item,
      id: uuid(),
    }));

    const createdParents: Partial<UserEntity>[] = [];
    const parents: DeepPartial<UserEntity>[] = [];

    const n = isamsParents.length;

    for (let i = 0; i < n; i++) {
      const isamsParent = isamsParents[i];
      if (isamsParent.email) {
        const existingUsersByParents = await this.usersService.find({
          where: {
            email: ILike(isamsParent.email),
            role: Not(UserRole.Player),
          },
          relations: ['organizations'],
        });

        const existingUserByParent = getExistingUserByParent(isamsParent, existingUsersByParents, organizationId);
        this.logger.log(
          `createUserPlayerByIsamsData --api existingUserByParent: ${JSON.stringify(existingUserByParent)}`
        );
        const parentId = existingUserByParent?.id || uuid();
        if (!parents.some(({ id }) => id === parentId)) {
          const parentUser = {
            ...existingUserByParent,
            id: parentId,
            role: existingUserByParent?.role || UserRole.Parent,
            firstName: isamsParent.firstName || existingUserByParent?.firstName || '',
            lastName: isamsParent.lastName || existingUserByParent?.lastName,
            email: isamsParent.email || existingUserByParent?.email,
            organizations: uniqBy(
              [...(existingUserByParent?.organizations || []).map(({ id }) => ({ id })), { id: organizationId }],
              'id'
            ),
          };

          parents.push(parentUser);
          if (!existingUserByParent) {
            createdParents.push(parentUser as Partial<UserEntity>);
          }
        }
      }
    }

    data.player = {
      userId: data.id,
      yearGroup: calculateYearGroup(birthday),
      membership: Membership.School,
      socsId: isamsData.socId,
      additionalRecepients,
      parents,
    };

    this.logger.log(`createUserPlayerByIsamsData --api data: ${JSON.stringify(data)}`);

    const created = await this.usersService.saveOne(data);

    try {
      await this.addSyncLog(syncId, getCreatedPlayerLog(created));
    } catch (err) {
      this.logger.error(`Error during sending sync message to iSAMS sync. Error: ${err.message}`);
    }

    try {
      const createdParentsLogs = getCreatedParentsLogs(createdParents);
      const newParentsForPlayerLogs = getNewParentsForPlayerLog(
        { player: { parents: [] } as UserEntity['player'] },
        created
      );
      for (const log of createdParentsLogs) {
        await this.addSyncLog(syncId, log);
      }
      for (const log of newParentsForPlayerLogs) {
        await this.addSyncLog(syncId, log);
      }
    } catch (err) {
      this.logger.error(`Error during creating logs for parents to new player. Error: ${err.message}`);
    }

    return created;
  }

  async getDataFromISAMS(url: string, filters: string): Promise<string> {
    const response = await this.api.get<string>(url, {
      headers: {
        ['Content-Type']: 'application/xml',
      },
      data: filters,
    });

    return response.data;
  }

  private getBatchApiURL(organizationUrl: string): string {
    return `https://${organizationUrl}/api/batch/1.0`;
  }

  private parseXMLData(xmlData: string): IsamsData {
    const xmlParser = new XMLParser({ ignoreAttributes: false });
    return xmlParser.parse(xmlData);
  }

  /**
   * Async function to send command message to start synchronize wonde school
   * @param id string - Wonde school id
   */
  private async sendSyncMessageToQueue(organizationId: string, iSAMSUrl: string, iSAMSKey: string): Promise<void> {
    await this.queue.add(ISAMS_COMMAND_SYNC, {
      organizationId,
      iSAMSKey,
      iSAMSUrl,
    });
  }

  private async uploadCsvReport(
    organizationId: string,
    syncId: string,
    data: Record<string, any>[],
    keyPrefix: 'after' | 'before'
  ): Promise<string> {
    const key = `ISAMS/${organizationId}-${keyPrefix}-${syncId}-${uuid()}-${uuid()}-${uuid()}-${new Date().getTime()}.csv`;
    const { stream: s3WritableStream, promise: s3Upload } = this.s3manager.uploadStreamToS3(
      key,
      FileFormat.csv,
      undefined,
      'public-read'
    );

    const gzip = createGzip();

    write(data, { headers: true }).pipe(gzip).pipe(s3WritableStream);

    return s3Upload.then(({ Location }) => Location);
  }
}

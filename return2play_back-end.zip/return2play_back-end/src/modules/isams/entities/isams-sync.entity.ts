import {
  Column,
  CreateDateColumn,
  Entity,
  Index,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
  RelationId,
  UpdateDateColumn,
} from 'typeorm';
import { OrganizationEntity } from '../../organizations/entities/organization.entity';
import { IsamsSyncLogEntity } from './isams-sync-logs.entity';

export enum ISAMS_SYNC_RESULTS {
  SUCCESS = 'success',
  FAILED = 'failed',
  PARTLY_SUCCESS = 'partly_success',
}
@Entity('isams_syncs')
export class IsamsSyncEntity {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @CreateDateColumn({ type: 'timestamp', readonly: true })
  createdAt: Date;

  @UpdateDateColumn({ type: 'timestamp', readonly: true })
  updatedAt: Date;

  @Column({ type: 'timestamp', nullable: true })
  startedAt: Date;

  @Column({ type: 'timestamp', nullable: true })
  receivedAt: Date;

  @Column({ type: 'timestamp', nullable: true })
  finishedAt: Date;

  @Index()
  @Column({
    type: 'enum',
    enum: ISAMS_SYNC_RESULTS,
    nullable: true,
  })
  result: ISAMS_SYNC_RESULTS;

  @Column('text', { nullable: true })
  filters?: string;

  @Column({ nullable: true })
  iSAMSDataUrl?: string;

  @Index()
  @ManyToOne(() => OrganizationEntity, (organization) => organization.isamsSyncs, {
    onDelete: 'CASCADE',
  })
  organization: OrganizationEntity;

  @RelationId((isamsSync: IsamsSyncEntity) => isamsSync.organization)
  @Column('uuid')
  organizationId: string;

  @OneToMany(() => IsamsSyncLogEntity, (error) => error.sync)
  errors: IsamsSyncLogEntity[];
}

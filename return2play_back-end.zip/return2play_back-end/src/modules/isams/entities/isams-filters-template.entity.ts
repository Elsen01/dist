import {
  Column,
  CreateDateColumn,
  Entity,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
  RelationId,
  UpdateDateColumn,
} from 'typeorm';
import { UserEntity } from '../../users/entities/user.entity';
import { OrganizationEntity } from '../../organizations/entities/organization.entity';

@Entity('isams_filters_templates')
export class IsamsFiltersTemplateEntity {
  @PrimaryGeneratedColumn('increment')
  id: number;

  @CreateDateColumn({ type: 'timestamp', readonly: true })
  createdAt: Date;

  @UpdateDateColumn({ type: 'timestamp', readonly: true })
  updatedAt: Date;

  @Column('text')
  value: string;

  @Column({ nullable: true })
  description?: string;

  @Column('boolean', { default: false })
  default: boolean;

  @ManyToOne(() => UserEntity, (user) => user.isamsFiltersTemplates, {
    onDelete: 'SET NULL',
  })
  createdBy: UserEntity;

  @RelationId((isamsFiltersTemplate: IsamsFiltersTemplateEntity) => isamsFiltersTemplate.createdBy)
  @Column()
  createdById: string;

  @OneToMany(() => OrganizationEntity, (organization) => organization.isamsFiltersTemplate)
  organizations: OrganizationEntity[];
}

import {
  Column,
  CreateDateColumn,
  Entity,
  Index,
  ManyToOne,
  PrimaryGeneratedColumn,
  RelationId,
  UpdateDateColumn,
} from 'typeorm';
import { IsamsSyncEntity } from './isams-sync.entity';

export enum ISAMS_SYNC_LOG_LEVELS {
  INFO = 'info',
  WARNING = 'warning',
  ERROR = 'error',
}

@Entity('isams_sync_logs')
export class IsamsSyncLogEntity {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ nullable: true })
  message?: string;

  @Column('text', { nullable: true })
  description?: string;

  @Column('text', { nullable: true })
  errorDetails?: string;

  @Index()
  @Column({
    type: 'enum',
    enum: ISAMS_SYNC_LOG_LEVELS,
    default: ISAMS_SYNC_LOG_LEVELS.INFO,
  })
  level: ISAMS_SYNC_LOG_LEVELS;

  @CreateDateColumn({ type: 'timestamp', readonly: true })
  createdAt: Date;

  @UpdateDateColumn({ type: 'timestamp', readonly: true })
  updatedAt: Date;

  @Index()
  @ManyToOne(() => IsamsSyncEntity, (sync) => sync.errors, {
    onDelete: 'CASCADE',
  })
  sync: IsamsSyncEntity;

  @RelationId((isamsSyncErr: IsamsSyncLogEntity) => isamsSyncErr.sync)
  @Column('uuid')
  syncId: string;
}

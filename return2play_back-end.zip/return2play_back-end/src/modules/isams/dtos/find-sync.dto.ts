import { IsEnum, IsOptional, IsString, MaxLength, MinLength } from 'class-validator';
import { PaginationDto } from '../../shared/shared.dto';
import { Order } from '../../shared/types';
import { ISAMS_SYNC_RESULTS } from '../entities/isams-sync.entity';
import { ISamsSyncsSortOptions } from '../types';

export class ISamsSyncFiltersQuery extends PaginationDto {
  @IsEnum(ISamsSyncsSortOptions)
  @IsOptional()
  sort? = ISamsSyncsSortOptions.Started;

  @IsEnum(Order)
  @IsOptional()
  order? = Order.DESC;

  @IsEnum(ISAMS_SYNC_RESULTS)
  @IsOptional()
  result?: ISAMS_SYNC_RESULTS;

  @IsString()
  @MinLength(1)
  @MaxLength(100)
  @IsOptional()
  searchWord?: string;
}

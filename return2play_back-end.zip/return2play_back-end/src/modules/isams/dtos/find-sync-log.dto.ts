import { IsEnum, IsOptional, IsString, MaxLength, MinLength } from 'class-validator';
import { PaginationDto } from '../../shared/shared.dto';
import { Order } from '../../shared/types';
import { ISamsSyncLogsSortOptions } from '../types';
import { ISAMS_SYNC_LOG_LEVELS } from '../entities/isams-sync-logs.entity';

export class ISamsSyncLogFiltersQuery extends PaginationDto {
  @IsEnum(ISamsSyncLogsSortOptions)
  @IsOptional()
  sort? = ISamsSyncLogsSortOptions.Created;

  @IsEnum(Order)
  @IsOptional()
  order? = Order.ASC;

  @IsEnum(ISAMS_SYNC_LOG_LEVELS)
  @IsOptional()
  level?: ISAMS_SYNC_LOG_LEVELS;

  @IsString()
  @MinLength(1)
  @MaxLength(100)
  @IsOptional()
  searchWord?: string;
}

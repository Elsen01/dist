import { Controller, Get, NotFoundException, Param, Query, UseGuards } from '@nestjs/common';
import {
  ApiBearerAuth,
  ApiForbiddenResponse,
  ApiNotFoundResponse,
  ApiOkResponse,
  ApiOperation,
  ApiTags,
  ApiUnprocessableEntityResponse,
} from '@nestjs/swagger';
import { IsamsService } from './isams.service';
import { FindManyResponse } from '../shared/types';
import { IsamsSyncEntity } from './entities/isams-sync.entity';
import { GET_MANY, GET_ONE } from './swagger';
import { UserRole } from '../users/types';
import { Roles } from '../shared/decorators/roles.decorator';
import { ISamsSyncFiltersQuery } from './dtos/find-sync.dto';
import { CognitoGuard } from '../shared/guards/cognito.guard';
import { RolesGuard } from '../shared/guards/roles.guard';
import { IdDto } from '../shared/shared.dto';
import { IsamsSyncLogEntity } from './entities/isams-sync-logs.entity';
import { ISamsSyncLogFiltersQuery } from './dtos/find-sync-log.dto';

@ApiTags('Integration iSAMS')
@UseGuards(CognitoGuard, RolesGuard)
@Roles(UserRole.SuperAdmin)
@ApiBearerAuth()
@Controller('integrations/isams')
export class IsamsController {
  constructor(private service: IsamsService) {}

  @ApiOperation(GET_MANY.OPERATION)
  @ApiOkResponse(GET_MANY.SUCCESS)
  @ApiNotFoundResponse(GET_MANY.NOT_FOUND)
  @ApiForbiddenResponse(GET_MANY.FORBIDDEN)
  @ApiUnprocessableEntityResponse(GET_MANY.FAILURE)
  @Get('/syncs')
  getMany(@Query() query: ISamsSyncFiltersQuery): Promise<FindManyResponse<IsamsSyncEntity>> {
    return this.service.findMany(query);
  }

  @ApiOperation(GET_ONE.OPERATION)
  @ApiOkResponse(GET_ONE.SUCCESS)
  @ApiNotFoundResponse(GET_ONE.NOT_FOUND)
  @ApiForbiddenResponse(GET_ONE.FORBIDDEN)
  @Get('/syncs/:id')
  async getOne(@Param() param: IdDto): Promise<IsamsSyncEntity> {
    const item = await this.service.findOne({ id: param.id });

    if (!item) {
      throw new NotFoundException();
    }

    return item;
  }

  @ApiOperation(GET_MANY.OPERATION)
  @ApiOkResponse(GET_MANY.SUCCESS)
  @ApiNotFoundResponse(GET_MANY.NOT_FOUND)
  @ApiForbiddenResponse(GET_MANY.FORBIDDEN)
  @ApiUnprocessableEntityResponse(GET_MANY.FAILURE)
  @Get('/syncs/:id/logs')
  getManyLogs(
    @Param() param: IdDto,
    @Query() query: ISamsSyncLogFiltersQuery
  ): Promise<FindManyResponse<IsamsSyncLogEntity>> {
    return this.service.findManyLogs(param.id, query);
  }
}

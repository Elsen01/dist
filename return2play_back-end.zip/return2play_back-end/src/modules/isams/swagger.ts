import { IDocumentedEndpoint } from '../shared/interfaces/swagger.interface';

export const GET_ONE: IDocumentedEndpoint = {
  OPERATION: {
    description: 'Get details about particular iSAMS synchronization. This action can perform only `Super admin`',
  },
  SUCCESS: {
    description: '`Success` Synchronization info is returned',
  },
  FAILURE: {
    description: '`API` Error occurs during select an entity',
  },
  NOT_FOUND: {
    description: '`API` Synchronization is not found within the system',
  },
  FORBIDDEN: {
    description: '`API` User has no permissions to get synchronization',
  },
};

export const GET_MANY: IDocumentedEndpoint = {
  OPERATION: {
    description: 'Get list of synchronizations.',
  },
  SUCCESS: {
    description: '`Success` Synchronizations info is returned',
  },
  FAILURE: {
    description: '`API` Error occurs during select an entity',
  },
  NOT_FOUND: {
    description: '`API` Synchronizations are not found within the system',
  },
  FORBIDDEN: {
    description: '`API` User has no permissions to get synchronizations',
  },
};

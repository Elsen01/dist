import { Inject, Injectable, Logger, LoggerService } from '@nestjs/common';
import { SchedulerRegistry } from '@nestjs/schedule';
import { IsamsConfigService } from '../../config/isams-config/isams-config.service';
import { AbstractCronJob } from '../shared/abstract-cron-job';
import { IsamsService } from './isams.service';
import { AppConfigService } from '../../config/config.service';

@Injectable()
export class IsamsCronJon extends AbstractCronJob {
  constructor(
    @Inject(Logger) logger: LoggerService,
    schedulerRegistry: SchedulerRegistry,
    private readonly config: IsamsConfigService,
    private readonly service: IsamsService,
    private readonly appConfigService: AppConfigService
  ) {
    super(config.cronJobName, logger, schedulerRegistry, {
      cronTime: config.cronTime,
      redis: appConfigService.redis,
      timeZone: config.cronTimeZone,
    });
  }

  /**
   * Async handler for 'iSAMS Cron Job'
   */
  async handleCron(): Promise<void> {
    if (!this.config.isCronON) {
      return this.logger.log(`Cron Job '${this.name}' is switched off for this env`);
    }

    await this.service.syncAllOrganizations();
  }
}

import { Test, TestingModule } from '@nestjs/testing';
import { IsamsController } from './isams.controller';

describe('IsamsController', () => {
  let controller: IsamsController;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [IsamsController],
    }).compile();

    controller = module.get<IsamsController>(IsamsController);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });
});

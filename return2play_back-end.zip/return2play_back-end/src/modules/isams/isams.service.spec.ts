import { Test, TestingModule } from '@nestjs/testing';
import { IsamsService } from './isams.service';

describe('IsamsService', () => {
  let service: IsamsService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [IsamsService],
    }).compile();

    service = module.get<IsamsService>(IsamsService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});

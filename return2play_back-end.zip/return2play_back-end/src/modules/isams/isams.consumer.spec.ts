import { Test, TestingModule } from '@nestjs/testing';
import { IsamsConsumer } from './isams.consumer';

describe('IsamsConsumer', () => {
  let provider: IsamsConsumer;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [IsamsConsumer],
    }).compile();

    provider = module.get<IsamsConsumer>(IsamsConsumer);
  });

  it('should be defined', () => {
    expect(provider).toBeDefined();
  });
});

export enum ISamsSyncsSortOptions {
  Result = 'result',
  Started = 'startedAt',
  Finished = 'finishedAt',
  Received = 'receivedAt',
  Organization = 'organization',
  ID = 'id',
}

export enum ISamsSyncLogsSortOptions {
  Created = 'createdAt',
  Message = 'message',
  Description = 'description',
  ErrorDetails = 'errorDetails',
  Level = 'level',
  ID = 'id',
}

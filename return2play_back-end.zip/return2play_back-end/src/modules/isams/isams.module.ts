import { Logger, Module } from '@nestjs/common';
import { IsamsService } from './isams.service';
import { TypeOrmModule } from '@nestjs/typeorm';
import { IsamsSyncEntity } from './entities/isams-sync.entity';
import { IsamsSyncLogEntity } from './entities/isams-sync-logs.entity';
import { IsamsCronJon } from './isams-cron-jon';
import { IsamsConfigModule } from '../../config/isams-config/isams-config.module';
import { OrganizationsModule } from '../organizations/organizations.module';
import { ISAMS_QUEUE_NAME } from '../../config/isams-config/isams-config.service';
import { BullModule } from '@nestjs/bull';
import { IsamsConsumer } from './isams.consumer';
import { UsersModule } from '../users/users.module';
import { IsamsFiltersTemplateEntity } from './entities/isams-filters-template.entity';
import { IsamsController } from './isams.controller';
import { SharedModule } from '../shared/shared.module';

@Module({
  imports: [
    TypeOrmModule.forFeature([IsamsSyncEntity, IsamsSyncLogEntity, IsamsFiltersTemplateEntity]),
    IsamsConfigModule,
    OrganizationsModule,
    BullModule.registerQueue({
      name: ISAMS_QUEUE_NAME,
    }),
    UsersModule,
    SharedModule,
  ],
  providers: [IsamsService, IsamsCronJon, Logger, IsamsConsumer],
  exports: [IsamsService],
  controllers: [IsamsController],
})
export class IsamsModule {}

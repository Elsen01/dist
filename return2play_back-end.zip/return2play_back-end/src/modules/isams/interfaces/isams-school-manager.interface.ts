import { IsamsBoardingHouses } from './isams-boarding-houses.interface';
import { IsamsForms } from './isams-forms.interface';
import { IsamsYears } from './isams-years.interface';

export interface IsamsSchoolManager {
  BoardingHouses: IsamsBoardingHouses;
  Forms: IsamsForms;
  Years: IsamsYears;
}

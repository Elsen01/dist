import { IsamsHRManager } from './isams-hr-manager.interface';
import { IsamsPupilManager } from './isams-pupil-manager.interface';
import { IsamsSchoolManager } from './isams-school-manager.interface';

export interface IsamsData {
  iSAMS: {
    HRManager: IsamsHRManager;
    PupilManager: IsamsPupilManager;
    SchoolManager: IsamsSchoolManager;
  };
}

import { IsamsYear } from './isams-year.interface';

export interface IsamsYears {
  Year: IsamsYear[];
}

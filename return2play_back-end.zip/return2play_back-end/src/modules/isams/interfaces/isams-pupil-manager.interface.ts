import { IsamsContacts } from './isams-contacts.interface';
import { IsamsCurrentPupils } from './isams-current-pupils.interface';

export interface IsamsPupilManager {
  CurrentPupils: IsamsCurrentPupils;
  Contacts: IsamsContacts;
}

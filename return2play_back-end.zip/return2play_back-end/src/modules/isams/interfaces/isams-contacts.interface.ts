import { IsamsContact } from './isams-contact.interface';

export interface IsamsContacts {
  Contact: IsamsContact[];
}

export interface IsamsYear {
  ['@_Id']: string;
  ['@_TutorId']: string;
  ['@_AssistantTutorId']: string;
}

export interface IsamsForm {
  ['@_Id']: string;
  ['@_TutorId']: string;
  ['@_YearId']: string;
}

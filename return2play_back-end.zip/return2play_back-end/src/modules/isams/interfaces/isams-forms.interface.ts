import { IsamsForm } from './isams-form.interface';

export interface IsamsForms {
  Form: IsamsForm[];
}

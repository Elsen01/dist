import { IsamsContactPupils } from './isams-contact-pupils.interface';

export interface IsamsContact {
  ['@_Id']: string;
  Forename: string;
  Surname: string;
  EmailAddress: string;
  Pupils: IsamsContactPupils;
  ParentalResponsibility?: string;
  CorrespondenceMailMerge: number;
  MailMergeAll: number;
}

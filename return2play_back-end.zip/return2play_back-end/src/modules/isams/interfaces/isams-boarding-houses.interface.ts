import { IsamsHouse } from './isams-house.interface';

export interface IsamsBoardingHouses {
  House: IsamsHouse[];
}

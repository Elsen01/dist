export interface IsamsPupil {
  ['@_AcademicHouseId']: string;
  ['@_BoardingHouseId']: string;
  ['@_DivisionId']: string;
  ['@_Id']: string;
  ['@_PersonGuid']: string;
  Forename: string;
  Surname: string;
  Gender: 'M' | 'F';
  DOB: string;
  EmailAddress: string;
  FamilyId: 19016;
  SchoolId: string | number;
  Form?: string;
  NCYear?: string | number;
}

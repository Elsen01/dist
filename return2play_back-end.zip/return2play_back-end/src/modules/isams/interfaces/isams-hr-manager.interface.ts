import { IsamsCurrentStaff } from './isams-current-staff.interface';

export interface IsamsHRManager {
  CurrentStaff: IsamsCurrentStaff;
}

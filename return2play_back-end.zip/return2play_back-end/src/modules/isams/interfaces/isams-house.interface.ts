export interface IsamsHouse {
  ['@_Id']: string;
  ['@_AssistantHouseMasterId']: string;
  ['@_HouseMasterId']: string;
}

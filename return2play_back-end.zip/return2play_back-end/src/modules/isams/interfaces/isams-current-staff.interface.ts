import { IsamsStaffMember } from './isams-staff-member.interface';

export interface IsamsCurrentStaff {
  StaffMember: IsamsStaffMember[];
}

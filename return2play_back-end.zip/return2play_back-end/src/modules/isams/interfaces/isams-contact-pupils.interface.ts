import { IsamsContactPupil } from './isams-contact-pupil.interface';

export interface IsamsContactPupils {
  Pupil: IsamsContactPupil | IsamsContactPupil[];
}

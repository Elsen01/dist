export interface IsamsSyncData {
  organizationId: string;
  iSAMSUrl: string;
  iSAMSKey: string;
}

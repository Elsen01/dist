export interface IsamsContactPupil {
  ['@_Id']: string;
  SchoolId: string;
  Status: string;
}

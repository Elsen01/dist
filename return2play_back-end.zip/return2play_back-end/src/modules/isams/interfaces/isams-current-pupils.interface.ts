import { IsamsPupil } from './isams-pupil.interface';

export interface IsamsCurrentPupils {
  Pupil: IsamsPupil[];
}

export interface IsamsStaffMember {
  ['@_Id']: string;
  ['@_PersonGuid']: string;
  ['@_PersonId']: string;
  Forename: string;
  Surname: string;
  DOB: string;
  SchoolEmailAddress: string;
}

import { Process, Processor } from '@nestjs/bull';
import { Inject, Logger, LoggerService } from '@nestjs/common';
import { Job } from 'bull';
import { ISAMS_COMMAND_SYNC, ISAMS_QUEUE_NAME } from '../../config/isams-config/isams-config.service';
import { IsamsSyncData } from './interfaces/isams-sync-data.interface';
import { IsamsService } from './isams.service';

@Processor(ISAMS_QUEUE_NAME)
export class IsamsConsumer {
  constructor(
    private readonly service: IsamsService,
    @Inject(Logger)
    private readonly logger: LoggerService
  ) {}

  @Process(ISAMS_COMMAND_SYNC)
  async syncOrganization({ data }: Job<IsamsSyncData>): Promise<void> {
    try {
      await this.service.syncOrganization(data);
    } catch (err) {
      this.logger.error(
        `Error during synchronization with iSAMS for organization with id '${data.organizationId}'. Error: ${err.message}`
      );
    }
  }
}

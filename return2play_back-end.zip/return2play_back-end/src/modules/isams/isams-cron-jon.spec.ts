import { Test, TestingModule } from '@nestjs/testing';
import { IsamsCronJon } from './isams-cron-jon';

describe('IsamsCronJon', () => {
  let provider: IsamsCronJon;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [IsamsCronJon],
    }).compile();

    provider = module.get<IsamsCronJon>(IsamsCronJon);
  });

  it('should be defined', () => {
    expect(provider).toBeDefined();
  });
});

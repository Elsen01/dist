import {
  Body,
  Controller,
  Delete,
  Get,
  HttpCode,
  HttpStatus,
  Param,
  Post,
  Put,
  Query,
  UploadedFile,
  UseGuards,
  UseInterceptors,
} from '@nestjs/common';
import {
  ApiBearerAuth,
  ApiConflictResponse,
  ApiConsumes,
  ApiForbiddenResponse,
  ApiNoContentResponse,
  ApiNotFoundResponse,
  ApiOkResponse,
  ApiOperation,
  ApiTags,
  ApiUnprocessableEntityResponse,
} from '@nestjs/swagger';
import { IUser } from './../shared/interfaces/request-user.interface';
import { UserRole } from './../users/types';
import { Roles } from './../shared/decorators/roles.decorator';
import { RolesGuard } from './../shared/guards/roles.guard';
import { CognitoGuard } from '../shared/guards/cognito.guard';
import { CreateOrganizationBody } from './dtos/create-organization.dto';
import { Edit2Fa, EditOrganizationBody } from './dtos/edit-organization.dto';
import { OrganizationEntity } from './entities/organization.entity';
import { OrganizationsService } from './organizations.service';
import { FiltersQuery } from './dtos/find-organization.dto';
import { User } from '../shared/decorators/user.decorator';
import { IdDto } from '../shared/shared.dto';
import { CREATE_ONE, EDIT_ONE, GET_MANY, GET_ONE, DELETE_ONE } from './swagger';
import { FileInterceptor } from '@nestjs/platform-express';
import { multerOptionsImg } from '../shared/helpers/multer/options';
import { IFile } from '../shared/helpers/s3bucket/types';
import { FindManyResponse } from '../shared/types';
import { HideFieldsForNotSuperAdminsFromResponse } from '../shared/interceptors/hide-fields-from-response/hide-fields-for-not-super-admins-from-response.interceptor';
import omit from 'lodash/omit';

export const ORGANIZATION_FIELDS_TO_HIDE_FROM_NOT_SUPER_ADMINS: (keyof OrganizationEntity)[] = ['iSAMSKey', 'iSAMSUrl'];

@ApiTags('Organizations')
@UseGuards(CognitoGuard, RolesGuard)
@Roles(UserRole.SuperAdmin)
@ApiBearerAuth()
@Controller('organizations')
export class OrganizationsController {
  constructor(private service: OrganizationsService) {}

  @ApiOperation(CREATE_ONE.OPERATION)
  @ApiNoContentResponse(CREATE_ONE.SUCCESS)
  @ApiConflictResponse(CREATE_ONE.ORGANIZATION_EXISTS)
  @ApiUnprocessableEntityResponse(CREATE_ONE.FAILURE)
  @ApiConsumes('multipart/form-data')
  @UseInterceptors(FileInterceptor('logo', multerOptionsImg()))
  @HttpCode(HttpStatus.NO_CONTENT)
  @Post()
  async createOne(@UploadedFile() logo: IFile, @Body() organization: CreateOrganizationBody): Promise<void> {
    return await this.service.createOne({ logo, ...organization });
  }

  @ApiOperation(GET_MANY.OPERATION)
  @ApiOkResponse(GET_MANY.SUCCESS)
  @ApiUnprocessableEntityResponse(GET_MANY.FAILURE)
  @Roles(UserRole.OrganizationAdmin, UserRole.MedicalStaff, UserRole.Doctor, UserRole.StaffUser, UserRole.Parent)
  @UseInterceptors(
    new HideFieldsForNotSuperAdminsFromResponse<OrganizationEntity>(ORGANIZATION_FIELDS_TO_HIDE_FROM_NOT_SUPER_ADMINS, {
      array: true,
      fromField: 'data',
    })
  )
  @Get()
  async findMany(@Query() query: FiltersQuery, @User() user: IUser): Promise<FindManyResponse<OrganizationEntity>> {
    return await this.service.findMany(user.userId, query);
  }

  @ApiOperation(GET_ONE.OPERATION)
  @ApiOkResponse({ ...GET_ONE.SUCCESS, type: OrganizationEntity })
  @ApiNotFoundResponse(GET_ONE.NOT_FOUND)
  @Roles(UserRole.OrganizationAdmin, UserRole.MedicalStaff, UserRole.Doctor, UserRole.StaffUser)
  @UseInterceptors(
    new HideFieldsForNotSuperAdminsFromResponse<OrganizationEntity>(ORGANIZATION_FIELDS_TO_HIDE_FROM_NOT_SUPER_ADMINS)
  )
  @Get('/:id')
  async findById(@Param() param: IdDto, @User() user: IUser): Promise<OrganizationEntity> {
    return await this.service.findById(param.id, user);
  }

  @ApiOperation(EDIT_ONE.OPERATION)
  @ApiOkResponse(EDIT_ONE.SUCCESS)
  @ApiUnprocessableEntityResponse(EDIT_ONE.FAILURE)
  @ApiConflictResponse(EDIT_ONE.ORGANIZATION_EXISTS)
  @Roles(UserRole.OrganizationAdmin)
  @Put('/2FA/:id')
  async update2Fa(@Param() { id }: IdDto, @Body() edit2Fa: Edit2Fa): Promise<void> {
    return await this.service.update2FA(edit2Fa, id);
  }

  @ApiOperation(EDIT_ONE.OPERATION)
  @ApiOkResponse(EDIT_ONE.SUCCESS)
  @ApiUnprocessableEntityResponse(EDIT_ONE.FAILURE)
  @ApiConflictResponse(EDIT_ONE.ORGANIZATION_EXISTS)
  @ApiNotFoundResponse(EDIT_ONE.UNKNOWN_ORGANIZATION)
  @ApiConsumes('multipart/form-data')
  @Roles(UserRole.OrganizationAdmin, UserRole.MedicalStaff)
  @UseInterceptors(FileInterceptor('logo', multerOptionsImg()))
  @Put('/:id')
  async updateOne(
    @UploadedFile() fileLogo: IFile,
    @Param() { id }: IdDto,
    @Body() organization: EditOrganizationBody,
    @User() user: IUser
  ): Promise<void> {
    const logo = fileLogo ?? organization.logo;
    if (user?.role !== UserRole.SuperAdmin) {
      return await this.service.updatedOne({ ...omit(organization, ['iSAMSUrl', 'iSAMSKey']), logo, id });
    }
    return await this.service.updatedOne({ ...organization, logo, id });
  }

  @ApiOperation(DELETE_ONE.OPERATION)
  @ApiNoContentResponse(DELETE_ONE.SUCCESS)
  @ApiNotFoundResponse(DELETE_ONE.NOT_FOUND)
  @ApiForbiddenResponse(DELETE_ONE.FORBIDDEN)
  @ApiUnprocessableEntityResponse(DELETE_ONE.FAILURE)
  @Delete('/:id')
  async deleteOne(@Param() { id }: IdDto, @User() user: IUser): Promise<void> {
    return await this.service.deleteOne(id, user);
  }
}

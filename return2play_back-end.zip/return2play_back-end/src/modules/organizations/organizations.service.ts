import {
  ConflictException,
  HttpStatus,
  Inject,
  Injectable,
  Logger,
  LoggerService,
  NotFoundException,
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { plainToClass } from 'class-transformer';
import { FindManyOptions, QueryRunner, Repository } from 'typeorm';
import { IMAGE_FORMATS, S3_ORGANIZATIONS_FOLDER } from '../shared/constants';
import { S3BucketManager } from '../shared/helpers/s3bucket/s3bucket.manager';
import { IUser } from '../shared/interfaces/request-user.interface';
import { FindManyResponse } from '../shared/types';
import { NewOrganization } from './dtos/create-organization.dto';
import { Edit2Fa, EditOrganization } from './dtos/edit-organization.dto';
import { FiltersQuery } from './dtos/find-organization.dto';
import { OrganizationEntity } from './entities/organization.entity';
import { OrganizationRepository } from './organizations.repository';
import { OrganizationStatus } from './types';
import moment from 'moment';

@Injectable()
export class OrganizationsService {
  constructor(
    // OLD VERSION
    @InjectRepository(OrganizationRepository)
    private organizationRepo: OrganizationRepository,
    // NEW VERSION
    @InjectRepository(OrganizationEntity)
    private readonly repository: Repository<OrganizationEntity>,

    private s3Bucket: S3BucketManager,
    @Inject(Logger) private logger: LoggerService
  ) {}

  findByIdsAndUserId(userId: string, ids: ReadonlyArray<string>): Promise<ReadonlyArray<OrganizationEntity>> {
    return this.repository
      .createQueryBuilder('organization')
      .leftJoin('organization.users', 'user')
      .where('user.id = :userId', {
        userId,
      })
      .andWhere('organization.id IN (:...ids) AND organization.status = :status', {
        ids,
        status: OrganizationStatus.Active,
      })
      .getMany();
  }

  find(options: FindManyOptions<OrganizationEntity>): Promise<ReadonlyArray<OrganizationEntity>> {
    return this.repository.find(options);
  }

  async createOne(organization: NewOrganization): Promise<any> {
    const { logo, ...body } = organization;
    const isOrgExists = await this.organizationRepo.isOrganizationExist({
      where: { name: body.name },
    });

    if (isOrgExists) {
      this.logger.error(`Organization ${organization.name} exists`);

      const errorObject = {
        statusCode: HttpStatus.CONFLICT,
        field: 'name',
        message: 'An organization with provided name already exists',
      };
      throw new ConflictException(errorObject);
    }

    const createNew = async (runner: QueryRunner): Promise<void> => {
      const entity = plainToClass(OrganizationEntity, {
        ...body,
        status: OrganizationStatus.Active,
      });
      const { id } = await runner.manager.save(entity);
      if (logo) {
        const s3Path = this.s3Bucket.getBucketPath(logo, id, S3_ORGANIZATIONS_FOLDER);

        const location = await this.s3Bucket.upload(s3Path, IMAGE_FORMATS, logo);
        this.logger.log(`Uploaded logo for organization ${id} and got location ${location}`);
        await runner.manager.update(OrganizationEntity, { id }, { logo: location });
      }
    };

    await this.organizationRepo.runTransaction(createNew);
  }

  async update2FA(data: Edit2Fa, id: string): Promise<void> {
    const organization = await this.organizationRepo.findById(id);

    if (!organization) {
      this.logger.error(`Organization ${id} for update is not found`);
      throw new NotFoundException('Organization not found');
    }

    await this.organizationRepo.update2FA(id, data);
  }

  async updatedOne(data: EditOrganization): Promise<void> {
    const { id, logo, name, ...body } = data;
    let target = await this.organizationRepo.findById(id);

    if (!target) {
      this.logger.error(`Organization ${id} for update is not found`);
      throw new NotFoundException('Organization not found');
    }

    const isOrganizationNameExists = await this.organizationRepo.isOrganizationNameExists(name, id);

    if (isOrganizationNameExists) {
      this.logger.error(`Organization with name ${name} already exists`);

      const errorObject = {
        statusCode: HttpStatus.CONFLICT,
        field: 'name',
        message: 'An organization with provided name already exists',
      };
      throw new ConflictException(errorObject);
    }

    const { createdAt } = target;
    const keyToRemove = target.logo?.match(/[a-z]+\/[\w\d-_]+.\w+$/)?.[0];

    Object.keys(target).forEach((key) => (target[key] = null));
    target.createdAt = createdAt;
    target.id = id;
    target.name = name;
    const now = moment();
    now.format('YYYY-MM-DD HH:mm:ss.SSSSSS');
    target.updatedAt = now.toDate();

    const updateOrganization = async (runner: QueryRunner): Promise<void> => {
      if (logo?.buffer) {
        const s3Path = this.s3Bucket.getBucketPath(logo, id, S3_ORGANIZATIONS_FOLDER);

        const newLogoUrl = await this.s3Bucket.upload(s3Path, IMAGE_FORMATS, logo);
        this.logger.log(`New logo ${newLogoUrl} for organization ${id}`);
        target.logo = newLogoUrl;

        if (keyToRemove) {
          await this.s3Bucket.remove(keyToRemove);
          this.logger.log(`Logo ${keyToRemove} was removed`);
        }
      } else if (logo) {
        target.logo = logo;
      }
      if (!logo && keyToRemove) {
        await this.s3Bucket.remove(keyToRemove);
        this.logger.log(`Logo ${keyToRemove} was removed`);
      }
      // eslint-disable-next-line @typescript-eslint/no-unused-vars
      const { tags, ...targetCopy } = target;
      target = plainToClass(OrganizationEntity, { ...targetCopy, ...body });

      await runner.manager.update(OrganizationEntity, { id }, target);
    };

    await this.organizationRepo.runTransaction(updateOrganization);
  }

  async findById(id: string, user: IUser): Promise<OrganizationEntity> {
    const organization = await this.organizationRepo.findById(id, user.userId);

    if (!organization) {
      this.logger.error(`Organization ${id} for user ${user.userId} not found`);
      throw new NotFoundException('Organization not found');
    }

    return organization;
  }

  async findMany(userId: string, query: FiltersQuery): Promise<FindManyResponse<OrganizationEntity>> {
    const organizationsResponse = await this.organizationRepo.findMany(userId, query);
    const data = organizationsResponse[0];
    return { data, totalItems: organizationsResponse[1] };
  }

  async deleteOne(id: string, user: IUser): Promise<void> {
    const organization = await this.organizationRepo.findById(id, user.userId);

    if (!organization) {
      this.logger.error(`Organization ${id} for user ${user.userId} not found`);
      throw new NotFoundException('Organization not found');
    }

    return await this.organizationRepo.deleteOne(organization);
  }
}

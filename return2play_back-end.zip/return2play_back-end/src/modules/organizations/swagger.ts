import { IDocumentedEndpoint } from '../shared/interfaces/swagger.interface';

export const CREATE_ONE: IDocumentedEndpoint = {
  OPERATION: {
    description: 'Create a new organization within the system. Only super admins are allowed to perform this action',
  },
  SUCCESS: {
    description: '`Success` Organization was created',
  },
  ORGANIZATION_EXISTS: {
    description: '`API` An organization with provided name already exist in the system',
  },
  FAILURE: {
    description: '`API` Saved entity to the database failed',
  },
};

export const EDIT_ONE: IDocumentedEndpoint = {
  OPERATION: {
    description:
      '`Super admin` and `admin of particular organization` are allowed to edit information. Only provided values are stored. If you do not provide, for example, logo url, it is completely removed.',
  },
  SUCCESS: {
    description: '`Success` Organization was updated or created with provided uuid',
  },
  ORGANIZATION_EXISTS: {
    description: '`API` An organization with provided name already exist in the system',
  },
  UNKNOWN_ORGANIZATION: {
    description: '`API` An organization with provided id does not exist',
  },
  FAILURE: {
    description: '`API` Error occurs during updating an entity',
  },
};

export const GET_ONE: IDocumentedEndpoint = {
  OPERATION: {
    description:
      'Get details about particular organizations. Only `super admin` and `admin of particular organization` are allowed to see informations',
  },
  SUCCESS: {
    description: '`Success` Organization info is returned',
  },
  NOT_FOUND: {
    description: '`API` Organization is not found within the system',
  },
};

export const GET_MANY: IDocumentedEndpoint = {
  OPERATION: {
    description:
      '`Super admin` is allowed to fetch all of organizations which meet provided filters. `Admin of particular organization` is allowed to get organizations related to them',
  },
  SUCCESS: {
    description: '`Success` List of organization filtered by provided constraints',
  },
  FAILURE: {
    description: '`API` Error occurs during fetching list',
  },
};

export const DELETE_ONE: IDocumentedEndpoint = {
  OPERATION: {
    description:
      '`Super admin` is allowed to delete any of organizations. `Admin of particular organization` is allowed to delete organizations related to them',
  },
  SUCCESS: {
    description: '`Success` Organization was deleted',
  },
  FAILURE: {
    description: '`API` Error occurs during delete operation',
  },
  NOT_FOUND: {
    description: '`API` Organization with provided id does not exist',
  },
  FORBIDDEN: {
    description: '`API` User has no permissions to delete the organization',
  },
};

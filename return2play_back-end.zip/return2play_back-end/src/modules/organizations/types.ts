import { OrganizationEntity } from './entities/organization.entity';
import { WondeSchoolEntity } from './entities/wondeSchool.entity';
export enum OrganizationType {
  School = 'School',
  Club = 'Club',
}

export enum OrganizationStatus {
  Active = 'Active',
  Inactive = 'Inactive',
  Deleted = 'Deleted',
}

export enum SortOptions {
  Name = 'name',
  Type = 'type',
  Status = 'status',
  Created = 'createdAt',
  ID = 'id',
}

export type CreateWondeSchool = Partial<WondeSchoolEntity> & Partial<OrganizationEntity>;

export enum SchoolType {
  BoardingSchool = 'Boarding School',
  DaySchool = 'Day School',
  PrepSchool = 'Prep School',
  MixedSchool = 'Mixed School',
}

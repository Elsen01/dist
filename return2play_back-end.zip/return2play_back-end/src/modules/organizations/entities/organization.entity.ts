import { WondeSchoolEntity } from './wondeSchool.entity';
import { SportInjuryEntity } from './../../injuries/entities/sportInjury.entity';
import { TagEntity } from './../../tags/entities/tag.entity';
import { UserEntity } from '../../users/entities/user.entity';
import {
  Column,
  CreateDateColumn,
  Entity,
  Index,
  JoinTable,
  ManyToMany,
  ManyToOne,
  OneToMany,
  OneToOne,
  PrimaryGeneratedColumn,
  RelationId,
  UpdateDateColumn,
} from 'typeorm';
import { OrganizationStatus, OrganizationType, SchoolType } from '../types';
import { IsamsSyncEntity } from '../../isams/entities/isams-sync.entity';
import { IsamsFiltersTemplateEntity } from '../../isams/entities/isams-filters-template.entity';

@Entity('organizations')
export class OrganizationEntity {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ length: 100 })
  name: string;

  @Column({ length: 255, nullable: true })
  email?: string;

  @Column({ length: 15, nullable: true })
  phone?: string;

  @Column({ length: 1000, nullable: true })
  website?: string;

  @CreateDateColumn({ name: 'created_at' })
  createdAt: Date;

  @Column({ name: 'address_1', nullable: true })
  address1?: string;

  @Column({ name: 'address_2', nullable: true })
  address2?: string;

  @Column('boolean', { name: 'is_2FA', default: false, nullable: true })
  is2FA: boolean;

  @Column({ length: 11, nullable: true })
  postcode?: string;

  @Column({ length: 100, nullable: true })
  town?: string;

  @Column({ length: 100, nullable: true })
  county?: string;

  @Column({ length: 100, nullable: true })
  country?: string;

  @Column({ type: 'enum', enum: OrganizationType })
  type: OrganizationType;

  @Column({ type: 'enum', enum: SchoolType, nullable: true })
  schoolType?: SchoolType;

  @Column({ nullable: true, unique: true })
  logo?: string;

  @Column({
    type: 'enum',
    enum: OrganizationStatus,
    default: OrganizationStatus.Active,
    select: false,
  })
  status: OrganizationStatus;

  @Column({ name: 'key_contact_name', length: 255, nullable: true })
  keyContactName?: string;

  @Column({ name: 'key_contact_email', length: 255, nullable: true })
  keyContactEmail?: string;

  @Column({ name: 'key_contact_role', length: 255, nullable: true })
  keyContactRole?: string;

  @Column({ name: 'socs_id', nullable: true })
  socsId?: string;

  @Column({ name: 'is_socs', default: true, nullable: true })
  isSocs?: boolean;

  @ManyToMany(() => UserEntity, (user) => user.organizations)
  @JoinTable({
    name: 'organizations_users',
    joinColumn: {
      name: 'organization_id',
      referencedColumnName: 'id',
    },
    inverseJoinColumn: {
      name: 'user_id',
      referencedColumnName: 'id',
    },
  })
  users: UserEntity[];

  @OneToMany(() => TagEntity, (tag) => tag.organization)
  tags: TagEntity[];

  @OneToMany(() => SportInjuryEntity, (injury) => injury.organization)
  sportInjuries: SportInjuryEntity[];

  @OneToOne(() => WondeSchoolEntity, (wondeSchool) => wondeSchool.organization, { cascade: true })
  wondeSchool?: WondeSchoolEntity;

  @Column({ name: 'isams_url', nullable: true })
  iSAMSUrl?: string;

  @Column({ name: 'isams_key', nullable: true })
  iSAMSKey?: string;

  @OneToMany(() => IsamsSyncEntity, (isamsSync) => isamsSync.organization)
  isamsSyncs: IsamsSyncEntity[];

  @Column('text', { name: 'isams_filters', nullable: true })
  iSAMSFilters?: string;

  @Index()
  @ManyToOne(() => IsamsFiltersTemplateEntity, (isamsFiltersTemplate) => isamsFiltersTemplate.organizations, {
    onDelete: 'SET NULL',
    nullable: true,
  })
  isamsFiltersTemplate?: IsamsFiltersTemplateEntity;

  @RelationId((organization: OrganizationEntity) => organization.isamsFiltersTemplate)
  @Column({ nullable: true })
  isamsFiltersTemplateId?: number;

  @UpdateDateColumn({ name: 'updated_at' })
  updatedAt: Date;
}

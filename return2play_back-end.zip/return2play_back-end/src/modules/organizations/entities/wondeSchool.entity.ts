import { Column, Entity, JoinColumn, OneToOne, PrimaryGeneratedColumn } from 'typeorm';
import { OrganizationEntity } from './organization.entity';

@Entity('wonde_schools')
export class WondeSchoolEntity {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ name: 'wonde_id', length: 255 })
  wondeId: string;

  @Column({ name: 'establishment_number', length: 255, nullable: true })
  establishmentNumber?: string;

  @Column({ name: 'la_code', length: 255, nullable: true })
  laCode?: string;

  @Column({ name: 'last_update', type: 'timestamptz' })
  lastUpdate: Date;

  @OneToOne(() => OrganizationEntity, (organization) => organization?.wondeSchool, {
    nullable: false,
    eager: true,
    cascade: ['insert', 'update'],
  })
  @JoinColumn({ name: 'organization_id', referencedColumnName: 'id' })
  organization: OrganizationEntity;
}

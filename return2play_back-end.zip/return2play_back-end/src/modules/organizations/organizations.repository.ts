import { OrganizationEntity } from './entities/organization.entity';
import { DeepPartial, EntityRepository, FindConditions, FindOneOptions, In, Not, QueryRunner } from 'typeorm';
import { UserRole } from '../users/types';
import { FiltersQuery } from './dtos/find-organization.dto';
import { CreateWondeSchool, OrganizationStatus, OrganizationType, SortOptions } from './types';
import { UnprocessableEntityException, ForbiddenException } from '@nestjs/common';
import { RoleManager } from '../shared/helpers/accessManager/role.manager';
import { BaseRepository } from '../shared/base.repository';
import { WondeSchoolEntity } from './entities/wondeSchool.entity';
import { PlayerEntity } from '../players/entities/player.entity';
import { InjuryStatus } from '../injuries/types';
import { Edit2Fa } from './dtos/edit-organization.dto';

@EntityRepository(OrganizationEntity)
export class OrganizationRepository extends BaseRepository<OrganizationEntity> {
  private roleManager = RoleManager.getInstance();

  async findById(orgId: string, userId?: string): Promise<OrganizationEntity> {
    const query = this.createQueryBuilder('org')
      .leftJoinAndSelect('org.tags', 'tag')
      .where('org.status != :status', { status: OrganizationStatus.Deleted });

    if (this.roleManager.role === UserRole.SuperAdmin) {
      query.addSelect('org.status').andWhere(`org.id = '${orgId}'`);
    } else if (userId) {
      query.leftJoin('org.users', 'user').andWhere('user.id = :userId AND org.id = :orgId', {
        userId: userId,
        orgId: orgId,
      });
    }

    return await query.getOne().catch((err) => {
      throw new UnprocessableEntityException(err.message);
    });
  }

  async findOne(id: string): Promise<OrganizationEntity> {
    return this.repository
      .createQueryBuilder('org')
      .leftJoinAndSelect('org.users', 'user')
      .leftJoinAndSelect('user.injuries', 'injury')
      .innerJoinAndSelect('user.player', 'player')
      .leftJoinAndSelect('injury.otherInjury', 'otherInjury')
      .where('org.id = :id', { id })
      .andWhere('injury.status <> :status', { status: InjuryStatus.Deleted })
      .getOne();
  }

  findWondeSchoolById(id: string): Promise<WondeSchoolEntity> {
    return this.getRepositoryFor(WondeSchoolEntity).findOne(id, {
      join: {
        alias: 'wondeSchool',
        leftJoinAndSelect: {
          organization: 'wondeSchool.organization',
        },
      },
    });
  }

  async findMany(
    userId: string,
    { limit, page, sort, order, status, type, searchWord }: FiltersQuery
  ): Promise<[OrganizationEntity[], number]> {
    const query = this.createQueryBuilder('org')
      .addSelect('org.status')
      .leftJoinAndSelect('org.tags', 'tag')
      .where(type ? 'org.type = :type' : 'true', { type })
      .andWhere(searchWord ? '(org.name ILIKE :name OR org.id::text ILIKE :name)' : 'true', {
        name: `%${searchWord}%`,
      })
      .andWhere(`org.status <> '${OrganizationStatus.Deleted}'`)
      .orderBy(`org.${sort}`, order)
      .addOrderBy(`org.${SortOptions.Created}`, order)
      .take(limit)
      .skip(page * limit);

    const isSuperAdminDoctor =
      this.roleManager.role === UserRole.SuperAdmin || this.roleManager.role === UserRole.Doctor;

    if (isSuperAdminDoctor) {
      query.addSelect('org.status').andWhere(status ? 'org.status = :status' : 'true', { status });
    } else if (this.roleManager.role === UserRole.Parent) {
      const player = await this.manager
        .getRepository(PlayerEntity)
        .createQueryBuilder('player')
        .leftJoinAndSelect('player.parent', 'parent')
        .where('player.user_id = :userId', { userId })
        .getOne();

      const isParent = Boolean(player.parents?.find((parent) => parent.id === this.roleManager.userId));

      if (!isParent) {
        throw new ForbiddenException('Not a parent of this player');
      }
    } else {
      query
        .leftJoin('org.users', 'user')
        .andWhere('user.id = :userId', {
          userId,
        })
        .andWhere('org.status = :activeStatus', {
          activeStatus: OrganizationStatus.Active,
        });
    }

    return await query.getManyAndCount().catch((err) => {
      throw new UnprocessableEntityException(err.message);
    });
  }

  async findByUserId(userId: string): Promise<OrganizationEntity[]> {
    return this.repository
      .createQueryBuilder('org')
      .innerJoin('org.users', 'user', 'user.id = :userId', { userId })
      .getMany();
  }

  async getOrganizationUserHaveAccessTo(organizationIds: string[]): Promise<string[]> {
    if (this.roleManager.role === UserRole.SuperAdmin) {
      return organizationIds;
    } else {
      const organizations = await this.repository
        .createQueryBuilder('org')
        .leftJoin('org.users', 'user')
        .where('user.id = :userId', { userId: this.roleManager.userId })
        .getMany();

      return organizations.filter((organization) => organizationIds.includes(organization.id)).map((value) => value.id);
    }
  }

  async isOrganizationExist(findCondition: FindOneOptions<OrganizationEntity>): Promise<Partial<OrganizationEntity>> {
    const { where, select = [] } = findCondition;
    const organization = await this.repository.findOne({ where, select: [...select, 'id'] }).catch((err) => {
      throw new UnprocessableEntityException(err.message);
    });
    return organization;
  }

  async findIfOrgsExist(organizationIds: string[]): Promise<boolean> {
    const orgs = await this.repository.find({ where: { id: In(organizationIds) } });

    return Boolean(orgs.length);
  }

  async isOrganizationNameExists(name: string, id: string): Promise<boolean> {
    const organization = await this.repository.findOne({ where: { name, id: Not(id) } }).catch((err) => {
      throw new UnprocessableEntityException(err.message);
    });

    return Boolean(organization);
  }

  async deleteOne(organization: OrganizationEntity): Promise<void> {
    await this.repository.update(organization, { status: OrganizationStatus.Deleted }).catch((err) => {
      throw new UnprocessableEntityException(err.message);
    });

    return;
  }

  saveMany(entities: DeepPartial<OrganizationEntity[]>): Promise<OrganizationEntity[]> {
    return this.repository.save(entities);
  }

  createOne(entityLike: DeepPartial<OrganizationEntity>): OrganizationEntity {
    return this.repository.create(entityLike);
  }

  async createWondeSchool(school: CreateWondeSchool): Promise<OrganizationEntity> {
    const { id, establishmentNumber, ...rest } = school;
    const wondeSchool = this.manager
      .getRepository(WondeSchoolEntity)
      .create({ ...rest, wondeId: id, lastUpdate: new Date(), establishmentNumber });

    return await this.repository.save({ ...rest, wondeSchool, type: OrganizationType.School });
  }

  async findWondeSchools(condition?: FindConditions<OrganizationEntity>): Promise<OrganizationEntity[]> {
    return this.repository.find({
      join: { innerJoin: { wondeSchool: 'org.wondeSchool' }, alias: 'org' },
      where: condition,
    });
  }

  async findAllIds(): Promise<OrganizationEntity[]> {
    return this.repository.find({ select: ['id'] }).catch((err) => {
      throw new UnprocessableEntityException(err.message);
    });
  }

  async update2FA(id: string, body: Edit2Fa): Promise<OrganizationEntity> {
    const { is2FA } = body;
    const updateTransaction = async (runner: QueryRunner): Promise<void> => {
      await runner.manager.update(OrganizationEntity, id, { is2FA });

      return;
    };
    return await this.runTransaction(updateTransaction);
  }
}

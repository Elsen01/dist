import { UserRequest } from '../../shared/user-request.interface';
import { OrganizationEntity } from '../entities/organization.entity';

export type OrganizationsRequest<
  P extends Record<string, any> | string[] = Record<string, any>,
  ResBody = any,
  ReqBody = any,
  ReqQuery = Record<string, any>
> = UserRequest<P, ResBody, ReqBody, ReqQuery> & {
  context: { organizations: ReadonlyArray<OrganizationEntity> };
};

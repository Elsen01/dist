import { PaginationDto } from './../../shared/shared.dto';
import { OrganizationType, SortOptions } from './../types';
import { IsEnum, IsOptional, IsString, MaxLength, MinLength } from 'class-validator';
import { OrganizationStatus } from '../types';
import { Order } from '../../shared/types';

export class FiltersQuery extends PaginationDto {
  @IsEnum(SortOptions)
  @IsOptional()
  sort? = SortOptions.Status;

  @IsEnum(Order)
  @IsOptional()
  order? = Order.ASC;

  @IsEnum(OrganizationStatus)
  @IsOptional()
  status?: OrganizationStatus;

  @IsEnum(OrganizationType)
  @IsOptional()
  type?: OrganizationType;

  @IsString()
  @MinLength(1)
  @MaxLength(100)
  @IsOptional()
  searchWord?: string;
}

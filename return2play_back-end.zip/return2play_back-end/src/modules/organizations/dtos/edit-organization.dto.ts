import { OrganizationStatus, OrganizationType, SchoolType } from './../types';
import {
  IsBoolean,
  IsEmail,
  IsEnum,
  IsNotEmpty,
  IsOptional,
  IsString,
  IsUrl,
  Matches,
  MaxLength,
  MinLength,
  ValidateIf,
} from 'class-validator';
import { ApiPropertyOptional } from '@nestjs/swagger';
import { PHONE_REGEXP } from '../../shared/constants';
import { IFile } from '../../shared/helpers/s3bucket/types';

export class EditOrganizationBody {
  @IsNotEmpty()
  @MaxLength(100)
  @MinLength(1)
  name: string;

  @IsEnum(OrganizationType)
  type: OrganizationType;

  @IsEnum(OrganizationStatus)
  status: OrganizationStatus;

  @IsEmail()
  @IsOptional()
  email?: string;

  @IsNotEmpty()
  @IsOptional()
  address1?: string;

  @IsNotEmpty()
  @IsOptional()
  address2?: string;

  @MaxLength(11)
  @MinLength(2)
  @IsOptional()
  postcode?: string;

  @MaxLength(100)
  @MinLength(1)
  @IsOptional()
  town?: string;

  @MaxLength(100)
  @MinLength(2)
  @IsOptional()
  county?: string;

  @MaxLength(100)
  @MinLength(2)
  @IsOptional()
  country?: string;

  @Matches(PHONE_REGEXP)
  @IsOptional()
  phone?: string;

  @MaxLength(1000)
  @IsUrl()
  @IsOptional()
  website?: string;

  @MaxLength(255)
  @MinLength(2)
  @IsString()
  @IsOptional()
  keyContactName?: string;

  @MaxLength(255)
  @MinLength(2)
  @IsString()
  @IsOptional()
  keyContactEmail?: string;

  @MaxLength(255)
  @MinLength(2)
  @IsString()
  @IsOptional()
  keyContactRole?: string;

  @ValidateIf((o) => o.type === OrganizationType.School)
  @IsEnum(SchoolType)
  schoolType?: SchoolType;

  @ApiPropertyOptional({ type: 'file' })
  @IsOptional()
  logo?: any;

  @IsOptional()
  iSAMSUrl?: string;

  @IsOptional()
  iSAMSKey?: string;
}

export class Edit2Fa {
  @IsBoolean()
  is2FA: boolean;
}

export type EditOrganization = Exclude<EditOrganizationBody, 'logo'> & {
  id: string;
  logo: IFile | string;
};

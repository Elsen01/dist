/* eslint-disable no-console */
import {
  CallHandler,
  ExecutionContext,
  Injectable,
  NestInterceptor,
  NotFoundException,
  UnprocessableEntityException,
} from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { Observable } from 'rxjs';
import { OrganizationsService } from '../organizations.service';
import { In } from 'typeorm';
import { UserRequest } from '../../shared/user-request.interface';
import { UserRole } from '../../users/types';
import { OrganizationEntity } from '../entities/organization.entity';
import { OrganizationStatus } from '../types';

const ORGANIZATIONS_BODY_KEY = 'ids';

@Injectable()
export class OrganizationsInterceptor implements NestInterceptor {
  constructor(private readonly service: OrganizationsService, private reflector: Reflector) {}

  async intercept(context: ExecutionContext, next: CallHandler): Promise<Observable<any>> {
    const request = context.switchToHttp().getRequest<UserRequest>();

    const ids = (request.body as { [ORGANIZATIONS_BODY_KEY]: Array<string> })[ORGANIZATIONS_BODY_KEY];

    if (ids === undefined || !ids.length) {
      throw new UnprocessableEntityException(`Please set 'ids' (organization ids) field to body`);
    }

    request.context.organizations = await this.findOrganizationOrFail(ids, request);

    return next.handle();
  }

  private async findOrganizationOrFail(
    ids: Array<string>,
    request: UserRequest
  ): Promise<ReadonlyArray<OrganizationEntity>> {
    const organizations =
      request.user.role === UserRole.SuperAdmin
        ? await this.service.find({ where: { id: In(ids), status: OrganizationStatus.Active } })
        : await this.service.findByIdsAndUserId(request.user.userId, ids);

    const notFoundOrganizationIds = ids.reduce((arr, id) => {
      if (!organizations.some((organization) => organization.id === id)) {
        arr.push(id);
      }

      return arr;
    }, []);

    if (notFoundOrganizationIds.length) {
      throw new NotFoundException(`Organizations with ids: ['${notFoundOrganizationIds.join(', ')}'] not found`);
    }

    return organizations;
  }
}

import { UnprocessableEntityException } from '@nestjs/common';
import { AbstractRepository, EntityRepository } from 'typeorm';
import { SportEntity } from './entities/sport.entity';

@EntityRepository(SportEntity)
export class SportRepository extends AbstractRepository<SportEntity> {
  async findSportList(): Promise<SportEntity[]> {
    return await this.repository
      .createQueryBuilder('sport')
      .leftJoinAndSelect('sport.injuryMechanisms', 'mechanism')
      .orderBy('sport.name', 'ASC')
      .addOrderBy('mechanism.name', 'ASC')
      .getMany()
      .catch((err) => {
        throw new UnprocessableEntityException(err.message);
      });
  }

  async findAllSportIds(): Promise<SportEntity[]> {
    return this.repository.find({ select: ['id'] }).catch((err) => {
      throw new UnprocessableEntityException(err.message);
    });
  }
}

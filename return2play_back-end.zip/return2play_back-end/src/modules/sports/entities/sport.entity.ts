import { InjuryMechanismEntity } from '../../injuries/entities/injuryMechanism.entity';
import { Column, CreateDateColumn, Entity, ManyToMany, PrimaryGeneratedColumn, UpdateDateColumn } from 'typeorm';

@Entity('sports')
export class SportEntity {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ length: 255 })
  name: string;

  @Column({ name: 'protective_headgear', nullable: true })
  protectiveHeadgear: boolean;

  @Column({ name: 'mouthguard', nullable: true })
  mouthguard: boolean;

  @ManyToMany(() => InjuryMechanismEntity, (injuryMechanism) => injuryMechanism.sports)
  injuryMechanisms: InjuryMechanismEntity[];

  @CreateDateColumn({ name: 'created_at' })
  createdAt: Date;

  @UpdateDateColumn({ name: 'updated_at' })
  updatedAt: Date;
}

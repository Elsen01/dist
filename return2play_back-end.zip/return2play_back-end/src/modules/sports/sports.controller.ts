import { SportsService } from './sports.service';
import { Controller, Get, UseGuards } from '@nestjs/common';
import { SportEntity } from './entities/sport.entity';
import {
  ApiBearerAuth,
  ApiForbiddenResponse,
  ApiOkResponse,
  ApiOperation,
  ApiTags,
  ApiUnprocessableEntityResponse,
} from '@nestjs/swagger';
import { CognitoGuard } from '../shared/guards/cognito.guard';
import { RolesGuard } from '../shared/guards/roles.guard';
import { ALL_ROLES } from '../users/types';
import { Roles } from '../shared/decorators/roles.decorator';
import { GET_SPORT_LISTS } from './swagger';

@ApiTags('Sports')
@UseGuards(CognitoGuard, RolesGuard)
@Roles(...ALL_ROLES)
@ApiBearerAuth()
@Controller('sports')
export class SportsController {
  constructor(private service: SportsService) {}

  @ApiOperation(GET_SPORT_LISTS.OPERATION)
  @ApiOkResponse(GET_SPORT_LISTS.SUCCESS)
  @ApiUnprocessableEntityResponse(GET_SPORT_LISTS.FAILURE)
  @ApiForbiddenResponse(GET_SPORT_LISTS.FORBIDDEN)
  @Get()
  async getSportList(): Promise<SportEntity[]> {
    return await this.service.getSportList();
  }
}

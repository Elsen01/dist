import { IDocumentedEndpoint } from '../shared/interfaces/swagger.interface';

export const GET_SPORT_LISTS: IDocumentedEndpoint = {
  OPERATION: {
    description:
      'Get list of all `Sports` and their `Mechanisms` within the system. All users roles are allowed to perform this action',
  },
  SUCCESS: {
    description: '`Success` Sports list are returned',
  },
  FORBIDDEN: {
    description: '`API` User has no permissions to get sports list',
  },
  FAILURE: {
    description: '`API` Select entity from the database failed',
  },
};

import { SportRepository } from './sport.repository';
import { Injectable } from '@nestjs/common';
import { SportEntity } from './entities/sport.entity';

@Injectable()
export class SportsService {
  constructor(private sportRepo: SportRepository) {}

  async getSportList(): Promise<SportEntity[]> {
    return await this.sportRepo.findSportList();
  }
}

import { SportRepository } from './sport.repository';
import { Module } from '@nestjs/common';
import { SportsService } from './sports.service';
import { SportsController } from './sports.controller';
import { TypeOrmModule } from '@nestjs/typeorm';
import { SharedModule } from '../shared/shared.module';

@Module({
  providers: [SportsService],
  controllers: [SportsController],
  imports: [TypeOrmModule.forFeature([SportRepository]), SharedModule],
})
export class SportsModule {}

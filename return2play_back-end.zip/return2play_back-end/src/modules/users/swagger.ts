import { IDocumentedEndpoint } from '../shared/interfaces/swagger.interface';

export const CREATE_ONE: IDocumentedEndpoint = {
  OPERATION: {
    description:
      'Create a new user within the system. Only super admins and organization admins are allowed to perform this action',
  },
  SUCCESS: {
    description: '`Success` User was created',
  },
  ORGANIZATION_NOT_FOUND: {
    description: '`API` Provided organizations do not exist or organization admin has no access to it',
  },
  USER_EXISTS: {
    description: '`API` User with provided email already exists',
  },
  FORBIDDEN: {
    description: '`API` User has no permissions to create other user',
  },
  FAILURE: {
    description: '`API` Saved entity to the database failed',
  },
};

export const EDIT_ONE: IDocumentedEndpoint = {
  OPERATION: {
    description:
      '`Super admin` and `admin of particular organization` are allowed to edit information. If a property is not provided it stays the same',
  },
  SUCCESS: {
    description: '`Success` User was updated',
  },
  NOT_FOUND: {
    description: '`API` User with provided id does not exist or provided organizations do not exist',
  },
  USER_EXISTS: {
    description: '`API` Other user with this email already exists',
  },
  EXTERNAL_ERROR: {
    description: '`Cognito` External error',
  },
  FORBIDDEN: {
    description: '`API` User has no permissions to update the user',
  },
};

export const EDIT_PROFILE_ME: IDocumentedEndpoint = {
  OPERATION: {
    description:
      '`Super admin`, ` organization admin` or `staff user` are allowed to edit information about there profile.',
  },
  SUCCESS: {
    description: '`Success` User was updated',
  },
  FORBIDDEN: {
    description: '`API` User has no permissions to update the user',
  },

  FAILURE: {
    description: '`API` Update entity to the database failed',
  },
};

export const GET_MANY: IDocumentedEndpoint = {
  OPERATION: {
    description:
      '`Super admin` is allowed to fetch all of users which meet provided filters. `Admin of particular organization` is allowed to get users related to them',
  },
  SUCCESS: {
    description: '`Success` List of users filtered by provided constraints',
  },
  FAILURE: {
    description: '`API` Error occurs during fetching list',
  },
  NOT_FOUND: {
    description: '`API` Users are not found within the system',
  },
};

export const GET_ONE: IDocumentedEndpoint = {
  OPERATION: {
    description:
      'Get details about particular user. Only `super admin` and `admin of particular organization` are allowed to see information',
  },
  SUCCESS: {
    description: '`Success` User info is returned',
  },
  FAILURE: {
    description: '`API` Error occurs during select an entity',
  },
  NOT_FOUND: {
    description: '`API` User are not found within the system',
  },
};

export const DELETE_ONE: IDocumentedEndpoint = {
  OPERATION: {
    description:
      'Change status of particular user to `Deleted`. Only `super admin` and `admin of particular organization` are allowed to delete user',
  },
  SUCCESS: {
    description: '`Success` User successfully deleted',
  },
  FAILURE: {
    description: '`API` Error occurs during delete an entity',
  },
  NOT_FOUND: {
    description: '`API` User are not found within the system',
  },
  FORBIDDEN: {
    description: '`API` User has no permissions to delete the user',
  },
};

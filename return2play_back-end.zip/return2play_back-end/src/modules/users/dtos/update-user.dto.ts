import { UpdateUserRole, UserRole, UserStatus } from './../types';
import {
  ArrayMinSize,
  IsArray,
  IsEmail,
  IsEnum,
  IsNotEmpty,
  IsOptional,
  IsUUID,
  Matches,
  MaxLength,
  MinLength,
  ValidateNested,
} from 'class-validator';
import { Type } from 'class-transformer';
import { NewTag } from './create-user.dto';
import { NAME_REGEXP } from '../../shared/constants';

export class UpdateUserBody {
  @IsArray()
  @ArrayMinSize(1)
  @IsUUID('all', { each: true })
  organizationIds: string[];

  @IsEmail()
  @MinLength(7)
  @MaxLength(255)
  email: string;

  @IsNotEmpty()
  @MinLength(1)
  @MaxLength(128)
  @Matches(NAME_REGEXP)
  firstName: string;

  @IsNotEmpty()
  @MinLength(1)
  @MaxLength(128)
  @Matches(NAME_REGEXP)
  lastName: string;

  @IsEnum(UpdateUserRole)
  @IsOptional()
  role?: UserRole;

  @IsEnum(UserStatus)
  status: UserStatus;

  @IsUUID('all', { each: true })
  @IsOptional()
  tagIds?: string[];

  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => NewTag)
  @IsOptional()
  newTags?: NewTag[];
}

export class UpdateProfileBody {
  @IsNotEmpty()
  @MinLength(1)
  @MaxLength(128)
  @Matches(NAME_REGEXP)
  firstName: string;

  @IsNotEmpty()
  @MinLength(1)
  @MaxLength(128)
  @Matches(NAME_REGEXP)
  lastName: string;
}

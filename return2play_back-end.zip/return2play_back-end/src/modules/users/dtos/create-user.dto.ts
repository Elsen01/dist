import { Type } from 'class-transformer';
import {
  IsArray,
  IsEmail,
  IsEnum,
  IsNotEmpty,
  IsOptional,
  IsString,
  IsUUID,
  Matches,
  MaxLength,
  MinLength,
  ValidateNested,
} from 'class-validator';
import { NAME_REGEXP } from '../../shared/constants';
import { UserRole } from '../types';

export class CreateUserBody {
  @IsArray()
  @IsUUID('all', { each: true })
  organizationIds: string[];

  @IsEmail()
  @MinLength(7)
  @MaxLength(255)
  email: string;

  @IsNotEmpty()
  @MinLength(1)
  @MaxLength(128)
  @Matches(NAME_REGEXP)
  firstName: string;

  @IsNotEmpty()
  @MinLength(1)
  @MaxLength(128)
  @Matches(NAME_REGEXP)
  lastName: string;

  @IsEnum(UserRole)
  role: UserRole;

  @IsUUID('all', { each: true })
  @IsOptional()
  tagIds?: string[];

  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => NewTag)
  @IsOptional()
  newTags?: NewTag[];
}

export class NewTag {
  @IsUUID()
  organizationId: string;

  @IsString()
  @MinLength(1)
  @MaxLength(255)
  @IsOptional()
  name: string;
}

import { PaginationDto } from './../../shared/shared.dto';
import { UserRole, UserSortOptions, UserStatus } from './../types';
import { IsEnum, IsOptional, IsString, IsUUID, MaxLength, MinLength } from 'class-validator';
import { Order } from '../../shared/types';

export class FiltersQuery extends PaginationDto {
  @IsEnum(UserSortOptions)
  @IsOptional()
  sort? = UserSortOptions.Status;

  @IsEnum(Order)
  @IsOptional()
  order? = Order.ASC;

  @IsEnum(UserStatus)
  @IsOptional()
  status?: UserStatus;

  @IsString()
  @MinLength(1)
  @MaxLength(100)
  @IsOptional()
  searchWord?: string;

  @IsEnum(UserRole, { each: true })
  @IsOptional()
  roles?: UserRole[];

  @IsUUID('all', { each: true })
  @IsOptional()
  tagIds?: string[];

  @IsUUID('all', { each: true })
  @IsOptional()
  organizationIds?: string[];
}

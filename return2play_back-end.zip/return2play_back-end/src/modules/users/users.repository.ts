import { UpdateProfileBody } from './dtos/update-user.dto';
import { UpdateDoctorBody } from './../doctors/dtos/edit-doctor.dto';
import { RoleManager } from './../shared/helpers/accessManager/role.manager';
import {
  EntityRepository,
  FindConditions,
  FindManyOptions,
  getRepository,
  QueryRunner,
  SelectQueryBuilder,
} from 'typeorm';
import { NotFoundException, UnprocessableEntityException, ForbiddenException } from '@nestjs/common';
import { PermissionManager } from '../shared/helpers/accessManager/permission.manager';
import { UserEntity } from './entities/user.entity';
import { OrganizationEntity } from '../organizations/entities/organization.entity';
import { stringToArray } from '../shared/utils/common.utils';
import { UserRole, UserStatus } from './types';
import { OrganizationStatus } from '../organizations/types';
import { FiltersQuery } from './dtos/find-user.dto';
import { BaseRepository } from '../shared/base.repository';
import { Membership } from '../players/types';
import { RegistrationBody } from '../auth/dtos/registration.dto';
import { PlayerEntity } from '../players/entities/player.entity';
import { TagEntity } from '../tags/entities/tag.entity';
import { LoginBody, LoginResponse } from '../auth/dtos/login.dto';

@EntityRepository(UserEntity)
export class UserRepository extends BaseRepository<UserEntity> {
  private readonly roleManager = RoleManager.getInstance();

  async findIfUserExits(condition: FindConditions<UserEntity>): Promise<UserEntity> {
    const user = await this.repository.findOne({ where: condition, select: ['id', 'email'] }).catch((err) => {
      throw new UnprocessableEntityException(err.message);
    });

    return user;
  }

  async findIfUserExitsCaseInsensitive(email: string): Promise<UserEntity> {
    const user = await this.repository
      .createQueryBuilder('user')
      .select(['id', 'email'])
      .where(`user.email ILIKE '${email}'`)
      .getOne()
      .catch((err) => {
        throw new UnprocessableEntityException(err.message);
      });

    return user;
  }

  async findByEmail2(email: string, body: Partial<UserEntity>): Promise<UserEntity | void> {
    const updatedUserEntity = await this.repository.save(body);
    return updatedUserEntity;
  }

  async findByEmail(email: string): Promise<UserEntity> {
    if (!email) {
      return null;
    }

    return this.repository
      .createQueryBuilder('user')
      .addSelect('user.status')
      .where('user.email = :email', { email })
      .orWhere('user.email = :emailLower', { emailLower: email.toLowerCase() })
      .getOne()
      .catch((err) => {
        throw new UnprocessableEntityException(err.message);
      });
  }

  async findManyByEmail(email: string): Promise<UserEntity[]> {
    return this.repository.find({ where: { email } }).catch((err) => {
      throw new UnprocessableEntityException(err.message);
    });
  }

  async findByEmailWithStatus(email: string): Promise<UserEntity[]> {
    return this.repository
      .createQueryBuilder('user')
      .addSelect('user.status')
      .leftJoinAndSelect('user.organizations', 'organizations')
      .addSelect('organizations.is_2FA')
      .where('user.email = :email', { email })
      .orWhere('user.email = :emailLower', { emailLower: email.toLowerCase() })
      .orWhere('UPPER(user.email) = :emailUpper', { emailUpper: email.toUpperCase() })
      .getMany();
  }

  async create(user: UserEntity): Promise<UserEntity> {
    const organizations = await this.getOrganizationsByRole(
      this.roleManager.role,
      this.roleManager.userId,
      user.organizations
    );

    const newUser = this.repository.create({
      ...user,
      organizations,
    });

    return await this.repository.save(newUser).catch((err) => {
      throw new UnprocessableEntityException(err.message);
    });
  }

  async createParents(users: UserEntity[]): Promise<UserEntity[]> {
    const newUsers = this.repository.create(users);

    return this.repository.save(newUsers).catch((err) => {
      throw new UnprocessableEntityException(err.message);
    });
  }

  async createPlayers(users: UserEntity[], organizationIds: string[]): Promise<UserEntity[]> {
    const orgs = await this.getRepositoryFor(OrganizationEntity)
      .createQueryBuilder('org')
      .where('org.id IN (:...organizationIds)', { organizationIds })
      .getMany();

    const organizations = await this.getOrganizationsByRole(this.roleManager.role, this.roleManager.userId, orgs);

    if (!orgs.length) {
      throw new NotFoundException('Organization not found');
    }

    const usersBodies = users.map((user) => {
      const userOrganization = Array.isArray(user.organizations)
        ? [...user.organizations, ...organizations]
        : organizations;

      return { ...user, role: UserRole.Player, organizations: userOrganization };
    });
    const newUsers = this.repository.create(usersBodies);

    return this.repository.save(newUsers).catch((err) => {
      throw new UnprocessableEntityException(err.message);
    });
  }

  async updateDoctor(id: string, user: UpdateDoctorBody): Promise<void> {
    await this.repository.save({ id, ...user }).catch((err) => {
      throw new UnprocessableEntityException(err.message);
    });

    return;
  }

  async createPlayer(user: RegistrationBody & { id: string }): Promise<UserEntity> {
    const savePlayer = async (runner: QueryRunner): Promise<UserEntity> => {
      const newUser = await runner.manager
        .getRepository(UserEntity)
        .save({
          ...user,
          role: UserRole.Player,
          status: UserStatus.Active,
        })
        .catch((err) => {
          throw new UnprocessableEntityException(err.message);
        });

      await runner.manager
        .getRepository(PlayerEntity)
        .save({ userId: user.id, membership: Membership.NonMember, user: newUser });

      return newUser;
    };

    return this.runTransaction(savePlayer);
  }

  async activateUser(email: string): Promise<void> {
    await this.repository.update({ email }, { status: UserStatus.Active }).catch((err) => {
      throw new UnprocessableEntityException(err.message);
    });

    return;
  }

  async update(user: UserEntity): Promise<UserEntity> {
    const organizations = await this.getOrganizationsByRole(
      this.roleManager.role,
      this.roleManager.userId,
      user.organizations
    );

    if (!organizations.length) {
      throw new NotFoundException('Organization not found');
    }

    const newUser = this.repository.create({
      ...user,
      organizations,
    });

    return await this.repository.save(newUser).catch((err) => {
      throw new UnprocessableEntityException(err.message);
    });
  }

  async updateMe(body: UpdateProfileBody): Promise<void> {
    await this.repository.update(this.roleManager.userId, { ...body }).catch((err) => {
      throw new UnprocessableEntityException(err.message);
    });

    return;
  }

  async findMany(filterQuery: FiltersQuery): Promise<[UserEntity[], number]> {
    const query = this.getBaseQueryToFindMany(filterQuery);

    if (this.roleManager.role !== UserRole.SuperAdmin) {
      const orgIds = stringToArray(await this.getOrganizationIds(this.roleManager.userId));

      const allowedOrgIds = filterQuery.organizationIds?.length
        ? orgIds.filter((id) => filterQuery.organizationIds.includes(id))
        : orgIds;

      query.andWhere('org.id IN (:...orgIds)', {
        orgIds: allowedOrgIds,
      });
    }

    const users = await query.getManyAndCount().catch((err) => {
      throw new UnprocessableEntityException(err.message);
    });

    return users;
  }

  findManyByCondition(condition: FindManyOptions<UserEntity>): Promise<UserEntity[]> {
    return this.repository.find(condition).catch((err) => {
      throw new UnprocessableEntityException(err.message);
    });
  }

  async findOne(userId: string): Promise<any> {
    try {
      const selectColumns = PermissionManager.getPlayerSelectColumn();

      const userQuery = this.createQueryBuilder('user')
        .addSelect(['org.id', 'org.name', 'user.status', 'tagOrg.id', ...selectColumns])
        .leftJoin('user.organizations', 'org')
        .leftJoinAndSelect('user.tags', 'tags')
        .leftJoin('tags.organization', 'tagOrg')
        .leftJoinAndSelect('user.player', 'player')
        .leftJoinAndSelect('user.children', 'children')
        .leftJoinAndSelect('user.doctor', 'doctor')
        .where('user.id = :userId', { userId });

      if (this.roleManager.role !== UserRole.SuperAdmin) {
        const orgIds = await this.getOrganizationIds(this.roleManager.userId);

        userQuery.andWhere('org.id IN (:...orgIds)', { orgIds });
      }
      const user = await userQuery.getOne();

      const children = (await userQuery.getOne()).children;

      const childrenUserIds = children.map((child) => child.userId);

      const childUsers = await this.repository.findByIds(childrenUserIds);
      // console.log({ childUsers });

      const playerChildren: any[] = childUsers.map((children) => children);
      // console.log({ playerChildren });

      user.children = playerChildren; // Assign the array of PlayerEntity objects to user.children

      // console.log({ user });

      // console.log('Childd:', childUsers);

      // const childrenWithUserDetails = children.map((child) => ({
      //   ...child,
      //   user: childUsers.find((user) => user.id === child.userId),
      // }));

      // console.log('CHILD DETAILS:', childrenWithUserDetails);

      return user;

      // return await userQuery.getOne().catch((err) => {
      //   throw new UnprocessableEntityException(err.message);
      // });
    } catch (err) {
      throw new UnprocessableEntityException(err.message);
    }
  }

  async deleteOne(id: string): Promise<void> {
    if (this.roleManager.role !== UserRole.SuperAdmin) {
      const orgIds = await this.getOrganizationIds(this.roleManager.userId);

      await this.createQueryBuilder('user')
        .leftJoin('user.organizations', 'org')
        .where('user.id = :userId', { userId: id })
        .andWhere('org.id IN (:...orgIds)', { orgIds })
        .getOneOrFail()
        .catch(() => {
          throw new ForbiddenException('This user has no permissions to delete a user of this organization');
        });
    }

    await this.repository.update(id, { status: UserStatus.Deleted }).catch((err) => {
      throw new UnprocessableEntityException(err.message);
    });

    return;
  }

  async findByToken(token: number): Promise<UserEntity[]> {
    return this.repository.find({ token: token });
  }

  async updateToken(body: LoginBody, token: number, tokenExpiresAt: Date): Promise<void> {
    await this.repository
      .update({ email: body.email }, { token: token, tokenExpiresAt: tokenExpiresAt })
      .catch((err) => {
        throw new UnprocessableEntityException(err.message);
      });
    return;
  }

  async updateAuthTokens(body: LoginBody, loginResponse: LoginResponse): Promise<void> {
    await this.repository
      .update(
        { email: body.email },
        {
          idToken: loginResponse.idToken,
          accessToken: loginResponse.accessToken,
          refreshToken: loginResponse.refreshToken,
        }
      )
      .catch((err) => {
        throw new UnprocessableEntityException(err.message);
      });
    return;
  }

  async deleteAuthTokens(email: string): Promise<void> {
    await this.repository
      .update(
        { email: email },
        {
          idToken: '',
          accessToken: '',
          refreshToken: '',
          token: 0,
        }
      )
      .catch((err) => {
        throw new UnprocessableEntityException(err.message);
      });
    return;
  }

  async findById(id: string): Promise<UserEntity> {
    return await this.repository.findOne(id).catch((err) => {
      throw new UnprocessableEntityException(err.message);
    });
  }

  async findMe(): Promise<UserEntity> {
    return await this.createQueryBuilder('user')
      .addSelect(['player.membership', 'user.status'])
      .leftJoinAndSelect('user.player', 'player')
      .leftJoinAndSelect('user.doctor', 'doctor')
      .leftJoinAndSelect('user.organizations', 'org')
      .leftJoinAndSelect('user.tags', 'tags')
      .where('user.id = :id', { id: this.roleManager.userId })
      .andWhere('user.status != :status', { status: UserStatus.Deleted })
      .getOne();
  }

  async findMe2Fa(): Promise<UserEntity> {
    return await this.createQueryBuilder('user')
      .addSelect(['player.membership', 'user.status'])
      .leftJoinAndSelect('user.player', 'player')
      .leftJoinAndSelect('user.doctor', 'doctor')
      .leftJoinAndSelect('user.organizations', 'org')
      .leftJoinAndSelect('user.tags', 'tags')
      .where('user.id = :id', { id: this.roleManager.userId })
      .andWhere('user.status != :status', { status: UserStatus.Deleted })
      .getOne();
  }

  async getChildrenIds(parentId: string): Promise<string[]> {
    const parent = await this.repository
      .createQueryBuilder('user')
      .leftJoinAndSelect('user.children', 'children')
      .where('user.id = :parentId', { parentId })
      .getOne()
      .catch((err) => {
        throw new UnprocessableEntityException(err.message);
      });

    return parent?.children?.map((child) => child.userId) ?? [];
  }

  async findManyPlayerByEmail(emails: string[]): Promise<UserEntity[]> {
    return this.repository
      .createQueryBuilder('user')
      .leftJoinAndSelect('user.player', 'player')
      .leftJoinAndSelect('user.wondeStudent', 'wondeStudent')
      .where('user.email IN (:...emails)', { emails })
      .andWhere('user.role = :playerRole', { playerRole: UserRole.Player })
      .getMany();
  }

  async findByFistLastNamesAndDoBString(namesDobString: string[], orgId: string): Promise<UserEntity[]> {
    return (
      this.repository
        .createQueryBuilder('u')
        .leftJoin('u.organizations', 'o')
        .leftJoinAndSelect('u.wondeStudent', 'wondeStudent')
        // eslint-disable-next-line no-use-before-define
        .where("concat(u.first_name, ' ', u.last_name,' ', u.birthday) IN (:...namesDobString)", { namesDobString })
        .andWhere('o.id = :orgId', { orgId })
        .getMany()
    );
  }

  private getBaseQueryToFindMany(filterQuery: FiltersQuery): SelectQueryBuilder<UserEntity> {
    const { limit, page, order, sort, searchWord, status, roles, organizationIds, tagIds } = filterQuery;

    const rolesToFind = this.getRolesToFind(roles) || [];
    const organizationIdArray = stringToArray(organizationIds) || [];

    const tagIdArray = stringToArray(tagIds) || [];

    const sortColumn = PermissionManager.getSortOptionUser(sort);

    const [firstName, lastName] = searchWord ? searchWord?.split(' ', 2) : '';

    const tagSubquery = this.manager
      .getRepository(TagEntity)
      .createQueryBuilder('tag')
      .select('user.id')
      .leftJoin('tag.users', 'user')
      .where('tag.id IN (:...tagIds)', {
        tagIds: tagIdArray,
      });

    return this.createQueryBuilder('user')
      .addSelect(['org.id', 'org.name', 'user.status', 'tagOrg.id'])
      .leftJoin('user.organizations', 'org')
      .leftJoinAndSelect('user.tags', 'tag')
      .leftJoin('tag.organization', 'tagOrg')
      .where('user.status != :userStatus', { userStatus: UserStatus.Deleted })
      .andWhere(rolesToFind.length ? 'user.role IN (:...roles)' : 'true', {
        roles: rolesToFind,
      })
      .andWhere('(org.status = :orgStatus OR org.status IS NULL)', {
        orgStatus: OrganizationStatus.Active,
      })
      .andWhere(
        searchWord
          ? `(to_tsvector('simple', f_concat_ws(' ', user.firstName , user.lastName))
          @@ plainto_tsquery('simple', :searchWord) OR user.firstName ILIKE :searchWord OR user.lastName ILIKE :searchWord OR 
          (user.firstName ILIKE :firstName AND user.lastName ILIKE :lastName) OR (user.lastName ILIKE :firstName AND user.firstName ILIKE :lastName))`
          : 'true',
        {
          searchWord: `%${searchWord}%`,
          firstName: `%${firstName}%`,
          lastName: `%${lastName}%`,
        }
      )
      .andWhere(status ? 'user.status = :status' : 'true', { status })
      .andWhere(organizationIdArray.length ? 'org.id IN (:...orgIds)' : 'true', {
        orgIds: organizationIdArray,
      })
      .andWhere(tagIds?.length ? `user.id IN (${tagSubquery.getQuery()})` : 'true')
      .orderBy(`user.${sortColumn}`, order)
      .addOrderBy('user.lastName', 'ASC')
      .addOrderBy('user.createdAt', 'DESC')
      .take(limit)
      .skip(page * limit)
      .setParameters(tagSubquery.getParameters());
  }

  private async getOrganizationIds(userId: string): Promise<string[]> {
    const res = await this.getRepositoryFor(OrganizationEntity)
      .createQueryBuilder('org')
      .select('org.id')
      .leftJoin('org.users', 'user')
      .where('user.id = :userId', { userId })
      .getMany()
      .catch((err) => {
        throw new UnprocessableEntityException(err.message);
      });

    return res.map((org) => org.id);
  }

  private getRolesToFind(rolesToFind: UserRole | UserRole[]): UserRole[] {
    const rolesPermittedToFind = PermissionManager.getPermittedRolesToView(this.roleManager.role);

    if (typeof rolesToFind === 'string') {
      return rolesPermittedToFind.filter((r) => r === rolesToFind);
    }

    const roles = rolesToFind?.length
      ? rolesToFind.filter((role) => rolesPermittedToFind.includes(role))
      : rolesPermittedToFind;

    return roles;
  }

  private async getOrganizationsByRole(
    role: UserRole,
    creatorId: string,
    organizations: OrganizationEntity[]
  ): Promise<OrganizationEntity[]> {
    const organizationIds = organizations && organizations.length ? organizations.map((org) => org.id) : [];

    if (role === UserRole.SuperAdmin || !role) {
      return organizations;
    } else {
      return await getRepository(OrganizationEntity)
        .createQueryBuilder('org')
        .select('org.id')
        .leftJoin('org.users', 'user')
        .where('user.id = :id', { id: creatorId })
        .andWhere(organizationIds.length ? 'org.id IN(:...organizationIds)' : 'true', {
          organizationIds,
        })
        .getMany()
        .catch((err) => {
          throw new UnprocessableEntityException(err.message);
        });
    }
  }
}

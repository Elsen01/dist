import { EDIT_ONE, CREATE_ONE, GET_MANY, GET_ONE, DELETE_ONE, EDIT_PROFILE_ME } from './swagger';
import { UpdateProfileBody, UpdateUserBody } from './dtos/update-user.dto';
import {
  Body,
  Controller,
  Delete,
  Get,
  HttpCode,
  HttpStatus,
  Param,
  Post,
  Put,
  Query,
  UseGuards,
} from '@nestjs/common';
import {
  ApiBearerAuth,
  ApiConflictResponse,
  ApiForbiddenResponse,
  ApiNoContentResponse,
  ApiNotFoundResponse,
  ApiOkResponse,
  ApiOperation,
  ApiServiceUnavailableResponse,
  ApiTags,
  ApiUnprocessableEntityResponse,
} from '@nestjs/swagger';
import { Roles } from '../shared/decorators/roles.decorator';
import { CognitoGuard } from '../shared/guards/cognito.guard';
import { RolesGuard } from '../shared/guards/roles.guard';
import { CreateUserBody } from './dtos/create-user.dto';
import { UserRole } from './types';
import { UsersService } from './users.service';
import { IdDto } from '../shared/shared.dto';
import { UserEntity } from './entities/user.entity';
import { FiltersQuery } from './dtos/find-user.dto';
import { FindManyResponse } from '../shared/types';

@ApiTags('Users')
@UseGuards(CognitoGuard, RolesGuard)
@Roles(UserRole.SuperAdmin, UserRole.OrganizationAdmin, UserRole.MedicalStaff)
@ApiBearerAuth()
@Controller('users')
export class UsersController {
  constructor(private service: UsersService) {}

  @ApiOperation(CREATE_ONE.OPERATION)
  @ApiNoContentResponse(CREATE_ONE.SUCCESS)
  @ApiForbiddenResponse(CREATE_ONE.FORBIDDEN)
  @ApiUnprocessableEntityResponse(CREATE_ONE.FAILURE)
  @ApiConflictResponse(CREATE_ONE.USER_EXISTS)
  @ApiNotFoundResponse(CREATE_ONE.ORGANIZATION_NOT_FOUND)
  @HttpCode(HttpStatus.NO_CONTENT)
  @Post()
  async createOne(@Body() body: CreateUserBody): Promise<void> {
    await this.service.createOne(body);
    return;
  }

  @ApiOperation(EDIT_ONE.OPERATION)
  @ApiNoContentResponse(EDIT_ONE.SUCCESS)
  @ApiNotFoundResponse(EDIT_ONE.NOT_FOUND)
  @ApiConflictResponse(EDIT_ONE.USER_EXISTS)
  @ApiServiceUnavailableResponse(EDIT_ONE.EXTERNAL_ERROR)
  @ApiForbiddenResponse(EDIT_ONE.FORBIDDEN)
  @HttpCode(HttpStatus.NO_CONTENT)
  @Put('/:id')
  updateOne(@Param() param: IdDto, @Body() body: UpdateUserBody): Promise<void> {
    return this.service.updateOne(param.id, body);
  }

  @ApiOperation(EDIT_PROFILE_ME.OPERATION)
  @ApiNoContentResponse(EDIT_PROFILE_ME.SUCCESS)
  @ApiForbiddenResponse(EDIT_PROFILE_ME.FORBIDDEN)
  @ApiUnprocessableEntityResponse(EDIT_PROFILE_ME.FAILURE)
  @HttpCode(HttpStatus.NO_CONTENT)
  @Roles(UserRole.StaffUser, UserRole.Parent, UserRole.Player, UserRole.Doctor)
  @Put('/profile/me')
  updateMe(@Body() body: UpdateProfileBody): Promise<void> {
    return this.service.updateMe(body);
  }

  @ApiOperation(GET_MANY.OPERATION)
  @ApiOkResponse(GET_MANY.SUCCESS)
  @ApiUnprocessableEntityResponse(GET_MANY.FAILURE)
  @ApiNotFoundResponse(GET_MANY.NOT_FOUND)
  @HttpCode(HttpStatus.OK)
  @Get()
  findMany(@Query() query: FiltersQuery): Promise<FindManyResponse<UserEntity>> {
    return this.service.findMany(query);
  }

  @ApiOperation(GET_ONE.OPERATION)
  @ApiOkResponse(GET_ONE.SUCCESS)
  @ApiUnprocessableEntityResponse(GET_ONE.FAILURE)
  @ApiNotFoundResponse(GET_ONE.NOT_FOUND)
  @Get('/:id')
  findOne(@Param() param: IdDto): Promise<UserEntity> {
    return this.service.findOne(param.id);
  }

  @ApiOperation(DELETE_ONE.OPERATION)
  @ApiNoContentResponse(DELETE_ONE.SUCCESS)
  @ApiUnprocessableEntityResponse(DELETE_ONE.FAILURE)
  @ApiNotFoundResponse(DELETE_ONE.NOT_FOUND)
  @ApiForbiddenResponse(DELETE_ONE.FORBIDDEN)
  @HttpCode(HttpStatus.NO_CONTENT)
  @Delete('/:id')
  deleteOne(@Param() param: IdDto): Promise<void> {
    return this.service.deleteOne(param.id);
  }
}

import { plainToClass } from 'class-transformer';
import { TagRepository } from './../tags/tags.repository';
import { UpdateProfileBody, UpdateUserBody } from './dtos/update-user.dto';
import { UserRepository } from './users.repository';
import {
  ConflictException,
  Injectable,
  ForbiddenException,
  NotFoundException,
  HttpException,
  Inject,
  Logger,
  LoggerService,
  UnprocessableEntityException,
  HttpStatus,
} from '@nestjs/common';
import AWS from 'aws-sdk';
import { InjectRepository } from '@nestjs/typeorm';
import { CreateUserBody } from './dtos/create-user.dto';
import { CognitoManager } from '../shared/helpers/cognito/cognito.manager';
import { PermissionManager } from '../shared/helpers/accessManager/permission.manager';
import { DeepPartial, FindConditions, FindManyOptions, Not, QueryRunner, Repository } from 'typeorm';
import { UserEntity } from './entities/user.entity';
import { FiltersQuery } from './dtos/find-user.dto';
import { FindManyResponse } from '../shared/types';
import { getEntityInstance } from '../shared/utils/common.utils';
import { UserRole } from './types';
import { OrganizationEntity } from '../organizations/entities/organization.entity';
import { AppConfigService } from '../../config/config.service';

@Injectable()
export class UsersService {
  constructor(
    @InjectRepository(UserRepository)
    private userRepo: UserRepository,
    private configService: AppConfigService,
    private cognitoManager: CognitoManager,
    @Inject(Logger) private logger: LoggerService,
    private tagRepo: TagRepository,
    // NEW VERSION
    @InjectRepository(UserEntity)
    private readonly repository: Repository<UserEntity>
  ) {}

  async createOne(requestBody: CreateUserBody): Promise<UserEntity> {
    const { email, role, newTags, tagIds: tags, organizationIds } = requestBody;

    if (role === UserRole.Doctor || role === UserRole.Player) {
      this.logger.error(`Can not create user ${email} with role doctor or player.`);

      const errorObject = {
        statusCode: HttpStatus.UNPROCESSABLE_ENTITY,
        field: 'role',
        message: 'Can not create user with role doctor or player',
      };
      throw new UnprocessableEntityException(errorObject);
    }
    const isUserExists = await this.userRepo.findIfUserExitsCaseInsensitive(email);

    if (isUserExists) {
      this.logger.error(`${email} is already stored`);

      const errorObject = {
        statusCode: HttpStatus.CONFLICT,
        field: 'email',
        message: `User with email ${email} already exists`,
      };
      throw new ConflictException(errorObject);
    }

    const isHasPermission = PermissionManager.isHasPermissionToCreateUser(role);

    if (!isHasPermission) {
      this.logger.error(`User ${role} is not allowed to create user`);
      throw new ForbiddenException('This user has no permissions to create user');
    }

    const cognitoUser = await this.cognitoManager.adminCreateUser(email).catch((err) => {
      throw new UnprocessableEntityException(err.message);
    });
    const id = cognitoUser.User.Username;

    try {
      await this.cognitoManager.addUserToUserGroup(id, role);

      const createNew = async (runner: QueryRunner): Promise<UserEntity> => {
        const organizations = organizationIds.map((id) => getEntityInstance(id, OrganizationEntity));

        const tagsToSave = await this.tagRepo.getTags(runner, tags || [], newTags);
        const userEntity = plainToClass(UserEntity, {
          ...requestBody,
          tags: tagsToSave,
          id,
          organizations: organizations?.length ? organizations : null,
        });

        return runner.manager.getCustomRepository(UserRepository).create(userEntity);
      };

      return await this.userRepo.runTransaction(createNew);
    } catch (err) {
      await this.cognitoManager.adminDeleteUser(id);
      this.logger.error(err);
      throw err;
    }
  }

  async updateByEmailForExistingUser(body: Partial<UserEntity>): Promise<UserEntity | void> {
    const result = await this.userRepo.findByEmail2(body.email, body);
    return result;
  }

  async updateOne(userId: string, requestBody: UpdateUserBody): Promise<void> {
    const { email, role, tagIds: tags, newTags, organizationIds } = requestBody;

    const user = await this.userRepo.findById(userId);
    if (!user) {
      this.logger.error(`User ${userId} doesn't exist`);
      throw new NotFoundException('User with this id does not exist');
    }

    const isUserEmailExists = await this.userRepo.findIfUserExits({
      email,
      id: Not(userId),
    });
    if (isUserEmailExists) {
      this.logger.error(`User with ${email} is already registered`);

      const errorObject = {
        statusCode: HttpStatus.CONFLICT,
        field: 'email',
        message: `User with email ${email} already exists`,
      };
      throw new ConflictException(errorObject);
    }

    let oldGroup = role;
    const isExistInCognito = await this.cognitoManager.adminGetUser(user.id).catch(() => false);

    if (user.role !== role && isExistInCognito) {
      oldGroup = await this.cognitoManager.removeUserFromCurrentUserGroup(userId);

      await this.cognitoManager.addUserToUserGroup(userId, role).catch((err) => {
        this.logger.error(`Failed adding user ${userId} to ${role}`);
        this.onFailCognitoUserGroupUpdate(userId, oldGroup, err);
      });
    }

    try {
      const createNew = async (runner: QueryRunner): Promise<void> => {
        const organizations = organizationIds.map((id) => getEntityInstance(id, OrganizationEntity));
        const tagsToSave = await this.tagRepo.getTags(runner, tags, newTags);
        const userEntity = runner.manager.create(UserEntity, {
          ...requestBody,
          tags: tagsToSave,
          id: userId,
          organizations,
        });

        await runner.manager.getCustomRepository(UserRepository).update(userEntity);
      };

      await this.userRepo.runTransaction(createNew);
      return;
    } catch (err) {
      this.logger.error(`Failed update user ${userId}`);
      oldGroup !== role ? this.onFailDatabaseUpdate(userId, oldGroup, err) : null;
    }
  }

  async updateMe(body: UpdateProfileBody): Promise<void> {
    this.userRepo.updateMe(body);
  }

  async findMany(query: FiltersQuery): Promise<FindManyResponse<UserEntity>> {
    const usersResponse = await this.userRepo.findMany(query);
    const data = usersResponse[0];
    return { data, totalItems: usersResponse[1] };
  }

  find(options: FindManyOptions<UserEntity>): Promise<ReadonlyArray<UserEntity>> {
    return this.repository.find(options);
  }

  findOneByOptions(options: FindConditions<UserEntity>): Promise<UserEntity> {
    return this.repository.findOne(options);
  }

  async findOne(userId: string): Promise<any> {
    const user = await this.userRepo.findOne(userId);

    if (!user) {
      this.logger.error(`User ${userId} is not found`);
      throw new NotFoundException('User not found');
    }

    const isHasPermission = PermissionManager.isHasPermissionToGetForUsersPage(user.role);

    if (!isHasPermission) {
      this.logger.error(`User ${user.id} is not allowed to retrieve user`);
      throw new ForbiddenException('This user has no permissions to get user');
    }

    return user;
  }

  async deleteOne(userId: string): Promise<void> {
    const userToDelete = await this.userRepo.findById(userId);

    if (!userToDelete) {
      this.logger.error(`User ${userId} doesn't exist`);
      throw new NotFoundException('User not found');
    }

    const isHasPermission = PermissionManager.isHasPermissionToDelete(userToDelete.role);

    if (!isHasPermission) {
      this.logger.error(`User is not allowed to delete ${userToDelete.role}`);
      throw new ForbiddenException('This user has no permissions to delete user');
    }

    return this.userRepo.deleteOne(userToDelete.id);
  }

  private async onFailDatabaseUpdate(userId: string, oldGroup: string, err: AWS.AWSError): Promise<void> {
    await this.cognitoManager.removeUserFromCurrentUserGroup(userId);
    await this.cognitoManager.addUserToUserGroup(userId, oldGroup);
    throw err;
  }

  private async onFailCognitoUserGroupUpdate(userId: string, oldGroup: string, err: AWS.AWSError): Promise<void> {
    await this.cognitoManager.addUserToUserGroup(userId, oldGroup);
    throw new HttpException(err.message, err.statusCode);
  }

  saveOne(item: DeepPartial<UserEntity>): Promise<UserEntity> {
    return this.repository.save(item);
  }

  save(items: Array<UserEntity>): Promise<ReadonlyArray<UserEntity>> {
    return this.repository.save(items);
  }

  async findPlayersForOrganization(organizationId: OrganizationEntity['id']): Promise<UserEntity[]> {
    return this.repository
      .createQueryBuilder('user')
      .addSelect('user.status')
      .innerJoinAndSelect('user.player', 'player')
      .innerJoin('user.organizations', 'organization')
      .leftJoinAndSelect('player.parents', 'parents')
      .leftJoinAndSelect('player.additionalRecepients', 'additionalRecepient')
      .where('organization.id = :organizationId', { organizationId })
      .getMany();
  }

  // eslint-disable-next-line @typescript-eslint/explicit-function-return-type
  async isNotField(userId: string) {
    console.log({ userId });

    const data = await this.repository
      .createQueryBuilder('user')
      .innerJoinAndSelect('user.player', 'player')
      .where('user.id = :userId', { userId })
      .getOne();

    return data?.player?.deletedParents;

    // console.log({ data1 });

    // const data = this.repository
    //   .createQueryBuilder('user')
    //   .innerJoinAndSelect('user.player', 'player')
    //   .where('player.deletedParents != :empty AND user.id = :userId', { empty: '', userId })
    //   .getOne();

    // const test = await data;

    // console.log({ test });
    // console.log('type:', typeof (await data));

    // if (typeof data !== undefined) {
    //   return (await data)?.player.deletedParents;
    // }
  }

  async findPlayerByEmailOrFnOrLn({
    email,
    firstName,
    lastName,
  }: Pick<UserEntity, 'email' | 'firstName' | 'lastName'>): Promise<UserEntity[]> {
    const orWhere: string[] = [];

    if (email) {
      orWhere.push('user.email ILIKE :email');
    }

    if (firstName) {
      orWhere.push('user.firstName ILIKE :firstName');
    }

    if (lastName) {
      orWhere.push('user.lastName ILIKE :lastName');
    }

    return this.repository
      .createQueryBuilder('user')
      .select(['user.id', 'user.firstName', 'user.lastName', 'user.email', 'user.gender', 'user.birthday', 'user.role'])
      .addSelect(['player.userId', 'player.socsId', 'player.deletedParents'])
      .addSelect(['organization.id', 'organization.name'])
      .addSelect([
        'parent.id',
        'parent.firstName',
        'parent.lastName',
        'parent.email',
        'parent.gender',
        'parent.birthday',
        'parent.role',
      ])
      .addSelect([
        'additionalRecepient.id',
        'additionalRecepient.firstName',
        'additionalRecepient.lastName',
        'additionalRecepient.email',
      ])
      .innerJoin('user.player', 'player')
      .innerJoin('user.organizations', 'organization')
      .leftJoin('player.parents', 'parent')
      .leftJoin('player.additionalRecepients', 'additionalRecepient')
      .where('user.role = :userRole', { userRole: UserRole.Player })
      .andWhere(orWhere.join(' OR '), {
        email: email ? `%${email}%` : undefined,
        firstName,
        lastName,
      })
      .getMany();
  }
}

import { DoctorEntity } from './../../doctors/entities/doctor.entity';
import { TagEntity } from './../../tags/entities/tag.entity';
import { PlayerEntity } from './../../players/entities/player.entity';
import { UserRole, UserStatus } from './../types';
import {
  Column,
  CreateDateColumn,
  Entity,
  ManyToMany,
  OneToOne,
  PrimaryColumn,
  OneToMany,
  UpdateDateColumn,
} from 'typeorm';
import { Gender } from '../types';
import { OrganizationEntity } from '../../organizations/entities/organization.entity';
import { InjuryEntity } from '../../injuries/entities/injury.entity';
import { NoteEntity } from '../../notes/entities/note.entity';
import { WondeStudentEntity } from '../../players/entities/wondeStudent.entity';
import { IsamsFiltersTemplateEntity } from '../../isams/entities/isams-filters-template.entity';

@Entity('users')
export class UserEntity {
  @PrimaryColumn()
  id: string;

  @Column({ name: 'first_name', length: 100 })
  firstName: string;

  @Column({ name: 'last_name', length: 100 })
  lastName: string;

  @Column({ length: 255, nullable: true })
  email?: string;

  @Column({ type: 'enum', nullable: true, enum: Gender })
  gender?: Gender;

  @Column({ type: 'enum', enum: UserRole })
  role: UserRole;

  @Column({ type: 'date', nullable: true })
  birthday?: Date;

  @Column({ type: 'integer', nullable: true })
  token?: number;

  @Column({ type: 'timestamp', nullable: true })
  tokenExpiresAt?: Date;

  @Column({ type: 'text', nullable: true })
  idToken?: string;

  @Column({ type: 'text', nullable: true })
  accessToken?: string;

  @Column({ type: 'text', nullable: true })
  refreshToken?: string;

  @Column({
    type: 'enum',
    enum: UserStatus,
    default: UserStatus.Active,
    select: false,
  })
  status: UserStatus;

  @CreateDateColumn({ name: 'created_at' })
  createdAt: Date;

  @ManyToMany(() => OrganizationEntity, (organization) => organization.users, {
    eager: true,
    cascade: true,
  })
  organizations: OrganizationEntity[];

  @ManyToMany(() => PlayerEntity, (player) => player.parents)
  children?: PlayerEntity[];

  @ManyToMany(() => TagEntity, (tag) => tag.users, {
    eager: true,
    nullable: true,
    cascade: true,
  })
  tags: TagEntity[];

  @OneToOne(() => PlayerEntity, (player) => player.user, { cascade: true })
  player?: PlayerEntity;

  @OneToOne(() => DoctorEntity, (doctor) => doctor.user)
  doctor?: DoctorEntity;

  @OneToMany(() => InjuryEntity, (injury) => injury.user)
  injuries?: InjuryEntity[];

  @OneToMany(() => NoteEntity, (note) => note.author)
  notes?: NoteEntity[];

  @OneToOne(() => WondeStudentEntity, (wondeStudent) => wondeStudent.player, { cascade: true })
  wondeStudent?: WondeStudentEntity;

  @OneToMany(() => IsamsFiltersTemplateEntity, (isamsFiltersTemplate) => isamsFiltersTemplate.createdBy)
  isamsFiltersTemplates?: IsamsFiltersTemplateEntity[];

  @UpdateDateColumn({ name: 'updated_at' })
  updatedAt: Date;
}

import { UpdatePlayerBody } from '../players/dtos/edit-player.dto';
import { TagEntity } from '../tags/entities/tag.entity';
import { UpdateUserBody } from './dtos/update-user.dto';

export enum Gender {
  Female = 'Female',
  Male = 'Male',
}

export enum UserRole {
  SuperAdmin = 'super_admins',
  Player = 'players',
  Parent = 'parents',
  StaffUser = 'staff_users',
  OrganizationAdmin = 'organization_admins',
  Doctor = 'doctors',
  MedicalStaff = 'medical_staff',
}

export const ALL_ROLES = [
  UserRole.SuperAdmin,
  UserRole.Parent,
  UserRole.Player,
  UserRole.StaffUser,
  UserRole.OrganizationAdmin,
  UserRole.Doctor,
  UserRole.MedicalStaff,
];

export enum UserStatus {
  Active = 'Active',
  Inactive = 'Inactive',
  Deleted = 'Deleted',
}

export enum UserSortOptions {
  Email = 'email',
  Status = 'status',
  FirstName = 'firstName',
  LastName = 'lastName',
  Role = 'role',
  Created = 'createdAt',
}

export enum UpdateUserRole {
  StaffUser = 'staff_users',
  OrganizationAdmin = 'organization_admins',
  MedicalStaff = 'medical_staff',
}

export type UpdateUserType = (UpdateUserBody | UpdatePlayerBody | Partial<UpdateUserBody>) & {
  id: string;
  tags: TagEntity[];
};

export type CreateUser = {
  id: string;
  organizationIds: string[];
  email: string;
  firstName: string;
  lastName: string;
  role: UserRole;
  tags: TagEntity[];
};

import { InternalServerErrorException, UnprocessableEntityException } from '@nestjs/common';
import { plainToClass } from 'class-transformer';
import { sortBy } from 'lodash';
import { EntityRepository, SelectQueryBuilder } from 'typeorm';
import { CreatePlayerFromImportBody } from '../imports/dto/import-player.dto';
import { InjuryEntity } from '../injuries/entities/injury.entity';
import { OrganizationEntity } from '../organizations/entities/organization.entity';
import { BaseRepository } from '../shared/base.repository';
import { TWO_WEEKS } from '../shared/constants';
import { PermissionManager } from '../shared/helpers/accessManager/permission.manager';
import { RoleManager } from '../shared/helpers/accessManager/role.manager';
import { calculateYearGroup, isOrganizationAdminOrMedicalStaff, stringToArray } from '../shared/utils/common.utils';
import { UserRole, UserStatus } from '../users/types';
import { UserRepository } from '../users/users.repository';
import { InjuryGroup, InjuryStatus, PlayStatus } from './../injuries/types';
import { Order } from './../shared/types';
import { UserEntity } from './../users/entities/user.entity';
import { CreatePlayerBody } from './dtos/create-player.dto';
import { UpdateBulkPlayer, UpdatePlayerBody } from './dtos/edit-player.dto';
import { PlayerFiltersQuery } from './dtos/find-player.dto';
import { PlayerEntity } from './entities/player.entity';
import { InjuryTypeFilter, Membership, PlayerSortOptions } from './types';

@EntityRepository(PlayerEntity)
export class PlayerRepository extends BaseRepository<PlayerEntity> {
  private readonly roleManager = RoleManager.getInstance();

  async create(player: CreatePlayerBody & { user: UserEntity }): Promise<PlayerEntity> {
    return await this.repository.save(player).catch((err) => {
      throw new UnprocessableEntityException(err.message);
    });
  }

  async createMany(
    requestBody: (CreatePlayerFromImportBody & { id: string })[],
    organizationIds: string[]
  ): Promise<PlayerEntity[]> {
    try {
      const usersBodies = requestBody.map((player) => plainToClass(UserEntity, player));
      let users = await this.manager.getCustomRepository(UserRepository).createPlayers(usersBodies, organizationIds);
      users = sortBy(users, ({ email }) => email);

      requestBody = sortBy(requestBody, ({ email }) => email);
      const playersBodies = requestBody.map(({ id: userId, membership, wondeStudent, birthday, socsId }, i) => {
        const yearGroup = calculateYearGroup(birthday);

        return { userId, membership, yearGroup, wondeStudent, user: users[i], socsId };
      });

      return this.repository.save(playersBodies);
    } catch (err) {
      throw new UnprocessableEntityException(err.message);
    }
  }

  async updatePlayerRelationships(player: PlayerEntity, parents: UserEntity[]): Promise<void> {
    await this.repository.save({ ...player, parents }).catch((err) => {
      throw new UnprocessableEntityException(err.message);
    });
  }

  async isHasAccessToPlayer(playerId: string): Promise<boolean> {
    if (this.roleManager.role === UserRole.SuperAdmin) {
      return true;
    }

    if (isOrganizationAdminOrMedicalStaff(this.roleManager.role) || this.roleManager.role === UserRole.StaffUser) {
      const orgIds = await this.getOrganizationIds(this.roleManager.userId);

      const player = await this.createQueryBuilderFor(UserEntity, 'user')
        .select('user.id')
        .leftJoin('user.organizations', 'org')
        .where('user.id = :playerId', { playerId })
        .andWhere('org.id IN (:...orgIds)', { orgIds })
        .getOne();

      return Boolean(player);
    }

    if (this.roleManager.role === UserRole.Player) {
      return this.roleManager.userId === playerId;
    }

    if (this.roleManager.role === UserRole.Parent) {
      const player = await this.manager
        .getRepository(PlayerEntity)
        .createQueryBuilder('player')
        .leftJoinAndSelect('player.parents', 'parent')
        .where('player.user_id = :id', { id: playerId })
        .andWhere('parent.id = :parentId', { parentId: this.roleManager.userId })
        .getOne();

      return Boolean(player);
    }

    return false;
  }

  async update(player: UpdatePlayerBody & { user: UserEntity }): Promise<PlayerEntity> {
    const { id } = player.user;

    return await this.repository.save({ ...player, userId: id }).catch((err) => {
      throw new UnprocessableEntityException(err.message);
    });
  }

  async partialUpdate(id: string, player: Partial<PlayerEntity>): Promise<void> {
    await this.repository.update(id, { ...player });

    return;
  }

  async updateBulk(player: UpdateBulkPlayer): Promise<void> {
    const { membership, id } = player;
    await this.repository.save({ membership, userId: id });
  }

  async updateMany(players: PlayerEntity[]): Promise<void> {
    await this.repository.save(players).catch((err) => {
      throw new UnprocessableEntityException(err.message);
    });

    return;
  }

  async findById(id: string): Promise<PlayerEntity> {
    try {
      const selectColumns = PermissionManager.getSelectColumnsPlayer();

      const playerQuery = this.repository
        .createQueryBuilder('player')
        .addSelect([...selectColumns, 'org.id', 'org.name', 'tagOrg.id'])
        .leftJoinAndSelect('player.user', 'user')
        .leftJoinAndSelect('player.parents', 'parents')
        .leftJoinAndSelect('user.tags', 'tag')
        .leftJoinAndSelect('player.payments', 'payment')
        .leftJoin('user.organizations', 'org')
        .leftJoin('tag.organization', 'tagOrg')
        .where('player.userId = :userId', { userId: id })
        .andWhere('user.role = :role', { role: UserRole.Player })
        .orderBy('payment.createdAt', 'DESC');

      const isSuperAdminDoctor =
        this.roleManager.role === UserRole.SuperAdmin || this.roleManager.role === UserRole.Doctor;

      if (this.roleManager.role === UserRole.Parent) {
        const playerIds = await this.getPlayerIdsByParent(this.roleManager.userId);

        playerQuery.andWhere('user.id IN (:...playerIds) ', { playerIds });
      } else if (!isSuperAdminDoctor) {
        const orgIds = await this.getOrganizationIds(this.roleManager.userId);

        playerQuery.andWhere('org.id IN (:...orgIds)', { orgIds });
      }

      return await playerQuery.getOne();
    } catch (err) {
      throw new UnprocessableEntityException(err.message);
    }
  }

  async findMany(query: PlayerFiltersQuery): Promise<[PlayerEntity[], number]> {
    try {
      const playersQuery = await this.getBaseQueryToFindMany(query);

      const isParent = this.roleManager.role === UserRole.Parent;
      const isSuperAdmin = this.roleManager.role === UserRole.SuperAdmin;

      if (isParent) {
        const playerIds = await this.getPlayerIdsByParent(this.roleManager.userId);

        playersQuery.andWhere(playerIds.length ? 'user.id IN (:...playerIds)' : 'false', { playerIds });
      } else if (!isSuperAdmin) {
        const orgIds = stringToArray(await this.getOrganizationIds(this.roleManager.userId));

        const allowedOrgIds = query.organizationIds?.length
          ? orgIds.filter((id) => query.organizationIds.includes(id))
          : orgIds;

        playersQuery.andWhere('org.id IN (:...orgIds)', {
          orgIds: allowedOrgIds,
        });
        // This prevents tags from other orgs to be displayed
        const [players, totalItems] = await playersQuery.getManyAndCount();
        players.forEach(({ user }) => {
          if (user.tags.length) {
            user.tags = user.tags.filter((tag) => orgIds.includes(tag.organization.id));
          }
        });

        return [players, totalItems];
      }

      return playersQuery.getManyAndCount();
    } catch (err) {
      throw new UnprocessableEntityException(err.message);
    }
  }

  findOne(id: string): Promise<PlayerEntity> {
    return this.repository
      .createQueryBuilder('player')
      .addSelect(['player.membership'])
      .leftJoinAndSelect('player.user', 'user')
      .leftJoinAndSelect('user.organizations', 'org')
      .where('player.userId = :id', { id })
      .getOne();
  }

  async findByEmail(email: string): Promise<PlayerEntity> {
    return await this.repository
      .createQueryBuilder('player')
      .addSelect(['player.membership'])
      .leftJoinAndSelect('player.user', 'user')
      .where('user.email = :email', { email })
      .getOne();
  }

  async findIsHasOpenInjury(id: string): Promise<PlayerEntity> {
    return await this.repository
      .createQueryBuilder('player')
      .addSelect(['player.membership'])
      .leftJoinAndSelect('player.user', 'user')
      .leftJoinAndSelect('user.injuries', 'injury')
      .where('user.id = :id', { id })
      .andWhere('injury.injuryGroup = :concussion', { concussion: InjuryGroup.Concussion })
      .andWhere(`injury.status = '${InjuryStatus.Active}'`)
      .andWhere('(injury.playStatus <> :cleared', {
        cleared: PlayStatus.Cleared,
      })
      .andWhere('injury.playStatus <> :safe)', { safe: PlayStatus.Safe })
      .getOne()
      .catch((err) => {
        throw new InternalServerErrorException(err.message);
      });
  }

  findOneWithParentsByEmail(id: string): Promise<PlayerEntity> {
    return this.repository
      .createQueryBuilder('player')
      .leftJoinAndSelect('player.parents', 'parents')
      .leftJoinAndSelect('player.user', 'user')
      .where(`user.status != '${UserStatus.Deleted}'`)
      .andWhere('user.id = :id', { id })
      .getOne();
  }

  findManyForYearGroupUpdate(limit: number, page: number): Promise<PlayerEntity[]> {
    return this.repository
      .createQueryBuilder('player')
      .leftJoinAndSelect('player.user', 'user')
      .where('user.status = :active', { active: UserStatus.Active })
      .skip(page * limit)
      .take(limit)
      .getMany();
  }

  findManyForMembershipUpdate(limit: number, page: number): Promise<PlayerEntity[]> {
    return this.repository
      .createQueryBuilder('player')
      .leftJoinAndSelect('player.user', 'user')
      .where('user.status = :active', { active: UserStatus.Active })
      .andWhere('player.membership = :membership', { membership: Membership.Regular })
      .skip(page * limit)
      .take(limit)
      .getMany();
  }

  findTwoWeeksMembershipExpiration(limit: number, page: number): Promise<PlayerEntity[]> {
    return this.repository
      .createQueryBuilder('player')
      .leftJoinAndSelect('player.user', 'user')
      .where('user.status = :active', { active: UserStatus.Active })
      .andWhere('player.membership = :membership', { membership: Membership.Regular })
      .andWhere(`player.membership_expiration_date::date = current_date - interval '${TWO_WEEKS}' `)
      .skip(page * limit)
      .take(limit)
      .getMany();
  }

  private async getBaseQueryToFindMany(query: PlayerFiltersQuery): Promise<SelectQueryBuilder<PlayerEntity>> {
    const { organizationIds, searchWord, status, playStatus, page, limit, injuryType, sort, order, tagIds } = query;
    const organizationIdArray = stringToArray(organizationIds);
    const selectColumns = PermissionManager.getSelectColumnsPlayer();
    const sortColumn = PermissionManager.getSortOptionPlayer(sort);
    const injuryTypeArray = stringToArray(injuryType);
    const tagArray = stringToArray(tagIds);

    const [firstName, lastName] = searchWord ? searchWord?.split(' ', 2) : '';

    const filteredInjuryType = injuryTypeArray?.filter((type) => type !== InjuryTypeFilter.Concussion);
    const isFilterConcussionType = filteredInjuryType?.length !== injuryTypeArray?.length;

    let injuryTypeStringCondition: string;

    if (injuryTypeArray?.length) {
      if (!isFilterConcussionType) {
        injuryTypeStringCondition = 'otherInjury.type IN (:...injuryTypeArray)';
      } else {
        injuryTypeStringCondition = filteredInjuryType?.length
          ? `(otherInjury.type IN (:...injuryTypeArray) OR injury.injuryGroup = '${InjuryGroup.Concussion}')`
          : `injury.injuryGroup = '${InjuryGroup.Concussion}'`;
      }
    } else {
      injuryTypeStringCondition = 'true';
    }

    const subQuery = this.manager
      .getRepository(UserEntity)
      .createQueryBuilder('user')
      .select('user.id')
      .distinctOn(['user.id'])
      .leftJoin('user.injuries', 'injury')
      .leftJoin('injury.otherInjury', 'otherInjury')
      .leftJoin('user.player', 'player')
      .orderBy('user.id')
      .addOrderBy('injury.accidentDate', 'DESC')
      .addOrderBy(PlayerSortOptions.PlayStatus, 'DESC')
      .where(`user.status != '${UserStatus.Deleted}'`)
      .andWhere(`user.role = '${UserRole.Player}'`)
      .andWhere(injuryTypeStringCondition, { injuryTypeArray: filteredInjuryType });

    if (sortColumn === PlayerSortOptions.LastName) {
      subQuery.addOrderBy(sortColumn, order);
    }

    const now = new Date();
    const sevenDaysAgo = new Date();
    sevenDaysAgo.setDate(now.getDate() - 7);
    const correctDate = sevenDaysAgo.toISOString().split('T')[0];

    const selectQuery = this.createQueryBuilder('player')
      .addSelect([...selectColumns, 'org.id', 'org.name', 'tagOrg.id'])
      .addSelect(
        `CASE WHEN injury.playStatus = '${PlayStatus.NotSafe}' and injury.injuryGroup = '${InjuryGroup.Concussion}' and injury.accidentDate >= '${correctDate}' THEN 1 ELSE null END`,
        'order1'
      )
      .addSelect(
        `CASE WHEN injury.playStatus = '${PlayStatus.NotSafe}' and injury.injuryGroup = '${InjuryGroup.HeadInjury}' and injury.accidentDate >= '${correctDate}' THEN 2 ELSE null END`,
        'order2'
      )
      .addSelect(
        `CASE WHEN injury.playStatus = '${PlayStatus.NotSafe}' and injury.injuryGroup = '${InjuryGroup.Concussion}' and injury.accidentDate < '${correctDate}' THEN 3 ELSE null END`,
        'order3'
      )
      .addSelect(
        `CASE WHEN injury.playStatus = '${PlayStatus.NotSafe}' and injury.injuryGroup = '${InjuryGroup.HeadInjury}' and injury.accidentDate < '${correctDate}' THEN 4 ELSE null END`,
        'order4'
      )
      .leftJoinAndSelect('player.user', 'user')
      .leftJoinAndSelect(
        'user.injuries',
        'injury',
        `injury.playStatus != '${PlayStatus.Cleared}' AND injury.playStatus != '${PlayStatus.Safe}'
          AND (injury.status = '${InjuryStatus.Active}' OR injury.status IS NULL)`
      )
      .leftJoinAndSelect('injury.otherInjury', 'otherInjury')
      .leftJoinAndSelect('injury.appointments', 'appointment')
      .leftJoinAndSelect('otherInjury.bodyRegion', 'bodyRegion')
      .leftJoinAndSelect('otherInjury.bodyPart', 'bodyPart')
      .leftJoinAndSelect('user.tags', 'tag')
      .leftJoin('user.organizations', 'org')
      .leftJoin('tag.organization', 'tagOrg')
      .where(`user.id IN (${subQuery.getQuery()})`)
      .andWhere(status ? 'user.status = :status' : 'true', { status })
      .andWhere(playStatus ? 'player.playStatus = :playStatus' : 'true', { playStatus })
      .andWhere(
        searchWord
          ? `(to_tsvector('simple', f_concat_ws(' ', user.firstName , user.lastName))
          @@ plainto_tsquery('simple', :searchWord) OR user.firstName ILIKE :searchWord OR user.lastName ILIKE :searchWord OR 
          (user.firstName ILIKE :firstName AND user.lastName ILIKE :lastName) OR (user.lastName ILIKE :firstName AND user.firstName ILIKE :lastName))`
          : 'true',
        {
          searchWord: `%${searchWord}%`,
          firstName: `%${firstName}%`,
          lastName: `%${lastName}%`,
        }
      )
      .andWhere(organizationIdArray?.length ? 'org.id IN (:...orgIds)' : 'true', {
        orgIds: organizationIdArray,
      })
      .andWhere(tagArray?.length ? 'tag.id IN (:...tags)' : 'true', {
        tags: tagArray,
      })
      .andWhere(injuryTypeStringCondition, { injuryTypeArray: filteredInjuryType })
      .orderBy({
        order1: 'ASC',
        order2: 'ASC',
        order3: 'ASC',
        order4: 'ASC',
      })
      .addOrderBy(PlayerSortOptions.PlayStatus, 'DESC')
      .addOrderBy(sortColumn, order)
      .take(limit)
      .skip(page * limit)
      .setParameters(subQuery.getParameters());
    return selectQuery;
  }

  async deleteOne(id: string): Promise<void> {
    await this.repository
      .createQueryBuilder()
      .update(UserEntity)
      .set({ status: UserStatus.Deleted })
      .where('id = :id', { id })
      .andWhere('role = :role', { role: UserRole.Player })
      .execute()
      .catch((err) => {
        throw new UnprocessableEntityException(err.message);
      });

    return;
  }

  async deleteMany(playerIds: string[]): Promise<void> {
    await this.repository
      .createQueryBuilder()
      .update(UserEntity)
      .set({ status: UserStatus.Deleted })
      .where('id IN (:...playerIds)', { playerIds })
      .andWhere('role = :role', { role: UserRole.Player })
      .execute()
      .catch((err) => {
        throw new UnprocessableEntityException(err.message);
      });

    return;
  }

  async findPlayersActiveInjury(playerIds: string[], order: Order): Promise<InjuryEntity[]> {
    const subQuery = this.manager
      .getRepository(InjuryEntity)
      .createQueryBuilder('injury')
      .select('injury.id')
      .leftJoin('injury.user', 'player')
      .orderBy('player.id')
      .addOrderBy('injury.accidentDate', order)
      .where(`injury.status = '${InjuryStatus.Active}'`)
      .andWhere('player.id IN (:...playerIds)', { playerIds })
      .andWhere('(injury.playStatus <> :cleared', {
        cleared: PlayStatus.Cleared,
      })
      .andWhere('injury.injuryGroup IN (:...injuryGroup)', {
        injuryGroup: [InjuryGroup.Concussion, InjuryGroup.HeadInjury],
      })
      .andWhere('injury.playStatus <> :safe)', { safe: PlayStatus.Safe });

    return (
      this.manager
        .getRepository(InjuryEntity)
        .createQueryBuilder('injury')
        .addSelect(['userDoctor.lastName', 'userDoctor.firstName'])
        .leftJoinAndSelect('injury.user', 'user')
        .leftJoinAndSelect('user.player', 'player')
        .leftJoinAndSelect('injury.appointments', 'appointment')
        .leftJoinAndSelect('appointment.timeSlot', 'timeSlot')
        .leftJoinAndSelect('timeSlot.clinic', 'clinic')
        .leftJoinAndSelect('clinic.doctor', 'doctor')
        .leftJoinAndSelect('clinic.timeSlots', 'timeslots')
        .leftJoin('doctor.user', 'userDoctor')
        .where('user.id IN (:...userIds)', { userIds: playerIds })
        .andWhere(`injury.id IN (${subQuery.getQuery()})`)
        // .andWhere('injury.injuryGroup = :injuryGroup', { injuryGroup: InjuryGroup.Concussion })
        .orderBy('injury.accidentDate', order)
        .addOrderBy('timeSlot.date')
        .setParameters(subQuery.getParameters())
        .getMany()
        .catch((err) => {
          throw new UnprocessableEntityException(err.message);
        })
    );
  }

  private async getPlayerIdsByParent(parentId: string): Promise<string[]> {
    const player = await this.createQueryBuilder('player')
      .leftJoin('player.parents', 'parent')
      .where('player_parent.parent_id = :parentId', { parentId })
      .getMany();

    return player.map((org) => org.userId);
  }

  private async getOrganizationIds(userId: string): Promise<string[]> {
    const res = await this.getRepositoryFor(OrganizationEntity)
      .createQueryBuilder('org')
      .select('org.id')
      .leftJoin('org.users', 'user')
      .where('user.id = :userId', { userId })
      .getMany()
      .catch((err) => {
        throw new UnprocessableEntityException(err.message);
      });

    return res.map((org) => org.id);
  }
}

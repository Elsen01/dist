import { IsEmail, IsUUID } from 'class-validator';

export class DeleteRelationBody {
  @IsUUID()
  playerId: string;

  @IsEmail()
  parentEmail: string;
}

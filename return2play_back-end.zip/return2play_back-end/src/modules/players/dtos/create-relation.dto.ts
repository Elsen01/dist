import { IsEmail, IsNotEmpty, IsOptional, IsString, IsUUID } from 'class-validator';

export class CreateRelationBody {
  @IsUUID()
  playerId: string;

  @IsEmail()
  parentEmail: string;

  @IsNotEmpty()
  @IsString()
  @IsOptional()
  parentFirstName?: string;

  @IsNotEmpty()
  @IsString()
  @IsOptional()
  parentLastName?: string;
}

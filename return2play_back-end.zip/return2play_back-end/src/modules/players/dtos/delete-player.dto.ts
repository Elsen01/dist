import { IsUUID } from 'class-validator';

export class DeleteManyBody {
  @IsUUID('all', { each: true })
  playerIds: string[];
}

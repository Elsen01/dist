import { Gender, UserStatus } from './../../users/types';
import { Membership, YearGroup } from './../types';
import {
  IsArray,
  IsDateString,
  IsEmail,
  IsEnum,
  IsNotEmpty,
  IsOptional,
  IsString,
  IsUUID,
  Matches,
  MaxLength,
  MinLength,
  ValidateNested,
} from 'class-validator';
import { Type } from 'class-transformer';
import { NewTag } from './create-player.dto';
import { NAME_REGEXP } from '../../shared/constants';

export class UpdatePlayerBody {
  @IsArray()
  @IsUUID('all', { each: true })
  organizationIds: string[];

  @IsNotEmpty()
  @MinLength(1)
  @MaxLength(128)
  @Matches(NAME_REGEXP)
  firstName: string;

  @IsNotEmpty()
  @MinLength(1)
  @MaxLength(128)
  @Matches(NAME_REGEXP)
  lastName: string;

  @IsEmail()
  @IsOptional()
  email?: string;

  @IsEnum(Membership)
  membership: Membership;

  @IsEnum(UserStatus)
  status: UserStatus;

  @IsDateString()
  birthday: Date;

  @IsEnum(Gender)
  gender: Gender;

  @IsString()
  @IsOptional()
  socsId?: string;

  @IsEnum(YearGroup)
  yearGroup: YearGroup;

  @IsUUID('all', { each: true })
  @IsOptional()
  tagIds?: string[];

  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => NewTag)
  @IsOptional()
  newTags?: NewTag[];
}

export class BulkUpdatePlayersBody {
  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => UpdateBulkPlayer)
  players: UpdateBulkPlayer[];
}

export class UpdateBulkPlayer {
  @IsUUID()
  id: string;

  @IsEnum(Membership)
  membership: Membership;
}

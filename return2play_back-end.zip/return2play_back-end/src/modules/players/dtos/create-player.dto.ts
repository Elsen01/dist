import { Gender } from './../../users/types';
import { CreateMembership, Membership } from './../types';
import {
  ArrayMinSize,
  IsArray,
  IsDateString,
  IsEmail,
  IsEnum,
  IsNotEmpty,
  IsOptional,
  IsString,
  IsUUID,
  Matches,
  MaxLength,
  MinLength,
  ValidateNested,
} from 'class-validator';
import { Type } from 'class-transformer';
import { ApiPropertyOptional } from '@nestjs/swagger';
import { NAME_REGEXP } from '../../shared/constants';

export class CreatePlayerBody {
  @IsArray()
  @ArrayMinSize(1)
  @IsUUID('all', { each: true })
  organizationIds: string[];

  @IsEmail()
  @MinLength(7)
  @MaxLength(255)
  @IsOptional()
  email?: string;

  @IsNotEmpty()
  @MinLength(1)
  @MaxLength(128)
  @Matches(NAME_REGEXP)
  firstName: string;

  @IsNotEmpty()
  @MinLength(1)
  @MaxLength(128)
  @Matches(NAME_REGEXP)
  lastName: string;

  @IsEnum(CreateMembership)
  membership: Membership;

  @IsDateString()
  birthday: Date;

  @IsEnum(Gender)
  gender: Gender;

  @IsString()
  @MinLength(2)
  @MaxLength(10)
  yearGroup: string;

  @IsString()
  @IsOptional()
  socsId?: string;

  @IsUUID('all', { each: true })
  @IsOptional()
  tagIds?: string[];

  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => NewTag)
  @IsOptional()
  newTags?: NewTag[];
}

export class NewTag {
  @IsUUID()
  organizationId: string;

  @IsString()
  @MinLength(1)
  @MaxLength(255)
  @IsOptional()
  name: string;
}

export class ImportCsvBody {
  @IsUUID('all', { each: true })
  ids: string[];

  @ApiPropertyOptional({ type: 'file' })
  @IsOptional()
  csv: any;
}

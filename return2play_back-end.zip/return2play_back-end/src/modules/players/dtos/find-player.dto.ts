import { Order } from './../../shared/types';
import { PlayStatus } from './../../injuries/types';
import { IsBooleanString, IsEnum, IsOptional, IsString, IsUUID, MaxLength, MinLength } from 'class-validator';
import { UserStatus } from '../../users/types';
import { PaginationDto } from '../../shared/shared.dto';
import { InjuryTypeFilter, PlayerSortOptions } from '../types';

export class PlayerFiltersQuery extends PaginationDto {
  @IsEnum(PlayerSortOptions)
  @IsOptional()
  sort? = PlayerSortOptions.LastName;

  @IsEnum(Order)
  @IsOptional()
  order? = Order.ASC;

  @IsEnum(UserStatus)
  @IsOptional()
  status?: UserStatus;

  @IsEnum(PlayStatus)
  @IsOptional()
  playStatus?: PlayStatus;

  @IsString()
  @MinLength(1)
  @MaxLength(100)
  @IsOptional()
  searchWord?: string;

  @IsUUID('all', { each: true })
  @IsOptional()
  tagIds?: string[];

  @IsEnum(InjuryTypeFilter, { each: true })
  @IsOptional()
  injuryType?: InjuryTypeFilter[];

  @IsUUID('all', { each: true })
  @IsOptional()
  organizationIds?: string[];

  @IsBooleanString()
  @IsOptional()
  orderByPlayStatus?: boolean;
}

export class DashboardQuery {
  @IsEnum(Order)
  @IsOptional()
  order? = Order.DESC;
}

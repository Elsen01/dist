import { IDocumentedEndpoint } from '../shared/interfaces/swagger.interface';

export const CREATE_ONE: IDocumentedEndpoint = {
  OPERATION: {
    description:
      'Create a new `Player` within the system. Only `super admins` and `organization admins` are allowed to perform this action',
  },
  SUCCESS: {
    description: '`Success` Player was created',
  },
  ORGANIZATION_NOT_FOUND: {
    description: '`API` Provided organizations do not exist or organization admin has no access to it',
  },
  USER_EXISTS: {
    description: '`API` User with provided email already exists',
  },
  FORBIDDEN: {
    description: '`API` User has no permissions to create player',
  },
  FAILURE: {
    description: '`API` Saved entity to the database failed',
  },
};

export const EDIT_ONE: IDocumentedEndpoint = {
  OPERATION: {
    description: '`Super admin` is allowed to edit information. If a property is not provided it stays the same',
  },
  SUCCESS: {
    description: '`Success` Player was updated',
  },
  NOT_FOUND: {
    description: '`API` Player with provided id does not exist or provided organizations do not exist',
  },
  FORBIDDEN: {
    description: '`API` User has no permissions to update the player',
  },
  FAILURE: {
    description: '`API` Saved entity to the database failed',
  },
};

export const CREATE_RELATION: IDocumentedEndpoint = {
  OPERATION: {
    description:
      'Create a new `Player - Parent` relation within the system. Only `super admins` and `organization admins of patricular ogranization` are allowed to perform this action',
  },
  SUCCESS: {
    description: '`Success` Relation was created',
  },
  RELATION_EXISTS: {
    description: '`API` Relation of these users already exists',
  },
  FORBIDDEN: {
    description: '`API` User has no permissions to create relation',
  },
  FAILURE: {
    description: '`API` Saved entity to the database failed',
  },
};

export const EDIT_MANY: IDocumentedEndpoint = {
  OPERATION: {
    description:
      '`Super admin` is allowed to edit status, tags and organization of many players. If a property is not provided it stays the same',
  },
  SUCCESS: {
    description: '`Success` Players were updated',
  },
  FORBIDDEN: {
    description: '`API` User has no permissions to update players',
  },
  FAILURE: {
    description: '`API` Saved entities to the database failed',
  },
};

export const GET_ONE: IDocumentedEndpoint = {
  OPERATION: {
    description: 'Get details about particular player.',
  },
  SUCCESS: {
    description: '`Success` Player info is returned',
  },
  FAILURE: {
    description: '`API` Error occurs during select an entity',
  },
  NOT_FOUND: {
    description: '`API` Player is not found within the system',
  },
  FORBIDDEN: {
    description: '`API` User has no permissions to get player',
  },
};

export const GET_MANY: IDocumentedEndpoint = {
  OPERATION: {
    description: 'Get list of players.',
  },
  SUCCESS: {
    description: '`Success` Players info is returned',
  },
  FAILURE: {
    description: '`API` Error occurs during select an entity',
  },
  NOT_FOUND: {
    description: '`API` Players are not found within the system',
  },
  FORBIDDEN: {
    description: '`API` User has no permissions to get players',
  },
};

export const DELETE_ONE: IDocumentedEndpoint = {
  OPERATION: {
    description: 'Delete player. Only `Super admin` can perform this action',
  },
  SUCCESS: {
    description: '`Success` Player was deleted',
  },
  FAILURE: {
    description: '`API` Error occurs during delete an entity',
  },
  FORBIDDEN: {
    description: '`API` User has no permissions to delete player',
  },
};

export const DELETE_RELATION: IDocumentedEndpoint = {
  OPERATION: {
    description:
      'Delete player-parent relation. Only `super admins` and `organization admins of patricular ogranization` are allowed to perform this action',
  },
  SUCCESS: {
    description: '`Success` Relation was deleted',
  },
  FORBIDDEN: {
    description: '`API` User has no permissions to delete relation',
  },
  FAILURE: {
    description: '`API` Error occurs during delete an entity',
  },
};

export const DELETE_MANY: IDocumentedEndpoint = {
  OPERATION: {
    description: 'Delete many players. Only `Super admin` can perform this action',
  },
  SUCCESS: {
    description: '`Success` Players were deleted',
  },
  FAILURE: {
    description: '`API` Error occurs during delete an entity',
  },
  FORBIDDEN: {
    description: '`API` User has no permissions to delete relation',
  },
};

export const GET_MY_DASHBOARD_DATA: IDocumentedEndpoint = {
  OPERATION: {
    description: '`Player` can get there own data or `Parent` his/shes children data for dashboard page.',
  },
  SUCCESS: {
    description: '`Success` Players information are returned',
  },
  FAILURE: {
    description: '`API` Error occurs during select an entity',
  },
  FORBIDDEN: {
    description: '`API` User has no permissions to get data',
  },
};

import { TagRepository } from './../tags/tags.repository';
import { PlayerRepository } from './player.repository';
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { PlayersController } from './players.controller';
import { PlayersService } from './players.service';
import { SharedModule } from '../shared/shared.module';
import { UserRepository } from '../users/users.repository';
import { UsersModule } from '../users/users.module';
import { RecipientsModule } from '../additional-recipients/recipients.module';
import { RecipientsService } from '../additional-recipients/recipients.service';
import { RecipientRepository } from '../additional-recipients/recipient.repository';
import { OrganizationRepository } from '../organizations/organizations.repository';
import { AwsSignManager } from '../shared/helpers/lambda/sign.manager';
import { OrganizationsModule } from '../organizations/organizations.module';
import { BullModule } from '@nestjs/bull';
import { IMPORT_PLAYERS_QUEUE_NAME } from './consts';
import { PlayersConsumer } from './players.consumer';

@Module({
  imports: [
    TypeOrmModule.forFeature([
      PlayerRepository,
      UserRepository,
      TagRepository,
      RecipientRepository,
      OrganizationRepository,
    ]),
    SharedModule,
    UsersModule,
    RecipientsModule,
    OrganizationsModule,
    BullModule.registerQueue({
      name: IMPORT_PLAYERS_QUEUE_NAME,
    }),
  ],
  controllers: [PlayersController],
  providers: [PlayersService, RecipientsService, AwsSignManager, PlayersConsumer],
})
export class PlayersModule {}

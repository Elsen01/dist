import { InjectQueue } from '@nestjs/bull';
import {
  ConflictException,
  ForbiddenException,
  HttpService,
  HttpStatus,
  Inject,
  Injectable,
  Logger,
  LoggerService,
  NotFoundException,
  UnprocessableEntityException,
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Queue } from 'bull';
import moment from 'moment';
import { FindOperator, In, QueryRunner } from 'typeorm';
import { v4 } from 'uuid';
import { AppConfigService } from '../../config/config.service';
import { AppointmentStatus } from '../appointments/types';
import { PlayerImportDto } from '../imports/dto/import-player.dto';
import { ILambdaResponse, lambdaImportUrl } from '../imports/types';
import { InjuryGroup } from '../injuries/types';
import { OrganizationEntity } from '../organizations/entities/organization.entity';
import { DEFAULT, S3_IMPORTS_FOLDER, TABLE_FORMATS } from '../shared/constants';
import { PermissionManager } from '../shared/helpers/accessManager/permission.manager';
import { CognitoManager } from '../shared/helpers/cognito/cognito.manager';
import { AwsSignManager } from '../shared/helpers/lambda/sign.manager';
import { S3BucketManager } from '../shared/helpers/s3bucket/s3bucket.manager';
import { IFile } from '../shared/helpers/s3bucket/types';
import { IUser } from '../shared/interfaces/request-user.interface';
import { FindManyResponse } from '../shared/types';
import { UserEntity } from '../users/entities/user.entity';
import { UserRepository } from '../users/users.repository';
import { InjuryEntity } from './../injuries/entities/injury.entity';
import { RoleManager } from './../shared/helpers/accessManager/role.manager';
import { calculateYearGroup, checkMembership, getEntityInstance } from './../shared/utils/common.utils';
import { TagRepository } from './../tags/tags.repository';
import { UserRole } from './../users/types';
import { UsersService } from './../users/users.service';
import { IMPORT_PLAYERS_COMMAND_START, IMPORT_PLAYERS_QUEUE_NAME } from './consts';
import { CreatePlayerBody } from './dtos/create-player.dto';
import { CreateRelationBody } from './dtos/create-relation.dto';
import { DeleteRelationBody } from './dtos/delete-relation.dto';
import { BulkUpdatePlayersBody, UpdatePlayerBody } from './dtos/edit-player.dto';
import { DashboardQuery, PlayerFiltersQuery } from './dtos/find-player.dto';
import { PlayerEntity } from './entities/player.entity';
import { getCriteriasForImport } from './helpers/get-criterias-for-import';
import { mapPlayersWithExistingUsers } from './helpers/map-players-with-existing-users';
import { PlayerRepository } from './player.repository';
import { OnePlayerResponse, PlayerParentPayer, StartImportData, YearGroup } from './types';

@Injectable()
export class PlayersService {
  constructor(
    @InjectRepository(PlayerRepository)
    private playerRepo: PlayerRepository,
    @InjectRepository(UserRepository)
    private userRepo: UserRepository,
    private configService: AppConfigService,
    private cognitoManager: CognitoManager,
    private tagRepo: TagRepository,
    @Inject(Logger) private logger: LoggerService,
    private userService: UsersService,
    private httpService: HttpService,
    private s3Bucket: S3BucketManager,
    private signManager: AwsSignManager,
    @InjectQueue(IMPORT_PLAYERS_QUEUE_NAME) private readonly queue: Queue
  ) {}

  private readonly roleManager = RoleManager.getInstance();

  async createOne(requestBody: CreatePlayerBody): Promise<any> {
    const { email, tagIds: tags, newTags, organizationIds } = requestBody;
    const isUserExists = email ? await this.userRepo.findIfUserExits({ email }) : false;

    if (isUserExists) {
      this.logger.error(`User with ${email} already exists`);

      const errorObject = {
        statusCode: HttpStatus.CONFLICT,
        field: 'email',
        message: `Player with email ${email} already exists`,
      };
      throw new ConflictException(errorObject);
    }

    const isHasPermission = PermissionManager.isHasPermissionToCreatePlayer();

    if (!isHasPermission) {
      this.logger.error('User is not allowed to create player');
      throw new ForbiddenException('This user has no permissions to create player');
    }

    const cognitoUser = email
      ? await this.cognitoManager.adminCreateUser(email).catch((err) => {
          throw new UnprocessableEntityException(err.message);
        })
      : null;
    const id = cognitoUser ? cognitoUser.User.Username : v4();

    try {
      if (email) {
        await this.cognitoManager.addUserToUserGroup(id, UserRole.Player);
      }
      const createNew = async (runner: QueryRunner): Promise<PlayerEntity> => {
        const tagsToSave = await this.tagRepo.getTags(runner, tags, newTags);
        const organizations = organizationIds.map((id) => getEntityInstance(id, OrganizationEntity));

        const userEntity = runner.manager.create(UserEntity, {
          ...requestBody,
          birthday: moment.parseZone(requestBody.birthday).format(),
          tags: tagsToSave,
          organizations,
          id,
          role: UserRole.Player,
        });
        const user = await runner.manager.save(UserEntity, userEntity);
        const playerEntity = runner.manager.create(PlayerEntity, {
          ...requestBody,
          user,
        });
        return await runner.manager.save(PlayerEntity, playerEntity);
      };
      return await this.playerRepo.runTransaction(createNew);
    } catch (err) {
      if (email) {
        await this.cognitoManager.adminDeleteUser(id);
      }
      throw new UnprocessableEntityException(err.message);
    }
  }

  async createRelationship(createRelationBody: CreateRelationBody): Promise<void> {
    const { playerId, parentEmail } = createRelationBody;
    const player = await this.getPlayerAndValidateRelationship(playerId);

    let newParent = await this.userRepo.findByEmail(parentEmail);

    if (!newParent) {
      newParent = await this.userService.createOne({
        email: parentEmail,
        role: UserRole.Parent,
        lastName: createRelationBody.parentLastName ?? DEFAULT,
        firstName: createRelationBody.parentFirstName ?? DEFAULT,
        organizationIds: [],
      });
    }

    if (newParent.role !== UserRole.Parent) {
      const errorObject = {
        statusCode: HttpStatus.UNPROCESSABLE_ENTITY,
        field: 'parentEmail',
        message: 'This Email cannot be used for a Parent account!',
      };
      throw new UnprocessableEntityException(errorObject);
    }

    let parents: UserEntity[] = player.parents || [];

    if (parents.find(({ id }) => id === newParent.id)) {
      const errorObject = {
        statusCode: HttpStatus.CONFLICT,
        field: 'parentEmail',
        message: 'Relation already exists',
      };
      throw new ConflictException(errorObject);
    }
    parents = [...parents, newParent];

    await this.playerRepo.updatePlayerRelationships(player, parents);
    await this.httpService
      .post(`http://${this.configService.aws.mailerHost}/player`, {
        playerId,
        parentId: newParent.id,
      })
      .toPromise();
  }

  async updateOne(userId: string, requestBody: UpdatePlayerBody): Promise<PlayerEntity> {
    const { tagIds: tags, newTags, organizationIds, email } = requestBody;
    const userToUpdate = await this.userRepo.findIfUserExits({
      id: userId,
      role: UserRole.Player,
    });
    if (!userToUpdate) {
      this.logger.error(`Player ${userId} does not exist`);
      throw new NotFoundException('Player with this id does not exist');
    }

    const oldTrimmedEmail = userToUpdate.email?.trim();
    const newTrimmedEmail = email?.trim();
    const isNewEmail = Boolean(newTrimmedEmail && newTrimmedEmail !== oldTrimmedEmail);

    const isEmailExist = await this.userRepo.findByEmail(email);

    if (isEmailExist && isEmailExist.id !== userId) {
      this.logger.error(`Player ${userId} already have an email`);
      throw new ConflictException('User with this email already exists');
    }

    const createNew = async (runner: QueryRunner): Promise<PlayerEntity> => {
      const tagsToSave = await this.tagRepo.getTags(runner, tags, newTags);
      const organizations = organizationIds.map((id) => getEntityInstance(id, OrganizationEntity));

      const userEntity = runner.manager.create(UserEntity, {
        ...requestBody,
        tags: tagsToSave,
        id: userId,
        role: UserRole.Player,
        organizations,
      });
      await runner.manager.save(UserEntity, userEntity);

      const playerEntity = runner.manager.create(PlayerEntity, { ...requestBody, userId });

      await runner.manager.update(PlayerEntity, { userId }, playerEntity);

      const cognitoUser = await this.cognitoManager.adminGetUser(userToUpdate.id).catch(async (err) => {
        if (isNewEmail && err.code === 'UserNotFoundException') {
          await this.cognitoManager.adminCreateUserFromMigration(email, userToUpdate.id);
          await this.cognitoManager.addUserToUserGroup(userToUpdate.id, UserRole.Player);
        }
      });

      if (cognitoUser && isNewEmail) {
        await this.cognitoManager.updateUserEmail(userToUpdate.id, email);
      }

      return;
    };

    return await this.playerRepo.runTransaction(createNew);
  }

  async updateBulk(updateBody: BulkUpdatePlayersBody): Promise<void> {
    const promises = updateBody.players.map((player) => this.playerRepo.updateBulk(player));

    await Promise.all(promises).catch((err) => {
      throw new UnprocessableEntityException(err.message);
    });
  }

  async findOne(id: string): Promise<OnePlayerResponse> {
    const isHasPermission = PermissionManager.isHasPermissionToGetPlayer();

    if (!isHasPermission) {
      this.logger.error(`User is not allowed to get player ${id}`);
      throw new ForbiddenException('This user has no permissions to get player');
    }

    const player = await this.playerRepo.findById(id);
    if (!player) {
      this.logger.error(`Player ${id} does not exist`);
      throw new NotFoundException('Player not found');
    }

    const parents: PlayerParentPayer[] = player.parents.map((parent) => {
      const isPayer = parent.email === player.payments[0]?.payerEmail;

      return { ...parent, isPayer };
    });

    const hasMembership = checkMembership(player.membership, player.membershipExpirationDate);

    player.parents = parents;

    return { ...player, hasMembership };
  }

  async findMany(query: PlayerFiltersQuery): Promise<FindManyResponse<PlayerEntity>> {
    const isHasPermission = PermissionManager.isHasPermissionToGetPlayer();

    if (!isHasPermission) {
      this.logger.error('User is not allowed to get players');
      throw new ForbiddenException('This user has no permissions to get players');
    }

    const [players, totalItems] = await this.playerRepo.findMany(query);

    const data = players.map((player) => {
      let bookedAppointment = '';
      const lastInjury = player.user.injuries[0];

      let lastInjuryAppointments = [];
      if (
        lastInjury?.injuryGroup === InjuryGroup.Concussion &&
        lastInjury.appointments &&
        lastInjury.appointments.length
      ) {
        lastInjuryAppointments = lastInjury.appointments.filter((appointment) => {
          return appointment.status !== AppointmentStatus.Completed;
        });
      }

      if (lastInjury?.injuryGroup === InjuryGroup.Concussion && lastInjuryAppointments.length) {
        bookedAppointment = 'Yes';
      } else if (lastInjury?.injuryGroup === InjuryGroup.Concussion && !lastInjuryAppointments.length) {
        bookedAppointment = 'No';
      }

      return {
        ...player,
        bookedAppointment,
      };
    });

    return { data, totalItems };
  }

  async deleteOne(id: string): Promise<void> {
    const isHasAccess = await this.playerRepo.isHasAccessToPlayer(id);

    if (!isHasAccess) {
      this.logger.error(`Admin has no access to player: ${id}`);
      throw new ForbiddenException('This user has no permission to delete given player');
    }

    return await this.playerRepo.deleteOne(id);
  }

  async deleteRelationship(deleteRelationBody: DeleteRelationBody): Promise<void> {
    const { playerId, parentEmail } = deleteRelationBody;
    const player = await this.getPlayerAndValidateRelationship(playerId);

    if (!player.deletedParents) {
      player.deletedParents = [];
    }

    // Now you can safely push parentEmail into deletedParents
    player.deletedParents.push(parentEmail.toLowerCase());

    const parent = await this.userRepo.findIfUserExits({ email: parentEmail, role: UserRole.Parent });
    if (!parent) {
      this.logger.error(`User ${parentEmail} does not exist`);
      throw new NotFoundException('User not found');
    }

    const oldParents: UserEntity[] = player.parents || [];
    const parents = oldParents.filter(({ email }) => email !== parentEmail);

    return this.playerRepo.updatePlayerRelationships(player, parents);
  }

  private async getPlayerAndValidateRelationship(id: string): Promise<PlayerEntity> {
    if (!this.playerRepo.isHasAccessToPlayer(id)) {
      this.logger.error('User has no permission to create/delete relation');
      throw new ForbiddenException('User has no permission to create/delete relation');
    }

    const player = await this.playerRepo.findOneWithParentsByEmail(id);
    if (!player) {
      this.logger.error(`Player ${id} does not exist`);
      throw new NotFoundException('Player not found');
    }

    return player;
  }

  async deleteMany(playerIds: string[]): Promise<void> {
    return await this.playerRepo.deleteMany(playerIds);
  }

  async getMyDashboardData(query: DashboardQuery): Promise<InjuryEntity[]> {
    try {
      const playerIds =
        this.roleManager.role === UserRole.Player
          ? [this.roleManager.userId]
          : await this.userRepo.getChildrenIds(this.roleManager.userId);

      return playerIds.length ? this.playerRepo.findPlayersActiveInjury(playerIds, query.order) : [];
    } catch (err) {
      this.logger.error(`Can not get dashboard data for user: ${this.roleManager.userId}. Error: ${err.message}`);
      throw new UnprocessableEntityException(err.message);
    }
  }

  async updateYearGroup(): Promise<void> {
    const limit = 10000;
    let page = 0;
    let stop = false;

    try {
      do {
        const players = await this.playerRepo.findManyForYearGroupUpdate(limit, page);

        players.forEach((player) => {
          if (player.yearGroup !== YearGroup.Adult && player.yearGroup !== YearGroup.NA) {
            const yearGroup = calculateYearGroup(player.user?.birthday);
            player.yearGroup = yearGroup;
          }
        });

        await this.playerRepo.updateMany(players);

        if (players.length < limit) {
          stop = true;
        }
        page++;
      } while (!stop);
    } catch (err) {
      this.logger.log(`Update of year groups failed on page: ${page}. Error: ${err.message}`);
    }
  }

  /**
   * Function to get link to template 'Import players from CSV'
   * @returns string
   */
  getCSVTemplateLink(): string {
    return this.configService.aws.csvTemplateLink;
  }

  /**
   * Async function to import players and their parents from CSV file
   * @param csv IFile
   * @param user IUser
   * @param organizations ReadonlyArray<OrganizationEntity>
   * @returns Promise<void>
   */
  async importFromCSV(csv: IFile, user: IUser, organizations: ReadonlyArray<OrganizationEntity>): Promise<void> {
    const path = await this.uploadCSV(csv, user.userId);

    await this.queue.add(IMPORT_PLAYERS_COMMAND_START, {
      path,
      organizations: organizations.map(({ id }) => id),
    });
  }

  /**
   * Async consumer for import players
   * @param data StartImportData
   */
  async consumeImportFromCSV({ path, organizations }: StartImportData): Promise<void> {
    try {
      const csvData = await this.parseCSV(path);

      const { emails, others } = getCriteriasForImport(csvData);

      // Find existing users
      const where: { email?: string | FindOperator<string> } = {};
      if (emails.length) {
        where.email = In(emails);
      }
      const existingUsers = await this.userService.find({
        where: [{ email: In(emails) }, ...others],
        relations: ['organizations', 'player', 'player.additionalRecepients'],
      });

      const existingUsersForSlice = await this.userService.find({
        where: [{ email: In(emails) }],
        relations: ['organizations', 'player', 'player.additionalRecepients'],
      });
      // eslint-disable-next-line prefer-const
      let existingEmails = [];
      for (const i of existingUsersForSlice) {
        existingEmails.push(i.email);
      }

      // Mapping  players, parents to users
      const usersFromCSV = mapPlayersWithExistingUsers(csvData, existingUsers, organizations);

      for (const i in usersFromCSV) {
        const currentEmail = usersFromCSV[i].email;

        if (existingEmails.includes(currentEmail)) {
          await this.userService.updateByEmailForExistingUser(usersFromCSV[i]);
          delete usersFromCSV[i];
        }
      }
      console.log({ usersFromCSV });

      // Save users to DB

      await this.userService.save(usersFromCSV);
    } catch (err) {
      this.logger.error(`Error during import players. Error: ${err.message}`);
    }
  }

  /**
   * Async function to upload csv to S3
   * @param file IFile
   * @param userId IUser['userId']
   * @returns Promise<string>
   */
  private async uploadCSV(file: IFile, userId: IUser['userId']): Promise<string> {
    const key = this.s3Bucket.getBucketKey(file, userId);
    const s3Path = `${S3_IMPORTS_FOLDER}/${key}`;
    await this.s3Bucket.upload(s3Path, TABLE_FORMATS, file);

    return lambdaImportUrl(key, S3_IMPORTS_FOLDER);
  }

  /**
   * Async function to parse CSV file with players
   * @param path string
   * @returns Promise<ReadonlyArray<PlayerImportDto>>
   */
  private async parseCSV(path: string): Promise<ReadonlyArray<PlayerImportDto>> {
    const stage = this.configService.stage;
    const { headers } = this.signManager.signRequest(`/${stage}/${path}`);
    console.log('salam12');
    const {
      data: { data },
    } = await this.httpService
      .post<ILambdaResponse>(
        `https://${this.configService.aws.lambdaHost}/${stage}/${path}`,
        {
          headers,
        },
        { timeout: 500000 }
      )
      .toPromise();
    console.log('salam13');

    return data;
  }
}

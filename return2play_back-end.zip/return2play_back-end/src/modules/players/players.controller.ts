import { CRON_FIRST_SEPTEMBER } from './../shared/constants';
import { InjuryEntity } from './../injuries/entities/injury.entity';
import { CreatePlayerBody } from './dtos/create-player.dto';
import { PlayersService } from './players.service';
import {
  BadRequestException,
  Body,
  Controller,
  Delete,
  Get,
  HttpCode,
  HttpStatus,
  Param,
  Post,
  Put,
  Query,
  Req,
  UnprocessableEntityException,
  UploadedFile,
  UseGuards,
  UseInterceptors,
} from '@nestjs/common';
import { PlayerEntity } from './entities/player.entity';
import {
  ApiBearerAuth,
  ApiConflictResponse,
  ApiConsumes,
  ApiForbiddenResponse,
  ApiNoContentResponse,
  ApiNotFoundResponse,
  ApiOkResponse,
  ApiOperation,
  ApiTags,
  ApiUnprocessableEntityResponse,
} from '@nestjs/swagger';
import {
  CREATE_ONE,
  EDIT_MANY,
  EDIT_ONE,
  GET_ONE,
  GET_MANY,
  DELETE_ONE,
  CREATE_RELATION,
  DELETE_RELATION,
  DELETE_MANY,
  GET_MY_DASHBOARD_DATA,
} from './swagger';
import { CognitoGuard } from '../shared/guards/cognito.guard';
import { RolesGuard } from '../shared/guards/roles.guard';
import { Roles } from '../shared/decorators/roles.decorator';
import { UserRole } from '../users/types';
import { UpdatePlayerBody, BulkUpdatePlayersBody } from './dtos/edit-player.dto';
import { IdDto } from '../shared/shared.dto';
import { DashboardQuery, PlayerFiltersQuery } from './dtos/find-player.dto';
import { FindManyResponse } from '../shared/types';
import { CreateRelationBody } from './dtos/create-relation.dto';
import { DeleteRelationBody } from './dtos/delete-relation.dto';
import { DeleteManyBody } from './dtos/delete-player.dto';
import { FileInterceptor } from '@nestjs/platform-express';
import { multerOptionsCsv } from '../shared/helpers/multer/options';
import { IFile } from '../shared/helpers/s3bucket/types';
import { Cron } from '@nestjs/schedule';
import { CsvTemplateResponse } from './types';
import { OrganizationsInterceptor } from '../organizations/interceptors/organizations.interceptor';
import { OrganizationsRequest } from '../organizations/interfaces/organizations-request.interface';

@ApiTags('Players')
@UseGuards(CognitoGuard, RolesGuard)
@Roles(UserRole.SuperAdmin)
@ApiBearerAuth()
@Controller('players')
export class PlayersController {
  constructor(private service: PlayersService) {}

  @ApiOperation(CREATE_ONE.OPERATION)
  @ApiNoContentResponse(CREATE_ONE.SUCCESS)
  @ApiForbiddenResponse(CREATE_ONE.FORBIDDEN)
  @ApiUnprocessableEntityResponse(CREATE_ONE.FAILURE)
  @ApiConflictResponse(CREATE_ONE.USER_EXISTS)
  @ApiNotFoundResponse(CREATE_ONE.ORGANIZATION_NOT_FOUND)
  @Roles(UserRole.OrganizationAdmin, UserRole.MedicalStaff)
  @Post()
  async createOne(@Body() userDto: CreatePlayerBody): Promise<PlayerEntity> {
    return await this.service.createOne(userDto);
  }

  @ApiOperation(CREATE_RELATION.OPERATION)
  @ApiNoContentResponse(CREATE_RELATION.SUCCESS)
  @ApiForbiddenResponse(CREATE_RELATION.FORBIDDEN)
  @ApiUnprocessableEntityResponse(CREATE_RELATION.FAILURE)
  @ApiConflictResponse(CREATE_RELATION.RELATION_EXISTS)
  @Roles(UserRole.OrganizationAdmin, UserRole.MedicalStaff)
  @HttpCode(HttpStatus.NO_CONTENT)
  @Post('/relationship')
  createRelationship(@Body() createRelationBody: CreateRelationBody): Promise<void> {
    return this.service.createRelationship(createRelationBody);
  }

  @ApiOperation(EDIT_ONE.OPERATION)
  @ApiNoContentResponse(EDIT_ONE.SUCCESS)
  @ApiNotFoundResponse(EDIT_ONE.NOT_FOUND)
  @ApiForbiddenResponse(EDIT_ONE.FORBIDDEN)
  @ApiUnprocessableEntityResponse(EDIT_ONE.FAILURE)
  @HttpCode(HttpStatus.NO_CONTENT)
  @Roles(UserRole.Player, UserRole.OrganizationAdmin, UserRole.MedicalStaff)
  @Put('/:id')
  updateOne(@Param() param: IdDto, @Body() body: UpdatePlayerBody): Promise<PlayerEntity> {
    return this.service.updateOne(param.id, body);
  }

  @ApiOperation(EDIT_MANY.OPERATION)
  @ApiNoContentResponse(EDIT_MANY.SUCCESS)
  @ApiForbiddenResponse(EDIT_ONE.FORBIDDEN)
  @ApiUnprocessableEntityResponse(EDIT_MANY.FAILURE)
  @HttpCode(HttpStatus.NO_CONTENT)
  @Roles(UserRole.OrganizationAdmin, UserRole.MedicalStaff)
  @Put()
  updateBulk(@Body() body: BulkUpdatePlayersBody): Promise<void> {
    return this.service.updateBulk(body);
  }

  @ApiOperation(GET_ONE.OPERATION)
  @ApiOkResponse({ ...GET_ONE.SUCCESS, type: PlayerEntity })
  @ApiNotFoundResponse(GET_ONE.NOT_FOUND)
  @ApiForbiddenResponse(GET_ONE.FORBIDDEN)
  @ApiUnprocessableEntityResponse(GET_ONE.FAILURE)
  @Roles(UserRole.Parent, UserRole.StaffUser, UserRole.OrganizationAdmin, UserRole.Doctor, UserRole.MedicalStaff)
  @Get('/:id')
  findOne(@Param() param: IdDto): Promise<PlayerEntity> {
    return this.service.findOne(param.id);
  }

  @ApiOperation(GET_MANY.OPERATION)
  @ApiOkResponse({ ...GET_MANY.SUCCESS, type: PlayerEntity, isArray: true })
  @ApiNotFoundResponse(GET_MANY.NOT_FOUND)
  @ApiForbiddenResponse(GET_MANY.FORBIDDEN)
  @ApiUnprocessableEntityResponse(GET_MANY.FAILURE)
  @Roles(UserRole.Parent, UserRole.StaffUser, UserRole.OrganizationAdmin, UserRole.MedicalStaff)
  @Get()
  findMany(@Query() query: PlayerFiltersQuery): Promise<FindManyResponse<PlayerEntity>> {
    return this.service.findMany(query);
  }

  @ApiOperation(DELETE_ONE.OPERATION)
  @ApiNoContentResponse(DELETE_ONE.SUCCESS)
  @ApiForbiddenResponse(DELETE_ONE.FORBIDDEN)
  @ApiUnprocessableEntityResponse(DELETE_ONE.FAILURE)
  @Roles(UserRole.OrganizationAdmin, UserRole.MedicalStaff)
  @Delete('/relationship')
  async deleteRelationship(@Body() deleteRelationBody: DeleteRelationBody): Promise<void> {
    return await this.service.deleteRelationship(deleteRelationBody);
  }

  @ApiOperation(DELETE_RELATION.OPERATION)
  @ApiNoContentResponse(DELETE_RELATION.SUCCESS)
  @ApiForbiddenResponse(DELETE_RELATION.FORBIDDEN)
  @ApiUnprocessableEntityResponse(DELETE_RELATION.FAILURE)
  @Roles(UserRole.OrganizationAdmin, UserRole.MedicalStaff)
  @Delete('/:id')
  async deleteOne(@Param() param: IdDto): Promise<void> {
    return await this.service.deleteOne(param.id);
  }

  @ApiOperation(DELETE_MANY.OPERATION)
  @ApiNoContentResponse(DELETE_MANY.SUCCESS)
  @ApiForbiddenResponse(DELETE_MANY.FORBIDDEN)
  @ApiUnprocessableEntityResponse(DELETE_MANY.FAILURE)
  @Roles(UserRole.OrganizationAdmin, UserRole.MedicalStaff)
  @Delete()
  async deleteMany(@Body() body: DeleteManyBody): Promise<void> {
    return await this.service.deleteMany(body.playerIds);
  }

  @ApiConsumes('multipart/form-data')
  @UseInterceptors(FileInterceptor('csv', multerOptionsCsv()), OrganizationsInterceptor)
  @Roles(UserRole.OrganizationAdmin, UserRole.MedicalStaff)
  @Post('/upload')
  async importPlayersFromCsv(@Req() request: OrganizationsRequest, @UploadedFile() file: IFile): Promise<void> {
    if (!file) {
      throw new BadRequestException('No file provided');
    }
    if (!file.size) {
      throw new UnprocessableEntityException('File is empty');
    }

    const {
      context: { organizations },
      user,
    } = request;

    await this.service.importFromCSV(file, user, organizations);
  }

  @Get('/download/csvTemplate')
  @Roles(UserRole.OrganizationAdmin, UserRole.StaffUser, UserRole.MedicalStaff)
  csvTemplate(): CsvTemplateResponse {
    return { link: this.service.getCSVTemplateLink() };
  }

  @ApiOperation(GET_MY_DASHBOARD_DATA.OPERATION)
  @ApiOkResponse(GET_MY_DASHBOARD_DATA.SUCCESS)
  @ApiForbiddenResponse(GET_MY_DASHBOARD_DATA.FORBIDDEN)
  @ApiUnprocessableEntityResponse(GET_MY_DASHBOARD_DATA.FAILURE)
  @Roles(UserRole.Player, UserRole.Parent)
  @Get('/dashboard/my')
  getMyDashboardData(@Query() query: DashboardQuery): Promise<InjuryEntity[]> {
    return this.service.getMyDashboardData(query);
  }

  @Cron(CRON_FIRST_SEPTEMBER)
  updateYearGroup(): Promise<void> {
    return this.service.updateYearGroup();
  }
}

import { uniqBy } from 'lodash';
import { v4 as uuid } from 'uuid';
import { AdditionalRecipientEntity } from '../../additional-recipients/entities/recipient.entity';

import { PlayerImportDto } from '../../imports/dto/import-player.dto';
import { calculateYearGroup } from '../../shared/utils/common.utils';
import { UserEntity } from '../../users/entities/user.entity';
import { UserRole } from '../../users/types';
import { Membership } from '../types';
import { findRecipient } from './find-recipient';
import { findUserByParent } from './find-user-by-parent';
import { findUserByPlayer } from './find-user-by-player';

/**
 * Function for mapping players from 'import players data' to UserEntities
 * @param players ReadonlyArray<PlayerImportDto>
 * @param users ReadonlyArray<UserEntity>
 * @param organizations ReadonlyArray<OrganizationEntity>
 * @returns Array<UserEntity>
 */
export function mapPlayersWithExistingUsers(
  players: ReadonlyArray<PlayerImportDto>,
  users: ReadonlyArray<UserEntity>,
  organizationIds: ReadonlyArray<string>
): Array<UserEntity> {
  const arr = [];

  const n = players.length;

  const organizations = organizationIds.map((id) => ({ id }));
  for (let i = 0; i < n; i++) {
    const player = players[i];
    const existingUser = findUserByPlayer(users, player);

    // Mapping parents
    const parentsFromCSV = uniqBy(player.parents || [], 'email');
    const parents: Array<UserEntity> = [];
    const m = parentsFromCSV?.length || 0;
    for (let j = 0; j < m; j++) {
      const parent = parentsFromCSV[j];

      if (!parent.email) {
        continue;
      }
      const existingUserForParent = findUserByParent(users, parent);
      parents.push({
        ...existingUserForParent,
        id: existingUserForParent?.id || uuid(),
        role: existingUserForParent?.role || UserRole.Parent,
        firstName: parent.firstName,
        lastName: parent.lastName,
        email: parent.email,
        organizations: uniqBy(
          [].concat(existingUserForParent ? existingUserForParent.organizations : [], organizations),
          'id'
        ),
      });
    }

    // Mapping recipients
    const recipients: Array<AdditionalRecipientEntity> = [];
    const recipientsCount = player.additional?.length || 0;
    for (let j = 0; j < recipientsCount; j++) {
      const recipient = player.additional[j];

      if (!recipient.email) {
        continue;
      }
      const existingRecipient = findRecipient(existingUser?.player?.additionalRecepients || [], recipient);
      recipients.push({
        ...existingRecipient,
        id: existingRecipient?.id || uuid(),
        firstName: recipient.firstName,
        lastName: recipient.lastName,
        email: recipient.email,
      });
    }

    const id = existingUser?.id || uuid();
    const birthday = player.birthday || existingUser?.birthday;

    const user: UserEntity = {
      ...existingUser,
      id,
      birthday,
      firstName: player.firstName || undefined,
      lastName: player.lastName || undefined,
      email: player.email || undefined,
      gender: player.gender || undefined,
      role: existingUser ? existingUser.role : UserRole.Player,
      organizations: uniqBy([].concat(existingUser ? existingUser.organizations : [], organizations), 'id'),
      player: {
        ...existingUser?.player,
        userId: id,
        membership: existingUser?.player?.membership || Membership.School,
        socsId: player.socsId || undefined,
        yearGroup: calculateYearGroup(birthday),
        parents: uniqBy(parents, 'id'),
        additionalRecepients: uniqBy(recipients, 'id'),
      },
    };

    arr.push(user);
  }

  return arr;
}

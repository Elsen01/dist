import { AdditionalRecipientEntity } from '../../additional-recipients/entities/recipient.entity';
import { AdditionalRecipientImportDto } from '../../imports/dto/import-recipient.dto';

/**
 * Function to find 'import players recipient' from array
 * @param arr ReadonlyArray<AdditionalRecipientEntity>
 * @param recipient AdditionalRecipientImportDto
 * @returns AdditionalRecipientEntity | undefined
 */
export function findRecipient(
  arr: ReadonlyArray<AdditionalRecipientEntity>,
  recipient: AdditionalRecipientImportDto
): AdditionalRecipientEntity | undefined {
  return arr.find(({ email }) => email && recipient.email && email === recipient.email);
}

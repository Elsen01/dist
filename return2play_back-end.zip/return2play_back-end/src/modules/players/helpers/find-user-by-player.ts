import { isSameDay } from 'date-fns';
import { PlayerImportDto } from '../../imports/dto/import-player.dto';
import { UserEntity } from '../../users/entities/user.entity';

/**
 * Function to find user for player from 'import players data'
 * @param arr ReadonlyArray<UserEntity>
 * @param player PlayerImportDto
 * @returns UserEntity | undefined
 */
export function findUserByPlayer(arr: ReadonlyArray<UserEntity>, player: PlayerImportDto): UserEntity | undefined {
  return arr.find(
    ({ email, firstName, lastName, birthday, gender }) =>
      (player.email && email === player.email) ||
      (!player.email &&
        firstName === player.firstName &&
        lastName === player.lastName &&
        isSameDay(new Date(player.birthday), new Date(birthday)) &&
        gender === player.gender)
  );
}

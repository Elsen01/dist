import { ParentImportDto } from '../../imports/dto/import-parent.dto';
import { UserEntity } from '../../users/entities/user.entity';

/**
 * Function to find user for parent from 'import players data'
 * @param arr ReadonlyArray<UserEntity>
 * @param parent ParentImportDto
 * @returns
 */
export function findUserByParent(arr: ReadonlyArray<UserEntity>, parent: ParentImportDto): UserEntity | undefined {
  return arr.find(({ email }) => email && parent.email && email === parent.email);
}

import { FindOperator, IsNull } from 'typeorm';
import { PlayerImportDto } from '../../imports/dto/import-player.dto';
import { UserEntity } from '../../users/entities/user.entity';

export interface CriteriasForImport {
  emails: Array<string>;
  others: Array<
    Omit<Partial<UserEntity>, 'email' | 'birthday'> & {
      email?: FindOperator<any> | string;
      birthday?: FindOperator<any> | Date;
    }
  >;
}

/**
 * Function for getting criterias that are using for search existing users in DB based on players from CSV
 * @param arr ReadonlyArray<PlayerImportDto>
 * @returns CriteriasForImport
 */
export function getCriteriasForImport(arr: ReadonlyArray<PlayerImportDto>): CriteriasForImport {
  const emails: CriteriasForImport['emails'] = [];
  const others: CriteriasForImport['others'] = [];

  const n = arr.length;
  for (let i = 0; i < n; i++) {
    const { email, firstName, lastName, birthday, gender, parents = [] } = arr[i];
    if (email) {
      emails.push(email);
    } else {
      const common = {
        firstName,
        lastName,
        gender,
        birthday,
      };
      others.push(
        {
          ...common,
          email: IsNull(),
        },
        {
          ...common,
          email: '',
        }
      );
    }

    const m = parents.length;
    for (let j = 0; j < m; j++) {
      const { email } = parents[j];
      if (email) {
        emails.push(email);
      }
    }
  }

  return { emails: [...new Set(emails)], others };
}

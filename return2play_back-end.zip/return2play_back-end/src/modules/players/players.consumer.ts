import { Process, Processor } from '@nestjs/bull';
import { Job } from 'bull';
import { IMPORT_PLAYERS_COMMAND_START, IMPORT_PLAYERS_QUEUE_NAME } from './consts';
import { PlayersService } from './players.service';

import { StartImportData } from './types';

@Processor(IMPORT_PLAYERS_QUEUE_NAME)
export class PlayersConsumer {
  constructor(private readonly service: PlayersService) {}

  @Process(IMPORT_PLAYERS_COMMAND_START)
  start({ data }: Job<StartImportData>): Promise<void> {
    console.log(333333333333);

    return this.service.consumeImportFromCSV(data);
  }
}

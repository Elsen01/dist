export const IMPORT_PLAYERS_QUEUE_NAME = 'import-players';

export const IMPORT_PLAYERS_COMMAND_START = 'start-import';

import { UserEntity } from '../users/entities/user.entity';
import { PlayerEntity } from './entities/player.entity';

export enum Membership {
  Regular = 'Regular Member',
  School = 'School Member',
  NonMember = 'Non-member',
}

export enum CreateMembership {
  School = 'School Member',
  NonMember = 'Non-member',
}

export enum GeneralSortOptions {
  FirstName = 'user.firstName',
  LastName = 'user.lastName',
  Gender = 'user.gender',
  Birthday = 'user.birthday',
  CreatedAt = 'user.createdAt',
  PlayStatus = 'player.playStatus',
}

export enum PlayerSortOptions {
  FirstName = 'user.firstName',
  LastName = 'user.lastName',
  Gender = 'user.gender',
  Birthday = 'user.birthday',
  Membership = 'player.membership',
  AgeGroup = 'player.yearGroup',
  Status = 'user.status',
  CreatedAt = 'user.createdAt',
  OrganizationName = 'org.name',
  InjuryType = 'otherInjury.type',
  BodyPart = 'bodyPart.name',
  InjuryCreatedAt = 'injury.createdAt',
  Tag = 'tag.name',
  PlayStatus = 'player.playStatus',
}

export enum InjuryTypeFilter {
  GrazeAbrasion = 'Graze/Abrasion',
  BruiseContusion = 'Bruise/Contusion',
  Blister = 'Blister',
  CrushInjury = 'Crush injury',
  CutLaceration = 'Cut/Laceration',
  Dislocation = 'Dislocation',
  FractureBrokenBone = 'Fracture/Broken bone',
  SprainLigaments = 'Sprain (ligaments)',
  StrainMuscle = 'Strain (muscle)',
  Concussion = 'Concussion',
}

export type PlayerResponse = Omit<PlayerEntity, 'parents'> & { parents: PlayerParentPayer };

export type PlayerParentPayer = UserEntity & { isPayer: boolean };

export type OnePlayerResponse = PlayerEntity & { hasMembership: boolean };

export enum YearGroup {
  U1 = 'U1',
  U2 = 'U2',
  U3 = 'U3',
  U4 = 'U4',
  U5 = 'U5',
  U6 = 'U6',
  U7 = 'U7',
  U8 = 'U8',
  U9 = 'U9',
  U10 = 'U10',
  U11 = 'U11',
  U12 = 'U12',
  U13 = 'U13',
  U14 = 'U14',
  U15 = 'U15',
  U16 = 'U16',
  U17 = 'U17',
  U18 = 'U18',
  Adult = 'Adult',
  NA = 'N/A',
}

export interface CsvTemplateResponse {
  link: string;
}

export interface StartImportData {
  path: string;
  organizations: ReadonlyArray<string>;
}

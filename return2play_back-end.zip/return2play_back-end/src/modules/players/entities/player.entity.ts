import { PaymentEntity } from './../../payments/entities/payment.entity';
import {
  Column,
  CreateDateColumn,
  Entity,
  JoinColumn,
  JoinTable,
  ManyToMany,
  OneToMany,
  OneToOne,
  PrimaryColumn,
  UpdateDateColumn,
} from 'typeorm';
import { UserEntity } from './../../users/entities/user.entity';
import { Membership } from './../types';
import { PlayStatus } from '../../injuries/types';
import { AppointmentEntity } from '../../appointments/entities/appointment.entity';
import { AdditionalRecipientEntity } from '../../additional-recipients/entities/recipient.entity';
import { WondeStudentEntity } from './wondeStudent.entity';

@Entity('players')
export class PlayerEntity {
  @PrimaryColumn({ name: 'user_id' })
  userId: string;

  @Column({ type: 'enum', enum: Membership })
  membership: Membership;

  @Column({ name: 'year_group', default: 'N/A' })
  yearGroup: string;

  @Column({
    name: 'play_status',
    type: 'enum',
    enum: PlayStatus,
    enumName: 'player_play_status_enum',
    default: PlayStatus.Safe,
  })
  playStatus: PlayStatus;

  @Column({ name: 'socs_id', nullable: true, length: 255 })
  socsId?: string;

  @Column({ name: 'membership_expiration_date', type: 'timestamptz', nullable: true })
  membershipExpirationDate?: Date;

  @OneToOne(() => UserEntity, { onDelete: 'CASCADE', eager: true })
  @JoinColumn({ name: 'user_id', referencedColumnName: 'id' })
  user: UserEntity;

  @ManyToMany(() => UserEntity, (user) => user.children, { eager: true, cascade: ['insert'] })
  @JoinTable({
    name: 'players_parents',
    joinColumn: {
      name: 'player_id',
      referencedColumnName: 'userId',
    },
    inverseJoinColumn: {
      name: 'parent_id',
      referencedColumnName: 'id',
    },
  })
  parents?: UserEntity[];

  @Column({ type: 'simple-array', name: 'deleted_parents', nullable: true })
  deletedParents: any[];

  @OneToMany(() => AppointmentEntity, (appointment) => appointment.player)
  appointments?: AppointmentEntity[];

  @OneToMany(() => AdditionalRecipientEntity, (recepient) => recepient.player, { cascade: true })
  additionalRecepients?: AdditionalRecipientEntity[];

  @OneToMany(() => PaymentEntity, (payment) => payment.player)
  payments?: PaymentEntity[];

  @OneToOne(() => WondeStudentEntity, (wondeStudent) => wondeStudent?.player, { cascade: true })
  wondeStudent?: WondeStudentEntity;

  @CreateDateColumn({ name: 'created_at' })
  createdAt: Date;

  @UpdateDateColumn({ name: 'updated_at' })
  updatedAt: Date;
}

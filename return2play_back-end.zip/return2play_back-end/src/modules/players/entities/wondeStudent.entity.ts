import { UserEntity } from './../../users/entities/user.entity';
import { Column, Entity, JoinColumn, OneToOne, PrimaryGeneratedColumn } from 'typeorm';

@Entity('wonde_student')
export class WondeStudentEntity {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ name: 'wonde_id', length: 255, unique: true })
  wondeId: string;

  @Column({ name: 'mis_id', length: 255 })
  misId: string;

  @Column({ name: 'wonde_last_modify', type: 'timestamptz' })
  wondeLastModify: Date;

  @Column({ name: 'last_update', type: 'timestamptz' })
  lastUpdate: Date;

  @OneToOne(() => UserEntity, (player) => player?.wondeStudent, { nullable: false, cascade: ['insert'] })
  @JoinColumn({ name: 'player_id', referencedColumnName: 'id' })
  player: UserEntity;
}

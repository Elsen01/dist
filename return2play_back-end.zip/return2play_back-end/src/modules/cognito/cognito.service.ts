import { Injectable } from '@nestjs/common';
import { CognitoIdentityServiceProvider } from 'aws-sdk';
import { AdminCreateUserResponse } from 'aws-sdk/clients/cognitoidentityserviceprovider';
import { promisify } from 'util';

import { CognitoConfigService } from '../../config/cognito-config/cognito-config.service';
import { UserEntity } from '../users/entities/user.entity';

@Injectable()
export class CognitoService {
  private readonly provider: CognitoIdentityServiceProvider;

  constructor(private readonly config: CognitoConfigService) {
    // Init Cognito Provider
    this.provider = new CognitoIdentityServiceProvider(config.aws);
  }

  /**
   * Async function to create AWS Cognito User
   * @param user UserEntity
   * @returns Promise<AdminCreateUserResponse>
   */
  createUser(user: UserEntity): Promise<AdminCreateUserResponse> {
    return promisify(this.provider.adminCreateUser.bind(this.provider))({
      UserPoolId: this.config.UserPoolId,
      Username: user.id,
      UserAttributes: [
        { Name: 'email', Value: user.email },
        { Name: 'email_verified', Value: 'true' },
      ],
    });
  }

  /**
   * Async function to add AWS Cognito User to Group
   * @param username string
   * @param group string
   * @returns Promise<Record<string, never>>
   */
  addUserToGroup(username: string, group: string): Promise<Record<string, never>> {
    return promisify(this.provider.adminAddUserToGroup.bind(this.provider))({
      GroupName: group,
      UserPoolId: this.config.UserPoolId,
      Username: username,
    });
  }
}

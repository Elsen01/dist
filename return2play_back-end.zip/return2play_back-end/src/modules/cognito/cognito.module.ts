import { Module } from '@nestjs/common';
import { CognitoConfigModule } from '../../config/cognito-config/cognito-config.module';
import { CognitoService } from './cognito.service';

@Module({
  imports: [CognitoConfigModule],
  providers: [CognitoService],
  exports: [CognitoService],
})
export class CognitoModule {}

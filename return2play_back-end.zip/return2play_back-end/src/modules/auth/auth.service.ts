import { checkMembership } from './../shared/utils/common.utils';
import {
  BadRequestException,
  ConflictException,
  ForbiddenException,
  HttpException,
  HttpService,
  HttpStatus,
  Inject,
  Injectable,
  InternalServerErrorException,
  Logger,
  LoggerService,
  NotFoundException,
  UnauthorizedException,
  UnprocessableEntityException,
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { CognitoUserAttribute } from 'amazon-cognito-identity-js';
import { LoginResponse, LoginBody } from './dtos/login.dto';
import { CognitoManager } from '../shared/helpers/cognito/cognito.manager';
import { RegistrationBody } from './dtos/registration.dto';
import { AppConfigService } from './../../config/config.service';
import { ResetPasswordBody, ChangePasswordBody } from './dtos/change-password.dto';
import { CognitoException, CognitoUserStatus } from '../shared/helpers/cognito/types';
import { RefreshTokensBody } from './dtos/refresh-tokens.dto';
import { UserRepository } from '../users/users.repository';
import { UserEntity } from '../users/entities/user.entity';
import {
  BAD_EMAIL_OR_PASSWORD_ERROR,
  EMAIL_PASSWORD_SAME_ERROR,
  BAD_PASSWORD_ERROR,
  NOT_CONFIRMED_ERROR,
  DEACTIVATED_ERROR,
  NOT_USER_FOUND,
} from './error-messages';
import { UserRole, UserStatus } from '../users/types';

@Injectable()
export class AuthService {
  constructor(
    private cognitoManager: CognitoManager,
    private configService: AppConfigService,
    @InjectRepository(UserRepository)
    private userRepo: UserRepository,
    private httpService: HttpService,
    @Inject(Logger)
    private logger: LoggerService // private isamsService: IsamsService
  ) {}

  async login(body: LoginBody): Promise<LoginResponse> {
    const users = await this.userRepo.findByEmailWithStatus(body.email);
    this.logger.log(`login --api BODY:${JSON.stringify(body)}`);
    if (!users.length) {
      throw new NotFoundException(NOT_USER_FOUND);
    }

    const notDeletedUsers = users.filter(({ status }) => status !== UserStatus.Deleted);

    if (!notDeletedUsers.length) {
      throw new ForbiddenException('User are delete');
    }

    const user =
      // find by same email and status 'active'
      notDeletedUsers.find(({ email, status }) => email === body.email && status !== UserStatus.Inactive) ||
      // find by email (skip case of email) and status 'active'
      notDeletedUsers.find(({ status }) => status !== UserStatus.Inactive);

    if (!user) {
      throw new ForbiddenException(DEACTIVATED_ERROR);
    }

    // const data = {
    //   organizationId: '085ddaf0-bd20-4132-9c56-e4af76226978',
    //   iSAMSKey: '85246FC6-5255-440A-A3A6-7ADD1FD8C129',
    //   iSAMSUrl: 'feltonfleet.isams.cloud',
    // };

    // await this.isamsService.syncOrganization(data);

    this.logger.log(`User is logging in ${body.email}`);
    const loginResponse = await this.cognitoManager.handleUserAuth(body, users).catch(async (err) => {
      this.logger.error(`Login failed for ${body.email} error: ${err} \n message: ${err.message}`);
      this.logger.log('USERS:', JSON.stringify(users));

      if (err.message === 'Temporary password has expired and must be reset by an administrator') {
        await this.cognitoManager.resendConfirmationLink(user.id);
        throw new UnprocessableEntityException(
          'Temporary password has expired. A new temporary password was sent to your email.'
        );
      }

      if (err.message === 'Incorrect username or password.' && user) {
        throw new UnauthorizedException(BAD_PASSWORD_ERROR);
      }

      if (err.message === 'Not confirmed' && user) {
        throw new UnauthorizedException(NOT_CONFIRMED_ERROR);
      }

      if (err.code === CognitoException.NotAuthorized && !user) {
        throw new UnauthorizedException(BAD_EMAIL_OR_PASSWORD_ERROR);
      }

      if (err.message === 'A new password is required') {
        throw new UnprocessableEntityException(err.message);
      }

      const isCognitoUser = await this.cognitoManager.adminGetUser(user.id).catch(async () => {
        const cognitoUser = await this.cognitoManager.adminCreateUserFromMigration(user.email, user.id).catch((err) => {
          if (err.code === 'UsernameExistsException' && users.length === 1) {
            throw new ConflictException('Account was created, temporary password was send on your email');
          }

          throw new InternalServerErrorException();
        });
        const id = cognitoUser.User.Username;

        await this.cognitoManager.addUserToUserGroup(id, user.role);

        throw new UnprocessableEntityException('A new password is required, temporary password was send on your email');
      });

      if (isCognitoUser && err.message === 'A new password is required') {
        throw new UnprocessableEntityException('A new password is required');
      }

      throw new UnauthorizedException(err.message);
    });

    loginResponse.mfa = false;

    if (
      users[0].role === UserRole.Player ||
      users[0].role === UserRole.StaffUser ||
      users[0].role === UserRole.OrganizationAdmin
    ) {
      if (users[0].organizations[0].is2FA) {
        const generatedToken = Math.floor(Math.random() * 900000) + 100000;
        const now = new Date();
        const futureTime = new Date(now.getTime() + 5 * 60 * 1000);

        await this.userRepo.updateToken(body, generatedToken, futureTime);

        await this.httpService
          .post(`http://${this.configService.aws.mailerHost}/auth`, {
            email: body.email,
            firstName: users[0].firstName,
            token: generatedToken,
          })
          .toPromise();
        await this.userRepo.updateAuthTokens(body, loginResponse);
        loginResponse.idToken = '';
        loginResponse.accessToken = '';
        loginResponse.refreshToken = '';
        loginResponse.mfa = true;
      }
    }
    return loginResponse;
  }

  async mfaLogin(token: number): Promise<LoginResponse> {
    const users = await this.userRepo.findByToken(token);
    const date = new Date();
    const expireDate = users[0].tokenExpiresAt;
    if (date < expireDate) {
      if (users[0].token !== token) {
        throw new UnauthorizedException('Wrong Token. Please Try Again');
      }
      const loginResponse: LoginResponse = {
        idToken: '',
        accessToken: '',
        refreshToken: '',
        mfa: true,
      };
      loginResponse.idToken = users[0].idToken;
      loginResponse.accessToken = users[0].accessToken;
      loginResponse.refreshToken = users[0].refreshToken;
      loginResponse.mfa = true;
      await this.userRepo.deleteAuthTokens(users[0].email);
      return loginResponse;
    } else {
      throw new UnauthorizedException('Token invalid or expired. Please try again');
    }
  }

  async signUpPlayer(user: RegistrationBody): Promise<void> {
    if (user.email === user.password) {
      throw new UnprocessableEntityException(EMAIL_PASSWORD_SAME_ERROR);
    }
    const isUserExists = await this.userRepo.findIfUserExits({ email: user.email });

    if (isUserExists) {
      throw new ConflictException('User with this email already exists');
    }

    this.logger.log(`${user.email} is signing up as player`);
    const id = await this.cognitoManager.signUpPlayer(user);
    await this.userRepo.createPlayer({ id, ...user });
    return;
  }

  async sendResetCodeOrTemporaryPassword(email: string): Promise<void> {
    const user = await this.userRepo.findByEmail(email);
    if (!user) {
      this.logger.error(`Reset code was not sent for ${email}`);
      throw new NotFoundException(
        // eslint-disable-next-line quotes
        "That e-mail address doesn't have an associated user account. Are you sure you've registered?"
      );
    }
    const { id } = user;

    const cognitoUser = await this.cognitoManager.adminGetUser(id).catch(async () => {
      this.logger.error(`User was not found in Cognito with id ${id}`);

      const createdCognitoUser = await this.cognitoManager.adminCreateUserFromMigration(user.email, user.id);

      const newId = createdCognitoUser.User.Username;

      await this.cognitoManager.addUserToUserGroup(newId, user.role);

      throw new NotFoundException(
        // eslint-disable-next-line quotes
        'An email has been sent with your temporary password. Please return to the login page and enter the temporary password here. You will then be asked to create a new password.'
      );
    });

    switch (cognitoUser.UserStatus) {
      case CognitoUserStatus.ForceChangePassword: {
        const userParams = {
          MessageAction: 'RESEND',
          Username: cognitoUser.Username,
          UserPoolId: this.configService.cognito.UserPoolId,
          UserAttributes: [
            new CognitoUserAttribute({
              Value: 'true',
              Name: 'email_verified',
            }),
            new CognitoUserAttribute({
              Value: email,
              Name: 'email',
            }),
          ],
        };
        this.cognitoManager.adminCreateUser(id, userParams).catch(({ message }) => {
          this.logger.error(
            `Admin could not create ${userParams.Username} with ${CognitoUserStatus.ForceChangePassword} status`
          );
          throw new UnprocessableEntityException(message);
        });
        throw new ConflictException(
          'An email has been sent with your temporary password. Please return to the login page and enter the temporary password here. You will then be asked to create a new password.'
        );
      }
      case CognitoUserStatus.Confirmed: {
        await this.cognitoManager.userForgotPassword(id).catch((err) => {
          throw new UnprocessableEntityException(err);
        });
        break;
      }
      case CognitoUserStatus.Unconfirmed: {
        await this.cognitoManager.resendConfirmationLink(id).catch(() => {
          this.logger.error(`${email} is not confirmed`);
          throw new UnauthorizedException('User email is not confirmed');
        });
        break;
      }
      default: {
        this.logger.error(`Unknown user status: ${cognitoUser.UserStatus}`);
        throw new UnprocessableEntityException('Unknown user status');
      }
    }
  }

  async resetPassword(body: ResetPasswordBody): Promise<void> {
    const { id } = await this.userRepo.findByEmail(body.email);

    await this.cognitoManager.resetPassword({ ...body, id }).catch((e) => {
      const { code, message, statusCode = HttpStatus.INTERNAL_SERVER_ERROR } = e;
      if (code === CognitoException.LimitExceeded) {
        throw new HttpException(message, HttpStatus.TOO_MANY_REQUESTS);
      } else if (code === CognitoException.ExpiredCode) {
        throw new BadRequestException(message);
      }
      throw new HttpException(e, statusCode);
    });
  }

  async logout(): Promise<void> {
    return await this.cognitoManager.logout();
  }

  async refreshTokens(body: RefreshTokensBody): Promise<LoginResponse> {
    return await this.cognitoManager.refreshTokens(body);
  }

  async getMe(): Promise<UserEntity & { hasMembership: boolean }> {
    const user = await this.userRepo.findMe();

    if (!user) {
      throw new NotFoundException('User does not exist');
    }

    const hasMembership =
      user.role === UserRole.Player
        ? checkMembership(user.player?.membership, user.player?.membershipExpirationDate)
        : false;

    return { ...user, hasMembership };
  }

  async changePassword(body: ChangePasswordBody): Promise<void> {
    return await this.cognitoManager.changePassword(body).catch((err) => {
      throw new UnprocessableEntityException(err.message);
    });
  }
}

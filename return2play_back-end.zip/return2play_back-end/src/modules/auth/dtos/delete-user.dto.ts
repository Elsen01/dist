import { IsEmail, IsNotEmpty } from 'class-validator';

export class DeleteUserBody {
  @IsEmail()
  email: string;

  @IsNotEmpty()
  password: string;
}

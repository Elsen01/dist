import { IsEmail, IsNotEmpty, Matches, MaxLength, MinLength } from 'class-validator';
import { NAME_REGEXP } from '../../shared/constants';
import { BAD_EMAIL_ERROR, EMPTY_FIELD_ERROR } from '../error-messages';

export class RegistrationBody {
  @IsNotEmpty({ message: EMPTY_FIELD_ERROR('email') })
  @IsEmail({}, { message: BAD_EMAIL_ERROR })
  email: string;

  @IsNotEmpty({ message: EMPTY_FIELD_ERROR('password') })
  password: string;

  @IsNotEmpty()
  @MinLength(1)
  @MaxLength(128)
  @Matches(NAME_REGEXP)
  firstName: string;

  @IsNotEmpty()
  @MinLength(1)
  @MaxLength(128)
  @Matches(NAME_REGEXP)
  lastName: string;
}

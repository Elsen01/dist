import { IsJWT, IsNotEmpty } from 'class-validator';

export class RefreshTokensBody {
  @IsNotEmpty()
  refreshToken: string;

  @IsJWT()
  idToken: string;
}

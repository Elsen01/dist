import { IsEmail, IsNotEmpty, MinLength } from 'class-validator';

export class ResetPasswordBody {
  @IsNotEmpty()
  @MinLength(8)
  newPassword: string;

  @IsNotEmpty()
  code: string;

  @IsEmail()
  email: string;
}

export class ChangePasswordBody {
  @IsNotEmpty()
  @MinLength(8)
  newPassword: string;

  @IsNotEmpty()
  @MinLength(8)
  oldPassword: string;
}

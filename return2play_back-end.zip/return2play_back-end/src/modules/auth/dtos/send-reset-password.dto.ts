import { IsEmail } from 'class-validator';

export class ResetPasswordCodeBody {
  @IsEmail()
  email: string;
}

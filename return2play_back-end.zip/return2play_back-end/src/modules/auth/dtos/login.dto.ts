import { IsEmail, IsNotEmpty, IsNumber, IsOptional } from 'class-validator';
import { BAD_EMAIL_OR_PASSWORD_ERROR, EMPTY_FIELD_ERROR } from '../error-messages';

export class LoginBody {
  @IsNotEmpty({ message: EMPTY_FIELD_ERROR('email') })
  @IsEmail({}, { message: BAD_EMAIL_OR_PASSWORD_ERROR })
  email: string;

  @IsNotEmpty({ message: EMPTY_FIELD_ERROR('password') })
  password: string;

  @IsNotEmpty({ message: EMPTY_FIELD_ERROR('new password') })
  @IsOptional()
  newPassword?: string;
}

export class mfaBody {
  @IsNotEmpty()
  @IsNumber()
  token: number;
}

export class LoginResponse {
  idToken: string;
  accessToken: string;
  refreshToken: string;
  mfa: boolean;
}

import { Body, Controller, Get, HttpCode, HttpStatus, Post, Put, UseGuards } from '@nestjs/common';
import {
  ApiConflictResponse,
  ApiNoContentResponse,
  ApiOperation,
  ApiTags,
  ApiUnprocessableEntityResponse,
  ApiBadRequestResponse,
  ApiBearerAuth,
  ApiForbiddenResponse,
  ApiOkResponse,
  ApiTooManyRequestsResponse,
  ApiUnauthorizedResponse,
  ApiNotFoundResponse,
} from '@nestjs/swagger';

import { AuthService } from './auth.service';

import { CognitoGuard } from '../shared/guards/cognito.guard';

import { LoginResponse, LoginBody, mfaBody } from './dtos/login.dto';
import { RegistrationBody } from './dtos/registration.dto';
import { ResetPasswordBody, ChangePasswordBody } from './dtos/change-password.dto';
import { RefreshTokensBody } from './dtos/refresh-tokens.dto';
import { ResetPasswordCodeBody } from './dtos/send-reset-password.dto';

import {
  CHANGE_PASSWORD,
  GET_ME,
  LOGIN,
  LOGOUT,
  REFRESH_TOKENS,
  REGISTRATION,
  RESET_CODE,
  RESET_PASSWORD,
} from './swagger';
import { UserEntity } from '../users/entities/user.entity';

@ApiTags('Authentication')
@Controller('auth')
export class AuthController {
  constructor(private service: AuthService) {}

  @ApiOperation(LOGIN.OPERATION)
  @ApiOkResponse(LOGIN.SUCCESS)
  @ApiUnauthorizedResponse(LOGIN.UNCONFIRMED_EMAIL)
  @ApiUnauthorizedResponse(LOGIN.INCORRECT_DATA)
  @ApiUnprocessableEntityResponse(LOGIN.TEMPORARY_PASSWORD)
  @HttpCode(HttpStatus.OK)
  @Post('/login')
  async login(@Body() loginUserDto: LoginBody): Promise<LoginResponse> {
    console.log('111111111111111111111111111111111111111111')
    console.log({loginUserDto})
    console.log('222222222222222222222222222222222222222222')
    return await this.service.login(loginUserDto);
  }

  @ApiOperation(LOGIN.OPERATION)
  @ApiOkResponse(LOGIN.SUCCESS)
  @ApiUnauthorizedResponse(LOGIN.INCORRECT_DATA)
  @ApiUnprocessableEntityResponse(LOGIN.TEMPORARY_PASSWORD)
  @HttpCode(HttpStatus.OK)
  @Post('/mFAuth')
  async mfa(@Body() body: mfaBody): Promise<LoginResponse> {
    return await this.service.mfaLogin(body.token);
  }

  @ApiOperation(REGISTRATION.OPERATION)
  @ApiNoContentResponse(REGISTRATION.SUCCESS)
  @ApiBadRequestResponse(REGISTRATION.INVALID_PASSWORD)
  @ApiConflictResponse(REGISTRATION.USER_EXISTS)
  @ApiUnprocessableEntityResponse(REGISTRATION.FAILURE)
  @HttpCode(HttpStatus.NO_CONTENT)
  @Post('/registration')
  async signUpPlayer(@Body() createUserDto: RegistrationBody): Promise<void> {
    return await this.service.signUpPlayer(createUserDto);
  }

  @ApiOperation(RESET_CODE.OPERATION)
  @ApiNoContentResponse(RESET_CODE.SUCCESS)
  @ApiNotFoundResponse(RESET_CODE.USER_NOT_EXISTS)
  @ApiUnauthorizedResponse(RESET_CODE.UNCONFIRMED_EMAIL)
  @ApiUnprocessableEntityResponse(RESET_CODE.UNKNOWN_STATUS)
  @HttpCode(HttpStatus.NO_CONTENT)
  @Put('/password/code')
  async sendResetCodeOrTemporaryPassword(@Body() data: ResetPasswordCodeBody): Promise<void> {
    return await this.service.sendResetCodeOrTemporaryPassword(data.email);
  }

  @ApiOperation(RESET_PASSWORD.OPERATION)
  @ApiNoContentResponse(RESET_PASSWORD.SUCCESS)
  @ApiTooManyRequestsResponse(RESET_PASSWORD.TOO_MANY_REQUESTS)
  @ApiBadRequestResponse(RESET_PASSWORD.INVALID_CODE)
  @HttpCode(HttpStatus.NO_CONTENT)
  @Put('/password/reset')
  async resetPassword(@Body() body: ResetPasswordBody): Promise<void> {
    return await this.service.resetPassword(body);
  }

  @ApiOperation(CHANGE_PASSWORD.OPERATION)
  @ApiOkResponse(CHANGE_PASSWORD.SUCCESS)
  @ApiForbiddenResponse(CHANGE_PASSWORD.FORBIDDEN)
  @ApiUnprocessableEntityResponse(CHANGE_PASSWORD.FAILURE)
  @ApiBearerAuth()
  @UseGuards(CognitoGuard)
  @HttpCode(HttpStatus.NO_CONTENT)
  @Put('/password/change')
  async changePassword(@Body() body: ChangePasswordBody): Promise<void> {
    return await this.service.changePassword(body);
  }

  @ApiOperation(LOGOUT.OPERATION)
  @ApiNoContentResponse(LOGOUT.SUCCESS)
  @ApiUnauthorizedResponse(LOGOUT.UNAUTHORIZED)
  @ApiForbiddenResponse(LOGOUT.INVALID_TOKEN)
  @ApiBearerAuth()
  @UseGuards(CognitoGuard)
  @HttpCode(HttpStatus.NO_CONTENT)
  @Get('/logout')
  async logout(): Promise<void> {
    return await this.service.logout();
  }

  @ApiOperation(GET_ME.OPERATION)
  @ApiOkResponse({ ...GET_ME.SUCCESS, type: UserEntity })
  @ApiNotFoundResponse(GET_ME.NOT_FOUND)
  @ApiForbiddenResponse(GET_ME.FORBIDDEN)
  @ApiUnprocessableEntityResponse(GET_ME.FAILURE)
  @ApiBearerAuth()
  @UseGuards(CognitoGuard)
  @Get('/me')
  getMe(): Promise<UserEntity & { hasMembership: boolean }> {
    return this.service.getMe();
  }

  @ApiOperation(REFRESH_TOKENS.OPERATION)
  @ApiOkResponse(REFRESH_TOKENS.SUCCESS)
  @ApiUnauthorizedResponse(REFRESH_TOKENS.INVALID_REFRESH_TOKEN)
  @ApiUnprocessableEntityResponse(REFRESH_TOKENS.FAILURE)
  @HttpCode(HttpStatus.OK)
  @Put('/refresh')
  async refreshTokens(@Body() body: RefreshTokensBody): Promise<LoginResponse> {
    return await this.service.refreshTokens(body);
  }
}

export const BAD_EMAIL_ERROR = 'Please use a valid email address';

export const EMAIL_PASSWORD_SAME_ERROR = 'Your password cannot be the same as your email';

export const EMPTY_FIELD_ERROR = (fieldName: string): string => `Please enter a ${fieldName}`;

// eslint-disable-next-line quotes
export const BAD_EMAIL_OR_PASSWORD_ERROR = `The email address or password you've entered is incorrect, try again`;

export const BAD_PASSWORD_ERROR =
  'The password you have entered is incorrect. Please enter your password again or reset your password.';

export const BAD_TEMPORARY_PASSWORD_ERROR =
  'The temporary password you have entered is incorrect. Please use the password reset functionality to generate a new temporary password.';

export const NOT_CONFIRMED_ERROR =
  'Your email address has not been confirmed. Please check your email for a confirmation email and click on the confirmation link within it';

export const DEACTIVATED_ERROR =
  'Your account has been deactivated. Please contact hello@return2play.org.uk to restore your access.';

export const NOT_USER_FOUND =
  'The email address used is incorrect or there is no user registered with this email address.';

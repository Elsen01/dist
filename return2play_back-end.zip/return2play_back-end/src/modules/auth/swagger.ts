import { IDocumentedEndpoint } from '../shared/interfaces/swagger.interface';

export const LOGIN: IDocumentedEndpoint = {
  OPERATION: {
    description:
      'For regular login flow provide `email` and `password` fields. If you get `422` (UnprocessableEntityException) then provide `newPassword` field. This exception occurs if user log in with a temporary password. They must provide a new own one.',
  },
  SUCCESS: {
    description:
      '`Success` User is authenticated. There are 3 tokens: `idToken` contains core information of user; use `accessToken` for accessing protected routes; use `refreshToken` in order to obtain new tokens',
  },
  UNCONFIRMED_EMAIL: {
    description:
      '`Cognito` User has not confirmed their email yet. Confirmation email was sent and user must verify their email before next attempt to login',
  },
  INCORRECT_DATA: {
    description: '`Cognito` User with provided email is not found or password is invalid',
  },
  TEMPORARY_PASSWORD: {
    description:
      '`Cognito` A temporary password was provided, user must specify `newPassword` along with temporary one and try again',
  },
};

export const REGISTRATION: IDocumentedEndpoint = {
  OPERATION: {
    description:
      'This endpoint is used for registration a new user with `parents` role. After registration user must verify their email via link. Password must fulfill the following constraints: at least one upper- and lowercase letter, number and minimum 8 symbols',
  },
  SUCCESS: {
    description: '`Success` User was signed up',
  },
  INVALID_PASSWORD: {
    description: '`Cognito` Password did not meet constraints. Come up with stronger one',
  },
  USER_EXISTS: {
    description: '`Cognito` User already exists, login instead',
  },
  FAILURE: {
    description: '`AWS` Registration process failed, see message in response for more information',
  },
};

export const RESET_CODE: IDocumentedEndpoint = {
  OPERATION: {
    description:
      'If user logged in the system at least one with own password, Cognito sends verification code for resetting password, use it before actually sends a new password in reset endpoint. Otherwise temporary password is sent, user must sign in and immediately change it',
  },
  SUCCESS: {
    description: '`Success` Code or temporary password was sent',
  },
  USER_NOT_EXISTS: {
    description: '`Cognito` User does not exist in the system',
  },
  UNCONFIRMED_EMAIL: {
    description: '`Cognito` Email is not confirmed. Confirmation link was sent to email',
  },
  UNKNOWN_STATUS: {
    description:
      '`API` User status is unknow for the system, this case has to be handled in more specific way. Contact backend developer and provide appropriate info',
  },
};

export const RESET_PASSWORD: IDocumentedEndpoint = {
  OPERATION: {
    description: 'After receiving a reset code, user is able to set a new password',
  },
  SUCCESS: {
    description: '`Success` Password was changed',
  },
  TOO_MANY_REQUESTS: {
    description: '`Cognito` User did too many requests, hold on and try again later',
  },
  INVALID_CODE: {
    description: '`Cognito` Code is expired or invalid, user should request a new or check the exist one',
  },
};

export const LOGOUT: IDocumentedEndpoint = {
  OPERATION: {
    description: 'If user has valid `accessToken`, they are able to log out, that is, remove session data from Cognito',
  },
  SUCCESS: {
    description: '`Success` Session data was removed from Cognito',
  },
  INVALID_TOKEN: {
    description: '`API` Token is expired or invalid',
  },
  UNAUTHORIZED: {
    description: '`AWS` See response message for additional information',
  },
};

export const REFRESH_TOKENS: IDocumentedEndpoint = {
  OPERATION: {
    description: 'When user `accessToken` is expired and `refreshToken` is valid, they are able to obtain new ones',
  },
  SUCCESS: {
    description: '`Success` Provide new id-, access- and refreshToken',
  },
  INVALID_REFRESH_TOKEN: {
    description: '`Cognito` Refresh token is invalid or expired',
  },
  FAILURE: {
    description:
      '`API` For additional info see response message. Contact backend developer and provide appropriate info about exception',
  },
};

export const GET_ME: IDocumentedEndpoint = {
  OPERATION: {
    description: 'Get details about logged in user.',
  },
  SUCCESS: {
    description: '`Success` User info is returned',
  },
  FAILURE: {
    description: '`API` Error occurs during select an entity',
  },
  NOT_FOUND: {
    description: '`API` User is not found within the system',
  },
  FORBIDDEN: {
    description: '`API` User has no permissions',
  },
};

export const CHANGE_PASSWORD: IDocumentedEndpoint = {
  OPERATION: {
    description: 'User can change password if old password and new password are provided.',
  },
  SUCCESS: {
    description: '`Success` Password successfully changed',
  },
  FAILURE: {
    description: '`API` Error occurs during change password',
  },
  FORBIDDEN: {
    description: '`API` User has no permissions',
  },
};

import { Body, Controller, Delete, Get, Param, Post, Query, UseGuards } from '@nestjs/common';
import {
  ApiTags,
  ApiBearerAuth,
  ApiForbiddenResponse,
  ApiOkResponse,
  ApiOperation,
  ApiUnprocessableEntityResponse,
  ApiNotFoundResponse,
  ApiConflictResponse,
} from '@nestjs/swagger';
import { Roles } from '../shared/decorators/roles.decorator';
import { CognitoGuard } from '../shared/guards/cognito.guard';
import { RolesGuard } from '../shared/guards/roles.guard';
import { IdDto, PaginationDto } from '../shared/shared.dto';
import { FindManyResponse } from '../shared/types';
import { UserRole } from '../users/types';
import { CreateRecipientBody } from './dtos/create-recipients.dto';
import { AdditionalRecipientEntity } from './entities/recipient.entity';
import { RecipientsService } from './recipients.service';
import { CREATE_ONE, DELETE_ONE, FIND_MANY } from './swagger';

@ApiTags('Additional Recipients')
@UseGuards(CognitoGuard, RolesGuard)
@Roles(UserRole.SuperAdmin, UserRole.OrganizationAdmin, UserRole.MedicalStaff)
@ApiBearerAuth()
@Controller('recipients')
export class RecipientsController {
  constructor(private service: RecipientsService) {}

  @ApiOperation(CREATE_ONE.OPERATION)
  @ApiOkResponse(CREATE_ONE.SUCCESS)
  @ApiConflictResponse(CREATE_ONE.RECEPIENT_EXISTS)
  @ApiUnprocessableEntityResponse(CREATE_ONE.FAILURE)
  @ApiForbiddenResponse(CREATE_ONE.FORBIDDEN)
  @Post()
  createOne(@Body() recipient: CreateRecipientBody): Promise<void> {
    return this.service.createOne(recipient);
  }

  @ApiOperation(DELETE_ONE.OPERATION)
  @ApiOkResponse(DELETE_ONE.SUCCESS)
  @ApiNotFoundResponse(DELETE_ONE.NOT_FOUND)
  @ApiUnprocessableEntityResponse(DELETE_ONE.FAILURE)
  @ApiForbiddenResponse(DELETE_ONE.FORBIDDEN)
  @Delete('/:id')
  deleteOne(@Param() param: IdDto): Promise<void> {
    return this.service.deleteOne(param.id);
  }

  @ApiOperation(FIND_MANY.OPERATION)
  @ApiOkResponse(FIND_MANY.SUCCESS)
  @ApiUnprocessableEntityResponse(FIND_MANY.FAILURE)
  @ApiForbiddenResponse(FIND_MANY.FORBIDDEN)
  @Roles(UserRole.Player, UserRole.Parent, UserRole.Doctor, UserRole.MedicalStaff, UserRole.StaffUser)
  @Get('/:id')
  findMany(@Param() param: IdDto, @Query() query: PaginationDto): Promise<FindManyResponse<AdditionalRecipientEntity>> {
    return this.service.findManyForPlayer(query, param.id);
  }
}

import { ForbiddenException, Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { PlayerRepository } from '../players/player.repository';
import { PaginationDto } from '../shared/shared.dto';
import { FindManyResponse } from '../shared/types';
import { CreateRecipientBody } from './dtos/create-recipients.dto';
import { AdditionalRecipientEntity } from './entities/recipient.entity';
import { RecipientRepository } from './recipient.repository';
import { RecipientStatus } from './types/recipient.types';

@Injectable()
export class RecipientsService {
  constructor(
    @InjectRepository(RecipientRepository) readonly recipientRepo: RecipientRepository,
    @InjectRepository(PlayerRepository) readonly playerRepo: PlayerRepository
  ) {}

  async createOne(recipient: CreateRecipientBody): Promise<void> {
    const isHasAccessToPlayer = await this.playerRepo.isHasAccessToPlayer(recipient.playerId);

    if (!isHasAccessToPlayer) {
      throw new ForbiddenException('User has no permission to create additional recipient for this player');
    }

    return this.recipientRepo.createOne(recipient);
  }

  async deleteOne(id: string): Promise<void> {
    const recipient = await this.recipientRepo.findOne({ id, status: RecipientStatus.Active });

    if (!recipient) {
      throw new NotFoundException('No such recipient found');
    }

    const isHasAccessToPlayer = await this.playerRepo.isHasAccessToPlayer(recipient.player.userId);

    if (!isHasAccessToPlayer) {
      throw new ForbiddenException('User has no permission to delete additional recipient for this player');
    }

    return this.recipientRepo.deleteOne(id);
  }

  async findManyForPlayer(
    query: PaginationDto,
    playerId: string
  ): Promise<FindManyResponse<AdditionalRecipientEntity>> {
    const isHasAccessToPlayer = await this.playerRepo.isHasAccessToPlayer(playerId);

    if (!isHasAccessToPlayer) {
      throw new ForbiddenException('User has no permission to view additional recepients of this player');
    }

    return this.recipientRepo.findMany({ player: { userId: playerId }, status: RecipientStatus.Active }, query);
  }
}

import { UnprocessableEntityException } from '@nestjs/common';
import { EntityRepository, FindConditions } from 'typeorm';
import { PlayerEntity } from '../players/entities/player.entity';
import { BaseRepository } from '../shared/base.repository';
import { RoleManager } from '../shared/helpers/accessManager/role.manager';
import { PaginationDto } from '../shared/shared.dto';
import { FindManyResponse } from '../shared/types';
import { CreateRecipientBody } from './dtos/create-recipients.dto';
import { AdditionalRecipientEntity } from './entities/recipient.entity';
import { RecipientSortOptions, RecipientStatus } from './types/recipient.types';

@EntityRepository(AdditionalRecipientEntity)
export class RecipientRepository extends BaseRepository<AdditionalRecipientEntity> {
  private readonly roleManager = RoleManager.getInstance();

  async createOne({ playerId, ...recepientBody }: CreateRecipientBody): Promise<void> {
    const player = await this.getRepositoryFor(PlayerEntity).findOne(playerId);

    const recipient = this.repository.create({ ...recepientBody, player });

    await this.repository.save(recipient).catch((err) => {
      throw new UnprocessableEntityException(err.message);
    });
  }

  findOne(conditions: FindConditions<AdditionalRecipientEntity>): Promise<AdditionalRecipientEntity> {
    return this.repository.findOne(conditions);
  }

  async findMany(
    condition: FindConditions<AdditionalRecipientEntity>,
    { limit, page }: PaginationDto = { limit: null, page: 0 }
  ): Promise<FindManyResponse<AdditionalRecipientEntity>> {
    try {
      const [data, totalItems] = await this.repository.findAndCount({
        where: condition,
        order: { [RecipientSortOptions.CreatedAt]: 'DESC' },
        skip: limit * page,
        take: limit,
      });

      return { totalItems, data };
    } catch (err) {
      throw new UnprocessableEntityException(err.message);
    }
  }

  async deleteOne(id: string): Promise<void> {
    await this.repository.update(id, { status: RecipientStatus.Deleted }).catch((err) => {
      throw new UnprocessableEntityException(err.message);
    });
  }
}

export enum RecipientStatus {
  Active = 'Active',
  Deleted = 'Deleted',
}

export enum RecipientSortOptions {
  CreatedAt = 'createdAt',
}

import { IsEmail, IsOptional, IsString, IsUUID, Matches, MaxLength } from 'class-validator';

export class CreateRecipientBody {
  @Matches(/^[a-z ,.'-]+/i)
  @MaxLength(35)
  firstName: string;

  @Matches(/^[a-z ,.'-]+/i)
  @MaxLength(35)
  lastName: string;

  @IsEmail()
  email: string;

  @IsOptional()
  @IsString()
  additionalInfo?: string;

  @IsUUID()
  playerId: string;
}

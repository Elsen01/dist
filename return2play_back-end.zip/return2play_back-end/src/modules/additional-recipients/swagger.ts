import { IDocumentedEndpoint } from '../shared/interfaces/swagger.interface';

export const CREATE_ONE: IDocumentedEndpoint = {
  OPERATION: {
    description:
      'Create additional mail recepient for a player. Only `super admins` and `organization admins` are allowed to perform this action',
  },
  SUCCESS: {
    description: '`Success` Additional recepient was created',
  },
  RECEPIENT_EXISTS: {
    description: '`API` Additional recepient already exists',
  },
  FORBIDDEN: {
    description: '`API` User has no permissions to create a recepient',
  },
  FAILURE: {
    description: '`API` Saved entity to the database failed',
  },
};

export const DELETE_ONE: IDocumentedEndpoint = {
  OPERATION: {
    description:
      'Delete additional mail recepient for a player. Only `super admins` and `organization admins` are allowed to perform this action',
  },
  SUCCESS: {
    description: '`Success` Additional recepient was deleted',
  },
  FORBIDDEN: {
    description: '`API` User has no permissions to delete a recepient',
  },
  NOT_FOUND: {
    description: '`API` Recepient is not found within the system',
  },
  FAILURE: {
    description: '`API` Saved entity to the database failed',
  },
};

export const FIND_MANY: IDocumentedEndpoint = {
  OPERATION: {
    description:
      'Get list of `Additional recepients` of a certain player. Only `super admins`, `organization admins`, `staff users`, `doctors`, `parents` and `players` are allowed to perform this action',
  },
  SUCCESS: {
    description: '`Success` Recepient list is returned',
  },
  FORBIDDEN: {
    description: '`API` User has no permissions to get recepient list',
  },
  FAILURE: {
    description: '`API` Error occurs during select an entity',
  },
};

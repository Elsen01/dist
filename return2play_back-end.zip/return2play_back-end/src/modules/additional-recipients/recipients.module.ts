import { Module } from '@nestjs/common';
import { RecipientsService } from './recipients.service';
import { RecipientsController } from './recipients.controller';
import { TypeOrmModule } from '@nestjs/typeorm';
import { RecipientRepository } from './recipient.repository';
import { PlayerRepository } from '../players/player.repository';
import { SharedModule } from '../shared/shared.module';

@Module({
  providers: [RecipientsService],
  controllers: [RecipientsController],
  imports: [TypeOrmModule.forFeature([RecipientRepository, PlayerRepository]), SharedModule],
})
export class RecipientsModule {}

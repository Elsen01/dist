import {
  Column,
  CreateDateColumn,
  Entity,
  JoinColumn,
  ManyToOne,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm';
import { PlayerEntity } from '../../players/entities/player.entity';
import { RecipientStatus } from '../types/recipient.types';

@Entity('additional_recepients')
export class AdditionalRecipientEntity {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ name: 'first_name' })
  firstName: string;

  @Column({ name: 'last_name' })
  lastName: string;

  @Column()
  email: string;

  @Column({ name: 'additional_info', nullable: true, type: 'text' })
  additionalInfo: string;

  @Column({ type: 'enum', enum: RecipientStatus, default: RecipientStatus.Active })
  status: RecipientStatus;

  @CreateDateColumn({ name: 'created_at' })
  createdAt: Date;

  @ManyToOne(() => PlayerEntity, (player) => player?.additionalRecepients, { onDelete: 'CASCADE' })
  @JoinColumn({ name: 'player_id', referencedColumnName: 'userId' })
  player: PlayerEntity;

  @UpdateDateColumn({ name: 'updated_at' })
  updatedAt: Date;
}

import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { RecipientRepository } from '../additional-recipients/recipient.repository';
import { RecipientsModule } from '../additional-recipients/recipients.module';
import { RecipientsService } from '../additional-recipients/recipients.service';
import { OrganizationRepository } from '../organizations/organizations.repository';
import { PlayerRepository } from '../players/player.repository';
import { PlayersService } from '../players/players.service';
import { AwsSignManager } from '../shared/helpers/lambda/sign.manager';
import { SharedModule } from '../shared/shared.module';
import { TagRepository } from '../tags/tags.repository';
import { UsersModule } from '../users/users.module';
import { UserRepository } from '../users/users.repository';
import { UsersService } from '../users/users.service';
import { ImportsService } from './imports.service';

@Module({
  controllers: [],
  providers: [ImportsService, PlayersService, UsersService, RecipientsService, AwsSignManager],
  imports: [
    TypeOrmModule.forFeature([
      PlayerRepository,
      UserRepository,
      RecipientRepository,
      TagRepository,
      OrganizationRepository,
    ]),
    SharedModule,
    UsersModule,
    RecipientsModule,
  ],
})
export class ImportsModule {}

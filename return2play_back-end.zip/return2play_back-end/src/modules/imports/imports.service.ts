import { ImportsManager } from './../shared/helpers/imports/imports.manager';
import {
  BadRequestException,
  HttpService,
  Inject,
  Injectable,
  Logger,
  LoggerService,
  UnprocessableEntityException,
} from '@nestjs/common';
import { IFile } from '../shared/helpers/s3bucket/types';
import { S3_IMPORTS_FOLDER, TABLE_FORMATS } from '../shared/constants';
import { ILambdaResponse, lambdaImportUrl } from './types';
import { S3BucketManager } from '../shared/helpers/s3bucket/s3bucket.manager';
import { RoleManager } from '../shared/helpers/accessManager/role.manager';
import { In } from 'typeorm';
import { InjectRepository } from '@nestjs/typeorm';
import { PlayerRepository } from '../players/player.repository';
import { RecipientRepository } from '../additional-recipients/recipient.repository';
import { UserRepository } from '../users/users.repository';
import { uniq } from 'lodash';
import { stringToArray } from '../shared/utils/common.utils';
import { OrganizationRepository } from '../organizations/organizations.repository';
import { AwsSignManager } from '../shared/helpers/lambda/sign.manager';
import { CsvTemplateResponse } from '../players/types';
import { AppConfigService } from '../../config/config.service';

@Injectable()
export class ImportsService {
  private readonly roleManager = RoleManager.getInstance();

  constructor(
    private configService: AppConfigService,
    private s3Bucket: S3BucketManager,
    private signManager: AwsSignManager,
    private httpService: HttpService,
    @Inject(Logger) private logger: LoggerService,
    @InjectRepository(PlayerRepository)
    private playerRepo: PlayerRepository,
    @InjectRepository(RecipientRepository)
    readonly recipientRepo: RecipientRepository,
    @InjectRepository(UserRepository)
    readonly userRepo: UserRepository,
    @InjectRepository(OrganizationRepository)
    readonly orgRepo: OrganizationRepository,
    private imports: ImportsManager
  ) {}

  async uploadPlayersCsv(file: IFile, organizationIds: string[]): Promise<void> {
    if (!file) {
      throw new BadRequestException('No file provided');
    }
    if (!file.size) {
      throw new UnprocessableEntityException('File is empty');
    }

    organizationIds = stringToArray(organizationIds);
    const orgsDoExist = await this.orgRepo.findIfOrgsExist(organizationIds);
    if (!orgsDoExist) {
      throw new UnprocessableEntityException('Invalid organizations ids');
    }

    const userId = this.roleManager.userId;
    const key = this.s3Bucket.getBucketKey(file, userId);
    const s3Path = `${S3_IMPORTS_FOLDER}/${key}`;
    await this.s3Bucket.upload(s3Path, TABLE_FORMATS, file);

    const stage = this.configService.stage;
    const lambdaImportPath = lambdaImportUrl(key, S3_IMPORTS_FOLDER);

    const { headers } = this.signManager.signRequest(`/${stage}/${lambdaImportPath}`);

    const { data } = await this.httpService
      .post<ILambdaResponse>(
        `https://${this.configService.aws.lambdaHost}/${stage}/${lambdaImportPath}`,
        {
          headers,
        },
        { timeout: 500000 }
      )
      .toPromise()
      .catch((err) => {
        throw new UnprocessableEntityException(err.response.data.errors);
      });

    const players = data.data;

    const playerEmails = players.filter((data) => data.email);
    const importPlayersEmail = playerEmails.map((p) => p.email);
    const parentEmails = players.flatMap((p) => p.parents.map((pr) => pr.email));
    const importParentsEmail = parentEmails.filter((e) => e);

    const existingPlayers = await this.userRepo.findManyPlayerByEmail(importPlayersEmail);
    const existingPlayersEmail = existingPlayers.map((p) => p.email);

    const existingPlayersImport = playerEmails.filter((p) => existingPlayersEmail.includes(p.email));

    const uniqEmails = uniq(playerEmails);
    if (playerEmails.length !== uniqEmails.length) {
      throw new UnprocessableEntityException('Found email duplicates');
    }

    try {
      return await this.playerRepo.runTransaction(
        this.imports.createManyFromImport,
        players,
        organizationIds,
        existingPlayersImport,
        importParentsEmail
      );
    } catch (err) {
      this.logger.error(err);
      throw new UnprocessableEntityException(err.message);
    }
  }

  async getCsvTemplateLink(): Promise<CsvTemplateResponse> {
    return { link: this.configService.aws.csvTemplateLink };
  }

  private async validateEmailsConflict(emails: string[]): Promise<void> {
    const users = await this.userRepo.findManyByCondition({ where: { email: In(emails) } });
    const { data: additionals } = await this.recipientRepo.findMany({ email: In(emails) });

    const existentEmails = users.map(({ email }) => email);
    existentEmails.concat(additionals.map(({ email }) => email));

    if (existentEmails.length) {
      throw new UnprocessableEntityException(`Users with these emails already exist: ${existentEmails.join(', ')}`);
    }
  }
}

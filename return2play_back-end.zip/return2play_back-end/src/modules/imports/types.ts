import { PlayerImportDto } from './dto/import-player.dto';

export const lambdaImportUrl = (key: string, folder: string): string => {
  return `import?key=${key}&folder=${folder}`;
};

export interface ILambdaResponse {
  data: PlayerImportDto[];
}

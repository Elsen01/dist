import { OmitType } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import {
  IsArray,
  IsDateString,
  IsEmail,
  IsEnum,
  IsNotEmpty,
  IsOptional,
  IsString,
  IsUUID,
  Matches,
  MaxLength,
  ValidateNested,
} from 'class-validator';
import { CreatePlayerBody, NewTag } from '../../players/dtos/create-player.dto';
import { WondeStudentEntity } from '../../players/entities/wondeStudent.entity';
import { NAME_REGEXP } from '../../shared/constants';
import { TagEntity } from '../../tags/entities/tag.entity';
import { Gender } from '../../users/types';
import { ParentImportDto } from './import-parent.dto';
import { AdditionalRecipientImportDto } from './import-recipient.dto';

export class PlayerImportDto {
  @Matches(NAME_REGEXP)
  @MaxLength(35)
  firstName: string;

  @Matches(NAME_REGEXP)
  @MaxLength(35)
  lastName: string;

  @IsEmail()
  email: string;

  @IsEnum(Gender)
  gender: Gender;

  @IsString()
  @IsNotEmpty()
  @IsOptional()
  yearGroup?: string;

  @IsDateString()
  birthday: Date;

  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => ParentImportDto)
  parents: ParentImportDto[];

  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => AdditionalRecipientImportDto)
  @IsOptional()
  additional?: AdditionalRecipientImportDto[];

  @IsUUID('all', { each: true })
  @IsOptional()
  tagIds?: string[];

  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => NewTag)
  @IsOptional()
  newTags?: NewTag[];

  @IsOptional()
  wondeStudent?: WondeStudentEntity;

  @IsOptional()
  socsId?: string;
}

export class CreatePlayerFromImportBody extends OmitType(CreatePlayerBody, ['newTags', 'tagIds'] as const) {
  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => TagEntity)
  @IsOptional()
  tags: TagEntity[];

  @IsOptional()
  wondeStudent?: WondeStudentEntity;
}

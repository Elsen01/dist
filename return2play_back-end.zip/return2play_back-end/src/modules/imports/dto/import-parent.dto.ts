import { IsEmail, Matches, MaxLength } from 'class-validator';
import { NAME_REGEXP } from '../../shared/constants';

export class ParentImportDto {
  @Matches(NAME_REGEXP)
  @MaxLength(35)
  firstName: string;

  @Matches(NAME_REGEXP)
  @MaxLength(35)
  lastName: string;

  @IsEmail()
  email?: string;
}

import { OmitType } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import { IsEmail, Matches, MaxLength, ValidateNested } from 'class-validator';
import { CreateRecipientBody } from '../../additional-recipients/dtos/create-recipients.dto';
import { PlayerEntity } from '../../players/entities/player.entity';
import { NAME_REGEXP } from '../../shared/constants';

export class AdditionalRecipientImportDto {
  @Matches(NAME_REGEXP)
  @MaxLength(35)
  firstName: string;

  @Matches(NAME_REGEXP)
  @MaxLength(35)
  lastName: string;

  @IsEmail()
  email: string;
}

export class CreateRecipientFromImport extends OmitType(CreateRecipientBody, ['playerId'] as const) {
  @ValidateNested()
  @Type(() => PlayerEntity)
  player: PlayerEntity;
}

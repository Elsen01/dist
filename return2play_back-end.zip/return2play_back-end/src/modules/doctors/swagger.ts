import { IDocumentedEndpoint } from '../shared/interfaces/swagger.interface';

export const CREATE_ONE: IDocumentedEndpoint = {
  OPERATION: {
    description: 'Create a new `Doctor` within the system. Only `super admins` are allowed to perform this action',
  },
  SUCCESS: {
    description: '`Success` Doctor was created',
  },
  ORGANIZATION_NOT_FOUND: {
    description: '`API` Provided organizations do not exist',
  },
  USER_EXISTS: {
    description: '`API` User with provided email already exists',
  },
  FORBIDDEN: {
    description: '`API` User has no permissions to create doctor',
  },
  FAILURE: {
    description: '`API` Saved entity to the database failed',
  },
};

export const EDIT_ONE: IDocumentedEndpoint = {
  OPERATION: {
    description: '`Super admin` is allowed to edit information. If a property is not provided it stays the same',
  },
  SUCCESS: {
    description: '`Success` Doctor was updated',
  },
  NOT_FOUND: {
    description: '`API` Doctor with provided id does not exist or provided organizations do not exist',
  },
  FORBIDDEN: {
    description: '`API` User has no permissions to update the doctor',
  },
  FAILURE: {
    description: '`API` Saved entity to the database failed',
  },
};

export const GET_ONE: IDocumentedEndpoint = {
  OPERATION: {
    description: 'Get details about particular doctor. This action can perform only `Super admin`',
  },
  SUCCESS: {
    description: '`Success` Doctor info is returned',
  },
  FAILURE: {
    description: '`API` Error occurs during select an entity',
  },
  NOT_FOUND: {
    description: '`API` Doctor is not found within the system',
  },
  FORBIDDEN: {
    description: '`API` User has no permissions to get doctor',
  },
};

export const GET_MANY: IDocumentedEndpoint = {
  OPERATION: {
    description: 'Get list of doctors.',
  },
  SUCCESS: {
    description: '`Success` Doctors info is returned',
  },
  FAILURE: {
    description: '`API` Error occurs during select an entity',
  },
  NOT_FOUND: {
    description: '`API` Doctors are not found within the system',
  },
  FORBIDDEN: {
    description: '`API` User has no permissions to get doctors',
  },
};

import { ApiPropertyOptional } from '@nestjs/swagger';
import { IsEmail, IsNotEmpty, IsOptional, Matches, MaxLength, MinLength } from 'class-validator';
import { NAME_REGEXP } from '../../shared/constants';

export class CreateDoctorBody {
  @IsEmail()
  @MinLength(7)
  @MaxLength(255)
  email: string;

  @IsNotEmpty()
  @MinLength(1)
  @MaxLength(128)
  @Matches(NAME_REGEXP)
  firstName: string;

  @IsNotEmpty()
  @MinLength(1)
  @MaxLength(128)
  @Matches(NAME_REGEXP)
  lastName: string;

  @MinLength(1)
  @MaxLength(255)
  gmc: string;

  @MinLength(1)
  @MaxLength(255)
  @IsOptional()
  speciality: string;

  @MinLength(1)
  @MaxLength(1000)
  @IsOptional()
  bio?: string;

  @ApiPropertyOptional({ type: 'file' })
  @IsOptional()
  picture?: any;
}

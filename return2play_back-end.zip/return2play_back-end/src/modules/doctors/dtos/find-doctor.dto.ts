import { IsEnum, IsOptional, IsString, MaxLength, MinLength } from 'class-validator';
import { PaginationDto } from '../../shared/shared.dto';
import { Order } from '../../shared/types';
import { DoctorSortOptions } from '../types';

export class DoctorFiltersQuery extends PaginationDto {
  @IsEnum(DoctorSortOptions)
  @IsOptional()
  sort? = DoctorSortOptions.CreatedAt;

  @IsEnum(Order)
  @IsOptional()
  order? = Order.DESC;

  @IsString()
  @MinLength(1)
  @MaxLength(100)
  @IsOptional()
  searchWord?: string;
}

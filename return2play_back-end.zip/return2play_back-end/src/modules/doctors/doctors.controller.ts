import { DoctorsService } from './doctors.service';
import {
  Body,
  Controller,
  Get,
  HttpCode,
  HttpStatus,
  Param,
  Post,
  Put,
  Query,
  UploadedFile,
  UseGuards,
  UseInterceptors,
} from '@nestjs/common';
import {
  ApiBearerAuth,
  ApiConflictResponse,
  ApiConsumes,
  ApiForbiddenResponse,
  ApiNoContentResponse,
  ApiNotFoundResponse,
  ApiOkResponse,
  ApiOperation,
  ApiTags,
  ApiUnprocessableEntityResponse,
} from '@nestjs/swagger';
import { Roles } from '../shared/decorators/roles.decorator';
import { CognitoGuard } from '../shared/guards/cognito.guard';
import { RolesGuard } from '../shared/guards/roles.guard';
import { UserRole } from '../users/types';
import { CreateDoctorBody } from './dtos/create-doctor.dto';
import { CREATE_ONE, EDIT_ONE, GET_MANY, GET_ONE } from './swagger';
import { FileInterceptor } from '@nestjs/platform-express';
import { multerOptionsImg } from '../shared/helpers/multer/options';
import { IFile } from '../shared/helpers/s3bucket/types';
import { IdDto } from '../shared/shared.dto';
import { UpdateDoctorBody } from './dtos/edit-doctor.dto';
import { FindManyResponse } from '../shared/types';
import { DoctorEntity } from './entities/doctor.entity';
import { DoctorFiltersQuery } from './dtos/find-doctor.dto';

@ApiTags('Doctors')
@UseGuards(CognitoGuard, RolesGuard)
@Roles(UserRole.SuperAdmin)
@ApiBearerAuth()
@Controller('doctors')
export class DoctorsController {
  constructor(private service: DoctorsService) {}

  @ApiOperation(CREATE_ONE.OPERATION)
  @ApiNoContentResponse(CREATE_ONE.SUCCESS)
  @ApiForbiddenResponse(CREATE_ONE.FORBIDDEN)
  @ApiUnprocessableEntityResponse(CREATE_ONE.FAILURE)
  @ApiConflictResponse(CREATE_ONE.USER_EXISTS)
  @ApiNotFoundResponse(CREATE_ONE.ORGANIZATION_NOT_FOUND)
  @HttpCode(HttpStatus.NO_CONTENT)
  @ApiConsumes('multipart/form-data')
  @UseInterceptors(FileInterceptor('picture', multerOptionsImg()))
  @Post()
  createDoctor(@UploadedFile() logo: IFile, @Body() body: CreateDoctorBody): Promise<void> {
    return this.service.createOne(logo, body);
  }

  @ApiOperation(EDIT_ONE.OPERATION)
  @ApiNoContentResponse(EDIT_ONE.SUCCESS)
  @ApiNotFoundResponse(EDIT_ONE.NOT_FOUND)
  @ApiForbiddenResponse(EDIT_ONE.FORBIDDEN)
  @ApiUnprocessableEntityResponse(EDIT_ONE.FAILURE)
  @ApiConsumes('multipart/form-data')
  @UseInterceptors(FileInterceptor('picture', multerOptionsImg()))
  @HttpCode(HttpStatus.NO_CONTENT)
  @Roles(UserRole.Doctor)
  @Put('/:id')
  update(@Param() param: IdDto, @Body() body: UpdateDoctorBody, @UploadedFile() fileLogo: IFile): Promise<void> {
    const picture = fileLogo ?? body.picture;

    return this.service.update(param.id, { ...body, picture });
  }

  @ApiOperation(GET_MANY.OPERATION)
  @ApiOkResponse(GET_MANY.SUCCESS)
  @ApiNotFoundResponse(GET_MANY.NOT_FOUND)
  @ApiForbiddenResponse(GET_MANY.FORBIDDEN)
  @ApiUnprocessableEntityResponse(GET_MANY.FAILURE)
  @Roles(UserRole.MedicalStaff, UserRole.OrganizationAdmin, UserRole.SuperAdmin)
  @Get()
  getMany(@Query() query: DoctorFiltersQuery): Promise<FindManyResponse<DoctorEntity>> {
    return this.service.findMany(query);
  }

  @ApiOperation(GET_ONE.OPERATION)
  @ApiOkResponse(GET_ONE.SUCCESS)
  @ApiNotFoundResponse(GET_ONE.NOT_FOUND)
  @ApiForbiddenResponse(GET_ONE.FORBIDDEN)
  @ApiUnprocessableEntityResponse(GET_ONE.FAILURE)
  @Get('/:id')
  getOne(@Param() param: IdDto): Promise<DoctorEntity> {
    return this.service.findOne(param.id);
  }
}

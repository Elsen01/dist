import { UserRole, UserStatus } from './../users/types';
import { UnprocessableEntityException } from '@nestjs/common';
import { EntityRepository, FindConditions } from 'typeorm';
import { RoleManager } from '../shared/helpers/accessManager/role.manager';
import { UserEntity } from '../users/entities/user.entity';
import { CreateDoctorBody } from './dtos/create-doctor.dto';
import { DoctorEntity } from './entities/doctor.entity';
import { UpdateDoctorBody } from './dtos/edit-doctor.dto';
import { DoctorFiltersQuery } from './dtos/find-doctor.dto';
import { BaseRepository } from '../shared/base.repository';

@EntityRepository(DoctorEntity)
export class DoctorRepository extends BaseRepository<DoctorEntity> {
  private readonly roleManager = RoleManager.getInstance();

  async create(player: CreateDoctorBody & { user: UserEntity }): Promise<DoctorEntity> {
    return await this.repository.save(player).catch((err) => {
      throw new UnprocessableEntityException(err.message);
    });
  }

  async update(id: string, user: UpdateDoctorBody): Promise<void> {
    await this.repository.save({ userId: id, ...user }).catch((err) => {
      throw new UnprocessableEntityException(err.message);
    });

    return;
  }

  async findById(id: string): Promise<DoctorEntity> {
    return await this.createQueryBuilder('doctor')
      .leftJoin('doctor.user', 'user')
      .where('doctor.userId = :id', { id })
      .andWhere('user.role = :role', { role: UserRole.Doctor })
      .getOne()
      .catch((err) => {
        throw new UnprocessableEntityException(err.message);
      });
  }

  async findMany(query: DoctorFiltersQuery): Promise<[DoctorEntity[], number]> {
    const { sort, order, page, limit, searchWord } = query;
    const [firstName, lastName] = searchWord ? searchWord?.split(' ', 2) : '';

    return await this.createQueryBuilder('doctor')
      .addSelect('user.status')
      .leftJoinAndSelect('doctor.user', 'user')
      .where('user.role = :role', { role: UserRole.Doctor })
      .andWhere('user.status <> :status', { status: UserStatus.Deleted })
      .andWhere(
        searchWord
          ? `(to_tsvector('simple', f_concat_ws(' ', user.firstName , user.lastName))
          @@ plainto_tsquery('simple', :searchWord) OR user.firstName ILIKE :searchWord OR user.lastName ILIKE :searchWord OR 
          (user.firstName ILIKE :firstName AND user.lastName ILIKE :lastName) OR (user.lastName ILIKE :firstName AND user.firstName ILIKE :lastName)
          OR user.email ILIKE :searchWord)`
          : 'true',
        {
          searchWord: `%${searchWord}%`,
          firstName: `%${firstName}%`,
          lastName: `%${lastName}%`,
        }
      )
      .orderBy(sort, order)
      .take(limit)
      .skip(limit * page)
      .getManyAndCount()
      .catch((err) => {
        throw new UnprocessableEntityException(err.message);
      });
  }

  async findOne(id: string): Promise<DoctorEntity> {
    return await this.createQueryBuilder('doctor')
      .addSelect('user.status')
      .leftJoinAndSelect('doctor.user', 'user')
      .where('user.role = :role', { role: UserRole.Doctor })
      .andWhere('user.status <> :status', { status: UserStatus.Deleted })
      .andWhere('user.id = :id', { id })
      .getOne()
      .catch((err) => {
        throw new UnprocessableEntityException(err.message);
      });
  }

  async findManyByCondition(condition: FindConditions<DoctorEntity>): Promise<DoctorEntity[]> {
    return this.repository.find({ where: condition, relations: ['user'] }).catch((err) => {
      throw new UnprocessableEntityException(err.message);
    });
  }
}

export enum DoctorSortOptions {
  FirstName = 'user.firstName',
  LastName = 'user.lastName',
  Email = 'user.email',
  Status = 'user.status',
  Gmc = 'doctor.gmc',
  CreatedAt = 'user.createdAt',
}

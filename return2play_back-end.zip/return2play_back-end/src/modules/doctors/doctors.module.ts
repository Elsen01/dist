import { DoctorRepository } from './doctor.repository';
import { Module } from '@nestjs/common';
import { DoctorsService } from './doctors.service';
import { DoctorsController } from './doctors.controller';
import { SharedModule } from '../shared/shared.module';
import { TypeOrmModule } from '@nestjs/typeorm';
import { UserRepository } from '../users/users.repository';

@Module({
  providers: [DoctorsService],
  controllers: [DoctorsController],
  imports: [TypeOrmModule.forFeature([DoctorRepository, UserRepository]), SharedModule],
})
export class DoctorsModule {}

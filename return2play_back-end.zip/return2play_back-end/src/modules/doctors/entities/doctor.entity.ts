import { UserEntity } from './../../users/entities/user.entity';
import {
  Column,
  CreateDateColumn,
  Entity,
  JoinColumn,
  OneToMany,
  OneToOne,
  PrimaryColumn,
  UpdateDateColumn,
} from 'typeorm';
import { ScheduledClinicEntity } from '../../clinics/entities/scheduledClinic.entity';
import { ClinicEntity } from '../../clinics/entities/clinic.entity';
import { AppointmentEntity } from '../../appointments/entities/appointment.entity';

@Entity('doctors')
export class DoctorEntity {
  @PrimaryColumn({ name: 'user_id' })
  userId: string;

  @Column()
  gmc: string;

  @Column({ nullable: true })
  bio?: string;

  @Column({ nullable: true })
  picture?: string;

  @Column({ nullable: true, length: 255 })
  speciality?: string;

  @OneToOne(() => UserEntity, { onDelete: 'CASCADE' })
  @JoinColumn({ name: 'user_id' })
  user: UserEntity;

  @OneToMany(() => ScheduledClinicEntity, (schedule) => schedule.doctor)
  scheduledClinics?: ScheduledClinicEntity[];

  @OneToMany(() => ClinicEntity, (clinic) => clinic.doctor)
  clinics?: ClinicEntity[];

  @OneToMany(() => AppointmentEntity, (appointment) => appointment.doctor)
  appointments?: AppointmentEntity[];

  @CreateDateColumn({ name: 'created_at' })
  createdAt: Date;

  @UpdateDateColumn({ name: 'updated_at' })
  updatedAt: Date;
}

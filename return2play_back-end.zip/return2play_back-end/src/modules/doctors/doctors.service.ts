import { PermissionManager } from './../shared/helpers/accessManager/permission.manager';
import { UserEntity } from './../users/entities/user.entity';
import { DoctorEntity } from './entities/doctor.entity';
import { DoctorRepository } from './doctor.repository';
import {
  ConflictException,
  Injectable,
  UnprocessableEntityException,
  NotFoundException,
  Inject,
  Logger,
  LoggerService,
  ForbiddenException,
  HttpStatus,
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { UserRepository } from '../users/users.repository';
import { CognitoManager } from '../shared/helpers/cognito/cognito.manager';
import { UserRole } from '../users/types';
import { QueryRunner } from 'typeorm';
import { CreateDoctorBody } from './dtos/create-doctor.dto';
import { plainToClass } from 'class-transformer';
import { S3BucketManager } from '../shared/helpers/s3bucket/s3bucket.manager';
import { IFile } from '../shared/helpers/s3bucket/types';
import { UpdateDoctorBody } from './dtos/edit-doctor.dto';
import { FindManyResponse } from '../shared/types';
import { DoctorFiltersQuery } from './dtos/find-doctor.dto';
import { IMAGE_FORMATS, S3_DOCTORS_FOLDER } from '../shared/constants';
import { AppConfigService } from '../../config/config.service';

@Injectable()
export class DoctorsService {
  constructor(
    @InjectRepository(DoctorRepository)
    private doctorRepo: DoctorRepository,
    @InjectRepository(UserRepository)
    private userRepo: UserRepository,
    private configService: AppConfigService,
    private cognitoManager: CognitoManager,
    private s3Bucket: S3BucketManager,
    @Inject(Logger) private logger: LoggerService
  ) {}

  async createOne(logo: IFile, requestBody: CreateDoctorBody): Promise<void> {
    const { email } = requestBody;
    const isUserExists = await this.userRepo.findIfUserExits({ email });

    if (isUserExists) {
      this.logger.error(`User ${email} is already registered`);

      const errorObject = {
        statusCode: HttpStatus.CONFLICT,
        field: 'email',
        message: 'User with this email already exists',
      };
      throw new ConflictException(errorObject);
    }

    const cognitoUser = await this.cognitoManager.adminCreateUser(email);
    const id = cognitoUser.User.Username;

    try {
      await this.cognitoManager.addUserToUserGroup(id, UserRole.Doctor);

      const createNew = async (runner: QueryRunner): Promise<void> => {
        const userEntity = plainToClass(UserEntity, {
          ...requestBody,
          id,
          role: UserRole.Doctor,
        });
        await runner.manager.save(userEntity);

        const doctorEntity = plainToClass(DoctorEntity, {
          ...requestBody,
          userId: id,
        });
        await runner.manager.save(doctorEntity);

        if (logo) {
          const s3Path = this.s3Bucket.getBucketPath(logo, id, S3_DOCTORS_FOLDER);

          const location = await this.s3Bucket.upload(s3Path, IMAGE_FORMATS, logo);
          await runner.manager.update(DoctorEntity, { userId: id }, { picture: location });
        }
      };

      await this.doctorRepo.runTransaction(createNew);

      return;
    } catch (err) {
      await this.cognitoManager.adminDeleteUser(id);
      this.logger.error(`Failed creating doctor: ${err.message}`);
      throw new UnprocessableEntityException(err.message);
    }
  }

  async update(id: string, requestBody: UpdateDoctorBody): Promise<void> {
    const { picture } = requestBody;
    const doctorToUpdate = await this.doctorRepo.findOne(id);

    if (!doctorToUpdate) {
      this.logger.error(`Doctor ${id} is not found`);
      throw new NotFoundException('Doctor not found');
    }

    const isHasAccess = PermissionManager.isHasAccessToDoctor(id);

    if (!isHasAccess) {
      throw new ForbiddenException('User has no permission to update doctor');
    }

    const keyToRemove = doctorToUpdate.picture?.match(/[a-z]+\/[\w\d-_]+.\w+$/)?.[0];

    const createNew = async (runner: QueryRunner): Promise<void> => {
      if (picture?.buffer) {
        const s3Path = this.s3Bucket.getBucketPath(picture, id, S3_DOCTORS_FOLDER);

        const newLogoUrl = await this.s3Bucket.upload(s3Path, IMAGE_FORMATS, picture);
        requestBody.picture = newLogoUrl;
        if (keyToRemove) {
          await this.s3Bucket.remove(keyToRemove);
        }
      } else if (picture) {
        requestBody.picture = picture;
      }

      await runner.manager.getCustomRepository(UserRepository).updateDoctor(id, requestBody);

      await runner.manager.getCustomRepository(DoctorRepository).update(id, requestBody);
    };

    await this.doctorRepo.runTransaction(createNew);
  }

  async findMany(query: DoctorFiltersQuery): Promise<FindManyResponse<DoctorEntity>> {
    const doctorsResponse = await this.doctorRepo.findMany(query);
    const data = doctorsResponse[0];
    return { data, totalItems: doctorsResponse[1] };
  }

  async findOne(id: string): Promise<DoctorEntity> {
    const doctor = await this.doctorRepo.findOne(id);

    if (!doctor) {
      throw new NotFoundException('Doctor not found');
    }

    return doctor;
  }
}

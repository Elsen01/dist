export const CRON_CLINIC_UPDATE_STRING = '0 0 * * FRI';

export const DAYS_AFTER_INJURY = 10;

export const IMAGE_FORMATS = 'image/jpeg, image/jpg, image/png';

export const TABLE_FORMATS = 'text/csv';

export const PDF_FORMAT = 'application/pdf';

export const PDF_IMAGE_FORMAT = 'image/jpeg, image/jpg, image/png, application/pdf';

export const NAME_REGEXP = /^[a-zA-Z\-\s']+$/;

export const PHONE_REGEXP = /^[0-9]{10}$/;

export const PAYMENT_WEBHOOK = '/payments/webhook';

export const STRIPE_HEADER = 'stripe-signature';

export const S3_IMPORTS_FOLDER = 'player_imports';

export const S3_ORGANIZATIONS_FOLDER = 'organizations';

export const S3_DOCTORS_FOLDER = 'doctors';

export const DEFAULT = 'DEFAULT';

export const ONE_DAY = '1 DAYS';

export const THIRTY_DAYS = '31 DAYS';

export const TWO_WEEKS = '2 week';

export const HOUR_MS = 3600000;

export const S3_API_VERSION = '2006-03-01';

export const S3Folders = {
  Certificates: 'assessments/certificates',
  Timetables: 'assessments/timetables',
  ReportsCsv: 'reports/csv',
  ReportsPdf: 'reports/pdf',
};

export const CRON_FIRST_SEPTEMBER = '0 3 1 9 *'; // once a year at 1 september 03:00

export const CRON_UPDATE_MEMBERSHIP = '0 4 * * *'; // every day at 04:00

export const CRON_TWO_WEEKS_EXPIRATION = '30 4 * * *'; // every day at 04:30

export const CRON_UPDATE_PLAY_STATUS = '0 0 * * *'; // every day at 00:00

export const EVERY_HOUR = '0 0-23/1 * * *'; // every hour

export const SUPER_USER_EMAIL = 'harry.black@melioramedicalgroup.co.uk';

export const SUPER_USER_ID = '2b0f3f6b-11a5-41eb-88b7-206461a52580';

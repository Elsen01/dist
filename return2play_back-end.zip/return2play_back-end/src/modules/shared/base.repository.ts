import { UnprocessableEntityException } from '@nestjs/common';
import { AbstractRepository, QueryRunner } from 'typeorm';

export class BaseRepository<T> extends AbstractRepository<T> {
  public async runTransaction(transactionalFn: (manager: QueryRunner, ...args) => Promise<any>, ...args): Promise<any> {
    const queryRunner = this.manager.connection.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();
    try {
      const res = await transactionalFn(queryRunner, ...args);
      await queryRunner.commitTransaction();
      return res;
    } catch (err) {
      await queryRunner.rollbackTransaction();
      throw new UnprocessableEntityException(err.message);
    } finally {
      await queryRunner.release();
    }
  }
}

interface IApiCase {
  description: string;
}

export interface IDocumentedEndpoint {
  OPERATION: IApiCase;
  SUCCESS: IApiCase;
  FAILURE?: IApiCase;
  [key: string]: IApiCase;
}

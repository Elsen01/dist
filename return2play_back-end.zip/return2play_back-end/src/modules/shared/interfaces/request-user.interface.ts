import { Request } from 'express';
import { UserRole } from '../../../modules/users/types';

export interface IUser {
  userId: string;
  role: UserRole;
}

export interface IRequestUser extends Request {
  user: IUser;
}

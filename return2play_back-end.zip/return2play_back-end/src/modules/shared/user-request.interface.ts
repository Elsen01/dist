import { IUser } from './interfaces/request-user.interface';
import { Request } from './request.interface';

export type UserRequest<
  P extends Record<string, any> | string[] = Record<string, any>,
  ResBody = any,
  ReqBody = any,
  ReqQuery = Record<string, any>
> = Request<P, ResBody, ReqBody, ReqQuery> & {
  user: IUser;
};

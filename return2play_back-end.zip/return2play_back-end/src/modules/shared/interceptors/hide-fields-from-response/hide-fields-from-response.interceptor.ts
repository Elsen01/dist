import { CallHandler, ExecutionContext, Injectable, NestInterceptor } from '@nestjs/common';
import omit from 'lodash/omit';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

interface HideFieldsFromResponseOptions {
  array?: boolean;
  fromField?: string;
}

@Injectable()
export class HideFieldsFromResponse<T extends Record<string, any>> implements NestInterceptor {
  constructor(
    protected readonly fieldsToHide: (keyof T)[] = [],
    protected readonly options: HideFieldsFromResponseOptions = {}
  ) {}

  intercept(context: ExecutionContext, next: CallHandler): Observable<any> | Promise<Observable<any>> {
    return next.handle().pipe(
      map((data) => {
        return this.hideFields(context, data);
      })
    );
  }

  protected hideFields(context: ExecutionContext, response: any): any {
    const rawData = this.options.fromField ? response[this.options.fromField] : response;

    let data;

    if (!this.options.array) {
      data = omit(rawData, this.fieldsToHide);
    } else {
      data = rawData.map((item) => omit(item, this.fieldsToHide));
    }

    if (this.options.fromField) {
      response[this.options.fromField] = data;
      return response;
    }

    return data;
  }
}

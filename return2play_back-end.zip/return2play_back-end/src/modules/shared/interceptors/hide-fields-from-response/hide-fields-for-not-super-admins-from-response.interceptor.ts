import { ExecutionContext, Injectable } from '@nestjs/common';

import { HideFieldsFromResponse } from './hide-fields-from-response.interceptor';
import { UserRequest } from '../../user-request.interface';
import { UserRole } from '../../../users/types';

@Injectable()
export class HideFieldsForNotSuperAdminsFromResponse<T extends Record<string, any>> extends HideFieldsFromResponse<T> {
  protected hideFields(context: ExecutionContext, response: any): any {
    const request = context.switchToHttp().getRequest<UserRequest>();
    if (request?.user?.role === UserRole.SuperAdmin) {
      return response;
    }

    return super.hideFields(context, response);
  }
}

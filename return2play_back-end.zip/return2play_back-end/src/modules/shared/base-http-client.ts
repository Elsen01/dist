import { HttpModuleOptions, HttpService, LoggerService } from '@nestjs/common';
import { AxiosInstance, AxiosResponse } from 'axios';
import rateLimit from 'axios-rate-limit';
import axiosRetry, { IAxiosRetryConfig } from 'axios-retry';
import { requestLogger, responseLogger, errorLogger, setGlobalConfig } from 'axios-logger';

export interface HttpClientConfig {
  apiConfig: HttpModuleOptions;
  retryConfig?: { retry?: boolean; retryOptions?: IAxiosRetryConfig };
  rateLimitConfig?: { maxRequests: number; perMilliseconds: number };
}

export class BaseHttpClient {
  protected readonly api: AxiosInstance;
  constructor(
    { axiosRef }: HttpService,
    protected readonly config: HttpClientConfig,
    protected readonly logger: LoggerService,
    protected name?: string
  ) {
    const { retryConfig, rateLimitConfig } = this.config;
    this.api = axiosRef;

    if (retryConfig && retryConfig.retry) {
      axiosRetry(this.api, retryConfig.retryOptions);
    }
    if (rateLimitConfig) {
      this.api = rateLimit(this.api, rateLimitConfig);
    }

    setGlobalConfig({
      params: true,
      headers: true,
      prefixText: name,
      logger: logger.log.bind(logger),
    });

    this.setRequestInterceptors();
    this.setResponseInterceptors();
  }

  public request<T, R = AxiosResponse<T>>(config: HttpModuleOptions): Promise<R> {
    return this.api.request(config);
  }

  public get<T, R = AxiosResponse<T>>(url: string, config?: HttpModuleOptions): Promise<R> {
    return this.api.get(url, config);
  }

  public delete<T, R = AxiosResponse<T>>(url: string, config?: HttpModuleOptions): Promise<R> {
    return this.api.delete(url, config);
  }

  public head<T, R = AxiosResponse<T>>(url: string, config?: HttpModuleOptions): Promise<R> {
    return this.api.head(url, config);
  }

  public post<T, R = AxiosResponse<T>>(url: string, data?: string, config?: HttpModuleOptions): Promise<R> {
    return this.api.post(url, data, config);
  }

  public put<T, R = AxiosResponse<T>>(url: string, data?: string, config?: HttpModuleOptions): Promise<R> {
    return this.api.put(url, data, config);
  }

  public patch<T, R = AxiosResponse<T>>(url: string, data?: string, config?: HttpModuleOptions): Promise<R> {
    return this.api.patch(url, data, config);
  }

  private setRequestInterceptors(): void {
    this.api.interceptors.request.use(requestLogger, errorLogger);
  }

  private setResponseInterceptors(): void {
    this.api.interceptors.response.use(responseLogger, errorLogger);
  }
}

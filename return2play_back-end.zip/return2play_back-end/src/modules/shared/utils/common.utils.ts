import { camelCase } from 'lodash';
import { IUsePagination } from '../types';
import { IMAGE_FORMATS, PDF_FORMAT } from '../constants';
import moment from 'moment';
import { UserRole } from '../../users/types';
import { Membership } from '../../players/types';

export const getEntityInstance = <T extends { id: string }>(id: string, Entity: new () => T): T => {
  const instance = new Entity();
  instance.id = id;
  return instance;
};

export const toCamelCase = <T extends { [key: string]: any }>(obj: T): unknown => {
  return Object.entries(obj).reduce((camelized, [key, value]) => {
    return { ...camelized, [camelCase(key)]: value };
  }, {});
};

export const toStringDbFormat = (value: string): string => `$STR$${value}$STR$`;

export const stringToArray = (str: string[] | string): string[] => {
  return typeof str === 'string' ? [str] : str;
};

export const getEnumValues = <T>(Enum: T): string[] => {
  const keys = Object.keys(Enum).filter((k) => typeof Enum[k as any] === 'string');
  const values = keys.map((k) => Enum[k as any]);

  return values;
};

export const getUTCDate = (date: Date): Date => {
  return new Date(
    Date.UTC(
      date.getUTCFullYear(),
      date.getUTCMonth(),
      date.getUTCDate(),
      date.getUTCHours(),
      date.getUTCMinutes(),
      date.getUTCMilliseconds()
    )
  );
};

export const arrayLastIndex = <T>(array: T[]): number => array.length - 1;

export const usePagination = (startPage: number): IUsePagination => {
  let pageNumber = startPage;

  return {
    page(): number {
      return pageNumber;
    },
    increment(): void {
      pageNumber++;
    },
  };
};

export const getAllNestedValues = (target: unknown, specifiedKey: string, values: any[] = []): string[] => {
  if (typeof target !== 'object') {
    return values;
  }

  const object = target as Record<string, unknown>;

  const targetKey = Object.keys(object).find((key) => key === specifiedKey);

  if (targetKey && object[targetKey]) {
    values.push(object[targetKey]);
  }

  const objectKeys = Object.keys(object).filter((key) => typeof object[key] === 'object');

  if (!objectKeys) {
    return values;
  }

  objectKeys.forEach((key) => {
    values.concat(getAllNestedValues(object[key], specifiedKey, values));
  });

  return values;
};

export const callPromisesSequentially = (tasks: Promise<void>[], errorHandler: (err: any) => any): Promise<void> => {
  return tasks.reduce((prev) => {
    return prev.then().catch((err) => {
      errorHandler(err);
    });
  }, Promise.resolve());
};

export const isOrganizationAdminOrMedicalStaff = (role: UserRole): boolean =>
  role === UserRole.MedicalStaff || role === UserRole.OrganizationAdmin;

export const getContentType = (extension: string): string => (extension === 'pdf' ? PDF_FORMAT : IMAGE_FORMATS);

export const checkMembership = (membership: Membership, membershipExpirationDate: Date): boolean => {
  return (
    membership === Membership.School ||
    (membership === Membership.Regular && moment(membershipExpirationDate).isSameOrAfter(new Date()))
  );
};

export const getFirstSeptemberCurrentYear = (): Date => new Date(new Date().getFullYear(), 12, 1, 0, 0, 0, 0);

export const calculateYearGroup = (birthday: Date): string => {
  const firstSeptemberCurrentYear = getFirstSeptemberCurrentYear();

  const fullYears = moment(firstSeptemberCurrentYear).diff(moment(birthday), 'years');

  if (fullYears <= 18 && fullYears > 0) {
    return `U${fullYears}`;
  } else if (fullYears > 18) {
    return 'Adult';
  } else {
    return 'N/A';
  }
};

export const checkExpiredMembership = (expirationDate: Date): boolean => {
  return moment(new Date()).isAfter(expirationDate);
};

export const getWeekDay = (date: Date): string => {
  const day = moment(date).isoWeekday();

  return String(day - 1);
};

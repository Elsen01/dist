export function isAxiosError(err: Error): boolean {
  const axiosErr = err as {
    isAxiosError?: boolean;
    response?: { data: string | Record<string, any>; status: number };
  };
  return !!(axiosErr.isAxiosError && axiosErr.response);
}

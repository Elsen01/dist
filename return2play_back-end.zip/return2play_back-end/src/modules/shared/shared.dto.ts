import { Type } from 'class-transformer';
import { IsNumber, IsUUID } from 'class-validator';

export class PaginationDto {
  @IsNumber()
  @Type(() => Number)
  limit: number;

  @IsNumber()
  @Type(() => Number)
  page: number;
}

export class IdDto {
  @IsUUID()
  id: string;
}

export class IdsDto {
  @IsUUID('all', { each: true })
  ids: string[];
}

import { WondeDateObject } from './../types';
export interface Subject {
  id: string;
  mis_id: string;
  code: string;
  name: string;
  active: boolean;
  created_at: WondeDateObject;
}

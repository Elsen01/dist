import { WondeDateObject, ContactDetails, WondeOneResponse, WondeManyResponse } from './../types';
import { WondeBaseUser } from '../types';

export interface Employee extends WondeBaseUser {
  date_of_birth: WondeDateObject;
  meta: {
    role: string;
    all_roles: string[];
    is_main_teacher: true;
    is_class_teacher: true;
  };
}

export interface EmployeeDetails extends WondeBaseUser {
  date_of_birth: WondeDateObject;
  contact_details: ContactDetails;
}

export type EmployeeDetailsResponse = WondeOneResponse<EmployeeDetails>;
export type EmployeesDetailsResponse = WondeManyResponse<EmployeeDetails>;

import { Employee } from './Employee';
import { Subject } from './Subject';

export interface Class {
  id: string;
  mis_id: string;
  name: string;
  code: string;
  description: string;
  subject: {
    data: Subject;
  };
  employees: {
    data: Employee[];
  };
}

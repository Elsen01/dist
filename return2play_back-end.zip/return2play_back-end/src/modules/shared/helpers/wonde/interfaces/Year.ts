import { WondeDateObject } from '../types';
import { Employee } from './Employee';

export interface Year {
  id: string;
  mis_id: string;
  name: string;
  code: string;
  type: string;
  description: string;
  notes: string;
  division: string;
  created_at: WondeDateObject;
  meta: {
    start_date: WondeDateObject;
    end_date: WondeDateObject;
  };
  employees: {
    data: Employee[];
  };
}

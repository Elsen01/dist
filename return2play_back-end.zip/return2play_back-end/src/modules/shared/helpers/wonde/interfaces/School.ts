import { WondeOneResponse, WondeManyResponse } from './../types';

export interface School {
  id: string;
  name: string;
  establishment_number: string;
  urn: number;
  phase_of_education: string;
  la_code: string;
  timezone: string;
  mis: string;
  address: {
    address_line_1: string;
    address_line_2: string;
    address_town: string;
    address_postcode: string;
    address_country: {
      code: string;
      name: string;
    };
  };
}

export type SchoolResponse = WondeOneResponse<School>;

export type SchoolsResponse = WondeManyResponse<School>;

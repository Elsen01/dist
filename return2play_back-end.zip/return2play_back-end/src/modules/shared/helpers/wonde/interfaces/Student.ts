import { Class } from './Class';
import { WondeOneResponse, WondeManyResponse, ContactDetails, WondeBaseUser } from './../types';
import { Year } from './Year';

export interface Relationship {
  bill_payer: string;
  lives_with_pupil: string;
  email_bills: string;
  copy_bills: string;
  court_order: string;
  pupil_report: string;
  parental_responsibility: string;
  correspondence: string;
  email_notification: string;
  sms_notification: string;
  mail_notification: string;
  push_notification: string;
  in_touch_communication: string;
  priority: string;
  relationship: string;
  emergency_contact: boolean;
}

export interface Contact extends WondeBaseUser {
  relationship: Relationship;
  contact_details: ContactDetails;
}

export interface Student extends WondeBaseUser {
  contact_details: ContactDetails;
  date_of_birth: {
    date: Date;
  };
  contacts: {
    data: Contact[];
  };
  classes: {
    data: Class[];
  };
  year: {
    data: Year;
  };
  updated_at: {
    date: Date;
    timezone_type: string;
    timezone: string;
  };
}

export type StudentResponse = WondeOneResponse<Student>;

export type StudentsResponse = WondeManyResponse<Student>;

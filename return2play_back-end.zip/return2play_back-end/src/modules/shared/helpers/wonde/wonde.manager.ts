import { Student, StudentsResponse } from './interfaces/Student';
import { School, SchoolResponse } from './interfaces/School';
import { HttpService, Injectable } from '@nestjs/common';
import { SchoolsResponse } from './interfaces/School';
import { AxiosResponse } from 'axios';
import { WondeParams } from './types';
import { EmployeesDetailsResponse, EmployeeDetails } from './interfaces/Employee';
import { AppConfigService } from '../../../../config/config.service';

@Injectable()
export class Wonde {
  constructor(private configService: AppConfigService, private httpService: HttpService) {}

  async getAllApprovedSchools(): Promise<School[]> {
    const schools: School[] = [];
    let more = true;
    let url = `${this.configService.wonde.apiUri}/schools`;

    do {
      const wondeResponse = await this.getApprovedSchools(url);
      schools.push(...wondeResponse.data);

      more = wondeResponse.meta.pagination.more;
      url = wondeResponse.meta.pagination.next;
    } while (more);

    return schools;
  }

  async getApprovedSchools(url: string): Promise<SchoolsResponse> {
    return this.get<SchoolsResponse>(url, { per_page: 50 });
  }

  async getSchoolById(schoolId: string): Promise<SchoolResponse> {
    return this.get<SchoolResponse>(`${this.configService.wonde.apiUri}/schools/${schoolId}/`);
  }

  async getAllStudentsBySchool(schoolId: string, updatedAfter?: string): Promise<Student[]> {
    const students: Student[] = [];
    let more = true;

    let url = `${this.configService.wonde.apiUri}/schools/${schoolId}/students`;

    do {
      const wondeResponse = await this.get<StudentsResponse>(url, {
        include: this.configService.wonde.studentInclude,
        per_page: 1000,
        updated_after: updatedAfter,
      });
      students.push(...wondeResponse.data);

      more = wondeResponse.meta.pagination.more;
      url = wondeResponse.meta.pagination.next;
    } while (more);

    return students;
  }

  async getAllEmployeesBySchool(schoolId: string, updatedAfter?: string): Promise<EmployeeDetails[]> {
    const employees: EmployeeDetails[] = [];
    let more = true;
    let url = `${this.configService.wonde.apiUri}/schools/${schoolId}/employees`;

    do {
      const wondeResponse = await this.get<EmployeesDetailsResponse>(url, {
        include: this.configService.wonde.employeeInclude,
        has_class: true,
        per_page: 100,
        updated_after: updatedAfter,
      });
      employees.push(...wondeResponse.data);

      more = wondeResponse.meta.pagination.more;
      url = wondeResponse.meta.pagination.next;
    } while (more);

    return employees;
  }

  private async get<T>(url: string, params?: WondeParams): Promise<T> {
    const { data }: AxiosResponse<T> = await this.httpService
      .get(url, {
        headers: { Authorization: `Bearer ${this.configService.wonde.apiKey}` },
        params,
      })
      .toPromise();

    return data;
  }
}

export interface WondeManyResponse<T> {
  data: T[];
  meta: { pagination: WondePagination };
}

export interface WondeOneResponse<T> {
  data: T;
}

export interface WondePagination {
  current_page: number;
  more: boolean;
  next?: string;
  per_page: number;
  previous?: string;
}

export interface WondeBaseUser {
  id: string;
  upi: string;
  initials: string;
  title: string;
  mis_id: string;
  surname: string;
  forename: string;
  gender: string;
  legal_surname: string;
  legal_forename: string;
}

export interface ContactDetails {
  data: {
    phones: {
      phone: string;
    };
    emails: {
      email: string;
    };
    addresses: {
      home: {
        house_number: string;
        house_name: string;
        apartment: string;
        street: string;
        district: string;
        town: string;
        county: string;
        country: string;
        postcode: string;
      };
    };
  };
}

export interface WondeParams {
  page?: number;
  per_page?: number;
  include?: string;
  updated_after?: string;
  updated_before?: string;
  has_class?: boolean;
  has_group?: boolean;
  current_page?: number;
}

export interface WondeDateObject {
  date: Date;
}

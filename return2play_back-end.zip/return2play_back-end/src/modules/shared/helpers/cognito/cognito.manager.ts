import {
  AuthenticationDetails,
  CognitoRefreshToken,
  CognitoUser,
  CognitoUserAttribute,
  CognitoUserPool,
  CognitoUserSession,
  ISignUpResult,
} from 'amazon-cognito-identity-js';
import {
  Injectable,
  UnprocessableEntityException,
  UnauthorizedException,
  BadRequestException,
  ConflictException,
  HttpException,
  Inject,
  Logger,
  LoggerService,
} from '@nestjs/common';
import AWS from 'aws-sdk';
import { v4 } from 'uuid';

import { TokenManager } from '../token/token.manager';

import { AppConfigService } from '../../../../config/config.service';

import {
  AdminAddUserToGroupRequest,
  AdminCreateUserRequest,
  AdminCreateUserResponse,
  AdminGetUserResponse,
  AdminListGroupsForUserResponse,
  CognitoException,
  GlobalSignOutRequest,
  ResetPassword,
} from './types';

import { ChangePasswordBody } from '../../../auth/dtos/change-password.dto';
import { LoginResponse, LoginBody } from '../../../auth/dtos/login.dto';
import { CognitoIdentityServiceProvider } from 'aws-sdk';
import {
  AdminRemoveUserFromGroupRequest,
  UpdateUserAttributesResponse,
} from 'aws-sdk/clients/cognitoidentityserviceprovider';
import { InjectRepository } from '@nestjs/typeorm';
import { UserEntity } from '../../../users/entities/user.entity';
import { UserRepository } from '../../../users/users.repository';
import { RegistrationBody } from '../../../auth/dtos/registration.dto';
import { UserRole } from '../../../users/types';
import { RefreshTokensBody } from '../../../auth/dtos/refresh-tokens.dto';
@Injectable()
export class CognitoManager {
  private readonly userPool: CognitoUserPool;

  private identityServiceProvider: CognitoIdentityServiceProvider;

  constructor(
    @Inject(Logger) private logger: LoggerService,
    @InjectRepository(UserRepository)
    private userRepo: UserRepository,
    private configService: AppConfigService,
    private tokenManager: TokenManager
  ) {
    this.userPool = new CognitoUserPool(this.configService.cognito);

    this.identityServiceProvider = new CognitoIdentityServiceProvider({
      apiVersion: 'latest',
      region: this.configService.aws.region,
      credentials: this.configService.aws,
    });
  }

  async handleUserAuth(loginBody: LoginBody, users: UserEntity[]): Promise<LoginResponse> {
    const { password, newPassword } = loginBody;
    let session: CognitoUserSession = null;
    let message: string = null;

    for await (const user of users) {
      const details = new AuthenticationDetails({
        Username: user.id,
        Password: password,
      });
      const cognitoUser = this.cognitoUserFactory(user.id);
      const res: CognitoUserSession & { message: string } = await this.authenticateUser(
        cognitoUser,
        details,
        newPassword
      ).catch((err) => {
        return err;
      });

      if (res.message === 'A new password is required') {
        throw new UnprocessableEntityException('A new password is required');
      }

      if (res.message === 'Temporary password has expired and must be reset by an administrator.') {
        throw new UnprocessableEntityException('Temporary password has expired and must be reset by an administrator');
      }

      if (res.isValid) {
        session = res;
      } else {
        message = res.message;
      }
    }

    if (!session) {
      throw new UnprocessableEntityException(message);
    }

    return this.getTokensFromSession(session);
  }

  async signUpPlayer(user: RegistrationBody): Promise<string> {
    const { email, password } = user;

    const signUp = async (email: string, password: string): Promise<ISignUpResult> => {
      const username = v4();
      const userAttribute = new CognitoUserAttribute({ Name: 'email', Value: email });

      return await new Promise((resolve, reject) => {
        this.userPool.signUp(username, password, [userAttribute], null, (err, result) =>
          err ? reject(err) : resolve(result)
        );
      });
    };

    const signUpResponse = await signUp(email, password).catch(({ message, code }) => {
      if (code === CognitoException.InvalidPassword) {
        this.logger.error('Password does not meet constraints');
        throw new BadRequestException(message);
      } else if (code === CognitoException.UsernameExists) {
        this.logger.error(`${email} already exists`);
        throw new ConflictException(message);
      }
      this.logger.error(`Sign up failed with code ${code}`);
      throw new UnprocessableEntityException(message);
    });
    const username = signUpResponse.user.getUsername();

    await this.addUserToUserGroup(username, UserRole.Player);

    return signUpResponse.user.getUsername();
  }

  async resetPassword(data: ResetPassword): Promise<void> {
    const cognitoUser = new CognitoUser({
      Username: data.id,
      Pool: this.userPool,
    });
    await new Promise<void>((resolve, reject) => {
      cognitoUser.confirmPassword(data.code, data.newPassword, {
        onSuccess: resolve,
        onFailure: (err: AWS.AWSError) => {
          this.logger.error(`Reset password for ${data.id} failed with ${err.code}`);
          reject(err);
        },
      });
    });
  }

  async logout(): Promise<void> {
    const params = {
      AccessToken: this.tokenManager.getTokenFromAuthorization(),
    };

    return await this.globalSignOut(params).catch(({ message }) => {
      throw new UnauthorizedException(message);
    });
  }

  async adminCreateUser(email: string, params: AdminCreateUserRequest): Promise<AdminCreateUserResponse>;
  async adminCreateUser(email: string): Promise<AdminCreateUserResponse>;
  async adminCreateUser(email: string, params?: AdminCreateUserRequest): Promise<AdminCreateUserResponse> {
    const userName = v4();
    const userAttribute = new CognitoUserAttribute({ Name: 'email', Value: email });

    const customParams: AdminCreateUserRequest = {
      UserPoolId: this.configService.cognito.UserPoolId,
      Username: userName,
      UserAttributes: [
        userAttribute,
        new CognitoUserAttribute({
          Value: 'true',
          Name: 'email_verified',
        }),
      ],
    };

    return await new Promise((resolve, reject) => {
      this.identityServiceProvider.adminCreateUser(params ? params : customParams, (err, data) => {
        if (err) {
          this.logger.error(`As admin, creating ${email} failed with ${err.code}`);
          return reject(err);
        }
        this.logger.log(`As admin, ${email} was created`);
        return resolve(data);
      });
    });
  }

  async adminCreateUserFromMigration(email: string, id: string): Promise<AdminCreateUserResponse> {
    const customParams: AdminCreateUserRequest = {
      UserPoolId: this.configService.cognito.UserPoolId,
      Username: id,
      UserAttributes: [
        { Name: 'email', Value: email },
        new CognitoUserAttribute({
          Value: 'true',
          Name: 'email_verified',
        }),
      ],
    };

    return await new Promise((resolve, reject) => {
      this.identityServiceProvider.adminCreateUser(customParams, (err, data) => {
        if (err) {
          this.logger.error(`As admin, creating ${email} failed with ${err.code}`);
          return reject(err);
        }
        this.logger.log(`As admin, ${email} was created`);
        return resolve(data);
      });
    });
  }

  async listUsersByRole(role: UserRole): Promise<CognitoIdentityServiceProvider.UsersListType> {
    let next = null;
    const users: CognitoIdentityServiceProvider.UsersListType = [];
    do {
      const params: CognitoIdentityServiceProvider.ListUsersInGroupRequest = {
        GroupName: role,
        UserPoolId: this.configService.cognito.UserPoolId,
        Limit: 60,
        NextToken: next,
      };

      const cognitoResponse: CognitoIdentityServiceProvider.ListUsersInGroupResponse = await new Promise(
        (resolve, reject) => {
          this.identityServiceProvider.listUsersInGroup(params, (err, data) => {
            if (err) {
              this.logger.error(`Failed to get users from group ${role} with ${err.code}`);
              return reject(err);
            }

            return resolve(data);
          });
        }
      );

      next = cognitoResponse.NextToken;
      users.push(...cognitoResponse.Users);
    } while (next);

    return users;
  }

  async updateUserEmail(id: string, email: string): Promise<UpdateUserAttributesResponse> {
    return await new Promise((resolve, reject) => {
      this.identityServiceProvider.adminUpdateUserAttributes(
        {
          UserAttributes: [{ Name: 'email', Value: email }],
          UserPoolId: this.configService.cognito.UserPoolId,
          Username: id,
        },
        (err, data) => {
          if (err) {
            this.logger.error(`Failed to update user with id ${id}. Error: ${err.code}`);
            return reject(err);
          }

          return resolve(data);
        }
      );
    });
  }

  async listUsersEmailsByRole(role: UserRole): Promise<string[]> {
    const cognitoGroupUsers = await this.listUsersByRole(role);
    const cognitoGroupUsersEmails = cognitoGroupUsers.flatMap((user) => {
      return user.Attributes.reduce((emails, attribute) => {
        if (attribute.Name === 'email') {
          emails.push(attribute.Value);
        }

        return emails;
      }, []);
    });

    return cognitoGroupUsersEmails;
  }

  async adminCreateManyByRole<T extends { id?: string; email?: string }>(
    users: T[],
    role: UserRole
  ): Promise<(T & { id: string })[]> {
    //@ts-ignore
    return Promise.allSettled(
      users.map(async (user) => {
        const userName = user.id ? user.id : v4();
        const userAttribute = new CognitoUserAttribute({ Name: 'email', Value: user.email });

        const params: AdminCreateUserRequest = {
          Username: userName,
          UserPoolId: this.configService.cognito.UserPoolId,
          UserAttributes: [
            userAttribute,
            new CognitoUserAttribute({
              Value: 'true',
              Name: 'email_verified',
            }),
          ],
        };

        let id: string;

        if (user.email) {
          const cognitoUser = await this.adminCreateUser(user.email, params);
          id = cognitoUser.User.Username;
          await this.addUserToUserGroup(id, role);
        } else {
          id = user.id ? user.id : v4();
        }

        return { ...user, id };
      })
    );
  }

  async adminCreateMany<T extends { id: string; email?: string; role: UserRole }>(
    users: T[]
  ): Promise<(T & { id: string })[]> {
    //@ts-ignore
    return Promise.allSettled(
      users.map(async (user) => {
        const userAttribute = new CognitoUserAttribute({ Name: 'email', Value: user.email });

        const params: AdminCreateUserRequest = {
          Username: user.id,
          UserPoolId: this.configService.cognito.UserPoolId,
          UserAttributes: [
            userAttribute,
            new CognitoUserAttribute({
              Value: 'true',
              Name: 'email_verified',
            }),
          ],
        };

        let id: string;

        if (user.email) {
          const cognitoUser = await this.adminCreateUser(user.email, params);
          id = cognitoUser.User.Username;
          await this.addUserToUserGroup(id, user.role);
        } else {
          id = user.id ? user.id : v4();
        }

        return { ...user, id };
      })
    );
  }

  async adminGetUser(userName: string): Promise<AdminGetUserResponse> {
    const params = {
      Username: userName,
      UserPoolId: this.configService.cognito.UserPoolId,
    };

    return await new Promise((resolve, reject) => {
      this.identityServiceProvider.adminGetUser(params, (err, user) => {
        if (err) {
          this.logger.error(`Cannot fetch ${userName}, failed with ${err.code}`);
          return reject(err);
        }
        return resolve(user);
      });
    });
  }

  async userForgotPassword(email: string): Promise<void> {
    const user = this.cognitoUserFactory(email);

    return await new Promise<void>((resolve, reject) =>
      user.forgotPassword({
        onSuccess: resolve,
        onFailure: (err) => {
          this.logger.error(`Forgot password failed for ${email}`);
          reject(err);
        },
      })
    );
  }

  async refreshTokens(data: RefreshTokensBody): Promise<LoginResponse> {
    const { idToken, refreshToken } = data;
    this.tokenManager.init({ token: idToken });
    const payload = await this.tokenManager.decodeToken();

    if (!payload) {
      this.logger.error('Decoding idToken failure');
      throw new UnauthorizedException('Invalid idToken is provided');
    }

    const userPoolId = this.userPool.getUserPoolId();
    const region = this.configService.aws.region;
    AWS.config.region = region;
    const key = `cognito-idp.${region}.amazonaws.com/${userPoolId}`;
    const credentials = new AWS.CognitoIdentityCredentials({
      IdentityPoolId: userPoolId,
      Logins: { [key]: idToken },
    });

    if (credentials.needsRefresh()) {
      const user = this.cognitoUserFactory(payload.email);
      const body = new CognitoRefreshToken({ RefreshToken: refreshToken });
      return await new Promise<LoginResponse>((resolve, reject) =>
        user.refreshSession(body, (err, session) => (err ? reject(err) : resolve(this.getTokensFromSession(session))))
      ).catch(({ message, code }) => {
        this.logger.error(`Refreshing tokens failed with ${code}`);
        if (code === CognitoException.NotAuthorized) {
          throw new UnauthorizedException(message);
        }
        throw new UnprocessableEntityException(message);
      });
    }
  }

  async authenticateUser(
    user: CognitoUser,
    details: AuthenticationDetails,
    password: string
  ): Promise<CognitoUserSession> {
    return await new Promise((resolve, reject) =>
      user.authenticateUser(details, {
        onSuccess: resolve,
        onFailure: async (err) => {
          if (err.code === CognitoException.UserNotConfirmed) {
            this.logger.log(`Resend confirmation link for ${details.getUsername()}`);
            await this.resendConfirmationLink(details.getUsername());
            reject(new UnprocessableEntityException('Not confirmed'));
          }
          reject(err);
        },
        newPasswordRequired: async () => {
          if (password) {
            this.logger.log(`New password is required, changing for ${details.getUsername()}`);
            const response = await this.onNewPasswordRequired(user, password);
            await this.userRepo.activateUser(details.getUsername());
            resolve(response);
          } else {
            this.logger.error(`User ${details.getUsername()} must provide new password`);
            reject(new UnprocessableEntityException('A new password is required'));
          }
        },
      })
    );
  }

  async addUserToUserGroup(username: string, userGroup: string): Promise<void> {
    const params: AdminAddUserToGroupRequest = {
      GroupName: userGroup,
      UserPoolId: this.userPool.getUserPoolId(),
      Username: username,
    };

    return await new Promise((resolve, reject) => {
      this.identityServiceProvider.adminAddUserToGroup(params, (err) => {
        if (err) {
          this.logger.error(`Cannot add ${username} to group ${userGroup}`);
          return reject(err);
        }
        this.logger.log(`Added ${username} to group ${userGroup}`);
        return resolve();
      });
    });
  }

  async removeUserFromCurrentUserGroup(username: string): Promise<UserRole> {
    const res = await this.adminListGroupsForUser(username).catch((err) => {
      this.logger.error(`Failed fetching groups for ${username} with ${err.code}`);
      throw new HttpException(err.message, err.statusCode);
    });

    const currentGroup = res.Groups[0]?.GroupName as UserRole;

    const params: AdminRemoveUserFromGroupRequest = {
      GroupName: currentGroup,
      UserPoolId: this.userPool.getUserPoolId(),
      Username: username,
    };

    return await new Promise((resolve, reject) => {
      this.identityServiceProvider.adminRemoveUserFromGroup(params, (err) => {
        if (err) {
          this.logger.error(`Failed removing user ${params.Username} from ${params.GroupName}; ${err.code}`);
          return reject(err);
        }
        return resolve(currentGroup);
      });
    });
  }

  async adminDeleteUser(id: string): Promise<void> {
    const params = {
      UserPoolId: this.userPool.getUserPoolId(),
      Username: id,
    };

    return await new Promise((resolve, reject) => {
      this.identityServiceProvider.adminDeleteUser(params, (err) => {
        if (err) {
          this.logger.error(`Failed to delete user ${params.Username}`);
          return reject(err);
        }
        return resolve();
      });
    });
  }

  async resendConfirmationLink(Username: string): Promise<AdminCreateUserResponse> {
    const userParams = {
      MessageAction: 'RESEND',
      Username,
      UserPoolId: this.configService.cognito.UserPoolId,
    };

    return await new Promise((resolve, reject) => {
      this.identityServiceProvider.adminCreateUser(userParams, (err, data) => {
        if (err) {
          this.logger.error(`Resending confirmation failed for ${Username}`);
          return reject(err);
        }
        resolve(data);
      });
    });
  }

  async changePassword(user: ChangePasswordBody): Promise<void> {
    const { oldPassword, newPassword } = user;

    return await new Promise((resolve, reject) => {
      this.identityServiceProvider.changePassword(
        {
          AccessToken: this.tokenManager.getTokenFromAuthorization(),
          PreviousPassword: oldPassword,
          ProposedPassword: newPassword,
        },
        (err) => {
          err ? reject(err) : resolve();
        }
      );
    });
  }

  private async globalSignOut(params: GlobalSignOutRequest): Promise<void> {
    return await new Promise((resolve, reject) => {
      this.identityServiceProvider.globalSignOut(params, (err) => {
        if (err) {
          this.logger.error(`Sign out failed with ${err.code}`);
          reject(err);
        }
        resolve();
      });
    });
  }

  private async onNewPasswordRequired(user: CognitoUser, password: string): Promise<CognitoUserSession> {
    return await new Promise((resolve, reject) => {
      user.completeNewPasswordChallenge(password, null, {
        onSuccess: resolve,
        onFailure: reject,
      });
    });
  }

  private cognitoUserFactory(email: string): CognitoUser {
    return new CognitoUser({ Username: email, Pool: this.userPool });
  }

  private getTokensFromSession(session: CognitoUserSession): LoginResponse {
    return {
      idToken: session.getIdToken().getJwtToken(),
      refreshToken: session.getRefreshToken().getToken(),
      accessToken: session.getAccessToken().getJwtToken(),
      mfa: null,
    };
  }

  private async adminListGroupsForUser(username: string): Promise<AdminListGroupsForUserResponse> {
    const params = {
      UserPoolId: this.userPool.getUserPoolId(),
      Username: username,
    };

    return await new Promise((resolve, reject) => {
      this.identityServiceProvider.adminListGroupsForUser(params, (err, data) => (err ? reject(err) : resolve(data)));
    });
  }
}

import { CognitoIdentityServiceProvider } from 'aws-sdk';

export enum CognitoUserStatus {
  Confirmed = 'CONFIRMED',
  Unconfirmed = 'UNCONFIRMED',
  Archived = 'ARCHIVED',
  ResetRequired = 'RESET_REQUIRED',
  Compromised = 'COMPROMISED',
  ForceChangePassword = 'FORCE_CHANGE_PASSWORD',
}

export enum CognitoException {
  UserNotConfirmed = 'UserNotConfirmedException',
  LimitExceeded = 'LimitExceededException',
  ExpiredCode = 'ExpiredCodeException',
  InvalidPassword = 'InvalidPasswordException',
  UsernameExists = 'UsernameExistsException',
  NotAuthorized = 'NotAuthorizedException',
  UserNotFound = 'UserNotFoundException',
}

export type ResendConfirmationСodeResponse = CognitoIdentityServiceProvider.ResendConfirmationCodeResponse;
export type AdminAddUserToGroupRequest = CognitoIdentityServiceProvider.AdminAddUserToGroupRequest;
export type GlobalSignOutRequest = CognitoIdentityServiceProvider.GlobalSignOutRequest;
export type AdminCreateUserRequest = CognitoIdentityServiceProvider.AdminCreateUserRequest;
export type AdminCreateUserResponse = CognitoIdentityServiceProvider.AdminCreateUserResponse;
export type AdminGetUserResponse = CognitoIdentityServiceProvider.AdminGetUserResponse;
export type AdminListGroupsForUserResponse = CognitoIdentityServiceProvider.AdminListGroupsForUserResponse;

export interface ResetPassword {
  newPassword: string;

  code: string;

  id: string;
}

import { BadRequestException } from '@nestjs/common';
import { MulterOptions } from '@nestjs/platform-express/multer/interfaces/multer-options.interface';

export function multerOptionsImg(): MulterOptions {
  const MAX_SIZE_IN_BYTES = 3000000; // 3 MB
  return {
    limits: {
      files: 1,
      fileSize: MAX_SIZE_IN_BYTES,
    },
    fileFilter: (req, file, callback): void => {
      if (!file.originalname.match(/\.(jpg|jpeg|png)$/)) {
        return callback(new BadRequestException('Only .jpg|.jpeg|.png are allowed!'), false);
      }
      callback(null, true);
    },
  };
}

export function multerOptionsCsv(): MulterOptions {
  // const MAX_SIZE_IN_BYTES = 3000000; // 3 MB
  return {
    limits: {
      files: 1,
      // fileSize: MAX_SIZE_IN_BYTES,
    },
    fileFilter: (req, file, callback): void => {
      if (!file.originalname.match(/\.(csv)$/)) {
        return callback(new BadRequestException('Only .csv are allowed!'), false);
      }
      callback(null, true);
    },
  };
}

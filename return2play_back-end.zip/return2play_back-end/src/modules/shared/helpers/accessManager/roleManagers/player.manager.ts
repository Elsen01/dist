import { UserRole } from '../../../../users/types';

export class PlayerManager {
  private static readonly permittedRolesToGetPlayer: UserRole[] = [
    UserRole.SuperAdmin,
    UserRole.OrganizationAdmin,
    UserRole.MedicalStaff,
    UserRole.StaffUser,
    UserRole.Parent,
    UserRole.Doctor,
  ];

  private static readonly permittedRolesToGetMembership: UserRole[] = [
    UserRole.SuperAdmin,
    UserRole.OrganizationAdmin,
    UserRole.MedicalStaff,
  ];

  public static isHasPermissionToGetPlayer(role: UserRole): boolean {
    return this.permittedRolesToGetPlayer.includes(role);
  }

  public static getSelectColumn(role: UserRole): string[] {
    const isPermitted = this.permittedRolesToGetMembership.includes(role);

    return isPermitted ? ['player.membership'] : [];
  }
}

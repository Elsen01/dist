import { ALL_ROLES, UserRole, UserSortOptions } from './../../../../users/types';

export class SuperAdminManager {
  private static readonly rolesPermittedToCreate: UserRole[] = [
    UserRole.SuperAdmin,
    UserRole.OrganizationAdmin,
    UserRole.MedicalStaff,
    UserRole.StaffUser,
    UserRole.Doctor,
    UserRole.Parent,
  ];

  private static readonly rolesPermittedToUpdate: UserRole[] = [
    UserRole.MedicalStaff,
    UserRole.OrganizationAdmin,
    UserRole.StaffUser,
  ];

  private static readonly _rolesPermittedToGet: UserRole[] = ALL_ROLES;

  private static readonly rolesPermittedToDelete: UserRole[] = [
    UserRole.SuperAdmin,
    UserRole.OrganizationAdmin,
    UserRole.MedicalStaff,
    UserRole.StaffUser,
    UserRole.Parent,
  ];

  private static userSort: string[] = [
    UserSortOptions.FirstName,
    UserSortOptions.LastName,
    UserSortOptions.Created,
    UserSortOptions.Email,
    UserSortOptions.Role,
    UserSortOptions.Status,
  ];

  private static readonly _selectColumnsPlayer = ['user.status'];

  public static get rolesPermittedToGet(): UserRole[] {
    return this._rolesPermittedToGet;
  }

  public static get selectColumnsPlayer(): string[] {
    return this._selectColumnsPlayer;
  }

  static isPermittedToCreate(userRole: UserRole): boolean {
    return this.rolesPermittedToCreate.includes(userRole);
  }

  static isPermittedToUpdate(userRole: UserRole): boolean {
    return this.rolesPermittedToUpdate.includes(userRole);
  }

  static isPermittedToGet(userRole: UserRole): boolean {
    return this._rolesPermittedToGet.includes(userRole);
  }

  static isPermittedToDelete(userRole: UserRole): boolean {
    return this.rolesPermittedToDelete.includes(userRole);
  }

  static sortOptionForUser(sort: string): string {
    return this.userSort.includes(sort) ? sort : UserSortOptions.Created;
  }
}

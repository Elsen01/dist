import { GeneralSortOptions, PlayerSortOptions } from './../../../../players/types';

export class StaffUserManager {
  private static playerSort: string[] = [
    GeneralSortOptions.FirstName,
    GeneralSortOptions.LastName,
    GeneralSortOptions.Gender,
    GeneralSortOptions.Birthday,
    GeneralSortOptions.CreatedAt,
    GeneralSortOptions.PlayStatus,
  ];

  static sortOptionForPlayer(sort: string): string {
    return this.playerSort.includes(sort) ? sort : PlayerSortOptions.CreatedAt;
  }
}

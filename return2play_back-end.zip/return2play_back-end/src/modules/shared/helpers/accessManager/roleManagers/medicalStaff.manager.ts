import { UserRole } from '../../../../users/types';

export class MedicalStaffManager {
  private static readonly rolesPermittedToCreate: UserRole[] = [
    UserRole.OrganizationAdmin,
    UserRole.StaffUser,
    UserRole.MedicalStaff,
  ];

  private static readonly _rolesPermittedToGet: UserRole[] = [
    UserRole.OrganizationAdmin,
    UserRole.StaffUser,
    UserRole.Parent,
    UserRole.MedicalStaff,
  ];

  private static readonly rolesPermittedToDelete: UserRole[] = [
    UserRole.OrganizationAdmin,
    UserRole.StaffUser,
    UserRole.Parent,
    UserRole.MedicalStaff,
  ];

  private static readonly _selectColumnsPlayer = ['player.membership', 'user.status'];

  public static get selectColumnsPlayer(): string[] {
    return this._selectColumnsPlayer;
  }

  public static get rolesPermittedToGet(): UserRole[] {
    return this._rolesPermittedToGet;
  }

  static isPermittedToCreate(userRoleToCreate: UserRole): boolean {
    return this.rolesPermittedToCreate.includes(userRoleToCreate);
  }

  static isPermittedToGet(userRoleToCreate: UserRole): boolean {
    return this.rolesPermittedToGet.includes(userRoleToCreate);
  }

  static isPermittedToDelete(userRoleToCreate: UserRole): boolean {
    return this.rolesPermittedToDelete.includes(userRoleToCreate);
  }
}

import { UserRole } from '../../../../users/types';

export class OrganizationAdminManager {
  private static readonly rolesPermittedToCreate: UserRole[] = [
    UserRole.OrganizationAdmin,
    UserRole.MedicalStaff,
    UserRole.StaffUser,
    UserRole.Parent,
  ];

  private static readonly rolesPermittedToUpdate: UserRole[] = [UserRole.MedicalStaff, UserRole.StaffUser];

  private static readonly _rolesPermittedToGet: UserRole[] = [
    UserRole.OrganizationAdmin,
    UserRole.StaffUser,
    UserRole.Parent,
    UserRole.MedicalStaff,
  ];

  private static readonly rolesPermittedToDelete: UserRole[] = [
    UserRole.OrganizationAdmin,
    UserRole.StaffUser,
    UserRole.Parent,
    UserRole.MedicalStaff,
  ];

  private static readonly _selectColumnsPlayer = ['player.membership', 'user.status'];

  public static get selectColumnsPlayer(): string[] {
    return this._selectColumnsPlayer;
  }

  public static get rolesPermittedToGet(): UserRole[] {
    return this._rolesPermittedToGet;
  }

  static isPermittedToCreate(userRole: UserRole): boolean {
    return this.rolesPermittedToCreate.includes(userRole);
  }

  static isPermittedToGet(userRole: UserRole): boolean {
    return this.rolesPermittedToGet.includes(userRole);
  }

  static isPermittedToUpdate(userRole: UserRole): boolean {
    return this.rolesPermittedToUpdate.includes(userRole);
  }

  static isPermittedToDelete(userRole: UserRole): boolean {
    return this.rolesPermittedToDelete.includes(userRole);
  }
}

import { MedicalStaffManager } from './roleManagers/medicalStaff.manager';
import { StaffUserManager } from './roleManagers/staffUser.manager';
import { UserSortOptions } from './../../../users/types';
import { DoctorManager } from './roleManagers/doctor.manager';
import { ParentManager } from './roleManagers/parent.manager';
import { RoleManager } from './role.manager';
import { PlayerManager } from './roleManagers/player.manager';
import { OrganizationAdminManager } from './roleManagers/organizationAdmin.manager';
import { SuperAdminManager } from './roleManagers/superAdmin.manager';
import { PlayerSortOptions } from '../../../players/types';
import { UserRole } from '../../../users/types';

export class PermissionManager {
  private static roleManager = RoleManager.getInstance();

  public static isHasPermissionToCreatePlayer(): boolean {
    switch (this.roleManager.role) {
      case UserRole.SuperAdmin:
        return true;
      case UserRole.OrganizationAdmin:
        return true;
      case UserRole.MedicalStaff:
        return true;
      default:
        return false;
    }
  }

  public static isHasPermissionToUpdatePlayer(id?: string): boolean {
    switch (this.roleManager.role) {
      case UserRole.SuperAdmin:
        return true;
      case UserRole.Player:
        return id === this.roleManager.userId;
      default:
        return false;
    }
  }

  static isHasPermissionToGetPlayer(): boolean {
    return PlayerManager.isHasPermissionToGetPlayer(this.roleManager.role);
  }

  public static isHasPermissionToCreateUser(userRoleToCreate: UserRole): boolean {
    switch (this.roleManager.role) {
      case UserRole.SuperAdmin:
        return SuperAdminManager.isPermittedToCreate(userRoleToCreate);
      case UserRole.OrganizationAdmin:
        return OrganizationAdminManager.isPermittedToCreate(userRoleToCreate);
      case UserRole.MedicalStaff:
        return MedicalStaffManager.isPermittedToCreate(userRoleToCreate);
      default:
        return false;
    }
  }

  public static isHasPermissionToDelete(roleToDelete: UserRole): boolean {
    switch (this.roleManager.role) {
      case UserRole.SuperAdmin:
        return SuperAdminManager.isPermittedToDelete(roleToDelete);
      case UserRole.OrganizationAdmin:
        return OrganizationAdminManager.isPermittedToDelete(roleToDelete);
      case UserRole.MedicalStaff:
        return MedicalStaffManager.isPermittedToDelete(roleToDelete);
      default:
        return false;
    }
  }

  public static isHasPermissionToGet(roleToView: UserRole): boolean {
    switch (this.roleManager.role) {
      case UserRole.SuperAdmin:
        return SuperAdminManager.isPermittedToGet(roleToView);
      case UserRole.OrganizationAdmin:
        return OrganizationAdminManager.isPermittedToGet(roleToView);
      case UserRole.MedicalStaff:
        return MedicalStaffManager.isPermittedToGet(roleToView);
      default:
        return false;
    }
  }

  public static isHasPermissionToGetForUsersPage(roleToView: UserRole): boolean {
    switch (this.roleManager.role) {
      case UserRole.SuperAdmin:
        return SuperAdminManager.isPermittedToGet(roleToView);
      case UserRole.OrganizationAdmin:
        return OrganizationAdminManager.isPermittedToGet(roleToView);
      case UserRole.MedicalStaff:
        return MedicalStaffManager.isPermittedToGet(roleToView);
      default:
        return false;
    }
  }

  public static getPermittedRolesToView(role: UserRole): UserRole[] {
    switch (role) {
      case UserRole.SuperAdmin:
        return SuperAdminManager.rolesPermittedToGet;
      case UserRole.OrganizationAdmin:
        return OrganizationAdminManager.rolesPermittedToGet;
      case UserRole.MedicalStaff:
        return MedicalStaffManager.rolesPermittedToGet;
      default:
        [];
    }
  }

  public static getSelectColumnsPlayer(): string[] {
    switch (this.roleManager.role) {
      case UserRole.SuperAdmin:
        return SuperAdminManager.selectColumnsPlayer;
      case UserRole.OrganizationAdmin:
        return OrganizationAdminManager.selectColumnsPlayer;
      case UserRole.MedicalStaff:
        return MedicalStaffManager.selectColumnsPlayer;
      default:
        return [];
    }
  }

  public static getSortOptionPlayer(sort: string): string {
    switch (this.roleManager.role) {
      case UserRole.Doctor:
        return DoctorManager.sortOptionForPlayer(sort);
      case UserRole.Parent:
        return ParentManager.sortOptionForPlayer(sort);
      case UserRole.OrganizationAdmin:
      case UserRole.SuperAdmin:
      case UserRole.MedicalStaff:
        return sort;
      case UserRole.StaffUser:
        return StaffUserManager.sortOptionForPlayer(sort);
      default:
        return PlayerSortOptions.CreatedAt;
    }
  }

  public static getSortOptionUser(sort: string): string {
    switch (this.roleManager.role) {
      case UserRole.SuperAdmin:
      case UserRole.OrganizationAdmin:
      case UserRole.MedicalStaff:
        return SuperAdminManager.sortOptionForUser(sort);
      default:
        return UserSortOptions.Created;
    }
  }

  public static isHasPermissionToGetTags(): boolean {
    switch (this.roleManager.role) {
      case UserRole.SuperAdmin:
      case UserRole.OrganizationAdmin:
      case UserRole.MedicalStaff:
        return true;
      default:
        return false;
    }
  }

  public static isHasAccessToDoctor(id: string): boolean {
    if (this.roleManager.role === UserRole.SuperAdmin) {
      return true;
    }

    return this.roleManager.role === UserRole.Doctor && this.roleManager.userId === id;
  }

  public static getPlayerSelectColumn(): string[] {
    return PlayerManager.getSelectColumn(this.roleManager.role);
  }
}

import { UserRole } from '../../../users/types';

export class RoleManager {
  private static instance: RoleManager;
  private _role: UserRole;
  private _userId: string;

  public set role(role: UserRole) {
    this._role = role;
  }

  public get role(): UserRole {
    return this._role;
  }

  public set userId(id: string) {
    this._userId = id;
  }

  public get userId(): string {
    return this._userId;
  }

  public static getInstance(): RoleManager {
    if (!RoleManager.instance) {
      RoleManager.instance = new RoleManager();
    }

    return RoleManager.instance;
  }
}

import { S3 } from 'aws-sdk';
import { PassThrough } from 'stream';

export interface IFile {
  fieldname: string;
  originalname: string;
  encoding: string;
  mimetype: string;
  buffer: Buffer;
  size: number;
}

export enum FileFormat {
  csv = 'csv',
  pdf = 'pdf',
  txt = 'txt',
}

export interface IUploadToS3 {
  promise: Promise<S3.ManagedUpload.SendData>;
  stream: PassThrough;
}

export interface IFormatS3Request {
  ContentType: string;
  format: FileFormat;
}

export enum ContentType {
  PDF = 'application/pdf',
  CSV = 'text/csv',
}

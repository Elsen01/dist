import { Inject, Injectable, Logger, LoggerService, UnprocessableEntityException } from '@nestjs/common';
import { S3 } from 'aws-sdk';
import { PutObjectOutput, PutObjectRequest } from 'aws-sdk/clients/s3';
import { PassThrough } from 'stream';
import { AppConfigService } from '../../../../config/config.service';
import { ContentType, FileFormat, IFile, IFormatS3Request, IUploadToS3 } from './types';

@Injectable()
export class S3BucketManager {
  private readonly bucket: S3;

  constructor(private configService: AppConfigService, @Inject(Logger) private logger: LoggerService) {
    const { accessKeyId, secretAccessKey } = this.configService.aws;
    this.bucket = new S3({ accessKeyId, secretAccessKey });
  }

  async upload(
    key: string,
    contentType: string,
    file: { buffer: Buffer },
    ACL?: PutObjectRequest['ACL']
  ): Promise<string> {
    return await this.bucket
      .upload({
        Bucket: this.configService.aws.s3Bucket,
        Key: key,
        Body: file.buffer,
        ContentType: contentType,
        ACL,
      })
      .promise()
      .then(({ Location }) => Location)
      .catch((reason) => {
        this.logger.error(`Failed to upload file ${key} to S3: ${reason.message}`);
        throw new UnprocessableEntityException(reason);
      });
  }

  async remove(key: string): Promise<void> {
    await this.bucket
      .deleteObject({
        Bucket: this.configService.aws.s3Bucket,
        Key: key,
      })
      .promise()
      .catch((reason) => {
        this.logger.error(`Failed to remove file ${key} from S3: ${reason.message}`);
        throw new UnprocessableEntityException(reason);
      });
  }

  getBucketPath(file: IFile, userId: string, folder: string): string {
    const key = this.getBucketKey(file, userId);

    return `${folder}/${key}`;
  }

  getBucketKey(file: IFile, userId: string): string {
    const extension = file.originalname.match(/\w+$/)[0];

    return `${new Date().getTime()}__${userId}.${extension}`;
  }

  uploadStreamToS3 = (
    filePath: string,
    fileFormat: FileFormat,
    bucketName = this.configService.aws.s3Bucket,
    ACL?: PutObjectRequest['ACL']
  ): IUploadToS3 => {
    const passT = new PassThrough();

    const { ContentType } = this.formatS3RequestFabric(fileFormat);

    const params: PutObjectRequest = {
      Body: passT,
      Bucket: bucketName,
      Key: filePath,
      ContentType,
      ContentEncoding: 'gzip',
      ACL,
    };

    return {
      promise: this.bucket.upload(params).promise(),
      stream: passT,
    };
  };

  formatS3RequestFabric(format: FileFormat): IFormatS3Request {
    if (format === FileFormat.pdf) {
      return {
        ContentType: ContentType.PDF,
        format,
      };
    }

    if (format === FileFormat.csv) {
      return {
        ContentType: ContentType.CSV,
        format,
      };
    }

    throw 'Error format';
  }

  putObjectToS3 = (destinationPath: string, content: string): Promise<PutObjectOutput> => {
    const params: PutObjectRequest = {
      Bucket: this.configService.aws.s3Bucket,
      Key: destinationPath,
      Body: content,
    };

    return this.bucket.putObject(params).promise();
  };

  getUrl = (key: string): Promise<string> => {
    return this.bucket.getSignedUrlPromise('getObject', { Bucket: this.configService.aws.s3Bucket, Key: key });
  };
}

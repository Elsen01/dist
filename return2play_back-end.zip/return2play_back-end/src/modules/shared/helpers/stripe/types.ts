import Stripe from 'stripe';

export type CheckoutSession = Stripe.Response<Stripe.Checkout.Session>;
export type SessionMode = Stripe.Checkout.SessionCreateParams.Mode;
export type PaymentMethod = Stripe.Checkout.SessionCreateParams.PaymentMethodType;

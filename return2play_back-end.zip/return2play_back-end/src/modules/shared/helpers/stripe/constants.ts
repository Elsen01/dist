import { PaymentMethod, SessionMode } from './types';

export const CARD: PaymentMethod = 'card';

export const MODE: SessionMode = 'payment';

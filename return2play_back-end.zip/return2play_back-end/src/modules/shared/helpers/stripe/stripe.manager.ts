import { MODE, CARD } from './constants';
import { Injectable } from '@nestjs/common';
import Stripe from 'stripe';
import { CheckoutSession } from './types';
import { AppConfigService } from '../../../../config/config.service';
import { CreateSessionBody } from '../../../payments/dtos/create-payment.dto';

@Injectable()
export class StripeManager {
  private readonly stripe: Stripe;

  constructor(private configService: AppConfigService) {
    this.stripe = new Stripe(configService.stripe.apiKey, configService.stripe.config);
  }

  async createCheckoutSession({
    priceId,
    payerEmail,
    successUrl,
    cancelUrl,
    playerId,
  }: CreateSessionBody & { priceId: string }): Promise<CheckoutSession> {
    return await this.stripe.checkout.sessions.create({
      mode: MODE,
      metadata: { playerId },
      customer_email: payerEmail,
      payment_method_types: [CARD],
      line_items: [
        {
          price: priceId,
          quantity: 1,
        },
      ],
      success_url: successUrl ?? this.configService.stripe.successUrl,
      cancel_url: cancelUrl ?? this.configService.stripe.cancelUrl,
    });
  }

  createWebhookEvent(payload: Buffer, signature: string): Stripe.Event {
    return this.stripe.webhooks.constructEvent(payload, signature, this.configService.stripe.webhookSecret);
  }
}

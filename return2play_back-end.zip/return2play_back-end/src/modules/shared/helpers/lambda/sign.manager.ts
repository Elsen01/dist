import { Injectable } from '@nestjs/common';
import { sign } from 'aws4';
import { AppConfigService } from '../../../../config/config.service';
import { IRequest } from './types';

@Injectable()
export class AwsSignManager {
  constructor(private readonly configManager: AppConfigService) {}

  signRequest(path: string): IRequest {
    return sign({
      method: 'POST',
      host: this.configManager.aws.lambdaHost,
      region: this.configManager.aws.region,
      path,
    });
  }
}

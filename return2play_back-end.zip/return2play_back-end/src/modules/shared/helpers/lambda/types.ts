export interface IRequest {
  method: string;
  host: string;
  region: string;
  path: string;
  headers: Record<string, string>;
}

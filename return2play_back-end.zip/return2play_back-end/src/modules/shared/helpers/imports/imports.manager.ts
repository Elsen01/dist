import { v4 } from 'uuid';
import { Inject, Injectable, Logger, LoggerService, UnprocessableEntityException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { plainToClass } from 'class-transformer';
import { uniqBy } from 'lodash';
import { QueryRunner, In } from 'typeorm';
import { calculateYearGroup } from '../../utils/common.utils';
import { CognitoManager } from '../cognito/cognito.manager';
import { Membership } from '../../../players/types';
import { UserEntity } from '../../../users/entities/user.entity';
import { CreatePlayerFromImportBody, PlayerImportDto } from '../../../imports/dto/import-player.dto';
import { OrganizationRepository } from '../../../organizations/organizations.repository';
import { TagRepository } from '../../../tags/tags.repository';
import { RecipientRepository } from '../../../additional-recipients/recipient.repository';
import { UserRepository } from '../../../users/users.repository';
import { ParentImportDto } from '../../../imports/dto/import-parent.dto';
import { UserRole } from '../../../users/types';
import { PlayerRepository } from '../../../players/player.repository';
import { AdditionalRecipientEntity } from '../../../additional-recipients/entities/recipient.entity';
import { TagEntity } from '../../../tags/entities/tag.entity';

@Injectable()
export class ImportsManager {
  constructor(
    private cognitoManager: CognitoManager,
    private tagRepo: TagRepository,
    @Inject(Logger) private logger: LoggerService,
    @InjectRepository(RecipientRepository)
    readonly recipientRepo: RecipientRepository,
    @InjectRepository(UserRepository)
    readonly userRepo: UserRepository,
    @InjectRepository(OrganizationRepository)
    readonly orgRepo: OrganizationRepository
  ) {}

  public createManyFromImport = async (
    runner: QueryRunner,
    playersImport: PlayerImportDto[],
    organizationIds: string[],
    existingPlayersImport: PlayerImportDto[],
    existingParentsImport: ParentImportDto[]
  ): Promise<void> => {
    const cognitoIds: string[] = [];

    try {
      const playersTagsAll = await this.getPlayerTags(runner, playersImport);

      let parentsImportsAll: UserEntity[] = [];

      const playersImportsAll = playersImport.map((playerData) => {
        const playerLike = plainToClass(PlayerImportDto, playerData);
        const { parents, newTags, ...player } = playerLike;
        const filteredParents = parents.filter((p) => p.email);

        const parentsBodies = filteredParents.map((parent) => {
          return plainToClass(UserEntity, { ...parent, role: UserRole.Parent });
        });
        parentsImportsAll.push(...parentsBodies);

        // Find matching tags
        const tags = playersTagsAll.filter((tag, index) => {
          const isMatch = newTags.find(
            ({ name, organizationId }) => tag.name === name && tag.organization.id === organizationId
          );
          const isFirst = playersTagsAll.indexOf(tag) === index;

          return isMatch && isFirst;
        });

        return {
          ...player,
          email: player.email,
          membership: Membership.School,
          yearGroup: calculateYearGroup(player?.birthday),
          organizationIds,
          socsId: playerLike.socsId,
          tags,
        } as CreatePlayerFromImportBody;
      });

      const cognitoPlayersEmails = existingPlayersImport.map((p) => p.email);
      const playersImportsNew = playersImportsAll.filter((player) => !cognitoPlayersEmails.includes(player.email));

      //const playersBodiesAll = await this.cognitoManager.adminCreateManyByRole(playersImportsNew, UserRole.Player);

      const playersBodiesAll = playersImportsNew.map((p) => ({ ...p, id: v4() }));

      const playersId = playersBodiesAll.filter((p) => p.id);
      cognitoIds.push(...playersId.map(({ id }) => id));

      const existingPlayers = await this.userRepo.findManyByCondition({
        where: { email: In(playersImportsAll.map((user) => user.email)) },
        join: {
          alias: 'user',
          leftJoinAndSelect: {
            player: 'user.player',
            additionalRecepients: 'player.additionalRecepients',
          },
        },
      });

      const playersToSave = playersImportsAll.map((user) => {
        const existingUser = existingPlayers.find((exUser) => user.email === exUser.email);
        if (existingUser) {
          if (existingUser.player) {
            existingUser.player.parents = [];
            existingUser.player.additionalRecepients = [];
          }

          return {
            ...existingUser,
            ...user,
          };
        }

        return playersBodiesAll.find((u) => u.email === user.email);
      });

      const filteredPlayersToSave = playersToSave.filter((p) => p);
      const players = await runner.manager.getCustomRepository(PlayerRepository).createMany(
        uniqBy(
          filteredPlayersToSave.map((p) => ({ ...p, birthday: new Date(p?.birthday) })),
          ({ id }) => id
        ),
        organizationIds
      );

      // Add additional recipients
      const { data: existingRecipients } = await this.recipientRepo.findMany({
        email: In(existingPlayers.flatMap((user) => user.player?.additionalRecepients?.map((ar) => ar.email))),
      });

      const additionalsBodiesAll = players.flatMap((player) => {
        const {
          user: { email },
        } = player;

        const { additional } = playersImport.find((player) => player.email === email);

        const filteredAdditional = additional?.filter((a) => a.email);

        return filteredAdditional?.reduce((allRecipients, recipient) => {
          const existingRecipient = existingRecipients.find((ex) => ex.email === recipient.email);
          if (existingRecipient) {
            return [...allRecipients, { ...existingRecipient, ...recipient, player }];
          }
          return [...allRecipients, { ...recipient, player }];
        }, []);
      });

      const filteredAdditionals = additionalsBodiesAll.filter((a) => a);

      filteredAdditionals.length
        ? await runner.manager.save(AdditionalRecipientEntity, filteredAdditionals).catch((err) => {
            throw new UnprocessableEntityException(err.message);
          })
        : null;

      // Create parents
      parentsImportsAll = uniqBy(parentsImportsAll, ({ email }) => email);
      const cognitoParentsEmails = existingParentsImport.map((p) => p.email);
      const parentsImportsNew = parentsImportsAll.filter((parent) => !cognitoParentsEmails.includes(parent.email));
      //const parentsBodiesAll = await this.cognitoManager.adminCreateManyByRole(parentsImportsNew, UserRole.Parent);

      const parentsBodiesAll = parentsImportsNew.map((p) => ({ ...p, id: v4() }));
      cognitoIds.push(...parentsBodiesAll.map(({ id }) => id));

      // Create parent-player relations
      let parentsWithChildrenAll = players.flatMap((player) => {
        const {
          user: { email },
        } = player;

        const { parents: parentsImport } = playersImport.find((player) => player.email === email);
        const relatedParents = parentsBodiesAll.filter(({ email }) =>
          parentsImport.find((parent) => parent.email === email)
        );
        relatedParents.forEach((parent) => {
          if (!parent.children) {
            parent.children = [player];
          } else {
            parent.children.push(player);
          }
        });

        return relatedParents;
      });

      parentsWithChildrenAll = uniqBy(parentsWithChildrenAll, ({ email }) => email);

      const existingUsers = await this.userRepo.findManyByCondition({
        where: { email: In(parentsWithChildrenAll.map((user) => user.email)) },
      });

      const usersToSave = parentsWithChildrenAll.map((user) => {
        const existingUser = existingUsers.find((exUser) => user.email === exUser.email);

        if (existingUser) {
          return {
            ...existingUser,
            ...user,
          };
        }

        return user;
      });

      const usersToSaveInCognito = await runner.manager.save(UserEntity, usersToSave);

      const playerSaveToCognito = await this.userRepo.findManyByCondition({
        where: { id: In(players.map((p) => p.userId)) },
      });

      //await this.cognitoManager.adminCreateManyByRole(parentsBodiesAll, UserRole.Parent);
      await this.cognitoManager.adminCreateMany([...usersToSaveInCognito, ...playerSaveToCognito]);
    } catch (err) {
      this.logger.error(`Import failed due to following error: ${err.message}. Starting rollback.`);
      await this.deleteManyCognito(cognitoIds);
      this.logger.log('Rollback succeeded.');
      throw new UnprocessableEntityException(`Import failed due to following error: ${err.message}.`);
    }
  };

  public createManyFromWonde = async (
    runner: QueryRunner,
    playersImport: PlayerImportDto[],
    organizationIds: string[],
    existingPlayersImport: PlayerImportDto[],
    existingParentsImport: ParentImportDto[],
    existingPlayers: UserEntity[]
  ): Promise<void> => {
    const cognitoIds: string[] = [];

    try {
      const playersTagsAll = await this.getPlayerTags(runner, playersImport);

      let parentsImportsAll: UserEntity[] = [];

      const playersImportsAll = playersImport.map((playerData) => {
        const playerLike = plainToClass(PlayerImportDto, playerData);
        const { parents, newTags, ...player } = playerLike;
        const filteredParents = parents.filter((p) => p.email);

        const parentsBodies = filteredParents.map((parent) => {
          return plainToClass(UserEntity, { ...parent, role: UserRole.Parent });
        });
        parentsImportsAll.push(...parentsBodies);

        // Find matching tags
        const tags = playersTagsAll.filter((tag, index) => {
          const isMatch = newTags.find(
            ({ name, organizationId }) => tag.name === name && tag.organization.id === organizationId
          );
          const isFirst = playersTagsAll.indexOf(tag) === index;

          return isMatch && isFirst;
        });

        return {
          ...player,
          email: player.email,
          membership: Membership.School,
          yearGroup: calculateYearGroup(player?.birthday),
          organizationIds,
          socsId: playerLike.socsId,
          tags,
        } as CreatePlayerFromImportBody;
      });

      const cognitoPlayersEmails = existingPlayersImport.map((p) => p.email);
      const cognitoPlayersWondeId = existingPlayersImport.map((p) => p.wondeStudent?.wondeId);

      const playersImportsNew = playersImportsAll.filter(
        (player) =>
          !cognitoPlayersEmails.includes(player.email) && !cognitoPlayersWondeId.includes(player.wondeStudent?.wondeId)
      );

      //const playersBodiesAll = await this.cognitoManager.adminCreateManyByRole(playersImportsNew, UserRole.Player);

      const playersBodiesAll = playersImportsNew.map((p) => ({ ...p, id: v4() }));

      const playersId = playersBodiesAll.filter((p) => p.id);
      cognitoIds.push(...playersId.map(({ id }) => id));

      // const existingPlayers = await runner.manager
      //   .getRepository(UserEntity)
      //   .createQueryBuilder('user')
      //   .leftJoinAndSelect('user.player', 'player')
      //   .leftJoinAndSelect('user.wondeStudent', 'wondeStudent')
      //   .leftJoinAndSelect('player.additionalRecepients', 'additionalRecepient')
      //   .where('user.email IN (:...emailsLow)', {
      //     emailsLow: playersImportsAll.map((user) => user.email?.toLowerCase()),
      //   })
      //   .orWhere('user.email IN (:...emailsUp)', {
      //     emailsUp: playersImportsAll.map((user) => user.email.toUpperCase()),
      //   })
      //   .orWhere('wondeStudent.wondeId IN (:...wondeIds)', { wondeIds })
      //   .getMany();

      const playersToSave = playersImportsAll.map((user) => {
        const existingUser = existingPlayers.find(
          (exUser) =>
            (user.email && user.email?.toLowerCase() === exUser.email?.toLowerCase()) ||
            user.wondeStudent?.wondeId === exUser.wondeStudent?.wondeId
        );
        if (existingUser) {
          if (existingUser.player) {
            existingUser.player.parents = [];
            existingUser.player.additionalRecepients = [];
          }

          return {
            ...existingUser,
            ...user,
          };
        }

        return playersBodiesAll.find((u) => u.email === user.email);
      });

      const filteredPlayersToSave = playersToSave.filter((p) => p);

      const uniqPlayers = uniqBy(
        filteredPlayersToSave.map((p) => ({ ...p, birthday: new Date(p?.birthday) })),
        ({ id }) => id
      );
      const wondeUsers = uniqPlayers.filter((u) => u.wondeStudent);
      const notWondeUsers = uniqPlayers.filter((u) => !u.wondeStudent);

      wondeUsers.forEach((wu) => {
        const included = cognitoPlayersWondeId.filter((p) => p).includes(wu.wondeStudent.wondeId);

        if (included) {
          delete wu.wondeStudent;
        }
      });

      const players = await runner.manager
        .getCustomRepository(PlayerRepository)
        .createMany([...notWondeUsers, ...wondeUsers], organizationIds);

      // Add additional recipients
      const { data: existingRecipients } = await this.recipientRepo.findMany({
        email: In(existingPlayers.flatMap((user) => user.player?.additionalRecepients?.map((ar) => ar.email))),
      });

      const additionalsBodiesAll = players.flatMap((player) => {
        const {
          user: { email },
        } = player;

        const { additional } = playersImport.find((player) => player.email === email);

        const filteredAdditional = additional?.filter((a) => a.email);

        return filteredAdditional?.reduce((allRecipients, recipient) => {
          const existingRecipient = existingRecipients.find(
            (ex) => ex.email.toLowerCase() === recipient.email.toLowerCase()
          );
          if (existingRecipient) {
            return [...allRecipients, { ...existingRecipient, ...recipient, player }];
          }
          return [...allRecipients, { ...recipient, player }];
        }, []);
      });

      const filteredAdditionals = additionalsBodiesAll.filter((a) => a);

      filteredAdditionals.length
        ? await runner.manager.save(AdditionalRecipientEntity, filteredAdditionals).catch((err) => {
            throw new UnprocessableEntityException(err.message);
          })
        : null;

      // Create parents
      parentsImportsAll = uniqBy(parentsImportsAll, ({ email }) => email);
      const cognitoParentsEmails = existingParentsImport.map((p) => p.email);
      const parentsImportsNew = parentsImportsAll.filter((parent) => !cognitoParentsEmails.includes(parent.email));
      //const parentsBodiesAll = await this.cognitoManager.adminCreateManyByRole(parentsImportsNew, UserRole.Parent);

      const parentsBodiesAll = parentsImportsNew.map((p) => ({ ...p, id: v4() }));
      cognitoIds.push(...parentsBodiesAll.map(({ id }) => id));

      // Create parent-player relations
      let parentsWithChildrenAll = players.flatMap((player) => {
        const {
          user: { email, wondeStudent },
        } = player;

        const { parents: parentsImport } = playersImport.find(
          (player) =>
            (player.email && player.email?.toLowerCase() === email?.toLowerCase()) ||
            player.wondeStudent?.wondeId === wondeStudent?.wondeId
        );
        const relatedParents = parentsBodiesAll.filter(({ email }) =>
          parentsImport.find((parent) => parent.email?.toLowerCase() === email?.toLowerCase())
        );
        relatedParents.forEach((parent) => {
          if (!parent.children) {
            parent.children = [player];
          } else {
            parent.children.push(player);
          }
        });

        return relatedParents;
      });

      parentsWithChildrenAll = uniqBy(
        parentsWithChildrenAll,
        (val) => `${val.firstName} ${val.lastName} ${val.birthday?.toString()}`
      );

      const existingUsers = await this.userRepo.findByFistLastNamesAndDoBString(
        parentsWithChildrenAll.map((val) => `${val.firstName} ${val.lastName} ${val.birthday?.toString()}`),
        organizationIds[0]
      );

      const usersToSave = parentsWithChildrenAll.map((user) => {
        const existingUser = existingUsers.find((exUser) => user.email.toLowerCase() === exUser.email.toLowerCase());

        if (existingUser) {
          return {
            ...existingUser,
            ...user,
          };
        }

        return user;
      });

      const usersToSaveInCognito = await runner.manager.save(UserEntity, usersToSave);

      const playerSaveToCognito = await this.userRepo.findManyByCondition({
        where: { id: In(players.map((p) => p.userId)) },
      });

      //await this.cognitoManager.adminCreateManyByRole(parentsBodiesAll, UserRole.Parent);
      await this.cognitoManager.adminCreateMany([...usersToSaveInCognito, ...playerSaveToCognito]);
    } catch (err) {
      this.logger.error(`Import failed due to following error: ${err.message}. Starting rollback.`);
      await this.deleteManyCognito(cognitoIds);
      this.logger.log('Rollback succeeded.');
      throw new UnprocessableEntityException(`Import failed due to following error: ${err.message}.`);
    }
  };

  private getPlayerTags(runner: QueryRunner, players: PlayerImportDto[]): Promise<TagEntity[]> {
    const tags = players.flatMap(({ tagIds }) => tagIds).filter((tag) => tag);
    const newTags = players.flatMap(({ newTags }) => newTags).filter((tag) => tag);

    return this.tagRepo.getTags(
      runner,
      tags,
      uniqBy(newTags, (tag) => [tag.name, tag.organizationId].join())
    );
  }

  private async deleteManyCognito(ids: string[]): Promise<void> {
    await Promise.all(ids.map(async (id) => await this.cognitoManager.adminDeleteUser(id)));
  }
}

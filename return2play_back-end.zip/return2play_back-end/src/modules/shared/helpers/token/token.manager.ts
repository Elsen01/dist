import { HttpService, Injectable } from '@nestjs/common';
import jsonwebtoken from 'jsonwebtoken';
import jwkToPem from 'jwk-to-pem';
import { Request } from 'express';
import { promisify } from 'util';
import { ITokenManagerData, IVerifyTokenAsync, MapOfKidToPublicKey, PublicKey, TokenHeader } from './types';
import { AppConfigService } from '../../../../config/config.service';

@Injectable()
export class TokenManager {
  private readonly cognitoIssuer: string;
  private request?: Request;
  private token?: string;
  private decodedPayload?: any | null = null;

  constructor(private service: AppConfigService, private httpService: HttpService) {
    this.cognitoIssuer = this.service.cognito.Issuer;
  }

  init(data: ITokenManagerData): void {
    const { request, token } = data;
    this.request = request;
    this.token = token;
    this.decodedPayload = null;
  }

  async getPayload(): Promise<any> {
    if (this.decodedPayload) {
      return this.decodedPayload;
    }

    this.decodedPayload = await this.verifyAndDecode();
    return this.decodedPayload;
  }

  getTokenFromAuthorization(): string {
    const DEFAULT_VALUE = '';
    const token = this.request?.headers?.authorization ?? DEFAULT_VALUE;

    return token.split(' ')[1] ?? DEFAULT_VALUE;
  }

  isInvalidIssuer(): boolean {
    return this.decodedPayload.iss !== this.cognitoIssuer;
  }

  isExpired(): boolean {
    const { exp, auth_time } = this.decodedPayload;
    const currentSeconds = Math.floor(new Date().valueOf() / 1000);
    return currentSeconds > exp || currentSeconds < auth_time;
  }

  isAccessToken(): boolean {
    return this.decodedPayload.token_use === 'access';
  }

  decodeToken(): any {
    const token = this.token ?? this.getTokenFromAuthorization();
    const payload = jsonwebtoken.decode(token);

    return payload;
  }

  private async getPublicKeys(): Promise<MapOfKidToPublicKey> {
    const url = `${this.cognitoIssuer}/.well-known/jwks.json`;
    const publicKeys = await this.httpService.get(url).toPromise();
    const cacheKeys = publicKeys.data.keys.reduce((agg: MapOfKidToPublicKey, current: PublicKey) => {
      const pem = jwkToPem(current as jwkToPem.JWK);
      agg[current.kid] = { instance: current, pem };
      return agg;
    }, {} as MapOfKidToPublicKey);
    return cacheKeys;
  }

  private async verifyAndDecode(): Promise<any | null> {
    const token = this.token ?? this.getTokenFromAuthorization();
    const tokenSections = token.split('.');

    if (tokenSections.length < 2) {
      return null;
    }

    const headerJSON = Buffer.from(tokenSections[0], 'base64').toString('utf8');

    const header = JSON.parse(headerJSON) as TokenHeader;
    const keys = await this.getPublicKeys();
    const key = keys[header.kid];

    if (!key) {
      return null;
    }

    const verifyAsync: IVerifyTokenAsync = promisify(jsonwebtoken.verify.bind(jsonwebtoken));
    const payload = await verifyAsync(token, key.pem).catch(() => null);

    return payload;
  }
}

import { Request } from 'express';

export interface ITokenManagerData {
  request?: Request;
  token?: string;
}

export interface TokenHeader {
  kid: string;
  alg: string;
}

export interface PublicKey {
  alg: string;
  e: string;
  kid: string;
  kty: string;
  n: string;
  use: string;
}

export interface MapOfKidToPublicKey {
  [key: string]: {
    instance: PublicKey;
    pem: string;
  };
}

export interface IVerifyTokenAsync {
  (token: string, key: string): Promise<any>;
}

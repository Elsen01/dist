import { StripeManager } from './helpers/stripe/stripe.manager';
import { HttpModule, Logger, Module } from '@nestjs/common';
import { CognitoManager } from './helpers/cognito/cognito.manager';
import { TokenManager } from './helpers/token/token.manager';
import { PermissionManager } from './helpers/accessManager/permission.manager';
import { CognitoGuard } from './guards/cognito.guard';
import { S3BucketManager } from './helpers/s3bucket/s3bucket.manager';
import { TypeOrmModule } from '@nestjs/typeorm';
import { UserRepository } from '../users/users.repository';
import { Wonde } from './helpers/wonde/wonde.manager';
import { ImportsManager } from './helpers/imports/imports.manager';
import { RecipientRepository } from '../additional-recipients/recipient.repository';
import { TagRepository } from '../tags/tags.repository';
import { OrganizationRepository } from '../organizations/organizations.repository';
import { AppConfigModule } from '../../config/config.module';

const PROVIDERS = [
  CognitoGuard,
  CognitoManager,
  TokenManager,
  PermissionManager,
  S3BucketManager,
  Logger,
  StripeManager,
  Wonde,
  ImportsManager,
];

@Module({
  imports: [
    AppConfigModule,
    HttpModule,
    TypeOrmModule.forFeature([UserRepository, RecipientRepository, TagRepository, OrganizationRepository]),
  ],
  providers: [...PROVIDERS],
  exports: [...PROVIDERS, AppConfigModule, HttpModule],
})
export class SharedModule {}

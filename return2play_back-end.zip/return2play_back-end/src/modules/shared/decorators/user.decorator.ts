import { createParamDecorator, ExecutionContext } from '@nestjs/common';
import { IUser } from '../interfaces/request-user.interface';
import { IRequestUser } from '../interfaces/request-user.interface';

export const User = createParamDecorator(
  (_data: unknown, ctx: ExecutionContext): IUser => {
    const request: IRequestUser = ctx.switchToHttp().getRequest();
    return request.user;
  }
);

import { LoggerService } from '@nestjs/common';
import { SchedulerRegistry } from '@nestjs/schedule';
import { CronJob } from 'cron';
import { toString as cronTimeToString } from 'cronstrue';
import Redis, { RedisOptions } from 'ioredis';

const DEFAULT_LOCKER_TTL = 60 * 10 * 1000; // 10 minutes
const PRECISION_FOR_EXECUTION_TIME = 3; // decimal places

export abstract class AbstractCronJob {
  abstract handleCron(): Promise<void> | void;

  private redis: Redis;
  constructor(
    public readonly name: string,
    protected readonly logger: LoggerService,
    protected readonly schedulerRegistry: SchedulerRegistry,
    options: { cronTime?: string; interval?: number; timeout?: number; redis?: RedisOptions; timeZone?: string }
  ) {
    if (options.cronTime) {
      const job = new CronJob(options.cronTime, this.HandleCron, undefined, undefined, options.timeZone);
      this.schedulerRegistry.addCronJob(this.name, job);
      job.start();
      this.logger.log(`Start Cron Job '${this.name}' with cron schedule: '${cronTimeToString(options.cronTime)}'`);
    }

    if (options.interval || options.interval === 0) {
      this.schedulerRegistry.addInterval(this.name, setInterval(this.HandleCron, options.interval));
      this.logger.log(`Start Cron Job '${this.name}' with cron schedule: 'once per ${options.interval || '-'} ms'`);
    }

    if (options.timeout || options.timeout === 0) {
      this.schedulerRegistry.addTimeout(this.name, setTimeout(this.HandleCron, options.timeout));
      this.logger.log(`Start Cron Job '${this.name}' with cron schedule: 'only once in ${options.timeout} ms'`);
    }

    if (options.redis) {
      this.redis = new Redis(options.redis);
    }
  }

  protected logExecute(): void | Promise<void> {
    this.logger.log(`Execute Cron Job '${this.name}'`);
  }

  protected logFinish(time?: number): void {
    this.logger.log(
      `Cron Job '${this.name}' is finished.${
        time !== undefined ? ` Time: ${time.toFixed(PRECISION_FOR_EXECUTION_TIME)} ms` : ''
      }`
    );
  }

  protected logError(err: Error): void {
    this.logger.error(`Cron Job '${this.name}' is finished with error. Error: ${err.message}'`);
  }

  protected get lockerKey(): string {
    return this.name.toLowerCase().replace(/\s/g, '-');
  }

  protected get lockerTTL(): number {
    return DEFAULT_LOCKER_TTL;
  }

  private get HandleCron(): () => Promise<void> {
    return async (): Promise<void> => {
      if (this.redis) {
        const acquiredLock = (await this.redis.set(this.lockerKey, 'locked', 'PX', this.lockerTTL, 'NX')) === 'OK';
        if (!acquiredLock) {
          return;
        }
      }

      const start = process.hrtime();
      this.logExecute();
      try {
        await this.handleCron();
      } catch (err) {
        this.logError(err);
      }

      const [seconds, nanoseconds] = process.hrtime(start);

      const milliseconds = seconds * 1000 + nanoseconds / 1000000;

      this.logFinish(milliseconds);

      if (this.redis) {
        await this.redis.del(this.lockerKey);
      }
    };
  }
}

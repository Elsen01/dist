export type FindManyResponse<T> = { data: T[]; totalItems: number };

export enum Order {
  ASC = 'ASC',
  DESC = 'DESC',
}

export interface IUsePagination {
  page: () => number;
  increment: () => void;
}

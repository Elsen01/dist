import { Request as ExpressRequest } from 'express';

export type Request<
  P extends Record<string, any> | string[] = Record<string, any>,
  ResBody = any,
  ReqBody = any,
  ReqQuery = Record<string, any>
> = ExpressRequest<P, ResBody, ReqBody, ReqQuery> & {
  context: Record<string, any>;
};

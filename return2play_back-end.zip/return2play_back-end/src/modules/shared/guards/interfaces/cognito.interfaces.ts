import { UserRole } from '../../../users/types';

export interface IAccessTokenPayload {
  token_use: string;
  auth_time: number;
  iss: string;
  exp: number;
  username: string;
  client_id: string;
  'cognito:groups': UserRole[];
}

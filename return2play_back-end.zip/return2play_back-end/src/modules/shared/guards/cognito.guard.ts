import { RoleManager } from './../helpers/accessManager/role.manager';
import { Injectable, CanActivate, ExecutionContext, UnauthorizedException, BadRequestException } from '@nestjs/common';
import { TokenManager } from '../helpers/token/token.manager';
import { IAccessTokenPayload } from './interfaces/cognito.interfaces';
import { IRequestUser } from '../interfaces/request-user.interface';

@Injectable()
export class CognitoGuard implements CanActivate {
  private roleManager = RoleManager.getInstance();

  constructor(private tokenManager: TokenManager) {}

  async canActivate(context: ExecutionContext): Promise<boolean> {
    try {
      const request: IRequestUser = context.switchToHttp().getRequest();
      this.tokenManager.init({ request });

      const payload = (await this.tokenManager.getPayload()) as IAccessTokenPayload;

      if (!payload) {
        throw new UnauthorizedException('Invalid token');
      }

      const isExpired = this.tokenManager.isExpired();
      const isInvalidIssuer = this.tokenManager.isInvalidIssuer();
      const isAccessToken = this.tokenManager.isAccessToken();

      if (isExpired || isInvalidIssuer || !isAccessToken) {
        throw new UnauthorizedException('Invalid token');
      }

      const role = payload['cognito:groups'][0];
      const userId = payload.username;

      request.user = {
        userId,
        role,
      };
      this.roleManager.role = role;
      this.roleManager.userId = userId;

      return true;
    } catch (err) {
      throw new BadRequestException(err);
    }
  }
}

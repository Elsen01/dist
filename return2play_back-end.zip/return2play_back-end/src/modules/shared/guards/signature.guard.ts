import { Injectable, CanActivate, ExecutionContext, UnauthorizedException } from '@nestjs/common';
import { KMS } from 'aws-sdk';
import { promisify } from 'util';
import { IRequestUser } from '../interfaces/request-user.interface';
import { AppConfigService } from '../../../config/config.service';

@Injectable()
export class SignatureGuard implements CanActivate {
  constructor(private configService: AppConfigService) {}
  async canActivate(context: ExecutionContext): Promise<boolean> {
    const { accessKeyId, secretAccessKey, region } = this.configService.aws;

    const request: IRequestUser = context.switchToHttp().getRequest();
    if (!request.body.signature) {
      throw new UnauthorizedException('Signature is not valid');
    }
    const signature = Buffer.from(request.body.signature, 'binary');

    const params: KMS.VerifyRequest = {
      KeyId: '5961b9a5-bfb6-4c24-89f2-b1ca27364d26',
      Signature: signature,
      SigningAlgorithm: 'RSASSA_PSS_SHA_256',
      Message: 'Validation SOCS',
    };

    const kms = new KMS({
      region: region,
      accessKeyId: accessKeyId,
      secretAccessKey: secretAccessKey,
    });

    const verifyKmsFunc = promisify(kms.verify).bind(kms);

    const res: KMS.VerifyResponse = await verifyKmsFunc(params).catch(() => {
      throw new UnauthorizedException('Signature is not valid');
    });

    if (!res?.SignatureValid) {
      throw new UnauthorizedException('Signature is not valid');
    }

    return true;
  }
}

import { IRequestUser } from './../interfaces/request-user.interface';
import { Injectable, CanActivate, ExecutionContext, ForbiddenException } from '@nestjs/common';
import { Reflector } from '@nestjs/core';

@Injectable()
export class RolesGuard implements CanActivate {
  constructor(private readonly reflector: Reflector) {}

  canActivate(context: ExecutionContext): boolean {
    const handlerRoles = this.reflector.get<string[]>('roles', context.getHandler()) || [];
    const controllerRoles = this.reflector.get<string[]>('roles', context.getClass()) || [];
    const request: IRequestUser = context.switchToHttp().getRequest();
    const roles = [...handlerRoles, ...controllerRoles];

    const hasPermissions = roles.includes(request.user.role);

    if (hasPermissions) {
      return true;
    }

    throw new ForbiddenException('User does not have enough permission');
  }
}

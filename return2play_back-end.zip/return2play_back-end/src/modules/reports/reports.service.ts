import { SportRepository } from './../sports/sport.repository';
import { S3BucketManager } from './../shared/helpers/s3bucket/s3bucket.manager';
import { ReportRepository } from './report.repository';
import { HttpService, Inject, Injectable, Logger, LoggerService, UnprocessableEntityException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { OrganizationRepository } from '../organizations/organizations.repository';
import { stringToArray } from '../shared/utils/common.utils';
import { ReportInjuryQuery } from './dtos/generate-report.dto';
import { ReportFormat, ReportResponse } from './types';
import { ReportEntity } from './entities/report.entity';
import { FindManyResponse } from '../shared/types';
import { FiltersQuery } from './dtos/find-report.dto';
import { AwsSignManager } from '../shared/helpers/lambda/sign.manager';
import { write } from 'fast-csv';
import { S3Folders } from '../shared/constants';
import { FileFormat } from '../shared/helpers/s3bucket/types';
import { createGzip } from 'zlib';
import moment from 'moment';
import { AppConfigService } from '../../config/config.service';
import { IUser } from '../shared/interfaces/request-user.interface';
import { UserRole } from '../users/types';

@Injectable()
export class ReportsService {
  constructor(
    @InjectRepository(OrganizationRepository)
    private organizationRepo: OrganizationRepository,
    @InjectRepository(ReportRepository)
    private reportRepo: ReportRepository,
    private httpService: HttpService,
    private configService: AppConfigService,
    private signManager: AwsSignManager,
    @Inject(Logger) private logger: LoggerService,
    private s3manager: S3BucketManager,
    private sportRepo: SportRepository
  ) {}

  async generateInjuryReport(query: ReportInjuryQuery, format: ReportFormat, user: IUser): Promise<ReportResponse> {
    const { organizationIds, allOrganization, allSports, sportIds, nonSport, allInjury } = query;
    console.log('salam2');

    try {
      if (!organizationIds?.length && !allOrganization) {
        throw new UnprocessableEntityException(
          'You should select particular organisations or "All organisations" option'
        );
      }
      console.log('salam3');

      if (!sportIds?.length && !allSports && !nonSport && !allInjury) {
        throw new UnprocessableEntityException(
          'You should select particular sport or "All sport", "Non sport" options'
        );
      }
      console.log('salam4');

      const formattedQuery = await this.formatQuery(query, user);
      console.log('salam5');

      const response =
        format === ReportFormat.Csv
          ? await this.generateCsvReport(formattedQuery)
          : await this.generatePdfReport(formattedQuery);
      console.log('salam5');

      await this.reportRepo.create(format);

      return response;
    } catch (err) {
      console.log('Catcha dushdu');

      this.logger.error(`Report generation field with error: ${err.message}`);
      throw new UnprocessableEntityException(err.message);
    }
  }

  async generateCsvReport(query: ReportInjuryQuery): Promise<ReportResponse> {
    const playerInjuryData = await this.reportRepo.findInjuryForCsv(query);

    const { stream: s3WritableStream, promise: s3Upload } = this.s3manager.uploadStreamToS3(
      `${S3Folders.ReportsCsv}/Injuries_Report_${new Date().toLocaleDateString()}_${new Date().getTime()}.csv`,
      FileFormat.csv,
      this.configService.aws.s3Bucket
    );

    const gzip = createGzip();

    write(playerInjuryData, { headers: true }).pipe(gzip).pipe(s3WritableStream);

    return s3Upload.then(({ Location: reportLink }) => ({ reportLink }));
  }

  async generatePdfReport(query: ReportInjuryQuery): Promise<ReportResponse> {
    const stage = this.configService.stage;
    console.log('stage');

    const { headers } = this.signManager.signRequest(`/${stage}/${ReportFormat.Pdf}`);
    console.log({ headers });

    const organizationIdsArray = stringToArray(query.organizationIds);

    const organizationIds = await this.organizationRepo.getOrganizationUserHaveAccessTo(organizationIdsArray);
    this.logger.log(`${this.configService.aws.lambdaHost}/${ReportFormat.Pdf}`);
    console.log('salam9');

    const response = await this.httpService
      .post<ReportResponse>(
        `https://${this.configService.aws.lambdaHost}/${stage}/${ReportFormat.Pdf}`,
        {
          ...query,
          organizationIds,
        },
        {
          headers,
        }
      )
      .toPromise();
    console.log('salam100');

    return response.data;
  }

  async getReportsList(query: FiltersQuery): Promise<FindManyResponse<ReportEntity>> {
    const response = await this.reportRepo.findMany(query);

    return { data: response[0], totalItems: response[1] };
  }

  public async formatQuery(query: ReportInjuryQuery, user: IUser): Promise<ReportInjuryQuery> {
    const { allOrganization, allSports, nonSport } = query;

    allOrganization ? (query.organizationIds = []) : null;
    allSports ? (query.sportIds = []) : null;
    allSports && nonSport ? (query.allInjury = true) : null;

    if (allOrganization && user.role === UserRole.OrganizationAdmin) {
      const organizations = await this.organizationRepo.findByUserId(user.userId);
      query.organizationIds = organizations.map(({ id }) => id);
    }

    if (query.allInjury) {
      query.sportIds = [];
    }

    query.startDate = moment(query.startDate).subtract(1, 'days').toDate();
    query.endDate = moment(query.endDate).add(1, 'days').toDate();

    return query;
  }
}

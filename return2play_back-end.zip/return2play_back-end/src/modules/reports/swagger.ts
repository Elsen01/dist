import { IDocumentedEndpoint } from '../shared/interfaces/swagger.interface';

export const GENERATE_REPORT: IDocumentedEndpoint = {
  OPERATION: {
    description:
      'Generate report for injuries in PDF or CSV format.`Super admins`, `organization admins` are allowed to perform this action',
  },
  SUCCESS: {
    description: '`Success` Link for report returned',
  },
  FORBIDDEN: {
    description: '`API` User has no permissions to generate injury report',
  },
  FAILURE: {
    description: '`API` Error occurs during update an entity',
  },
};

export const GET_REPORTS_LIST: IDocumentedEndpoint = {
  OPERATION: {
    description:
      '`Super admin` or `organization admin` can get list of reports, `organization admins` are allowed to get only own reports',
  },
  SUCCESS: {
    description: '`Success` Report list was returned',
  },
  FORBIDDEN: {
    description: '`API` User has no permissions to get report list',
  },
  FAILURE: {
    description: '`API` Error occurs select an entity',
  },
};

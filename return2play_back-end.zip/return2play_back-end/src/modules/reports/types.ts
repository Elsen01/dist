export enum ReportFormat {
  Pdf = 'pdf',
  Csv = 'csv',
}

export type ReportResponse = {
  reportLink: string;
};

export enum SortOptions {
  Date = 'report.date',
}

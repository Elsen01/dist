import { ReportRepository } from './report.repository';
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ReportsController } from './reports.controller';
import { ReportsService } from './reports.service';
import { OrganizationRepository } from '../organizations/organizations.repository';
import { SharedModule } from '../shared/shared.module';
import { AwsSignManager } from '../shared/helpers/lambda/sign.manager';
import { SportRepository } from '../sports/sport.repository';

@Module({
  controllers: [ReportsController],
  providers: [ReportsService, AwsSignManager],
  imports: [TypeOrmModule.forFeature([ReportRepository, OrganizationRepository, SportRepository]), SharedModule],
})
export class ReportsModule {}

import { UserEntity } from '../users/entities/user.entity';
import { getEntityInstance, stringToArray } from '../shared/utils/common.utils';
import { EntityRepository } from 'typeorm';
import { RoleManager } from '../shared/helpers/accessManager/role.manager';
import { ReportEntity } from './entities/report.entity';
import { UnprocessableEntityException } from '@nestjs/common';
import { ReportFormat } from './types';
import { FiltersQuery } from './dtos/find-report.dto';
import { UserRole } from '../users/types';
import { BaseRepository } from '../shared/base.repository';
import { ReportInjuryQuery } from './dtos/generate-report.dto';
import { ActivityType } from '../injuries/types';

@EntityRepository(ReportEntity)
export class ReportRepository extends BaseRepository<ReportEntity> {
  private readonly roleManager = RoleManager.getInstance();

  async create(format: ReportFormat): Promise<void> {
    const author = getEntityInstance(this.roleManager.userId, UserEntity);

    await this.repository.save({ format, author }).catch((err) => {
      throw new UnprocessableEntityException(err.message);
    });
    return;
  }

  findInjuryForCsv(query: ReportInjuryQuery): Promise<UserEntity[]> {
    const { organizationIds, startDate, endDate, sportIds, nonSport, allInjury, allSports } = query;
    const orgIdArray = stringToArray(organizationIds);
    const sportIdArray = stringToArray(sportIds);

    return this.manager
      .getRepository(UserEntity)
      .createQueryBuilder('user')
      .select([
        // 'user.id',
        // 'user.firstName',
        // 'user.lastName',
        // 'user.email',
        'user.gender',
        "TO_CHAR(user.birthday, 'dd/mm/yyyy') as user_birthday",
        // 'player.membership',
        'player.yearGroup',
        'player.playStatus',
        'injury.id as injury_id',
        'injury.injuryGroup',
        'injury.activityType',
        "TO_CHAR(injury.accidentDate, 'dd/mm/yyyy') as injury_accident_date",
        "TO_CHAR(injury.createdAt, 'dd/mm/yyyy') as injury_created_at",
        'injury.injuredAt',
        'injury.playStatus as injury_play_status',
        'otherInjury.category',
        'otherInjury.type',
        'otherInjury.bodySide',
        'bodyRegion.name',
        'bodyPart.name',
        'sportInjury.matchTraining',
        'sportInjury.playSide',
        'sportInjury.typePeriod',
        'sport.name',
        'injuryMechanism.name',
      ])
      .innerJoin('user.player', 'player')
      .leftJoin('user.injuries', 'injury')
      .leftJoin('injury.otherInjury', 'otherInjury') //sportInjury
      .leftJoin('injury.sportInjury', 'sportInjury')
      .leftJoin('user.organizations', 'org')
      .leftJoin('sportInjury.sport', 'sport')
      .leftJoin('sportInjury.injuryMechanism', 'injuryMechanism')
      .leftJoin('otherInjury.bodyPart', 'bodyPart')
      .leftJoin('otherInjury.bodyRegion', 'bodyRegion')
      .where(organizationIds?.length ? 'org.id IN (:...orgIdArray)' : 'true', { orgIdArray })
      .andWhere(sportIds?.length && !allInjury ? 'sport.id IN (:...sportIdArray)' : 'true', {
        sportIdArray,
      })
      .andWhere(nonSport && !allInjury ? 'injury.activityType = :nonSportType' : 'true', {
        nonSportType: ActivityType.NonSport,
      })
      .andWhere(allSports && !allInjury ? 'injury.activityType = :sportType' : 'true', {
        sportType: ActivityType.Sport,
      })
      .andWhere(startDate ? 'injury.accidentDate >= :startDate' : 'true', { startDate })
      .andWhere(endDate ? 'injury.accidentDate <= :endDate' : 'true', { endDate })
      .orderBy('user.firstName')
      .addOrderBy('user.lastName')
      .getRawMany();
  }

  async findMany(filter: FiltersQuery): Promise<[ReportEntity[], number]> {
    const { sort, order, limit, page } = filter;

    const query = this.repository
      .createQueryBuilder('report')
      .leftJoinAndSelect('report.author', 'author')
      .orderBy(sort, order)
      .take(limit)
      .skip(limit * page);

    const isSuperAdmin = this.roleManager.role === UserRole.SuperAdmin;
    if (!isSuperAdmin) {
      query.where('report.author = :adminId', { adminId: this.roleManager.userId });
    }

    return await query.getManyAndCount().catch((err) => {
      throw new UnprocessableEntityException(err.message);
    });
  }
}

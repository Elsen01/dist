import { IsEnum, IsOptional } from 'class-validator';
import { PaginationDto } from '../../shared/shared.dto';
import { Order } from '../../shared/types';
import { SortOptions } from '../types';

export class FiltersQuery extends PaginationDto {
  @IsEnum(SortOptions)
  @IsOptional()
  sort? = SortOptions.Date;

  @IsEnum(Order)
  @IsOptional()
  order? = Order.DESC;
}

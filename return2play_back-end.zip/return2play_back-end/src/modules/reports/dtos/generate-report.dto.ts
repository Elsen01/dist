import { Type } from 'class-transformer';
import { IsDateString, IsEnum, IsOptional, IsUUID, IsBoolean } from 'class-validator';
import { ReportFormat } from '../types';

export class ReportInjuryQuery {
  @IsUUID('all', { each: true })
  @IsOptional()
  organizationIds?: string[];

  @IsUUID('all', { each: true })
  @IsOptional()
  sportIds?: string[];

  @IsDateString()
  startDate: Date;

  @IsDateString()
  endDate: Date;

  @IsBoolean()
  @IsOptional()
  @Type(() => Boolean)
  allOrganization?: boolean;

  @IsBoolean()
  @IsOptional()
  @Type(() => Boolean)
  allSports?: boolean;

  @IsBoolean()
  @IsOptional()
  @Type(() => Boolean)
  nonSport?: boolean;

  @IsBoolean()
  @IsOptional()
  @Type(() => Boolean)
  allInjury?: boolean;
}

export class ReportInjuryParam {
  @IsEnum(ReportFormat)
  format: ReportFormat;
}

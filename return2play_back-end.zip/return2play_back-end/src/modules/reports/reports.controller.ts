import { ReportsService } from './reports.service';
import { Controller, Get, Param, Query, UseGuards } from '@nestjs/common';
import {
  ApiBearerAuth,
  ApiForbiddenResponse,
  ApiNoContentResponse,
  ApiOperation,
  ApiTags,
  ApiUnprocessableEntityResponse,
} from '@nestjs/swagger';
import { ReportInjuryParam, ReportInjuryQuery } from './dtos/generate-report.dto';
import { GENERATE_REPORT, GET_REPORTS_LIST } from './swagger';
import { ReportResponse } from './types';
import { CognitoGuard } from '../shared/guards/cognito.guard';
import { RolesGuard } from '../shared/guards/roles.guard';
import { Roles } from '../shared/decorators/roles.decorator';
import { UserRole } from '../users/types';
import { ReportEntity } from './entities/report.entity';
import { FindManyResponse } from '../shared/types';
import { FiltersQuery } from './dtos/find-report.dto';
import { User } from '../shared/decorators/user.decorator';
import { IUser } from '../shared/interfaces/request-user.interface';

@ApiTags('Reports')
@UseGuards(CognitoGuard, RolesGuard)
@Roles(UserRole.SuperAdmin, UserRole.OrganizationAdmin, UserRole.MedicalStaff)
@ApiBearerAuth()
@Controller('reports')
export class ReportsController {
  constructor(private service: ReportsService) {}

  @ApiOperation(GENERATE_REPORT.OPERATION)
  @ApiNoContentResponse(GENERATE_REPORT.SUCCESS)
  @ApiForbiddenResponse(GENERATE_REPORT.FORBIDDEN)
  @ApiUnprocessableEntityResponse(GENERATE_REPORT.FAILURE)
  @Get('/:format')
  async generateInjuryReportPdf(
    @Query() query: ReportInjuryQuery,
    @Param() params: ReportInjuryParam,
    @User() user: IUser
  ): Promise<ReportResponse> {
    console.log('salam1');

    return await this.service.generateInjuryReport(query, params.format, user);
  }

  @ApiOperation(GET_REPORTS_LIST.OPERATION)
  @ApiNoContentResponse(GET_REPORTS_LIST.SUCCESS)
  @ApiForbiddenResponse(GET_REPORTS_LIST.FORBIDDEN)
  @ApiUnprocessableEntityResponse(GET_REPORTS_LIST.FAILURE)
  @Get()
  async getReportsList(@Query() query: FiltersQuery): Promise<FindManyResponse<ReportEntity>> {
    return await this.service.getReportsList(query);
  }
}

import {
  Column,
  CreateDateColumn,
  Entity,
  JoinColumn,
  JoinTable,
  ManyToMany,
  ManyToOne,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm';
import { DoctorEntity } from '../../doctors/entities/doctor.entity';
import { OrganizationEntity } from '../../organizations/entities/organization.entity';
import { ClinicStatus, AppointmentFormat, AppointmentType, Weekday, AppointmentTypeArray } from '../types';

@Entity('doctor_clinic_schedule')
export class ScheduledClinicEntity {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ type: 'time', name: 'start_time' })
  startTime: string;

  @Column({ type: 'time', name: 'end_time' })
  endTime: string;

  @Column({ type: 'simple-array' })
  days: Weekday[];

  @Column({ name: 'appointment_length', nullable: true })
  appointmentLength: number;

  @Column({ type: 'varchar', length: 255, nullable: true })
  location: string;

  @Column({ type: 'enum', enum: AppointmentFormat })
  format: AppointmentFormat;

  @Column({ type: 'simple-array', enum: AppointmentTypeArray, nullable: true, name: 'medical_type' })
  medicalType: AppointmentType[];

  @Column({ type: 'enum', enum: ClinicStatus, default: ClinicStatus.Active })
  status: ClinicStatus;

  @Column({ name: 'all_organizations', nullable: true })
  allOrganizations: boolean;

  @ManyToOne(() => DoctorEntity, (doctor) => doctor?.scheduledClinics)
  @JoinColumn({ name: 'doctor_id' })
  doctor: DoctorEntity;

  @ManyToMany(() => OrganizationEntity)
  @JoinTable({
    name: 'schedule_organization',
    joinColumn: {
      name: 'clinic_id',
      referencedColumnName: 'id',
    },
    inverseJoinColumn: {
      name: 'organization_id',
      referencedColumnName: 'id',
    },
  })
  organizations: OrganizationEntity[];

  @CreateDateColumn({ name: 'created_at' })
  createdAt: Date;

  @UpdateDateColumn({ name: 'updated_at' })
  updatedAt: Date;
}

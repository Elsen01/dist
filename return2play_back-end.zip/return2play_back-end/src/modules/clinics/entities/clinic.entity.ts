import {
  Column,
  CreateDateColumn,
  Entity,
  JoinColumn,
  JoinTable,
  ManyToMany,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm';
import { DoctorEntity } from '../../doctors/entities/doctor.entity';
import { AppointmentFormat, AppointmentType, AppointmentTypeArray, ClinicStatus, ClinicType } from '../types';
import { OrganizationEntity } from '../../organizations/entities/organization.entity';
import { ScheduledClinicEntity } from './scheduledClinic.entity';
import { TimeSlotEntity } from './timeSlot.entity';

@Entity('clinics')
export class ClinicEntity {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ type: 'time', name: 'start_time' })
  startTime: string;

  @Column({ type: 'time', name: 'end_time' })
  endTime: string;

  @Column({ name: 'appointment_length', nullable: true })
  appointmentLength: number;

  @Column({ type: 'varchar', length: 255, nullable: true })
  location: string;

  @Column({ type: 'date' })
  date: Date;

  @Column({ type: 'enum', enum: AppointmentFormat })
  format: AppointmentFormat;

  @Column({ type: 'simple-array', enum: AppointmentTypeArray, nullable: true, name: 'medical_type' })
  medicalType: AppointmentType[];

  @Column({ type: 'enum', enum: ClinicStatus, default: ClinicStatus.Active })
  status: ClinicStatus;

  @Column({ type: 'enum', enum: ClinicType, default: ClinicType.OneTime })
  type: ClinicType;

  @Column({ name: 'all_organizations', nullable: true })
  allOrganizations: boolean;

  @OneToMany(() => TimeSlotEntity, (timeSlot) => timeSlot.clinic, { onDelete: 'CASCADE' })
  timeSlots: TimeSlotEntity[];

  @ManyToOne(() => DoctorEntity, (doctor) => doctor?.clinics)
  @JoinColumn({ name: 'doctor_id' })
  doctor: DoctorEntity;

  @ManyToOne(() => ScheduledClinicEntity)
  @JoinColumn({ name: 'schedule_id' })
  schedule?: ScheduledClinicEntity;

  @ManyToMany(() => OrganizationEntity)
  @JoinTable({
    name: 'clinic_organization',
    joinColumn: {
      name: 'clinic_id',
      referencedColumnName: 'id',
    },
    inverseJoinColumn: {
      name: 'organization_id',
      referencedColumnName: 'id',
    },
  })
  organizations: OrganizationEntity[];

  @CreateDateColumn({ name: 'created_at' })
  createdAt: Date;

  @UpdateDateColumn({ name: 'updated_at' })
  updatedAt: Date;
}

import {
  Column,
  CreateDateColumn,
  Entity,
  JoinColumn,
  ManyToOne,
  OneToOne,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm';
import { AppointmentEntity } from '../../appointments/entities/appointment.entity';
import { ClinicStatus } from '../types';
import { ClinicEntity } from './clinic.entity';

@Entity('timeslots')
export class TimeSlotEntity {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ type: 'time', name: 'start_time' })
  startTime: string;

  @Column({ type: 'time', name: 'end_time' })
  endTime: string;

  @Column({ type: 'date' })
  date: Date;

  @Column({ type: 'enum', enum: ClinicStatus, default: ClinicStatus.Active })
  status: ClinicStatus;

  @OneToOne(() => AppointmentEntity, (appointment) => appointment.timeSlot, { onDelete: 'SET NULL' })
  appointment?: AppointmentEntity;

  @Column({ default: false })
  booked: boolean;

  @ManyToOne(() => ClinicEntity, (clinic) => clinic?.timeSlots)
  @JoinColumn({ name: 'clinic_id' })
  clinic: ClinicEntity;

  @CreateDateColumn({ name: 'created_at' })
  createdAt: Date;

  @UpdateDateColumn({ name: 'updated_at' })
  updatedAt: Date;
}

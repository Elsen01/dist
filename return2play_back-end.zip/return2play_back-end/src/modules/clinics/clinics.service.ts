import { UpdateClinicBody, UpdateScheduledClinicBody } from './dtos/update-clinic.dto';
import { stringToArray, toCamelCase, getEntityInstance } from '../shared/utils/common.utils';
import {
  Injectable,
  NotFoundException,
  UnprocessableEntityException,
  ForbiddenException,
  ConflictException,
} from '@nestjs/common';
import { In, Not, QueryRunner } from 'typeorm';
import { isEqual, uniq } from 'lodash';
import { RoleManager } from '../shared/helpers/accessManager/role.manager';
import { ClinicRepository } from './clinics.repository';
import { CreateScheduledClinicBody } from './dtos/create-clinic-schedule.dto';
import { CreateClinicBody } from './dtos/create-clinic.dto';
import { FindManyDto, FindManyQuery, FindManySummaryDto } from './dtos/find-clinic.dto';
import { ClinicSidePanelResponse, ClinicStatus, ClinicType, ClinicWithStatistic, SummaryDateStatistics } from './types';
import { ClinicEntity } from './entities/clinic.entity';
import { InjuryRepository } from '../injuries/injury.repository';
import { UserRole } from '../users/types';
import { DoctorRepository } from '../doctors/doctor.repository';
import moment from 'moment';
import { Moment } from 'moment';
// import { AppointmentType } from '../appointments/types';
// import { isEqual } from 'lodash';
import { OrganizationEntity } from '../organizations/entities/organization.entity';
import { TimeSlotEntity } from './entities/timeSlot.entity';
import { InjuryEntity } from '../injuries/entities/injury.entity';

@Injectable()
export class ClinicsService {
  private readonly roleManage = RoleManager.getInstance();

  constructor(
    private clinicRepo: ClinicRepository,
    private injuryRepo: InjuryRepository,
    private doctorRepo: DoctorRepository
  ) {}

  createClinic(clinic: CreateClinicBody): Promise<void> {
    return this.clinicRepo.createClinicOneTime(clinic);
  }

  async createScheduledClinic(clinic: CreateScheduledClinicBody): Promise<void> {
    const recurringClinicDays = clinic.days.map((d) => +d);

    const prevMonday = new Date();
    prevMonday.setDate(prevMonday.getDate() - ((prevMonday.getDay() + 6) % 7));

    const firstWeekDates = recurringClinicDays.map((d) => moment(prevMonday).add(d, 'days'));

    const fullYearClinicDates: Date[] = firstWeekDates.map((d) => d.toDate());

    for (let i = 0; i < 52; i++) {
      let lastWeekDates = [...firstWeekDates];
      const dates = lastWeekDates.map((d) => moment(d.add(7, 'days')));

      fullYearClinicDates.push(...dates.map((d) => d.toDate()));

      lastWeekDates = [...dates];
    }

    const clinicRelated = await this.clinicRepo.getClinicRelated(clinic);

    return this.clinicRepo.createScheduledClinic(clinicRelated, fullYearClinicDates, clinic);
  }

  async updateScheduledClinic(clinic: any): Promise<void> {
    const recurringClinicDays = clinic.days.map((d) => +d);

    const prevMonday = new Date();
    prevMonday.setDate(prevMonday.getDate() - ((prevMonday.getDay() + 6) % 7));

    const firstWeekDates = recurringClinicDays.map((d) => moment(prevMonday).add(d, 'days'));

    const fullYearClinicDates: Date[] = firstWeekDates.map((d) => d.toDate());

    for (let i = 0; i < 52; i++) {
      let lastWeekDates = [...firstWeekDates];
      const dates = lastWeekDates.map((d) => moment(d.add(7, 'days')));

      fullYearClinicDates.push(...dates.map((d) => d.toDate()));

      lastWeekDates = [...dates];
    }

    const clinicRelated = await this.clinicRepo.getClinicRelated(clinic);

    return this.clinicRepo.createScheduledClinic(clinicRelated, fullYearClinicDates, clinic);
  }

  clinicToSchedule(): Promise<void> {
    return this.clinicRepo.scheduleToClinics();
  }

  async deleteClinic(id: string): Promise<void> {
    const clinic = await this.clinicRepo.findClinic({ id, status: Not(ClinicStatus.Inactive) });

    if (!clinic) {
      throw new NotFoundException('Clinic not found');
    }

    return this.clinicRepo.deleteOne(clinic);
  }

  async deleteScheduledClinic(id: string): Promise<void> {
    const clinic = await this.clinicRepo.findClinicRecurring({ id, status: Not(ClinicStatus.Inactive) });

    if (!clinic) {
      throw new NotFoundException('Clinic not found');
    }

    return this.clinicRepo.deleteOneRecurring(id);
  }

  async findManyInRange(query: FindManyDto): Promise<ClinicWithStatistic[]> {
    const startDate = new Date(query.startDate);
    const endDate = new Date(query.endDate);
    if (startDate > endDate) {
      throw new UnprocessableEntityException('End date is greater than start date.');
    }

    const doctorId = this.roleManage.role === UserRole.SuperAdmin ? query.doctorId : this.roleManage.userId;

    const clinicStatistic = await this.clinicRepo.getClinicsStatistic(
      startDate.toISOString(),
      endDate.toISOString(),
      doctorId
    );

    const clinics = await this.clinicRepo.findManyInRange(startDate.toISOString(), endDate.toISOString(), doctorId);

    return clinics.map((clinic) => ({ ...clinic, ...clinicStatistic.find((stat) => stat.id === clinic.id) }));
  }

  async findManyInRangeSummary(query: FindManySummaryDto): Promise<SummaryDateStatistics[]> {
    const startDate = new Date(query.startDate);
    const endDate = new Date(query.endDate);
    if (startDate > endDate) {
      throw new UnprocessableEntityException('End date is greater than start date.');
    }

    const rawStats = await this.clinicRepo.getClinicsStatisticsSummary(startDate.toISOString(), endDate.toISOString());

    let dates = rawStats.map(({ date }) => date.toISOString());
    dates = uniq(dates);

    const doctors = await this.doctorRepo.findManyByCondition({
      userId: In(rawStats.flatMap(({ doctorIds }) => doctorIds)),
    });

    const summary = dates.map((date) => {
      const prettyDate = date.split('T')[0];

      const matchRawStats = rawStats.filter((stats) => stats.date.toISOString() === date);

      const stats = matchRawStats.map((stats) => {
        const matchDoctors = doctors.filter(({ userId }) =>
          matchRawStats.some(({ doctorIds }) => doctorIds.includes(userId))
        );
        // eslint-disable-next-line @typescript-eslint/no-unused-vars
        const { doctorIds, ...restStats } = stats;

        return { ...restStats, doctors: matchDoctors };
      });

      return { [prettyDate]: stats };
    });

    return summary;
  }

  async findManyByPlayer(id: string, query: FindManyQuery): Promise<ClinicEntity[]> {
    const { injuryId, doctorId, appointmentType } = query;

    const isHasAccessToPlayer = await this.injuryRepo.isHasAccessToPlayer(id);

    let tenDaysAfterInjuryAccident: Date = null;
    let injury: InjuryEntity;
    if (injuryId) {
      injury = await this.injuryRepo.findInjury({ id: injuryId });

      tenDaysAfterInjuryAccident = moment(injury.accidentDate).add(0, 'days').isAfter()
        ? moment(injury.accidentDate).add(0, 'days').toDate()
        : moment().toDate();
    }

    if (!isHasAccessToPlayer) {
      throw new ForbiddenException('User has no access to player');
    }

    const result = await this.clinicRepo.findManyByPlayer(
      id,
      {
        clinicStartDate: tenDaysAfterInjuryAccident,
        doctorId,
        appointmentType,
      },
      injury
    );

    return result;
  }

  async getSidePanel(query: FindManyDto): Promise<ClinicSidePanelResponse[]> {
    const data = await this.clinicRepo.getClinicCountGroupByDoctors(query);

    return data.map(toCamelCase) as ClinicSidePanelResponse[];
  }

  async updateOne(clinicId: string, body: UpdateClinicBody): Promise<void> {
    const clinic = await this.clinicRepo.findOne({ id: clinicId });
    if (!clinic) {
      throw new NotFoundException('Clinic not found');
    }

    // const canUpdate = this.validateClinicUpdate(clinic, body);

    // if (!canUpdate) {
    //   throw new ConflictException('Can not edit clinic due the booked appointment within the clinic');
    // }
    const { startClinic: newClinicStartDate, endClinic: newClinicEndDate } = this.clinicsTimeToMoment(
      body.date,
      body.startTime,
      body.endTime
    );

    const { startClinic: oldClinicStartDate, endClinic: oldClinicEndDate } = this.clinicsTimeToMoment(
      clinic.date,
      clinic.startTime,
      clinic.endTime
    );

    const startClinicDiff = newClinicStartDate.diff(oldClinicStartDate);
    const endClinicDiff = newClinicEndDate.diff(oldClinicEndDate);

    //const timeSlotsToDelete: TimeSlotEntity[] = [];
    const timeSlotsToCreate: TimeSlotEntity[] = [];

    // if (endClinicDiff > 0) {
    //   const timeSlots = this.getTimeSlotsToCreate(oldClinicEndDate, newClinicEndDate, clinic);

    //   timeSlotsToCreate.push(...timeSlots);
    // } else if (endClinicDiff < 0) {
    //   const timeSlotsToDelete = await this.clinicRepo.findTimeSlotsToDeleteInEnd(clinicId, newClinicEndDate.toDate());

    //   timeSlotsToDelete.push(...timeSlotsToDelete);
    // }
    // if (startClinicDiff < 0) {
    //   const timeSlots = this.getTimeSlotsToCreate(newClinicEndDate, newClinicEndDate, clinic);

    //   timeSlotsToCreate.push(...timeSlots);
    // } else if (startClinicDiff > 0) {
    //   const timeSlotsToDelete = await this.clinicRepo.findTimeSlotsToDeleteInStart(
    //     clinicId,
    //     newClinicStartDate.toDate()
    //   );

    //   timeSlotsToDelete.push(...timeSlotsToDelete);
    // }

    const updateClinicTransition = async (runner: QueryRunner): Promise<void> => {
      let organizations = stringToArray(body.organizationIds)?.map((id) => getEntityInstance(id, OrganizationEntity));
      const allOrganizations = organizations?.length ? false : true;
      allOrganizations ? (organizations = []) : null;

      timeSlotsToCreate.length ? await this.clinicRepo.saveClinicTimeslotsTransaction(runner, timeSlotsToCreate) : null;
      await this.clinicRepo.updateClinic(runner, { id: clinicId, organizations, allOrganizations, ...body });

      console.log({ startClinicDiff });
      console.log({ endClinicDiff });
    };

    await this.clinicRepo.runTransaction(updateClinicTransition);
    const clinicForTimeslots = await this.clinicRepo.findOneById(clinicId);
    console.log({ clinicForTimeslots });

    // if (startClinicDiff !== 0 && endClinicDiff === 0) {
    //   this.clinicRepo.deleteAllOldTimeSlots(clinicId);
    // }
    if (startClinicDiff !== 0 || endClinicDiff !== 0) {
      console.log('saaaalaam');
      this.clinicRepo.deleteAllOldTimeSlotsForStartTime(clinicId, body.startTime, body.endTime);
      const oldTimeslots = await this.clinicRepo.findOldTimeSlots(clinic.id);

      // if (endClinicDiff < 0) {
      //   console.log(111111111);

      //   await this.clinicRepo.deleteAllOldTimeSlotsForStartTime(clinicId, body.endTime);
      // } else {
      //   console.log(222222222);

      //   await this.clinicRepo.deleteAllOldTimeSlots(clinicId);
      // }
      await this.clinicRepo.saveClinicAndUpdateTimeslotsTransactionDuringUpdate(clinicForTimeslots, oldTimeslots);
    }
    // timeSlotsToCreate.length
    //   ? await this.clinicRepo.saveClinicTimeslotsTransactionDuringUpdate(clinicForTimeslots)
    //   : null;
    return;
  }

  async updateRecurringClinic(id: string, clinicBody: UpdateScheduledClinicBody): Promise<void> {
    const clinic = await this.clinicRepo.findOne({ id });
    console.log({ clinic });

    if (!clinic) {
      throw new NotFoundException('Clinic not found');
    }
    console.log('Recurring update2');

    if (clinic.type !== ClinicType.Recurring) {
      throw new UnprocessableEntityException('Clinic not recurring');
    }
    console.log('Recurring update3');

    const allClinicBySchedule = [clinic, ...(await this.clinicRepo.findClinicsBySchedule(clinic.schedule.id))];
    const isEqualDays = isEqual(clinicBody.days, clinic.schedule.days);
    const hasBookedAppointments = allClinicBySchedule.map((c) => c.timeSlots.some((ts) => ts.booked)).some((i) => i);
    console.log('Recurring update4');

    if (!isEqualDays && hasBookedAppointments) {
      throw new ConflictException('Can not edit clinic due the booked appointment within the clinics');
    }
    console.log('Recurring update5');

    if (isEqualDays && hasBookedAppointments) {
      throw new ConflictException('Clinic cannot be edited while any appointments are booked');
    }
    console.log('Recurring update6');

    const canUpdate = allClinicBySchedule
      .map((c) => this.validateClinicUpdate(c, { ...clinicBody, date: clinic.date }))
      .some((v) => v);
    console.log('Recurring update7');

    if (!canUpdate) {
      throw new ConflictException('Can not edit clinic due the booked appointment within the clinics');
    }

    const recurringClinicDays = clinicBody.days.map((d) => +d);

    const prevMonday = new Date();
    prevMonday.setDate(prevMonday.getDate() - ((prevMonday.getDay() + 6) % 7));

    const firstWeekDates = recurringClinicDays.map((d) => moment(prevMonday).add(d, 'days'));

    const fullYearClinicDates: Date[] = firstWeekDates.map((d) => d.toDate());

    for (let i = 0; i < 52; i++) {
      let lastWeekDates = [...firstWeekDates];
      const dates = lastWeekDates.map((d) => moment(d.add(7, 'days')));

      fullYearClinicDates.push(...dates.map((d) => d.toDate()));

      lastWeekDates = [...dates];
    }

    const clinicRelated = await this.clinicRepo.getClinicRelated({
      ...clinicBody,
      doctorId: clinic.doctor.userId,
    });

    return await this.clinicRepo.updateScheduledClinic(
      {
        ...clinic.schedule,
        ...clinicBody,
        ...clinicRelated,
      },
      allClinicBySchedule,
      clinic,
      clinicRelated,
      fullYearClinicDates,
      clinicBody
    );
  }

  private validateClinicUpdate(oldClinic: ClinicEntity, newClinic: UpdateClinicBody): boolean {
    const isSameDates =
      oldClinic.date === newClinic.date &&
      oldClinic.startTime.slice(0, -3) === newClinic.startTime &&
      oldClinic.endTime.slice(0, -3) === newClinic.endTime;

    if (isSameDates) {
      return true;
    }

    const bookedTimeSlots = oldClinic.timeSlots.filter((timeslot) => timeslot.booked);

    if (!bookedTimeSlots.length) {
      return true;
    }

    const newClinicStartFullDate = this.dateStringTimeStringToMoment(newClinic.date, newClinic.startTime);
    const newClinicEndFullDate = this.dateStringTimeStringToMoment(newClinic.date, newClinic.endTime);

    return this.bookedTimeslotBetweenClinicDate(bookedTimeSlots, newClinicStartFullDate, newClinicEndFullDate);
  }

  private dateStringTimeStringToMoment(date: Date, time: string): Moment {
    return moment(new Date(`${date}T${time}`));
  }

  private bookedTimeslotBetweenClinicDate(
    bookedTimeSlots: TimeSlotEntity[],
    startDate: Moment,
    endDate: Moment
  ): boolean {
    return bookedTimeSlots.some(
      (timeslot) =>
        this.dateStringTimeStringToMoment(timeslot.date, timeslot.startTime).isBetween(startDate, endDate) ||
        this.dateStringTimeStringToMoment(timeslot.date, timeslot.endTime).isBetween(startDate, endDate)
    );
  }

  private clinicsTimeToMoment(
    date: Date,
    startTime: string,
    endTime: string
  ): { startClinic: Moment; endClinic: Moment } {
    const startClinic = this.dateStringTimeStringToMoment(date, startTime);
    const endClinic = this.dateStringTimeStringToMoment(date, endTime);

    return {
      startClinic,
      endClinic,
    };
  }

  private getTimeSlotsToCreate(startDate: Moment, endDate: Moment, oldClinic: ClinicEntity): TimeSlotEntity[] {
    const timeSlots: TimeSlotEntity[] = [];

    let timeSlotStart = moment(startDate);
    const timeSlotEnd = moment(startDate);
    do {
      timeSlotEnd.add(oldClinic.appointmentLength, 'minutes');

      const timeSlot = this.clinicRepo.createTimeSlot({
        date: oldClinic.date,
        startTime: timeSlotStart.format('hh:mm:ss'),
        endTime: timeSlotEnd.format('hh:mm:ss'),
      });

      timeSlotStart = moment(timeSlotEnd);
      timeSlots.push(timeSlot);
    } while (endDate.isAfter(timeSlotStart));

    return timeSlots;
  }
}

import { InjuryRepository } from './../injuries/injury.repository';
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { SharedModule } from '../shared/shared.module';
import { ClinicsController } from './clinics.controller';
import { ClinicRepository } from './clinics.repository';
import { ClinicsService } from './clinics.service';
import { DoctorRepository } from '../doctors/doctor.repository';
import { OrganizationRepository } from '../organizations/organizations.repository';

@Module({
  providers: [ClinicsService],
  controllers: [ClinicsController],
  imports: [
    TypeOrmModule.forFeature([ClinicRepository, InjuryRepository, DoctorRepository, OrganizationRepository]),
    SharedModule,
  ],
})
export class ClinicsModule {}

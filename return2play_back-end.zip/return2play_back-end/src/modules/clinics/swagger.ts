import { IDocumentedEndpoint } from '../shared/interfaces/swagger.interface';

export const CREATE_ONE_CLINIC: IDocumentedEndpoint = {
  OPERATION: {
    description: 'Create a new clinic within the system. Only doctors are allowed to perform this action',
  },
  SUCCESS: {
    description: '`Success` Clinic was created',
  },
  CLINIC_EXISTS: {
    description: '`API` Exact same clinic already exists',
  },
  FORBIDDEN: {
    description: '`API` User has no permissions to create clinic',
  },
  FAILURE: {
    description: '`API` Saved entity to the database failed',
  },
};

export const CREATE_ONE_CLINIC_RECURRING: IDocumentedEndpoint = {
  OPERATION: {
    description: 'Create a new recurring clinic within the system. Only doctors are allowed to perform this action',
  },
  SUCCESS: {
    description: '`Success` Recurring clinic was created',
  },
  CLINIC_EXISTS: {
    description: '`API` Exact same recurring clinic already exists',
  },
  FORBIDDEN: {
    description: '`API` User has no permissions to create recurring clinic',
  },
  FAILURE: {
    description: '`API` Saved entity to the database failed',
  },
};

export const DELETE_ONE_CLINIC: IDocumentedEndpoint = {
  OPERATION: {
    description:
      'Change status of particular clinic to `Inactive`. Only `doctor who created the clinic` is allowed to inactivate it',
  },
  SUCCESS: {
    description: '`Success` Clinic successfully inactivated',
  },
  FAILURE: {
    description: '`API` Error occurs during inactivating an entity',
  },
  NOT_FOUND: {
    description: '`API` Clinic is not found within the system',
  },
  FORBIDDEN: {
    description: '`API` User has no permissions to delete the clinic',
  },
};

export const FIND_MANY_IN_RANGE: IDocumentedEndpoint = {
  OPERATION: {
    description:
      'Get `Clinic` list of in date range of a certain doctor. Only doctors are allowed to perform this action',
  },
  SUCCESS: {
    description: '`Success` Clinic list is returned',
  },
  FORBIDDEN: {
    description: '`API` User has no permissions to get clinic list',
  },
  FAILURE: {
    description: '`API` Error occurs during select an entity',
  },
};

export const FIND_MANY_BY_PLAYER: IDocumentedEndpoint = {
  OPERATION: {
    description:
      'Get `Clinic` and `Time Slots` list that are available for the player. Only player, parents or super admin are allowed to perform this action',
  },
  SUCCESS: {
    description: '`Success` Clinic list is returned',
  },
  FORBIDDEN: {
    description: '`API` User has no permissions to get clinic list',
  },
  FAILURE: {
    description: '`API` Error occurs during select an entity',
  },
};

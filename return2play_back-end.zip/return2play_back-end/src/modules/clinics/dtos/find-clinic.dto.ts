import { OmitType } from '@nestjs/swagger';
import { IsISO8601, IsUUID, IsOptional, ValidateIf, IsString } from 'class-validator';
import { AppointmentType } from '../../appointments/types';

export class FindManyDto {
  @IsISO8601()
  startDate: Date;

  @IsISO8601()
  endDate: Date;

  @IsUUID()
  @IsOptional()
  doctorId?: string;
}

export class FindManySummaryDto extends OmitType(FindManyDto, ['doctorId' as const]) {}

export class FindManyQuery {
  @IsUUID()
  @IsOptional()
  doctorId?: string;

  @IsUUID()
  @ValidateIf((o) => o.appointmentType === AppointmentType.ConcussionFollowUp)
  injuryId?: string;

  @IsString()
  appointmentType: AppointmentType;
}

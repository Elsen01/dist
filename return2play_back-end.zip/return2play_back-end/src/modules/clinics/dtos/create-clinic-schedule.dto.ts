import { IsArray, IsEnum, IsOptional, IsString, IsUUID, Matches, MaxLength } from 'class-validator';
import { AppointmentFormat, AppointmentLength, AppointmentType, Weekday } from '../types';

export class CreateScheduledClinicBody {
  @Matches(/^([0-9]|0[0-9]|1[0-9]|2[0-3]):[0-5][0-9]$/)
  startTime: string;

  @Matches(/^([0-9]|0[0-9]|1[0-9]|2[0-3]):[0-5][0-9]$/)
  endTime: string;

  @IsEnum(AppointmentLength)
  appointmentLength: AppointmentLength;

  @IsEnum(Weekday, { each: true })
  days: Weekday[];

  @IsEnum(AppointmentFormat)
  format: AppointmentFormat;

  @IsArray()
  medicalType: AppointmentType[];

  @IsString()
  @MaxLength(255)
  @IsOptional()
  location: string;

  @IsOptional()
  @IsArray()
  @IsUUID('all', { each: true })
  organizationIds: string[];

  @IsOptional()
  @IsUUID()
  doctorId: string;
}

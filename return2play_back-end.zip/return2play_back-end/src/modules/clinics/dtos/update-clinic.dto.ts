import { IsArray, IsEnum, IsISO8601, IsOptional, IsString, IsUUID, Matches, MaxLength } from 'class-validator';
import { AppointmentFormat, AppointmentType, ClinicType, Weekday } from '../types';

export class UpdateClinicBody {
  @Matches(/^([0-9]|0[0-9]|1[0-9]|2[0-3]):[0-5][0-9]$/)
  startTime: string;

  @Matches(/^([0-9]|0[0-9]|1[0-9]|2[0-3]):[0-5][0-9]$/)
  endTime: string;

  @IsISO8601()
  date: Date;

  @IsEnum(AppointmentFormat)
  format: AppointmentFormat;

  @IsArray()
  medicalType: AppointmentType[];

  @IsEnum(ClinicType)
  type: ClinicType;

  @IsString()
  @MaxLength(255)
  @IsOptional()
  location: string;

  @IsOptional()
  @IsArray()
  @IsUUID('all', { each: true })
  organizationIds: string[];

  @IsOptional()
  @IsUUID()
  doctorId: string;
}

export class UpdateScheduledClinicBody {
  @Matches(/^([0-9]|0[0-9]|1[0-9]|2[0-3]):[0-5][0-9]$/)
  startTime: string;

  @Matches(/^([0-9]|0[0-9]|1[0-9]|2[0-3]):[0-5][0-9]$/)
  endTime: string;

  @IsEnum(Weekday, { each: true })
  days: Weekday[];

  @IsEnum(AppointmentFormat)
  format: AppointmentFormat;

  @IsArray()
  medicalType: AppointmentType[];

  @IsEnum(ClinicType)
  type: ClinicType;

  @IsString()
  @MaxLength(255)
  @IsOptional()
  location: string;

  @IsOptional()
  @IsArray()
  @IsUUID('all', { each: true })
  organizationIds: string[];

  @IsOptional()
  @IsUUID()
  doctorId: string;
}

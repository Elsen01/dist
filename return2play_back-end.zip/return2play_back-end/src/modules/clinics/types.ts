import { UpdateScheduledClinicBody } from './dtos/update-clinic.dto';
import { DoctorEntity } from '../doctors/entities/doctor.entity';
import { CreateScheduledClinicBody } from './dtos/create-clinic-schedule.dto';
import { CreateClinicBody } from './dtos/create-clinic.dto';
import { ClinicEntity } from './entities/clinic.entity';
import { ScheduledClinicEntity } from './entities/scheduledClinic.entity';
import { UserRole, UserStatus } from '../users/types';

export enum AppointmentFormat {
  FaceToFace = 'face-to-face',
  Telemedicine = 'telemedicine',
}

export enum AppointmentType {
  ConcussionAdvice = 'concussion advice',
  ConcussionFollowUp = 'concussion follow up',
  ConcussionFinalClearence = 'concussion final clearance',
  All = 'all appointments',
}

export const AppointmentTypeArray: AppointmentType[] = [
  AppointmentType.ConcussionAdvice,
  AppointmentType.ConcussionFollowUp,
  AppointmentType.ConcussionFinalClearence,
  AppointmentType.All,
];

export enum Weekday {
  Monday = '0',
  Tuesday = '1',
  Wednesday = '2',
  Thursday = '3',
  Friday = '4',
  Saturday = '5',
  Sunday = '6',
}

export enum ClinicStatus {
  Active = 'Active',
  Inactive = 'Inactive',
}

export enum ClinicType {
  OneTime = 'one-time',
  Recurring = 'recurring',
}

export type ClinicParam = CreateClinicBody | CreateScheduledClinicBody | UpdateScheduledClinicBody;

export type ClinicResponse = ClinicEntity | ScheduledClinicEntity;

export interface ClinicStatistic {
  id: string;
  available: number;
  booked: number;
}

export interface SummaryRawStatistics {
  date: Date;
  hour: number;
  available: number;
  booked: number;
  timeslots: number;
  clinics: number;
  doctorIds: string[];
}

export interface SummaryDateStatistics {
  [date: string]: {
    hour: number;
    available: number;
    booked: number;
    timeslots: number;
    clinics: number;
    doctors: DoctorEntity[];
  }[];
}

export interface SummaryStatistics {
  summary: SummaryDateStatistics[];
}

export type ClinicWithStatistic = ClinicEntity & ClinicStatistic;

export interface ClinicCountParams {
  startDate: Date;
  endDate: Date;
  doctorId?: string | string[];
}

export interface ClinicSidePanelResponse {
  userId: string;
  gmc: string;
  bio: string;
  picture: string;
  speciality?: string;
  firstName: string;
  lastName: string;
  email: string;
  gender?: string;
  role: UserRole;
  birthday?: Date;
  status: UserStatus;
  createdAt: Date;
  id: string;
  totClinic: number;
  bookedAppointments: number;
  availableAppointments: number;
}

export enum AppointmentLength {
  Five = 5,
  Ten = 10,
  Fifteen = 15,
  Twenty = 20,
}

export interface FindManyByPlayer {
  doctorId: string;
  clinicStartDate?: Date;
  appointmentType: AppointmentType;
}

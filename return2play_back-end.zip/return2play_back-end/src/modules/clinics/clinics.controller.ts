// import { UpdateClinicBody, UpdateScheduledClinicBody } from './dtos/update-clinic.dto';
import { IdDto } from './../shared/shared.dto';
import {
  Body,
  Controller,
  Delete,
  Get,
  HttpCode,
  HttpStatus,
  Param,
  Post,
  Put,
  Query,
  UseGuards,
} from '@nestjs/common';
import {
  ApiBearerAuth,
  ApiForbiddenResponse,
  ApiNoContentResponse,
  ApiNotFoundResponse,
  ApiOkResponse,
  ApiOperation,
  ApiTags,
  ApiUnprocessableEntityResponse,
} from '@nestjs/swagger';
import { CognitoGuard } from '../shared/guards/cognito.guard';
import { Cron } from '@nestjs/schedule';
import { RolesGuard } from '../shared/guards/roles.guard';
import { Roles } from '../shared/decorators/roles.decorator';
import { CREATE_ONE_CLINIC, CREATE_ONE_CLINIC_RECURRING, DELETE_ONE_CLINIC, FIND_MANY_IN_RANGE } from './swagger';
import { ClinicsService } from './clinics.service';
import { UserRole } from '../users/types';
import { CreateClinicBody } from './dtos/create-clinic.dto';
import { CreateScheduledClinicBody } from './dtos/create-clinic-schedule.dto';
import { CRON_CLINIC_UPDATE_STRING } from '../shared/constants';
import { FindManyDto, FindManyQuery, FindManySummaryDto } from './dtos/find-clinic.dto';
import { ClinicEntity } from './entities/clinic.entity';
import { ClinicSidePanelResponse, SummaryDateStatistics } from './types';
import { UpdateScheduledClinicBody } from './dtos/update-clinic.dto';

@ApiTags('Clinics')
@UseGuards(CognitoGuard, RolesGuard)
@Roles(UserRole.SuperAdmin)
@ApiBearerAuth()
@Controller('clinics')
export class ClinicsController {
  constructor(private service: ClinicsService) {}

  @ApiOperation(CREATE_ONE_CLINIC.OPERATION)
  @ApiOkResponse(CREATE_ONE_CLINIC.SUCCESS)
  @ApiUnprocessableEntityResponse(CREATE_ONE_CLINIC.FAILURE)
  @ApiForbiddenResponse(CREATE_ONE_CLINIC.FORBIDDEN)
  @Roles(UserRole.Doctor)
  @Post('oneTime')
  createClinic(@Body() clinic: CreateClinicBody): Promise<void> {
    return this.service.createClinic(clinic);
  }

  @ApiOperation(CREATE_ONE_CLINIC_RECURRING.OPERATION)
  @ApiOkResponse(CREATE_ONE_CLINIC_RECURRING.SUCCESS)
  @ApiUnprocessableEntityResponse(CREATE_ONE_CLINIC_RECURRING.FAILURE)
  @ApiForbiddenResponse(CREATE_ONE_CLINIC_RECURRING.FORBIDDEN)
  @Roles(UserRole.Doctor)
  @Post('recurring')
  createClinicRecurring(@Body() clinic: CreateScheduledClinicBody): Promise<void> {
    return this.service.createScheduledClinic(clinic);
  }

  @Cron(CRON_CLINIC_UPDATE_STRING)
  scheduleToClinic(): Promise<void> {
    return this.service.clinicToSchedule();
  }

  @ApiOperation(DELETE_ONE_CLINIC.OPERATION)
  @ApiNoContentResponse(DELETE_ONE_CLINIC.SUCCESS)
  @ApiUnprocessableEntityResponse(DELETE_ONE_CLINIC.FAILURE)
  @ApiNotFoundResponse(DELETE_ONE_CLINIC.NOT_FOUND)
  @ApiForbiddenResponse(DELETE_ONE_CLINIC.FORBIDDEN)
  @HttpCode(HttpStatus.NO_CONTENT)
  @Roles(UserRole.Doctor)
  @Delete('/:id')
  deleteClinic(@Param('id') id: string): Promise<void> {
    return this.service.deleteClinic(id);
  }

  @ApiOperation(DELETE_ONE_CLINIC.OPERATION)
  @ApiNoContentResponse(DELETE_ONE_CLINIC.SUCCESS)
  @ApiUnprocessableEntityResponse(DELETE_ONE_CLINIC.FAILURE)
  @ApiNotFoundResponse(DELETE_ONE_CLINIC.NOT_FOUND)
  @ApiForbiddenResponse(DELETE_ONE_CLINIC.FORBIDDEN)
  @HttpCode(HttpStatus.NO_CONTENT)
  @Roles(UserRole.Doctor)
  @Delete('recurring/:id')
  deleteClinicRecurring(@Param('id') id: string): Promise<void> {
    return this.service.deleteClinic(id);
  }

  @ApiOperation(FIND_MANY_IN_RANGE.OPERATION)
  @ApiOkResponse(FIND_MANY_IN_RANGE.SUCCESS)
  @ApiUnprocessableEntityResponse(FIND_MANY_IN_RANGE.FAILURE)
  @ApiForbiddenResponse(FIND_MANY_IN_RANGE.FORBIDDEN)
  @Roles(UserRole.Doctor)
  @Get()
  findMany(@Query() dateRange: FindManyDto): Promise<ClinicEntity[]> {
    return this.service.findManyInRange(dateRange);
  }

  @ApiOperation(FIND_MANY_IN_RANGE.OPERATION)
  @ApiOkResponse(FIND_MANY_IN_RANGE.SUCCESS)
  @ApiUnprocessableEntityResponse(FIND_MANY_IN_RANGE.FAILURE)
  @ApiForbiddenResponse(FIND_MANY_IN_RANGE.FORBIDDEN)
  @Get('/summary')
  findManySummary(@Query() dateRange: FindManySummaryDto): Promise<SummaryDateStatistics[]> {
    return this.service.findManyInRangeSummary(dateRange);
  }

  @Get('/sidePanel')
  findSidePanel(@Query() query: FindManyDto): Promise<ClinicSidePanelResponse[]> {
    return this.service.getSidePanel(query);
  }

  @ApiOperation(FIND_MANY_IN_RANGE.OPERATION)
  @ApiOkResponse(FIND_MANY_IN_RANGE.SUCCESS)
  @ApiUnprocessableEntityResponse(FIND_MANY_IN_RANGE.FAILURE)
  @ApiForbiddenResponse(FIND_MANY_IN_RANGE.FORBIDDEN)
  @Roles(UserRole.Parent, UserRole.Player, UserRole.Doctor, UserRole.OrganizationAdmin, UserRole.MedicalStaff)
  @Get('player/:id')
  async findManyByPlayer(@Param() params: IdDto, @Query() query: FindManyQuery): Promise<ClinicEntity[]> {
    return await this.service.findManyByPlayer(params.id, query);
  }

  @Roles(UserRole.Doctor)
  @Put('/:id/oneTime')
  updateOneTime(@Body() body: any, @Param() params: IdDto): Promise<void> {
    return this.service.updateOne(params.id, body);
  }

  @Roles(UserRole.Doctor)
  @Put('/:id/recurring')
  updateClinicRecurring(@Param() params: IdDto, @Body() clinic: UpdateScheduledClinicBody): Promise<void> {
    return this.service.updateRecurringClinic(params.id, clinic);
  }
}

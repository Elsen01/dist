import { ForbiddenException, HttpStatus, UnprocessableEntityException } from '@nestjs/common';
import moment from 'moment';
import { DeepPartial, DeleteResult, EntityRepository, FindConditions, In, QueryRunner } from 'typeorm';
import { DoctorEntity } from '../doctors/entities/doctor.entity';
import { OrganizationEntity } from '../organizations/entities/organization.entity';
import { BaseRepository } from '../shared/base.repository';
import { ONE_DAY, THIRTY_DAYS } from '../shared/constants';
import { RoleManager } from '../shared/helpers/accessManager/role.manager';
import { getEntityInstance, stringToArray, toStringDbFormat } from '../shared/utils/common.utils';
import { UserRole } from '../users/types';
import { CreateScheduledClinicBody } from './dtos/create-clinic-schedule.dto';
import { CreateClinicBody } from './dtos/create-clinic.dto';
import { UpdateClinicBody, UpdateScheduledClinicBody } from './dtos/update-clinic.dto';
import { ClinicEntity } from './entities/clinic.entity';
import { ScheduledClinicEntity } from './entities/scheduledClinic.entity';
import { TimeSlotEntity } from './entities/timeSlot.entity';
import {
  AppointmentType,
  ClinicCountParams,
  ClinicParam,
  ClinicStatistic,
  ClinicStatus,
  ClinicType,
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  FindManyByPlayer,
  SummaryRawStatistics,
} from './types';
import { PlayStatus } from '../injuries/types';
import { InjuryEntity } from '../injuries/entities/injury.entity';
@EntityRepository(ClinicEntity)
export class ClinicRepository extends BaseRepository<ClinicEntity> {
  private readonly roleManager = RoleManager.getInstance();
  private readonly timeSlotEntity = new TimeSlotEntity();

  @ClinicRepository.prototype.ValidateRole
  async createClinicOneTime(clinic: CreateClinicBody): Promise<void> {
    await this.validateClinic(clinic);
    const clinicRelated = await this.getClinicRelated(clinic);
    let newClinic = this.repository.create({ ...clinic, ...clinicRelated });

    const saveClinicOneTimeTransaction = async (runner: QueryRunner): Promise<void> => {
      const repository = runner.manager.getRepository(ClinicEntity);

      newClinic = await repository.save(newClinic).catch((err) => {
        throw new UnprocessableEntityException(err.message);
      });

      newClinic.date = new Date(newClinic.date);
      const timeslots = this.createClinicTimeslots(newClinic);
      await this.saveClinicTimeslotsTransaction(runner, timeslots);

      return;
    };

    return this.runTransaction(saveClinicOneTimeTransaction);
  }

  private createClinicTimeslots(clinic: ClinicEntity): TimeSlotEntity[] {
    const clinicDate = new Date(clinic.date);
    const startDatetime = new Date(`${clinicDate.toISOString().split('T')[0]} ${clinic.startTime}`);
    const endDatetime = new Date(`${clinicDate.toISOString().split('T')[0]} ${clinic.endTime}`);
    // Getting clinic length in minutes
    const clinicLength = (endDatetime.getTime() - startDatetime.getTime()) / 60000;

    const numOfTimeslots = Math.floor(clinicLength / clinic.appointmentLength);

    const timeslots: TimeSlotEntity[] = [];
    for (let i = 0; i < numOfTimeslots; i++) {
      const startTime = i ? timeslots[i - 1].endTime : clinic.startTime;
      const startDatetimeMs = new Date(`${clinicDate.toISOString().split('T')[0]} ${startTime}`).getTime();
      const endDatetime = new Date(startDatetimeMs + clinic.appointmentLength * 60000);
      const endTime = `${endDatetime.getHours()}:${endDatetime.getMinutes()}`;

      const timeslot = this.getRepositoryFor(TimeSlotEntity).create({ startTime, endTime, date: clinic.date, clinic });

      timeslots.push(timeslot);
    }

    return timeslots;
  }

  private async updateClinicTimeslots(clinic: ClinicEntity, oldTimeslots: any[]): Promise<TimeSlotEntity[]> {
    console.log('OLD TIMESLOTS:', oldTimeslots);

    const clinicDate = new Date(clinic.date);
    console.log('CLinicENDTIME:', clinic.endTime);
    const startDatetime = new Date(`${clinicDate.toISOString().split('T')[0]} ${clinic.startTime}`);
    const endDatetime = new Date(`${clinicDate.toISOString().split('T')[0]} ${clinic.endTime}`);
    // Getting clinic length in minutes
    const clinicLength = (endDatetime.getTime() - startDatetime.getTime()) / 60000;

    const numOfTimeslots = Math.floor(clinicLength / clinic.appointmentLength);

    const timeslots: TimeSlotEntity[] = [];
    for (let i = 0; i < numOfTimeslots; i++) {
      const startTime = i ? `${timeslots[i - 1].endTime}:00` : clinic.startTime;
      const startDatetimeMs = new Date(`${clinicDate.toISOString().split('T')[0]} ${startTime}`).getTime();
      console.log({ startDatetimeMs });

      const endDatetime = new Date(startDatetimeMs + clinic.appointmentLength * 60000);
      console.log({ endDatetime });
      let minutes: any;

      if (endDatetime.getMinutes() === 0) {
        // eslint-disable-next-line @typescript-eslint/no-unused-vars
        minutes = endDatetime.getMinutes().toString().padStart(2, '0');
      } else {
        minutes = endDatetime.getMinutes();
      }

      const endTime = `${endDatetime.getHours()}:${minutes}`;
      console.log({ startTime });
      console.log({ endTime });

      const timeslot = await this.getRepositoryFor(TimeSlotEntity).create({
        startTime,
        endTime,
        date: clinic.date,
        clinic,
      });
      timeslots.push(timeslot);
      if (!oldTimeslots.includes(startTime)) {
        const savedTimeslots = await this.getRepositoryFor(TimeSlotEntity).save({
          startTime,
          endTime,
          date: clinic.date,
          clinic,
        });

        console.log({ savedTimeslots });
      }
      console.log({ timeslots });
    }

    console.log(1111111111111111111111);

    return timeslots;
  }

  async findOldTimeSlots(clinicId: string): Promise<string[]> {
    const timeSlots = await this.manager
      .getRepository(TimeSlotEntity)
      .createQueryBuilder('timeSlot')
      .select(['timeSlot.startTime'])
      .where('timeSlot.clinic_id = :clinicId', { clinicId })
      .getMany();

    const startTimeArray = timeSlots.map((timeSlot) => timeSlot.startTime);

    return startTimeArray;
  }

  saveClinicTimeslotsTransaction(runner: QueryRunner, timeslots: TimeSlotEntity[]): Promise<TimeSlotEntity[]> {
    return runner.manager
      .getRepository(TimeSlotEntity)
      .save(timeslots)
      .catch((err) => {
        throw new UnprocessableEntityException(err.message);
      });
  }

  async deleteAllOldTimeSlots(clinicId: string): Promise<void> {
    // .andWhere('start_time NOT BETWEEN :startTime AND :endTime', {

    await this.manager
      .getRepository(TimeSlotEntity)
      .createQueryBuilder()
      .delete()
      .where('clinic_id = :clinicId', { clinicId })
      .andWhere('booked = false')
      .execute();
    return;
  }

  async deleteAllOldTimeSlotsForStartTime(clinicId: string, startTime: string, endTime: string): Promise<void> {
    // .andWhere('start_time NOT BETWEEN :startTime AND :endTime', {

    const data = await this.manager
      .getRepository(TimeSlotEntity)
      .createQueryBuilder()
      .where('(clinic_id = :clinicId) AND (start_time < :startTime OR end_time > :endTime)', {
        clinicId,
        startTime,
        endTime,
      })
      .getMany();

    console.log({ data });

    await this.manager
      .getRepository(TimeSlotEntity)
      .createQueryBuilder()
      .delete()
      .where('(clinic_id = :clinicId) AND (start_time < :startTime OR end_time > :endTime)', {
        clinicId,
        startTime,
        endTime,
      })

      .execute();
    return;
  }

  public saveClinicTimeslotsTransactionDuringUpdate(clinic: ClinicEntity): Promise<TimeSlotEntity[]> {
    const timeslots = [];

    const ts = this.createClinicTimeslots(clinic);
    timeslots.push(...ts);

    return this.manager
      .getRepository(TimeSlotEntity)
      .save(timeslots)
      .catch((err) => {
        throw new UnprocessableEntityException(err.message);
      });
  }

  public async saveClinicAndUpdateTimeslotsTransactionDuringUpdate(
    clinic: ClinicEntity,
    oldTimeslots: any[]
  ): Promise<void> {
    const timeslots = [];

    const ts = this.updateClinicTimeslots(clinic, oldTimeslots);
    timeslots.push(ts);

    // timeslots.push(...ts);

    // return await this.manager
    //   .getRepository(TimeSlotEntity)
    //   .save(timeslots)
    //   .catch((err) => {
    //     throw new UnprocessableEntityException(err.message);
    //   });
  }

  private deleteClinicTimeslotsTransaction(runner: QueryRunner, clinicIds: string[]): Promise<DeleteResult> {
    return runner.manager.getRepository(TimeSlotEntity).delete({ clinic: { id: In(clinicIds) } });
  }

  async createScheduledClinic(
    clinicRelated: {
      organizations: OrganizationEntity[];
      doctor: DoctorEntity;
      allOrganizations: boolean;
    },
    clinicDates: Date[],
    clinic: CreateScheduledClinicBody
  ): Promise<void> {
    const saveScheduledClinicTransaction = async (runner: QueryRunner): Promise<void> => {
      const clinicRepo = runner.manager.getRepository(ClinicEntity);
      const scheduleRepo = runner.manager.getRepository(ScheduledClinicEntity);

      const schedule = scheduleRepo.create({ ...clinic, ...clinicRelated });
      await scheduleRepo.save(schedule);

      const clinics = await Promise.all(
        clinicDates.map((d) =>
          clinicRepo.save({ ...clinic, ...clinicRelated, date: d, type: ClinicType.Recurring, schedule })
        )
      );

      const timeslots = [];
      clinics.forEach((oneTime) => {
        const ts = this.createClinicTimeslots(oneTime);
        timeslots.push(...ts);
      });

      await this.saveClinicTimeslotsTransaction(runner, timeslots);
      return;
    };

    return this.runTransaction(saveScheduledClinicTransaction);
  }

  async updateScheduledClinic(
    clinicSchedule: ScheduledClinicEntity,
    clinicsToUpdate: ClinicEntity[],
    oldClinic: ClinicEntity,
    clinicRelated: {
      organizations: OrganizationEntity[];
      doctor: DoctorEntity;
      allOrganizations: boolean;
    },
    clinicDates: Date[],
    clinic: UpdateScheduledClinicBody
  ): Promise<void> {
    const saveScheduledClinicTransaction = async (runner: QueryRunner): Promise<void> => {
      const clinicRepo = runner.manager.getRepository(ClinicEntity);
      const scheduleRepo = runner.manager.getRepository(ScheduledClinicEntity);
      const timeslotRepoRepo = runner.manager.getRepository(TimeSlotEntity);

      await timeslotRepoRepo.delete(clinicsToUpdate.flatMap((c) => c.timeSlots.map((t) => t.id)));
      await clinicRepo.delete(clinicsToUpdate.map((c) => c.id));
      await scheduleRepo.save(clinicSchedule);

      const clinics = await Promise.all(
        clinicDates.map((d) =>
          clinicRepo.save({
            ...clinic,
            ...clinicRelated,
            date: d,
            type: clinic.type,
            schedule: clinicSchedule,
            appointmentLength: oldClinic.appointmentLength,
          })
        )
      );

      const timeslots = [];
      clinics.forEach((oneTime) => {
        const ts = this.createClinicTimeslots(oneTime);
        timeslots.push(...ts);
      });

      await this.saveClinicTimeslotsTransaction(runner, timeslots);
      return;
    };

    return this.runTransaction(saveScheduledClinicTransaction);
  }

  async scheduleToClinics(): Promise<void> {
    const scheduledClinics = await this.getRepositoryFor(ScheduledClinicEntity).find({ status: ClinicStatus.Active });

    // Splitting the array into 50-elements chunks for better performance
    for (let i = 0; i < scheduledClinics.length; i += 50) {
      const clinicsChunk = scheduledClinics.slice(i, i + 50);
      await Promise.allSettled(
        clinicsChunk.map(async (recurring) => {
          const clinics = await this.recurringToOneTime(recurring);

          const scheduleToClinicsTransaction = async (runner: QueryRunner): Promise<void> => {
            const repository = runner.manager.getRepository(ClinicEntity);

            await repository.save(clinics).catch((err) => {
              throw new UnprocessableEntityException(err.message);
            });

            const timeslots = [];
            clinics.forEach((oneTime) => {
              const ts = this.createClinicTimeslots(oneTime);
              timeslots.push(...ts);
            });

            await this.saveClinicTimeslotsTransaction(runner, timeslots);
          };

          return this.runTransaction(scheduleToClinicsTransaction);
        })
      );
    }
  }

  private async recurringToOneTime(recurring: ScheduledClinicEntity): Promise<ClinicEntity[]> {
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const { id, days, ...other } = recurring;

    const clinics: ClinicEntity[] = [];

    await Promise.allSettled(
      days.map(async (day) => {
        const date = new Date();
        date.setDate(date.getDate() + ((8 + +day - date.getDay()) % 7));

        await this.validateClinic({ date, ...other, organizationIds: [], doctorId: other.doctor.userId });

        const clinic = this.repository.create({
          date,
          ...other,
          type: ClinicType.Recurring,
          schedule: recurring,
          allOrganizations: recurring.allOrganizations,
          organizations: recurring.organizations,
        });

        clinics.push(clinic);
      })
    );

    return clinics;
  }

  async findOne(condition: FindConditions<ClinicEntity>): Promise<ClinicEntity> {
    return await this.repository
      .findOne({
        where: condition,
        join: {
          alias: 'clinic',
          leftJoinAndSelect: {
            doctor: 'clinic.doctor',
            organizations: 'clinic.organizations',
            timeSlots: 'clinic.timeSlots',
            schedule: 'clinic.schedule',
          },
        },
      })
      .catch((err) => {
        throw new UnprocessableEntityException(err.message);
      });
  }

  async findOneById(id: any): Promise<ClinicEntity> {
    return await this.repository.findOne({ id: id }).catch((err) => {
      throw new UnprocessableEntityException(err.message);
    });
  }

  async updateRecurringClinic(
    id: string,
    updateBody: UpdateScheduledClinicBody,
    clinic: ClinicEntity
  ): Promise<ScheduledClinicEntity> {
    const saveScheduledClinicTransaction = async (runner: QueryRunner): Promise<void> => {
      const scheduleRepo = runner.manager.getRepository(ScheduledClinicEntity);
      const clinicRepo = runner.manager.getRepository(ClinicEntity);
      let organizations = stringToArray(updateBody.organizationIds)?.map((id) =>
        getEntityInstance(id, OrganizationEntity)
      );
      const allOrganizations =
        organizations?.length && organizations.length !== clinic.organizations.length ? false : true;
      allOrganizations
        ? (organizations = await this.getRepositoryFor(OrganizationEntity).find({ select: ['id'] }))
        : null;

      await scheduleRepo.save({ ...clinic, id, organizations, allOrganizations, ...updateBody }).catch((err) => {
        throw new UnprocessableEntityException(err.message);
      });

      await clinicRepo.save({ ...clinic, ...updateBody, allOrganizations, organizations, id });

      return;
    };

    return this.runTransaction(saveScheduledClinicTransaction);
  }

  private ValidateRole(
    target: any,
    propertyName: string,
    descriptor: TypedPropertyDescriptor<(clinic: ClinicParam) => Promise<void>>
  ): void {
    const originalMethod = descriptor.value;

    descriptor.value = function (clinic: ClinicParam): Promise<void> {
      if (this.roleManager.role === UserRole.Doctor) {
        clinic.doctorId = this.roleManager.userId;
      } else if (this.roleManager.role === UserRole.SuperAdmin && !clinic.doctorId) {
        // eslint-disable-next-line quotes
        throw new UnprocessableEntityException(`Doctor ID hasn't been provided`);
      }

      const result = originalMethod.call(this, clinic);
      return result;
    };

    Object.defineProperty(target, propertyName, descriptor);
  }

  private async validateClinic(clinic: CreateClinicBody): Promise<void> {
    const dateNow = moment(new Date());

    const isAfter = moment(clinic.date).startOf('day').isSameOrAfter(dateNow.startOf('day'));
    if (!isAfter) {
      throw new UnprocessableEntityException('Date must not be from past.');
    }

    const startDateTime = new Date(`${clinic.date}T${clinic.startTime}`);
    const endDateTime = new Date(`${clinic.date}T${clinic.endTime}`);

    if (startDateTime >= endDateTime) {
      throw new UnprocessableEntityException('End time greater or equal than start time.');
    }

    // Appointment length (min) to (ms)
    if (endDateTime.getTime() - startDateTime.getTime() < clinic.appointmentLength * 60000) {
      throw new UnprocessableEntityException('Appointment length greater than clinic time.');
    }

    const isTimeBooked = await this.repository
      .createQueryBuilder('clinic')
      .where('clinic.doctor_id =:doctorId', { doctorId: clinic.doctorId })
      .andWhere('clinic.status <> :inactive', { inactive: ClinicStatus.Inactive })
      .andWhere('clinic.date =:date', { date: clinic.date })
      .andWhere(
        `(clinic.start_time, clinic.end_time)
        OVERLAPS
        ('${clinic.startTime}'::time, '${clinic.endTime}'::time)`
      )
      .getOne();

    if (isTimeBooked) {
      const errorObject = {
        statusCode: HttpStatus.UNPROCESSABLE_ENTITY,
        field: 'startTime',
        message: 'Given time overlaps already present time',
      };
      throw new UnprocessableEntityException(errorObject);
    }
  }

  private async validateClinicSchedule(clinic: CreateScheduledClinicBody): Promise<void> {
    const [startHours, startMins] = clinic.startTime.split(':');
    const [endHours, endMins] = clinic.endTime.split(':');

    const startDateTime = new Date().setHours(+startHours, +startMins);
    const endDateTime = new Date().setHours(+endHours, +endMins);

    if (startDateTime >= endDateTime) {
      throw new UnprocessableEntityException('End time greater or equal than start time.');
    }

    // Appointment length (min) to (ms)
    if (endDateTime - startDateTime < clinic.appointmentLength * 60000) {
      throw new UnprocessableEntityException('Appointment length greater than clinic time.');
    }

    const isTimeBooked = await this.getRepositoryFor(ScheduledClinicEntity)
      .createQueryBuilder('schedule')
      .where('schedule.doctor_id =:doctorId', { doctorId: clinic.doctorId })
      .andWhere('schedule.status <> :inactive', { inactive: ClinicStatus.Inactive })
      // eslint-disable-next-line quotes
      .andWhere(`string_to_array(schedule.days, ',') &&:days`, { days: clinic.days })
      .andWhere(
        `(schedule.start_time, schedule.end_time)
        OVERLAPS
        ('${clinic.startTime}'::time, '${clinic.endTime}'::time)`
      )
      .getOne();

    if (isTimeBooked) {
      const errorObject = {
        statusCode: HttpStatus.UNPROCESSABLE_ENTITY,
        field: 'startTime',
        message: 'Given time overlaps already present time',
      };
      throw new UnprocessableEntityException(errorObject);
    }
  }

  async getClinicRelated(
    clinic: ClinicParam
  ): Promise<{ organizations: OrganizationEntity[]; doctor: DoctorEntity; allOrganizations: boolean }> {
    let organizations = [];
    let allOrganizations = false;

    if (!clinic.organizationIds?.length) {
      allOrganizations = true;
    } else {
      organizations = clinic.organizationIds.map((id) => getEntityInstance(id, OrganizationEntity));
    }

    const doctor = await this.getRepositoryFor(DoctorEntity).findOne(clinic.doctorId);

    return { organizations, doctor, allOrganizations };
  }

  async deleteOne(clinic: ClinicEntity): Promise<void> {
    const { id, type } = clinic;
    const doctorId = this.roleManager.userId;

    if (this.roleManager.role === UserRole.Doctor) {
      await this.createQueryBuilder('clinic')
        .where('clinic.id =:id', { id })
        .andWhere('clinic.doctor_id =:doctorId', { doctorId })
        .getOneOrFail()
        .catch(() => {
          throw new ForbiddenException('This user has no permissions to delete a clinic');
        });
    }

    const deleteClinicTransaction = async (runner: QueryRunner): Promise<void> => {
      const clinicRepo = runner.manager.getRepository(ClinicEntity);
      await this.deleteClinicTimeslotsTransaction(runner, [id]);
      await clinicRepo.delete(id).catch((err) => {
        throw new UnprocessableEntityException(err.message);
      });

      if (type === ClinicType.Recurring) {
        const relatedClinics = await clinicRepo.find({ schedule: clinic.schedule });
        const relatedClinicIds = relatedClinics
          .filter((relatedClinic) => moment(relatedClinic.date).isSameOrAfter(moment().startOf('day')))
          .map(({ id }) => id);
        if (relatedClinicIds.length) {
          await this.deleteClinicTimeslotsTransaction(runner, relatedClinicIds);
          await this.repository.update(relatedClinicIds, { status: ClinicStatus.Inactive });
        }
        return;
      }
      return;
    };

    return this.runTransaction(deleteClinicTransaction);
  }

  async deleteOneRecurring(id: string): Promise<void> {
    const clinic = await this.repository
      .createQueryBuilder('clinic')
      .leftJoinAndSelect('clinic.doctor', 'doctor')
      .leftJoinAndSelect('clinic.schedule', 'schedule')
      .leftJoinAndSelect('clinic.timeSlots', 'timeslot')
      .where('clinic.id =:id', { id })
      .getOneOrFail()
      .catch((err) => {
        throw new UnprocessableEntityException(err.message);
      });

    const { schedule } = clinic;

    if (this.roleManager.role === UserRole.Doctor && schedule.doctor.userId !== this.roleManager.userId) {
      throw new ForbiddenException('This user has no permissions to delete a clinic');
    }

    const isBookedTimeSlot = clinic.timeSlots.some((ts) => ts.booked);
    if (isBookedTimeSlot) {
      throw new UnprocessableEntityException('Can not delete clinic. Booked appointment within the clinic.');
    }

    const deleteRecurringClinicTransaction = async (runner: QueryRunner): Promise<void> => {
      const scheduleRepo = runner.manager.getRepository(ScheduledClinicEntity);
      const clinicRepo = runner.manager.getRepository(ClinicEntity);

      const relatedClinics = await clinicRepo.find({ schedule });
      const relatedClinicIds = relatedClinics.map(({ id }) => id);

      if (relatedClinicIds.length) {
        await this.deleteClinicTimeslotsTransaction(runner, relatedClinicIds);
        await this.repository.update(relatedClinicIds, { status: ClinicStatus.Inactive });
      }

      await scheduleRepo.update(schedule.id, { status: ClinicStatus.Inactive }).catch((err) => {
        throw new UnprocessableEntityException(err.message);
      });

      return;
    };

    return this.runTransaction(deleteRecurringClinicTransaction);
  }

  async findClinic(condition: FindConditions<ClinicEntity>): Promise<ClinicEntity> {
    return this.repository
      .findOne({ where: condition, join: { alias: 'clinic', leftJoinAndSelect: { schedule: 'clinic.schedule' } } })
      .catch((err) => {
        throw new UnprocessableEntityException(err.message);
      });
  }

  async findClinicRecurring(condition: FindConditions<ScheduledClinicEntity>): Promise<ScheduledClinicEntity> {
    return this.getRepositoryFor(ScheduledClinicEntity)
      .findOne({ where: condition })
      .catch((err) => {
        throw new UnprocessableEntityException(err.message);
      });
  }

  // async findManyByPlayer(
  //   id: string,
  //   { doctorId, clinicStartDate, appointmentType }: FindManyByPlayer
  // ): Promise<ClinicEntity[]> {

  //   const timeSlotsSubQuery = await this.manager
  //     .getRepository(TimeSlotEntity)
  //     .createQueryBuilder('timeslot')
  //     .innerJoin('timeslot.clinic', 'clinic')
  //     .leftJoin('clinic.organizations', 'org', 'clinic.all_organizations = true')
  //     .leftJoin('clinic.doctor', 'doctor')
  //     .leftJoin('org.users', 'player')
  //     .where('timeslot.booked = false')
  //     .andWhere(id ? 'player.id = :id' : 'clinic.all_organizations = true', { id })
  //     .andWhere(
  //       clinicStartDate
  //         ? '(timeslot.date + timeslot.startTime) >= :clinicStartDate'
  //         : `timeslot.date >= now() - INTERVAL '${ONE_DAY}'`,
  //       { clinicStartDate }
  //     )
  //     .andWhere(`timeslot.date < now() + INTERVAL '${THIRTY_DAYS}'`)
  //     .andWhere(doctorId ? 'doctor.user_id = :doctorId' : 'true', { doctorId })
  //     .andWhere('clinic.status = :clinicStatus', { clinicStatus: ClinicStatus.Active })
  //     // .andWhere(`clinic.medicalType IN (:...medicalType)`, {
  //     //   medicalType: [appointmentType, AppointmentType.All],
  //     // })
  //     // .distinctOn(['timeslot.clinic_id'])
  //     // .orderBy('timeslot.clinic_id')
  //     .where(':appointmentType = ANY(clinic.medicalType)', { appointmentType })
  //     .orWhere(`'${AppointmentType.All}' = ANY(clinic.medicalType)`)

  //     .orderBy('timeslot.startTime', 'ASC')
  //     // .take(100)
  //     .getMany()
  //     .catch((err) => {
  //       throw new UnprocessableEntityException(err.message);
  //     });

  //   const timeslotIds = timeSlotsSubQuery.map((slot) => slot.id);

  //   return await this.createQueryBuilder('clinic')
  //     .leftJoinAndSelect('clinic.timeSlots', 'timeslot2')
  //     .leftJoinAndSelect('clinic.doctor', 'doctor')
  //     .leftJoinAndSelect('doctor.user', 'user')
  //     .where(timeslotIds.length ? `timeslot2.id IN (:...timeslotIds)` : 'true', { timeslotIds })
  //     .andWhere(doctorId ? 'doctor.user_id = :doctorId' : 'true', { doctorId })
  // .andWhere(`clinic.medicalType IN (:...medicalType)`, {
  //   medicalType: [appointmentType, AppointmentType.All],
  // })
  //     .andWhere(
  //       clinicStartDate
  //         ? '(timeslot2.date + timeslot2.startTime) >= :clinicStartDate'
  //         : `timeslot2.date >= now() - INTERVAL '${ONE_DAY}'`,
  //       { clinicStartDate }
  //     )
  //     .andWhere(`timeslot2.date < now() + INTERVAL '${THIRTY_DAYS}'`)
  //     .orderBy('clinic.date', 'ASC')
  //     .addOrderBy('clinic.startTime', 'ASC')
  //     .addOrderBy('timeslot2.startTime', 'ASC')
  //     // .take(100)
  //     .getMany()
  //     .catch((err) => {
  //       throw new UnprocessableEntityException(err.message);
  //     });
  // }

  async findManyByPlayer(
    id: string,
    { clinicStartDate, doctorId, appointmentType }: any,
    injury: InjuryEntity
  ): Promise<ClinicEntity[]> {
    const timeSlotsSubQuery = await this.manager
      .getRepository(TimeSlotEntity)
      .createQueryBuilder('timeslot')
      .innerJoin('timeslot.clinic', 'clinic')
      .leftJoin('clinic.organizations', 'org', 'clinic.all_organizations = true')
      .leftJoin('clinic.doctor', 'doctor')
      .leftJoin('org.users', 'player')
      .where('timeslot.booked = false')
      .andWhere(id ? 'player.id = :id' : 'clinic.all_organizations = true', { id })
      .andWhere(
        clinicStartDate
          ? '(timeslot.date + timeslot.startTime) >= :clinicStartDate'
          : `timeslot.date >= now() - INTERVAL '${ONE_DAY}'`,
        { clinicStartDate }
      )
      .andWhere(`timeslot.date < now() + INTERVAL '${THIRTY_DAYS}'`)
      .andWhere(doctorId ? 'doctor.user_id = :doctorId' : 'true', { doctorId })
      .orderBy('timeslot.startTime', 'ASC')
      // .take(100)
      .getMany()
      .catch((err) => {
        throw new UnprocessableEntityException(err.message);
      });

    const timeslotIds = timeSlotsSubQuery.map((slot) => slot.id);

    const result = await this.createQueryBuilder('clinic')
      .leftJoinAndSelect('clinic.timeSlots', 'timeslot2')
      .leftJoinAndSelect('clinic.doctor', 'doctor')
      .leftJoinAndSelect('doctor.user', 'user')
      .where(timeslotIds.length ? `timeslot2.id IN (:...timeslotIds)` : 'true', { timeslotIds })
      .andWhere(doctorId ? 'doctor.user_id = :doctorId' : 'true', { doctorId })
      .andWhere(
        clinicStartDate
          ? '(timeslot2.date + timeslot2.startTime) >= :clinicStartDate'
          : `timeslot2.date >= now() - INTERVAL '${ONE_DAY}'`,
        { clinicStartDate }
      )
      .andWhere(`timeslot2.date < now() + INTERVAL '${THIRTY_DAYS}'`)
      .orderBy('clinic.date', 'ASC')
      .addOrderBy('clinic.startTime', 'ASC')
      .addOrderBy('timeslot2.startTime', 'ASC')
      // .take(100)
      .getMany()
      .catch((err) => {
        throw new UnprocessableEntityException(err.message);
      });

    return result.filter((item: any) => {
      console.log({ item });

      const medicalTypes = item.medicalType || [] || null;
      if (appointmentType === AppointmentType.ConcussionAdvice) {
        if (injury.playStatus === PlayStatus.ReduceActivity) {
          return (
            medicalTypes.includes(appointmentType) ||
            medicalTypes.includes(AppointmentType.All) ||
            medicalTypes.includes(AppointmentType.ConcussionFollowUp) ||
            medicalTypes.includes(AppointmentType.ConcussionFinalClearence)
          );
        } else {
          return (
            medicalTypes.includes(appointmentType) ||
            medicalTypes.includes(AppointmentType.All) ||
            medicalTypes.includes(AppointmentType.ConcussionFollowUp)
          );
        }
      } else {
        return medicalTypes.includes(appointmentType) || medicalTypes.includes(AppointmentType.All);
      }
    });
  }

  findManyInRange(startDate: string, endDate: string, doctorId: string): Promise<ClinicEntity[]> {
    return this.createQueryBuilder('clinic')
      .addSelect(['orgs.id', 'orgs.name'])
      .leftJoinAndSelect('clinic.schedule', 'schedule')
      .leftJoin('clinic.organizations', 'orgs')
      .leftJoinAndSelect('clinic.timeSlots', 'timeslots')
      .where('clinic.doctor_id = :doctorId', { doctorId })
      .andWhere(`clinic.date BETWEEN '${startDate}'::date AND '${endDate}'::date`)
      .andWhere('clinic.status <> :inactive', { inactive: ClinicStatus.Inactive })
      .getMany()
      .catch((err) => {
        throw new UnprocessableEntityException(err.message);
      });
  }

  async getClinicsStatistic(startDate: string, endDate: string, doctorId: string): Promise<ClinicStatistic[]> {
    const statistic = (await this.repository.query(`  
    SELECT c.id as id,
           count(CASE WHEN t.booked = TRUE THEN 1 ELSE null END)::INT AS booked,
           count(CASE WHEN t.booked = true THEN null ELSE 1 END) ::INT AS available
    FROM clinics c
      LEFT JOIN timeslots t ON t.clinic_id = c.id
    WHERE c.date BETWEEN '${startDate}'::DATE AND '${endDate}'::DATE
      AND c.doctor_id = '${doctorId}' 
      AND c.status <> '${ClinicStatus.Inactive}'
    GROUP BY c.id;`)) as ClinicStatistic[];

    return statistic;
  }

  async getClinicsStatisticsSummary(startDate: string, endDate: string): Promise<SummaryRawStatistics[]> {
    const statistic = (await this.repository.query(`
    SELECT extract(HOUR FROM s)                                       AS hour,
           t.date                                                     AS date,
           count(CASE WHEN t.booked = true THEN 1 END)::INT           AS booked,
           count(CASE WHEN t.booked = false THEN 1 END)::INT          AS available,
           count(DISTINCT t)::INT                                     AS timeslots,
           count(DISTINCT c)::INT                                     AS clinics,
           json_agg(DISTINCT (d.user_id))                             AS "doctorIds"
    FROM generate_series(
        current_timestamp::DATE - INTERVAL '24' HOUR,
        current_timestamp::DATE - INTERVAL '2' HOUR,
        INTERVAL '1' HOUR
    ) s
        INNER JOIN timeslots t ON (t.start_time, t.end_time) OVERLAPS (s::time, s::time + INTERVAL '1' HOUR)
        LEFT JOIN clinics c ON c.id = t.clinic_id
        LEFT JOIN doctors d ON c.doctor_id = d.user_id
    WHERE t.date BETWEEN '${startDate}'::DATE AND '${endDate}'::DATE
        AND t.status <> '${ClinicStatus.Inactive}'
    GROUP BY t.date, extract(HOUR FROM s)
    ORDER BY t.date, extract(HOUR FROM s);`)) as SummaryRawStatistics[];

    return statistic;
  }

  getClinicCountGroupByDoctors({ startDate, endDate, doctorId }: ClinicCountParams): Promise<unknown[]> {
    const doctorIdArray = stringToArray(doctorId);
    const doctorIdsString = doctorIdArray?.map(toStringDbFormat);

    const doctorIdCondition = doctorIdsString?.length ? `d.user_id IN (${doctorIdsString}) AND` : '';

    return this.manager.query(`
      SELECT d.*, u.*, count(DISTINCT c.id)::int AS "totClinic", count(CASE WHEN t.booked = TRUE THEN 1 ELSE NULL end)::int AS "bookedAppointments", count(CASE WHEN t.booked = FALSE THEN 1 ELSE NULL end)::int AS "availableAppointments"
      FROM clinics c 
      LEFT JOIN timeslots t ON t.clinic_id = c.id 
      LEFT JOIN doctors d ON d.user_id = c.doctor_id
      LEFT JOIN users u ON u.id = d.user_id 
      WHERE ${doctorIdCondition} t.date BETWEEN '${startDate}'::DATE AND '${endDate}'::DATE AND t.status <> '${ClinicStatus.Inactive}'
      GROUP BY d.user_id, u.id;
    `);
  }

  async findTimeSlotsToDeleteInEnd(clinicId: string, endDate: Date): Promise<TimeSlotEntity[]> {
    return this.manager
      .getRepository(TimeSlotEntity)
      .createQueryBuilder('timeSlot')
      .select('timeSlot.id')
      .where('timeSlot.clinic_id = :clinicId', { clinicId })
      .andWhere('(timeSlot.date + timeSlot.end_time) >= :endDate', { endDate })
      .getMany();
  }

  async findTimeSlotsToDeleteInStart(clinicId: string, startTime: Date): Promise<TimeSlotEntity[]> {
    return this.manager
      .getRepository(TimeSlotEntity)
      .createQueryBuilder('timeSlot')
      .select('timeSlot.id')
      .where('timeSlot.clinic_id = :clinicId', { clinicId })
      .andWhere('(timeSlot.date + timeSlot.start_time) <= :startTime', { startTime })
      .getMany();
  }

  createTimeSlot(entityLikeArray: DeepPartial<TimeSlotEntity>): TimeSlotEntity {
    return this.manager.getRepository(TimeSlotEntity).create(entityLikeArray);
  }

  async deleteTimeSlots(runner: QueryRunner, timeSlots: TimeSlotEntity[]): Promise<void> {
    await runner.manager.getRepository(TimeSlotEntity).remove(timeSlots);

    return;
  }

  async updateClinic(
    runner: QueryRunner,
    clinic: UpdateClinicBody & { id: string; organizations: OrganizationEntity[]; allOrganizations: boolean }
  ): Promise<void> {
    await runner.manager.getRepository(ClinicEntity).save(clinic);

    return;
  }

  findClinicsBySchedule(scheduleId: string): Promise<ClinicEntity[]> {
    const nowISO = new Date().toISOString().split('T')[0];
    return this.repository
      .createQueryBuilder('clinic')
      .leftJoin('clinic.schedule', 'schedule')
      .leftJoinAndSelect('clinic.timeSlots', 'timeslot')
      .where('schedule.id = :scheduleId', { scheduleId })
      .andWhere('clinic.date > :now', { now: nowISO })
      .getMany();
  }
}

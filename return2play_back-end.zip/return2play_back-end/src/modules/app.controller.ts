import { Controller, Get } from '@nestjs/common';
import { ApiExcludeEndpoint } from '@nestjs/swagger';

@Controller()
export class AppController {
  @ApiExcludeEndpoint()
  @Get()
  async checkLiveness(): Promise<string> {
    return await new Promise((resolve) => resolve('Return2Play is working!'));
  }
}

import { IDocumentedEndpoint } from '../shared/interfaces/swagger.interface';

export const BOOK_APPOINTMENT: IDocumentedEndpoint = {
  OPERATION: {
    description:
      '`Parent` or `Player` can book an appointment for concussion injury after 10 days of injury in open clinic within the system.',
  },
  SUCCESS: {
    description: '`Success` Appointment was created',
  },
  FORBIDDEN: {
    description: '`API` User has no permissions to create appointment',
  },
  FAILURE: {
    description: '`API` Saved entity to the database failed',
  },
  NOT_FOUND: {
    description: '`API` `Injury`, `Player` or `Clinic` not found within the system ',
  },
  CONFLICT: {
    description:
      '`API` `Clinic` already booked or player has no access to organization for this clinic or clinic date 10 days before injury',
  },
};

export const FIND_ONE: IDocumentedEndpoint = {
  OPERATION: {
    description:
      '`Parent` or `Player` can book an appointment for concussion injury after 10 days of injury in open clinic within the system.',
  },
  SUCCESS: {
    description: '`Success` Appointment was returned',
  },
  FORBIDDEN: {
    description: '`API` User has no permissions to get appointment',
  },
  FAILURE: {
    description: '`API` Select entity from the database failed',
  },
  NOT_FOUND: {
    description: '`API` `Appointment`, not found within the system ',
  },
};

export const GET_MANY_BY_PLAYER: IDocumentedEndpoint = {
  OPERATION: {
    description: '`Doctor`, `Super admin` can see all appointments for particular player within the system.',
  },
  SUCCESS: {
    description: '`Success` Player appointments are returned',
  },
  FORBIDDEN: {
    description: '`API` User has no permissions to get appointments',
  },
  FAILURE: {
    description: '`API` Select entity from the database failed',
  },
};

export const GET_MANY_BY_INJURY: IDocumentedEndpoint = {
  OPERATION: {
    description:
      '`Doctor`, `Super admin`, `Organisation admin` can see all appointments for particular injury within the system.',
  },
  SUCCESS: {
    description: '`Success` Injury appointments are returned',
  },
  FORBIDDEN: {
    description: '`API` User has no permissions to get appointments',
  },
  FAILURE: {
    description: '`API` Select entity from the database failed',
  },
};

export const GET_APPOINTMENTS_LIST: IDocumentedEndpoint = {
  OPERATION: {
    description: '`Doctors` can view the list of all upcoming/past appointments',
  },
  SUCCESS: {
    description: '`Success` Appointments list was returned',
  },
  FORBIDDEN: {
    description: '`API` User has no permissions to get appointments list',
  },
  FAILURE: {
    description: '`API` Error occurs select an entity',
  },
};

export const DELETE_ONE: IDocumentedEndpoint = {
  OPERATION: {
    description: '`Player`, `Parent` or `Super Admin` can cancel an appointment',
  },
  SUCCESS: {
    description: '`Success` Appointment was deleted',
  },
  FORBIDDEN: {
    description: '`API` User has no permissions to cancel appointment',
  },
  FAILURE: {
    description: '`API` Error occurs delete an entity',
  },
};

export const UPDATE_ONE: IDocumentedEndpoint = {
  OPERATION: {
    description: '`Doctor` or `Super Admin` can update status of an appointment',
  },
  SUCCESS: {
    description: '`Success` Appointment was updated',
  },
  FORBIDDEN: {
    description: '`API` User has no permissions to update appointment',
  },
  FAILURE: {
    description: '`API` Error occurs update an entity',
  },
};

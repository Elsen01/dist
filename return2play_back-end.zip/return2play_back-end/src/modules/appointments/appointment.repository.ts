import { RoleManager } from './../shared/helpers/accessManager/role.manager';
import { PlayerEntity } from './../players/entities/player.entity';
import { NotFoundException, UnprocessableEntityException } from '@nestjs/common';
import { EntityRepository, FindConditions, QueryRunner } from 'typeorm';
import { AppointmentStatus, CreateAppointment } from './types';
import { FindManyResponse } from '../shared/types';
import { PaginationDto } from '../shared/shared.dto';
import { BaseRepository } from '../shared/base.repository';
import { UserRole } from '../users/types';
import { UpdateAppointmentBody } from './dtos/update-appointment.dto';
import { FindAppointmentDto } from './dtos/find-appointment.dto';
import { TimeSlotEntity } from '../clinics/entities/timeSlot.entity';
import { AppointmentEntity } from './entities/appointment.entity';
import { UserEntity } from '../users/entities/user.entity';

@EntityRepository(AppointmentEntity)
export class AppointmentRepository extends BaseRepository<AppointmentEntity> {
  private readonly roleManager = RoleManager.getInstance();

  async createOne(appointment: CreateAppointment): Promise<AppointmentEntity> {
    const bookAppointmentTransition = async (runner: QueryRunner): Promise<AppointmentEntity> => {
      const newAppointment = await runner.manager.save(AppointmentEntity, {
        ...appointment,
        doctor: appointment.clinic.doctor,
      });

      await runner.manager.update(TimeSlotEntity, { id: appointment.timeSlot.id }, { booked: true });

      return newAppointment;
    };

    return await this.runTransaction(bookAppointmentTransition);
  }

  async findByPlayerId(id: string, query: PaginationDto): Promise<[AppointmentEntity[], number]> {
    const { limit, page } = query;

    return await this.manager
      .getRepository(AppointmentEntity)
      .createQueryBuilder('appointment')
      .leftJoinAndSelect('appointment.player', 'player')
      .leftJoinAndSelect('player.user', 'user')
      .leftJoinAndSelect('appointment.assessment', 'assessment')
      .leftJoinAndSelect('appointment.doctor', 'doctor')
      .leftJoinAndSelect('doctor.user', 'docUser')
      .leftJoinAndSelect('appointment.timeSlot', 'timeSlot')
      .leftJoinAndSelect('timeSlot.clinic', 'clinic')
      .leftJoinAndSelect('clinic.doctor', 'clinicDoctor')
      .leftJoinAndSelect('clinicDoctor.user', 'clinicUserDoctor')
      .where('player.userId = :id', { id })
      .orderBy('timeSlot.date', 'DESC')
      .addOrderBy('timeSlot.startTime', 'DESC')
      .take(limit)
      .skip(limit * page)
      .getManyAndCount()
      .catch((err) => {
        throw new UnprocessableEntityException(err.message);
      });
  }

  async findByInjuryId(id: string, query: PaginationDto): Promise<[AppointmentEntity[], number]> {
    const { limit, page } = query;

    return await this.manager
      .getRepository(AppointmentEntity)
      .createQueryBuilder('appointment')
      .leftJoinAndSelect('appointment.player', 'player')
      .leftJoinAndSelect('player.user', 'user')
      .leftJoinAndSelect('appointment.assessment', 'assessment')
      .leftJoinAndSelect('appointment.timeSlot', 'timeSlot')
      .leftJoinAndSelect('timeSlot.clinic', 'clinic')
      .leftJoinAndSelect('clinic.doctor', 'clinicDoctor')
      .leftJoinAndSelect('clinicDoctor.user', 'userClinicDoctor')
      .leftJoinAndSelect('appointment.injury', 'injury')
      .where('injury.id = :id', { id })
      .andWhere('appointment.status = :status', { status: AppointmentStatus.New })
      .orderBy('timeSlot.date', 'DESC')
      .addOrderBy('timeSlot.startTime', 'DESC')
      .take(limit)
      .skip(limit * page)
      .getManyAndCount()
      .catch((err) => {
        throw new UnprocessableEntityException(err.message);
      });
  }

  async findById(id: string, condition?: FindConditions<AppointmentEntity>): Promise<AppointmentEntity> {
    return await this.repository
      .findOne(id, {
        where: condition,
        join: {
          alias: 'appointment',
          leftJoinAndSelect: {
            injury: 'appointment.injury',
            doctor: 'appointment.doctor',
            userDoctor: 'doctor.user',
            player: 'appointment.player',
            user: 'player.user',
            timeSlot: 'appointment.timeSlot',
            assessment: 'appointment.assessment',
          },
        },
      })
      .catch((err) => {
        throw new UnprocessableEntityException(err.message);
      });
  }

  async findAllOrg({
    searchWord,
    page,
    limit,
    dateFrom,
    dateTo,
    startDate,
    endDate,
    order,
    sort,
    doctorId,
    appointmentStatus,
    orgId,
    decidedOutcome,
  }: FindAppointmentDto): Promise<FindManyResponse<AppointmentEntity>> {
    const [firstName, lastName] = searchWord ? searchWord?.split(' ', 2) : '';

    const orgAdmin = await this.manager
      .getRepository(UserEntity)
      .createQueryBuilder('user')
      .innerJoinAndSelect('user.organizations', 'orgs')
      .where('user.id = :id', { id: this.roleManager.userId })
      .getOne();

    if (!orgAdmin) throw new NotFoundException('No users in organizations!');

    const orgIds = orgAdmin.organizations.map((org) => org.id);

    const players = await this.manager
      .getRepository(UserEntity)
      .createQueryBuilder('user')
      .leftJoinAndSelect('user.organizations', 'org')
      .where('org.id IN (:...orgIds)', { orgIds })
      .andWhere('user.role = :role', { role: UserRole.Player })
      .getMany();

    if (!players.length) throw new NotFoundException('No players in organizations!');

    const playerIds = players.map((player) => player.id);

    const [appointments, totalItems] = await this.repository
      .createQueryBuilder('appointment')
      .leftJoinAndSelect('appointment.player', 'player')
      .leftJoinAndSelect('appointment.timeSlot', 'timeSlot')
      .leftJoinAndSelect('player.user', 'user')
      .leftJoinAndSelect('user.organizations', 'org')
      .leftJoinAndSelect('appointment.doctor', 'doctor')
      .leftJoinAndSelect('doctor.user', 'userDoctor')
      .leftJoinAndSelect('appointment.injury', 'injury')
      .leftJoinAndSelect('appointment.assessment', 'assessment')
      .where('user.id IN (:...playerIds)', { playerIds })
      .andWhere(orgId ? 'org.id = :orgId' : 'true', { orgId })
      .andWhere(startDate ? '(timeSlot.date + timeSlot.start_time) >= :startDate' : 'true', { startDate })
      .andWhere(endDate ? '(timeSlot.date + timeSlot.end_time) <= :endDate' : 'true', { endDate })
      .andWhere(dateFrom ? '(timeSlot.date + timeSlot.start_time) >= :dateFrom' : 'true', { dateFrom })
      .andWhere(dateTo ? '(timeSlot.date + timeSlot.end_time) <= :dateTo' : 'true', { dateTo })
      .andWhere(
        searchWord
          ? `(to_tsvector('simple', f_concat_ws(' ', user.firstName , user.lastName))
          @@ plainto_tsquery('simple', :searchWord) OR user.firstName ILIKE :searchWord OR user.lastName ILIKE :searchWord OR 
          (user.firstName ILIKE :firstName AND user.lastName ILIKE :lastName) OR (user.lastName ILIKE :firstName AND user.firstName ILIKE :lastName)
          OR user.email ILIKE :searchWord)`
          : 'true',
        {
          searchWord: `%${searchWord}%`,
          firstName: `%${firstName}%`,
          lastName: `%${lastName}%`,
        }
      )
      .andWhere(doctorId ? 'doctor.userId = :doctorId' : 'true', { doctorId })
      .andWhere(appointmentStatus ? 'appointment.status = :appointmentStatus' : 'true', { appointmentStatus })
      .andWhere(decidedOutcome ? 'assessment.decided_outcome = :decidedOutcome' : 'true', { decidedOutcome })
      .orderBy(sort, order)
      .skip(page * limit)
      .take(limit)
      .getManyAndCount();

    return { totalItems, data: appointments };
  }

  async findAll({
    searchWord,
    page,
    limit,
    dateFrom,
    dateTo,
    startDate,
    endDate,
    order,
    sort,
    doctorId,
    orgId,
    appointmentStatus,
    decidedOutcome,
  }: FindAppointmentDto): Promise<FindManyResponse<AppointmentEntity>> {
    const [firstName, lastName] = searchWord ? searchWord?.split(' ', 2) : '';

    const [appointments, totalItems] = await this.repository
      .createQueryBuilder('appointment')
      .leftJoinAndSelect('appointment.player', 'player')
      .leftJoinAndSelect('appointment.timeSlot', 'timeSlot')
      .leftJoinAndSelect('player.user', 'user')
      .leftJoinAndSelect('user.organizations', 'org')
      .leftJoinAndSelect('appointment.doctor', 'doctor')
      .leftJoinAndSelect('doctor.user', 'userDoctor')
      .leftJoinAndSelect('appointment.injury', 'injury')
      .leftJoinAndSelect('appointment.assessment', 'assessment')
      .where(startDate ? '(timeSlot.date + timeSlot.start_time) >= :startDate' : 'true', { startDate })
      .andWhere(endDate ? '(timeSlot.date + timeSlot.end_time) <= :endDate' : 'true', { endDate })
      .andWhere(dateFrom ? '(timeSlot.date + timeSlot.start_time) >= :dateFrom' : 'true', { dateFrom })
      .andWhere(dateTo ? '(timeSlot.date + timeSlot.end_time) <= :dateTo' : 'true', { dateTo })
      .andWhere(orgId ? 'org.id = :orgId' : 'true', { orgId })
      .andWhere(
        searchWord
          ? `(to_tsvector('simple', f_concat_ws(' ', user.firstName , user.lastName))
          @@ plainto_tsquery('simple', :searchWord) OR user.firstName ILIKE :searchWord OR user.lastName ILIKE :searchWord OR 
          (user.firstName ILIKE :firstName AND user.lastName ILIKE :lastName) OR (user.lastName ILIKE :firstName AND user.firstName ILIKE :lastName)
          OR user.email ILIKE :searchWord)`
          : 'true',
        {
          searchWord: `%${searchWord}%`,
          firstName: `%${firstName}%`,
          lastName: `%${lastName}%`,
        }
      )
      .andWhere(doctorId ? 'doctor.userId = :doctorId' : 'true', { doctorId })
      .andWhere(appointmentStatus ? 'appointment.status = :appointmentStatus' : 'true', { appointmentStatus })
      .andWhere(decidedOutcome ? 'assessment.decided_outcome = :decidedOutcome' : 'true', { decidedOutcome })
      .orderBy(sort, order)
      .skip(page * limit)
      .take(limit)
      .getManyAndCount();

    return { totalItems, data: appointments };
  }

  async findMany({
    searchWord,
    page,
    limit,
    dateFrom,
    dateTo,
    startDate,
    endDate,
    doctorId,
    order,
    sort,
    appointmentStatus,
    orgId,
    decidedOutcome,
  }: FindAppointmentDto): Promise<FindManyResponse<AppointmentEntity>> {
    const [firstName, lastName] = searchWord ? searchWord?.split(' ', 2) : '';

    const [appointments, totalItems] = await this.repository
      .createQueryBuilder('appointment')
      .leftJoinAndSelect('appointment.player', 'player')
      .leftJoinAndSelect('appointment.timeSlot', 'timeSlot')
      .leftJoinAndSelect('player.user', 'user')
      .leftJoinAndSelect('user.organizations', 'org')
      .leftJoinAndSelect('appointment.doctor', 'doctor')
      .leftJoinAndSelect('doctor.user', 'userDoctor')
      .leftJoinAndSelect('appointment.injury', 'injury')
      .leftJoinAndSelect('appointment.assessment', 'assessment')
      .where(startDate ? '(timeSlot.date + timeSlot.start_time) >= :startDate' : 'true', { startDate })
      .andWhere(endDate ? '(timeSlot.date + timeSlot.end_time) <= :endDate' : 'true', { endDate })
      .andWhere(dateFrom ? '(timeSlot.date + timeSlot.start_time) >= :dateFrom' : 'true', { dateFrom })
      .andWhere(dateTo ? '(timeSlot.date + timeSlot.end_time) <= :dateTo' : 'true', { dateTo })
      .andWhere(orgId ? 'org.id = :orgId' : 'true', { orgId })
      .andWhere(
        searchWord
          ? `(to_tsvector('simple', f_concat_ws(' ', user.firstName , user.lastName))
          @@ plainto_tsquery('simple', :searchWord) OR user.firstName ILIKE :searchWord OR user.lastName ILIKE :searchWord OR 
          (user.firstName ILIKE :firstName AND user.lastName ILIKE :lastName) OR (user.lastName ILIKE :firstName AND user.firstName ILIKE :lastName)
          OR user.email ILIKE :searchWord)`
          : 'true',
        {
          searchWord: `%${searchWord}%`,
          firstName: `%${firstName}%`,
          lastName: `%${lastName}%`,
        }
      )
      .andWhere(doctorId ? 'doctor.userId = :doctorId' : 'true', { doctorId })
      .andWhere(appointmentStatus ? 'appointment.status = :appointmentStatus' : 'true', { appointmentStatus })
      .andWhere(decidedOutcome ? 'assessment.decided_outcome = :decidedOutcome' : 'true', { decidedOutcome })
      .orderBy(sort, order)
      .skip(page * limit)
      .take(limit)
      .getManyAndCount();

    return { totalItems, data: appointments };
  }

  async deleteOne(appointment: AppointmentEntity): Promise<void> {
    const cancelAppointmentTransition = async (runner: QueryRunner): Promise<void> => {
      await runner.manager.delete(AppointmentEntity, appointment.id);

      await runner.manager.update(TimeSlotEntity, { id: appointment.timeSlot.id }, { booked: false });

      return;
    };

    await this.runTransaction(cancelAppointmentTransition);

    return;
  }

  async isHasAccessToAppointment(appointment: AppointmentEntity): Promise<boolean> {
    if (this.roleManager.role === UserRole.Player) {
      return this.roleManager.userId === appointment.player.userId;
    }
    if (this.roleManager.role === UserRole.Parent) {
      const player = await this.manager
        .getRepository(PlayerEntity)
        .createQueryBuilder('player')
        .leftJoinAndSelect('player.parents', 'parent')
        .where('player.user_id = :id', { id: appointment.player.userId })
        .getOne()
        .catch((err) => {
          throw new UnprocessableEntityException(err.message);
        });

      return Boolean(player.parents?.find((parent) => parent.id === this.roleManager.userId));
    }

    if (this.roleManager.role === UserRole.Doctor) {
      return appointment.doctor.userId === this.roleManager.userId;
    }

    if (this.roleManager.role === UserRole.OrganizationAdmin) {
      const admin = await this.manager
        .getRepository(UserEntity)
        .createQueryBuilder('user')
        .leftJoinAndSelect('user.organizations', 'org')
        .leftJoinAndSelect('org.users', 'player')
        .where('player.id = :id', { id: appointment.player.userId })
        .andWhere('user.id = :userId', { userId: this.roleManager.userId })
        .getOne()
        .catch((err) => {
          throw new UnprocessableEntityException(err.message);
        });

      return Boolean(admin);
    }

    return this.roleManager.role === UserRole.SuperAdmin;
  }

  async updateOne(id: string, body: UpdateAppointmentBody): Promise<void> {
    await this.repository.update(id, { status: body.status });
    return;
  }
}

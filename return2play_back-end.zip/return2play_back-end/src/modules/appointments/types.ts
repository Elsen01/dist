import { ClinicEntity } from '../clinics/entities/clinic.entity';
import { TimeSlotEntity } from '../clinics/entities/timeSlot.entity';
import { InjuryEntity } from '../injuries/entities/injury.entity';
import { PlayerEntity } from '../players/entities/player.entity';
import { AppointmentEntity } from './entities/appointment.entity';

export enum AppointmentStatus {
  New = 'new',
  Completed = 'completed',
  NotAttended = 'not attended',
}

export enum Order {
  DESC = 'DESC',
  ASC = 'ASC',
}

export enum AppointmentFormat {
  FaceToFace = 'face-to-face',
  Telemedicine = 'telemedicine',
}

export enum AppointmentType {
  ConcussionAdvice = 'concussion advice',
  ConcussionFollowUp = 'concussion follow up',
  ConcussionFinalClearence = 'concussion final clearance',
}

export enum ClinicStatus {
  Active = 'Active',
  Inactive = 'Inactive',
}

export interface CreateAppointment {
  injury: InjuryEntity;
  timeSlot: TimeSlotEntity;
  player: PlayerEntity;
  clinic: ClinicEntity;
  location?: string;
}

export const DAYS_AFTER_INJURY = 10;

export enum AppointmentTimeStatus {
  Past = 'past',
  Upcoming = 'upcoming',
}

export enum AppointmentSortOptions {
  Date = 'timeSlot.date',
  StartTime = 'timeSlot.startTime',
}

export enum AppointmentSearchFields {
  StartTime = '"ts"."start_time"',
  EndTime = '"ts"."end_time"',
  PlayerFirstName = '"user"."first_name"',
  PlayerLastName = '"user"."last_name"',
  PlayerEmail = '"user"."email"',
}

export type AppointmentResponse = AppointmentEntity & { isFirstAppointment: boolean };

import { ClinicRepository } from './../clinics/clinics.repository';
import { AppointmentRepository } from './appointment.repository';
import { Module } from '@nestjs/common';
import { AppointmentsController } from './appointments.controller';
import { AppointmentsService } from './appointments.service';
import { TypeOrmModule } from '@nestjs/typeorm';
import { SharedModule } from '../shared/shared.module';
import { InjuryRepository } from '../injuries/injury.repository';
import { PlayerRepository } from '../players/player.repository';
import { NoteRepository } from '../notes/note.repository';
import { NotesService } from '../notes/notes.service';

@Module({
  controllers: [AppointmentsController],

  providers: [AppointmentsService, NotesService],
  imports: [
    TypeOrmModule.forFeature([
      AppointmentRepository,
      ClinicRepository,
      InjuryRepository,
      NoteRepository,
      PlayerRepository,
    ]),
    SharedModule,
  ],
})
export class AppointmentsModule {}

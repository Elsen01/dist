import {
  ConflictException,
  ForbiddenException,
  HttpService,
  HttpStatus,
  Injectable,
  NotFoundException,
  UnprocessableEntityException,
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { AppConfigService } from '../../config/config.service';
import { RoleManager } from '../shared/helpers/accessManager/role.manager';
import { PaginationDto } from '../shared/shared.dto';
import { FindManyResponse } from '../shared/types';
import { checkMembership } from '../shared/utils/common.utils';
import { UserRole } from '../users/types';
import { ClinicRepository } from './../clinics/clinics.repository';
import { InjuryRepository } from './../injuries/injury.repository';
import { PlayerRepository } from './../players/player.repository';
import { AppointmentRepository } from './appointment.repository';
import { CreateAppointmentBody } from './dtos/create-appointment.dto';
import { FindAppointmentDto } from './dtos/find-appointment.dto';
import { UpdateAppointmentBody } from './dtos/update-appointment.dto';
import { AppointmentEntity } from './entities/appointment.entity';
import { AppointmentResponse, AppointmentStatus, ClinicStatus } from './types';
import { NotesService } from '../notes/notes.service';

@Injectable()
export class AppointmentsService {
  private readonly roleManager = RoleManager.getInstance();

  constructor(
    @InjectRepository(AppointmentRepository)
    private appointmentRepo: AppointmentRepository,
    @InjectRepository(ClinicRepository)
    private clinicRepo: ClinicRepository,
    @InjectRepository(InjuryRepository)
    private injuryRepo: InjuryRepository,
    @InjectRepository(PlayerRepository)
    private playerRepo: PlayerRepository,
    private configService: AppConfigService,
    private httpService: HttpService,
    private noteService: NotesService
  ) {}

  async bookAppointment(body: CreateAppointmentBody): Promise<void> {
    const { clinicId, injuryId, playerId, timeSlotId } = body;
    const injury = await this.injuryRepo.findInjury({
      id: injuryId,
      // injuryGroup: In([InjuryGroup.Concussion, InjuryGroup.HeadInjury]),
      // playStatus: In([PlayStatus.ReduceActivity, PlayStatus.NotSafe]),
    });
    if (!injury) {
      const errorObject = { field: 'injuryId', message: `${injury.injuryGroup} not found` };
      throw new NotFoundException(JSON.stringify(errorObject));
    }
    const player = await this.playerRepo.findOne(playerId);

    if (!player) {
      const errorObject = { statusCode: HttpStatus.NOT_FOUND, field: 'playerId', message: 'Player not found' };
      throw new NotFoundException(errorObject);
    }

    const hasMembership = checkMembership(player.membership, player.membershipExpirationDate);

    if (!hasMembership) {
      throw new ConflictException('Player has no membership');
    }

    const clinic = await this.clinicRepo.findOne({
      id: clinicId,
      status: ClinicStatus.Active,
    });

    if (!clinic) {
      const errorObject = { statusCode: HttpStatus.NOT_FOUND, field: 'clinicId', message: 'Clinic not found' };
      throw new NotFoundException(errorObject);
    }

    // const clinicDate = moment(clinic.date).format('YYYY-MM-DD');

    // const currentTime = moment().format('HH:mm:ss');
    // const currentDate = moment().format('YYYY-MM-DD');
    // const startDateTime = moment(`${clinic.startTime}`, 'HH:mm:ss');
    // const endDateTime = moment(`${clinic.endTime}`, 'HH:mm:ss');

    // if (currentDate === clinicDate && moment(currentTime, 'HH:mm:ss').isBetween(startDateTime, endDateTime)) {
    //   throw new NotFoundException('Cannot be booked');
    // }

    const timeSlot = clinic.timeSlots.find((ts) => ts.id === timeSlotId);

    if (!timeSlot || timeSlot?.booked) {
      const errorObject = {
        statusCode: HttpStatus.NOT_FOUND,
        field: 'timeSlotId',
        message: 'Time slot already booked or does not exist',
      };
      throw new NotFoundException(errorObject);
    }

    const isHasAccessToOrganization = clinic.allOrganizations
      ? true
      : clinic.organizations.some((clinicOrg) =>
          player.user.organizations.map((playerOrg) => playerOrg.id.includes(clinicOrg.id))
        );

    if (!isHasAccessToOrganization) {
      const errorObject = {
        statusCode: HttpStatus.CONFLICT,
        field: 'playerId',
        message: 'Player does not have access to organizations for this clinic',
      };
      throw new ConflictException(errorObject);
    }

    // const appointmentDate = moment(clinic.date);

    // const isAllowToBook =
    //   clinic.medicalType.includes(AppointmentType.ConcussionAdvice) || clinic.medicalType.includes(AppointmentType.All);
    // appointmentDate.diff(injury.accidentDate, 'days') >= DAYS_AFTER_INJURY;

    // if (!isAllowToBook) {
    //   const errorObject = {
    //     statusCode: HttpStatus.CONFLICT,
    //     field: 'injuryId',
    //     message: '10 days did not pass from injury date',
    //   };
    //   throw new ConflictException(errorObject);
    // }

    const { location } = clinic;
    const appointment = await this.appointmentRepo.createOne({ timeSlot, injury, player, clinic, location });
    await this.httpService
      .post(`http://${this.configService.aws.mailerHost}/appointment/confirm/${appointment.id}`)
      .toPromise()
      .catch((err) => {
        throw new UnprocessableEntityException(err);
      });

    return;
  }

  async findOne(id: string): Promise<AppointmentResponse> {
    const appointment = await this.appointmentRepo.findById(id);

    if (!appointment) {
      throw new NotFoundException('Appointment not found.');
    }

    const injury = await this.injuryRepo.findInjuryWithLastAppointment(appointment.injury.id);

    const isFirstAppointment = injury?.appointments?.length <= 1;

    return { ...appointment, isFirstAppointment };
  }

  async findByPlayer(id: string, query: PaginationDto): Promise<FindManyResponse<AppointmentEntity>> {
    const response = await this.appointmentRepo.findByPlayerId(id, query);

    return { data: response[0], totalItems: response[1] };
  }

  async findByInjury(id: string, query: PaginationDto): Promise<FindManyResponse<AppointmentEntity>> {
    const response = await this.appointmentRepo.findByInjuryId(id, query);

    return { data: response[0], totalItems: response[1] };
  }

  findMany(query: FindAppointmentDto): Promise<FindManyResponse<AppointmentEntity>> {
    if (this.roleManager.role === UserRole.Doctor) {
      query.doctorId = this.roleManager.userId;
    }

    if (this.roleManager.role === UserRole.SuperAdmin) {
      return this.appointmentRepo.findAll(query);
    }

    if ([UserRole.OrganizationAdmin, UserRole.MedicalStaff].includes(this.roleManager.role)) {
      return this.appointmentRepo.findAllOrg(query);
    }

    return this.appointmentRepo.findMany(query);
  }

  async deleteOne(id: string): Promise<void> {
    const appointment = await this.appointmentRepo.findById(id, { status: AppointmentStatus.New });

    if (!appointment) {
      throw new NotFoundException('Appointment not found');
    }

    const isHasAccess = await this.appointmentRepo.isHasAccessToAppointment(appointment);

    if (!isHasAccess) {
      throw new ForbiddenException('User has no access to this appointment');
    }
    await this.httpService.post(`http://${this.configService.aws.mailerHost}/appointment/cancel/${id}`).toPromise();

    return await this.appointmentRepo.deleteOne(appointment);
  }

  async updateOne(id: string, body: UpdateAppointmentBody): Promise<void> {
    const appointment = await this.appointmentRepo.findById(id);

    if (!appointment) {
      throw new NotFoundException('Appointment not found');
    }

    const isHasAccess = await this.appointmentRepo.isHasAccessToAppointment(appointment);

    if (!isHasAccess) {
      throw new ForbiddenException('User has no access to this appointment');
    }

    await this.appointmentRepo.updateOne(id, body);

    // await this.injuryRepo.updateInjuryStatus(appointment.injury.id, { attendStatus: body.attendStatus });

    await this.noteService.createForAttendStatus(body.injuryId, body.text);
    await this.httpService.post(`http://${this.configService.aws.mailerHost}/appointment/update/${id}`).toPromise();
  }

  async reminderAppointment(): Promise<void> {
    await this.httpService.post(`http://${this.configService.aws.mailerHost}/appointment/reminder`).toPromise();
    return;
  }
}

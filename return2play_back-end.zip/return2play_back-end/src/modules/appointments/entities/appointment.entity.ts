import { AssessmentEntity } from './../../assessments/entities/assessment.entity';
import {
  Column,
  CreateDateColumn,
  Entity,
  JoinColumn,
  ManyToOne,
  OneToOne,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm';
import { AppointmentStatus } from '../types';
import { TimeSlotEntity } from '../../clinics/entities/timeSlot.entity';
import { PlayerEntity } from '../../players/entities/player.entity';
import { InjuryEntity } from '../../injuries/entities/injury.entity';
import { DoctorEntity } from '../../doctors/entities/doctor.entity';

@Entity('appointments')
export class AppointmentEntity {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ type: 'varchar', length: 255, nullable: true })
  location: string;

  @Column({ type: 'enum', enum: AppointmentStatus, default: AppointmentStatus.New })
  status: AppointmentStatus;

  @OneToOne(() => TimeSlotEntity, (clinic) => clinic.appointment, { nullable: false, onDelete: 'CASCADE' })
  @JoinColumn({ name: 'timeslot_id' })
  timeSlot: TimeSlotEntity;

  @ManyToOne(() => PlayerEntity, (player) => player.appointments, { nullable: false })
  @JoinColumn({ name: 'player_id' })
  player: PlayerEntity;

  @ManyToOne(() => DoctorEntity, (doctor) => doctor.scheduledClinics, { nullable: false })
  @JoinColumn({ name: 'doctor_id' })
  doctor: DoctorEntity;

  @ManyToOne(() => InjuryEntity, (injury) => injury.appointments, { nullable: false })
  @JoinColumn({ name: 'injury_id' })
  injury: InjuryEntity;

  @OneToOne(() => AssessmentEntity, (assessment) => assessment.appointment)
  assessment?: AssessmentEntity;

  @CreateDateColumn({ name: 'created_at' })
  createdAt: Date;

  @UpdateDateColumn({ name: 'updated_at' })
  updatedAt: Date;
}

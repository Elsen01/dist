import { UpdateAppointmentBody } from './dtos/update-appointment.dto';
import { IdDto, PaginationDto } from './../shared/shared.dto';
import { CreateAppointmentBody } from './dtos/create-appointment.dto';
import { AppointmentsService } from './appointments.service';
import {
  Body,
  Controller,
  Get,
  HttpCode,
  HttpStatus,
  Param,
  Post,
  Query,
  UseGuards,
  Delete,
  Put,
} from '@nestjs/common';
import {
  ApiBearerAuth,
  ApiConflictResponse,
  ApiForbiddenResponse,
  ApiNoContentResponse,
  ApiNotFoundResponse,
  ApiOkResponse,
  ApiOperation,
  ApiTags,
  ApiUnprocessableEntityResponse,
} from '@nestjs/swagger';
import { Roles } from '../shared/decorators/roles.decorator';
import { CognitoGuard } from '../shared/guards/cognito.guard';
import { RolesGuard } from '../shared/guards/roles.guard';
import { UserRole } from '../users/types';
import {
  BOOK_APPOINTMENT,
  DELETE_ONE,
  FIND_ONE,
  GET_APPOINTMENTS_LIST,
  GET_MANY_BY_INJURY,
  GET_MANY_BY_PLAYER,
  UPDATE_ONE,
} from './swagger';
import { FindManyResponse } from '../shared/types';
import { AppointmentEntity } from './entities/appointment.entity';
import { FindAppointmentDto } from './dtos/find-appointment.dto';
import { AppointmentResponse } from './types';
// import { Cron } from '@nestjs/schedule';
// import { Cron } from '@nestjs/schedule';

@ApiTags('Appointments')
@UseGuards(CognitoGuard, RolesGuard)
@Roles(UserRole.SuperAdmin)
@ApiBearerAuth()
@Controller('appointments')
export class AppointmentsController {
  constructor(private service: AppointmentsService) {}

  @ApiOperation(BOOK_APPOINTMENT.OPERATION)
  @ApiNoContentResponse(BOOK_APPOINTMENT.SUCCESS)
  @ApiForbiddenResponse(BOOK_APPOINTMENT.FORBIDDEN)
  @ApiUnprocessableEntityResponse(BOOK_APPOINTMENT.FAILURE)
  @ApiConflictResponse(BOOK_APPOINTMENT.CONFLICT)
  @ApiNotFoundResponse(BOOK_APPOINTMENT.NOT_FOUND)
  @HttpCode(HttpStatus.NO_CONTENT)
  @Roles(UserRole.Player, UserRole.Parent, UserRole.Doctor, UserRole.OrganizationAdmin, UserRole.MedicalStaff)
  @Post()
  async createOne(@Body() body: CreateAppointmentBody): Promise<void> {
    return await this.service.bookAppointment(body);
  }

  @ApiOperation(FIND_ONE.OPERATION)
  @ApiOkResponse(FIND_ONE.SUCCESS)
  @ApiForbiddenResponse(FIND_ONE.FORBIDDEN)
  @ApiUnprocessableEntityResponse(FIND_ONE.FAILURE)
  @Roles(UserRole.Doctor, UserRole.Parent, UserRole.Player)
  @Get('/:id')
  async findOne(@Param() param: IdDto): Promise<AppointmentResponse> {
    return await this.service.findOne(param.id);
  }

  @ApiOperation(GET_MANY_BY_PLAYER.OPERATION)
  @ApiOkResponse(GET_MANY_BY_PLAYER.SUCCESS)
  @ApiForbiddenResponse(GET_MANY_BY_PLAYER.FORBIDDEN)
  @ApiUnprocessableEntityResponse(GET_MANY_BY_PLAYER.FAILURE)
  @Roles(UserRole.Doctor)
  @Get('player/:id')
  async getPlayerAppointments(
    @Param() params: IdDto,
    @Query() query: PaginationDto
  ): Promise<FindManyResponse<AppointmentEntity>> {
    return await this.service.findByPlayer(params.id, query);
  }

  @ApiOperation(GET_MANY_BY_INJURY.OPERATION)
  @ApiOkResponse(GET_MANY_BY_INJURY.SUCCESS)
  @ApiForbiddenResponse(GET_MANY_BY_INJURY.FORBIDDEN)
  @ApiUnprocessableEntityResponse(GET_MANY_BY_INJURY.FAILURE)
  @Roles(UserRole.Doctor, UserRole.OrganizationAdmin, UserRole.MedicalStaff)
  @Get('injury/:id')
  async getInjuryAppointments(
    @Param() params: IdDto,
    @Query() query: PaginationDto
  ): Promise<FindManyResponse<AppointmentEntity>> {
    return await this.service.findByInjury(params.id, query);
  }

  @ApiOperation(GET_APPOINTMENTS_LIST.OPERATION)
  @ApiNoContentResponse(GET_APPOINTMENTS_LIST.SUCCESS)
  @ApiForbiddenResponse(GET_APPOINTMENTS_LIST.FORBIDDEN)
  @ApiUnprocessableEntityResponse(GET_APPOINTMENTS_LIST.FAILURE)
  @Get()
  @Roles(UserRole.Doctor, UserRole.MedicalStaff, UserRole.OrganizationAdmin, UserRole.SuperAdmin)
  findMany(@Query() query: FindAppointmentDto): Promise<FindManyResponse<AppointmentEntity>> {
    return this.service.findMany(query);
  }

  @ApiOperation(DELETE_ONE.OPERATION)
  @ApiNoContentResponse(DELETE_ONE.SUCCESS)
  @ApiForbiddenResponse(DELETE_ONE.FORBIDDEN)
  @ApiUnprocessableEntityResponse(DELETE_ONE.FAILURE)
  @HttpCode(HttpStatus.NO_CONTENT)
  @Roles(UserRole.Doctor, UserRole.Parent, UserRole.Player, UserRole.OrganizationAdmin, UserRole.MedicalStaff)
  @Delete('/:id')
  async deleteOne(@Param() params: IdDto): Promise<void> {
    return await this.service.deleteOne(params.id);
  }

  @ApiOperation(UPDATE_ONE.OPERATION)
  @ApiNoContentResponse(UPDATE_ONE.SUCCESS)
  @ApiForbiddenResponse(UPDATE_ONE.FORBIDDEN)
  @ApiUnprocessableEntityResponse(UPDATE_ONE.FAILURE)
  @HttpCode(HttpStatus.NO_CONTENT)
  @Roles(UserRole.Doctor)
  @Put('/:id')
  async updateOne(@Param() params: IdDto, @Body() body: UpdateAppointmentBody): Promise<void> {
    return await this.service.updateOne(params.id, body);
  }
  // @Cron('0 0-23/1 * * *')

  // @Cron('0 * * * * *')
  // eslint-disable-next-line @typescript-eslint/explicit-function-return-type
  async reminderAppointment(): Promise<any> {
    console.log(111111111);

    return await this.service.reminderAppointment();
  }
}

import { IsUUID } from 'class-validator';

export class CreateAppointmentBody {
  @IsUUID()
  playerId: string;

  @IsUUID()
  clinicId: string;

  @IsUUID()
  injuryId: string;

  @IsUUID()
  timeSlotId: string;
}

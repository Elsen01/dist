import { IsEnum } from 'class-validator';
import { AppointmentStatus } from '../types';

export class UpdateAppointmentStatus {
  @IsEnum(AppointmentStatus)
  status: AppointmentStatus;
}

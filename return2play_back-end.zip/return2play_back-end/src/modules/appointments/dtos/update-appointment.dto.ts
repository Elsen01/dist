import { IsEnum, IsString, IsUUID, MaxLength } from 'class-validator';
import { AppointmentStatus } from '../types';

export class UpdateAppointmentBody {
  @IsEnum(AppointmentStatus)
  status: AppointmentStatus;

  @IsUUID()
  injuryId: string;

  @IsString()
  @MaxLength(1000)
  text: string;
}

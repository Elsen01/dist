import { IsDateString, IsEnum, IsOptional, IsString, IsUUID, MaxLength, MinLength } from 'class-validator';
import { PaginationDto } from '../../shared/shared.dto';
import { AppointmentSortOptions, AppointmentStatus, Order } from '../types';
import { DecidedOutcome } from '../../assessments/types';

export class FindAppointmentDto extends PaginationDto {
  @IsDateString()
  @IsOptional()
  dateFrom?: Date;

  @IsDateString()
  @IsOptional()
  dateTo?: Date;

  @IsDateString()
  @IsOptional()
  startDate?: Date;

  @IsDateString()
  @IsOptional()
  endDate?: Date;

  @IsString()
  @MinLength(1)
  @MaxLength(100)
  @IsOptional()
  searchWord?: string;

  @IsUUID()
  @IsOptional()
  doctorId?: string;

  @IsUUID()
  @IsOptional()
  orgId?: string;

  @IsEnum(AppointmentSortOptions)
  @IsOptional()
  sort? = AppointmentSortOptions.Date;

  @IsEnum(Order)
  @IsOptional()
  order? = Order.DESC;

  @IsOptional()
  appointmentStatus?: AppointmentStatus;

  @IsOptional()
  decidedOutcome?: DecidedOutcome;
}

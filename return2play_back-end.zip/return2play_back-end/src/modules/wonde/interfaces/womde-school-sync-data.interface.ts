export interface WondeSchoolSyncData {
  id: string;
}

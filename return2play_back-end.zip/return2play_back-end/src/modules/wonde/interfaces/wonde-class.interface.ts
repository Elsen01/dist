import { WondeEmployee } from './wonde-employee.interface';
import { WondeSubject } from './wonde-subject.interface';

export interface WondeClass {
  id: string;
  mis_id: string;
  name: string;
  code: string;
  description: string;
  subject: {
    data: WondeSubject;
  };
  employees: {
    data: WondeEmployee[];
  };
}

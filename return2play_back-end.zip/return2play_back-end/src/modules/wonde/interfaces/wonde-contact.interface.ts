import { WondeBaseUser } from './wonde-base-user.interface';
import { WondeContactDetails } from './wonde-contact-details.interface';
import { WondeRelationship } from './wonde-relation.interface';

export interface WondeContact extends WondeBaseUser {
  relationship: WondeRelationship;
  contact_details: WondeContactDetails;
}

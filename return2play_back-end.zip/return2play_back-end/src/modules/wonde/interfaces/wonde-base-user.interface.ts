export interface WondeBaseUser {
  id: string;
  upi: string;
  initials: string;
  title: string;
  mis_id: string;
  surname: string;
  forename: string;
  gender: string;
  legal_surname: string;
  legal_forename: string;
}

export interface WondeContactDetails {
  data: {
    phones: {
      phone: string;
    };
    emails: {
      email: string;
    };
    addresses: {
      home: {
        house_number: string;
        house_name: string;
        apartment: string;
        street: string;
        district: string;
        town: string;
        county: string;
        country: string;
        postcode: string;
      };
    };
  };
}

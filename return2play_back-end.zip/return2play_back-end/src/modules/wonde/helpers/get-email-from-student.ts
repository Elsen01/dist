import { WondeStudent } from '../interfaces/wonde-student.interface';

/**
 * Function to get email from student
 * @param student WondeStudent
 * @returns string | undefined
 */
export function getEmailFromStudent({ contact_details }: WondeStudent): string | undefined {
  return contact_details?.data?.emails?.email;
}

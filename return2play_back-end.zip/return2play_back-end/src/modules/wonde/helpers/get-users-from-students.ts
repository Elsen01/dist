import { uniqBy } from 'lodash';
import { v4 as uuid } from 'uuid';

import { Membership } from '../../players/types';
import { calculateYearGroup } from '../../shared/utils/common.utils';
import { UserEntity } from '../../users/entities/user.entity';
import { UserRole } from '../../users/types';
import { WondeStudent } from '../interfaces/wonde-student.interface';
import { findUserByParentEmail } from './find-user-by-parent-email';
import { findUserByStudent } from './find-user-by-student';
import { getBirthDate } from './get-birthdate';
import { getEmailFromParent } from './get-email-from-parent';
import { getEmailFromStudent } from './get-email-from-student';
import { getGender } from './get-gender';

/**
 * Function for mapping students from 'Wonde Students' to UserEntities
 * @param players ReadonlyArray<PlayerImportDto>
 * @param users ReadonlyArray<UserEntity>
 * @param organizations ReadonlyArray<OrganizationEntity>
 * @returns Array<UserEntity>
 */
export function getUsersFromStudents(
  students: ReadonlyArray<WondeStudent>,
  users: ReadonlyArray<UserEntity>,
  organizationId: string
): Array<UserEntity> {
  const arr = [];

  const n = students.length;
  const organizations = [{ id: organizationId }];
  for (let i = 0; i < n; i++) {
    const student = students[i];
    const existingUser = findUserByStudent(users, student);

    // Mapping parents
    const parents: Array<UserEntity> = [];
    const parentsFromWonde = uniqBy(student.contacts?.data || [], 'contact_details.data.emails.email');
    const m = parentsFromWonde.length || 0;
    for (let j = 0; j < m; j++) {
      const parent = parentsFromWonde[j];
      const parentEmail = getEmailFromParent(parent);
      if (!parentEmail) {
        continue;
      }
      const existingUserForParent = findUserByParentEmail(users, parentEmail);

      parents.push({
        ...existingUserForParent,
        id: existingUserForParent?.id || uuid(),
        role: existingUserForParent?.role || UserRole.Parent,
        firstName: parent.forename ?? 'Mr/Mrs',
        lastName: parent.surname ?? 'Mr/Mrs',
        email: parentEmail,
        organizations: uniqBy(
          [].concat(existingUserForParent ? existingUserForParent.organizations : [], organizations),
          'id'
        ),
      });
    }

    const id = existingUser?.id || uuid();
    const birthday = student.date_of_birth && getBirthDate(student.date_of_birth);
    const email = getEmailFromStudent(student);
    const gender = getGender(student.gender);

    const { id: wondeId, mis_id: misId, updated_at } = student;

    const user: UserEntity = {
      ...existingUser,
      id,
      birthday: existingUser?.birthday || birthday,
      firstName: existingUser?.firstName || student.forename || undefined,
      lastName: existingUser?.lastName || student.surname || undefined,
      email: existingUser?.email || email || undefined,
      gender: existingUser?.gender || gender || undefined,
      role: existingUser?.role || UserRole.Player,
      organizations: uniqBy([].concat(existingUser ? existingUser.organizations : [], organizations), 'id'),
      player: {
        ...existingUser?.player,
        userId: id,
        membership: existingUser?.player?.membership || Membership.School,
        yearGroup: existingUser?.player?.yearGroup || calculateYearGroup(birthday),
        parents: uniqBy(parents, 'id'),
      },
      wondeStudent: {
        id: existingUser?.wondeStudent?.id || id,
        wondeId,
        misId,
        lastUpdate: new Date(),
        wondeLastModify: updated_at.date,
        player: { id } as UserEntity,
      },
    };

    arr.push(user);
  }

  return arr;
}

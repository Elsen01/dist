import { UserEntity } from '../../users/entities/user.entity';

/**
 * Function to find user by email
 * @param arr ReadonlyArray<UserEntity>
 * @param parentEmail string
 * @returns UserEntity | undefined
 */
export function findUserByParentEmail(arr: ReadonlyArray<UserEntity>, parentEmail: string): UserEntity | undefined {
  return arr.find(({ email }) => email && parentEmail && email === parentEmail);
}

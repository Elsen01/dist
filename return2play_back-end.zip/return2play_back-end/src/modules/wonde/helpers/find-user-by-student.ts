import { isSameDay } from 'date-fns';
import { UserEntity } from '../../users/entities/user.entity';
import { UserRole } from '../../users/types';
import { WondeStudent } from '../interfaces/wonde-student.interface';
import { getBirthDate } from './get-birthdate';
import { getEmailFromStudent } from './get-email-from-student';
import { getGender } from './get-gender';

/**
 * Function to find user for student from 'wonde students'
 * @param arr ReadonlyArray<UserEntity>
 * @param student WondeStudent
 * @returns UserEntity | undefined
 */
export function findUserByStudent(arr: ReadonlyArray<UserEntity>, student: WondeStudent): UserEntity | undefined {
  // Find only in players
  const players = arr.filter(({ role }) => role === UserRole.Player);

  // Find by already synchronized
  const foundByWondeId = players.find(({ wondeStudent }) => wondeStudent?.wondeId === student.id);
  if (foundByWondeId) {
    return foundByWondeId;
  }

  // Find by email
  const studentEmail = getEmailFromStudent(student);
  const foundByEmail = studentEmail && players.find(({ email }) => email === studentEmail);
  if (foundByEmail) {
    return foundByEmail;
  }

  const studentGender = getGender(student.gender);
  const studentBirthDate = getBirthDate(student.date_of_birth);

  // Find by FN + LN + GENDER + DOB + missed email
  const foundByFNLNGENDERDOB = players.find(({ firstName, lastName, birthday, gender, email }) => {
    return (
      firstName === student.forename &&
      lastName === student.surname &&
      student.date_of_birth &&
      isSameDay(studentBirthDate, new Date(birthday)) &&
      gender === studentGender &&
      ((!studentEmail && !email) || (studentEmail && !email) || (!studentEmail && email))
    );
  });
  if (foundByFNLNGENDERDOB) {
    return foundByFNLNGENDERDOB;
  }

  return;
}

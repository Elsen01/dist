import { Gender } from '../../users/types';
import { WondeStudent } from '../interfaces/wonde-student.interface';

/**
 * Function to get gender for wonde student
 * @param gender WondeStudent['gender']
 * @returns Gender
 */
export function getGender(gender: WondeStudent['gender']): Gender {
  return gender === 'MALE' ? Gender.Male : Gender.Female;
}

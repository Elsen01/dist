import { WondeStudent } from '../interfaces/wonde-student.interface';

export function getBirthDate(dateOfBirth: WondeStudent['date_of_birth']): Date {
  if (!dateOfBirth.date) {
    return new Date();
  }
  return new Date(dateOfBirth.date.toString().split(' ')[0]);
}

import { FindOperator } from 'typeorm';

import { UserEntity } from '../../users/entities/user.entity';
import { WondeStudent } from '../interfaces/wonde-student.interface';
import { getEmailFromParent } from './get-email-from-parent';
import { getEmailFromStudent } from './get-email-from-student';

export interface CriteriasForSync {
  emails: Array<string>;
  others: Array<
    Omit<Partial<UserEntity>, 'email' | 'birthday'> & {
      email?: FindOperator<any> | string;
      birthday?: FindOperator<any> | Date;
    }
  >;
}

/**
 * Function for getting criterias that are using for search existing users in DB based on Wonde Students
 * @param arr ReadonlyArray<WondeStudent>
 * @returns CriteriasForSync
 */
export function getCriteriasForSync(arr: ReadonlyArray<WondeStudent>): CriteriasForSync {
  const emails: CriteriasForSync['emails'] = [];
  const others: CriteriasForSync['others'] = [];

  const n = arr.length;
  for (let i = 0; i < n; i++) {
    const { forename, surname, contacts } = arr[i];
    const email = getEmailFromStudent(arr[i]);
    if (email) {
      emails.push(email);
    }
    others.push({
      firstName: forename,
      lastName: surname,
    });

    const m = contacts?.data?.length || 0;
    for (let j = 0; j < m; j++) {
      const email = getEmailFromParent(contacts.data[j]);
      if (email) {
        emails.push(email);
      }
    }
  }

  return { emails: [...new Set(emails)], others };
}

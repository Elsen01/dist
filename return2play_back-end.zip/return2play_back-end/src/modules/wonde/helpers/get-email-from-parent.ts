import { WondeContact } from '../interfaces/wonde-contact.interface';

/**
 * Function to get email for parent
 * @param parent WondeContact
 * @returns string | undefined
 */
export function getEmailFromParent(parent: WondeContact): string | undefined {
  return parent?.contact_details?.data?.emails?.email;
}

import { v4 } from 'uuid';
import { OrganizationEntity } from '../../organizations/entities/organization.entity';

import { WondeSchoolEntity } from '../../organizations/entities/wondeSchool.entity';
import { OrganizationType } from '../../organizations/types';
import { WondeSchool } from '../interfaces/wonde-school.interface';

/**
 * Function to map Wonde School to DB Entity
 * @param school WondeSchool
 * @returns WondeSchoolEntity
 */
export function mapSchool(school: WondeSchool): WondeSchoolEntity {
  const {
    address_line_1: address1,
    address_line_2: address2,
    address_postcode: postcode,
    address_town: town,
  } = school.address;

  const { id: wondeId, establishment_number: establishmentNumber, la_code: laCode, name } = school;

  const id = v4();

  return {
    id,
    wondeId,
    establishmentNumber,
    laCode,
    lastUpdate: new Date(),
    organization: {
      id,
      name,
      address1,
      address2,
      postcode,
      town,
      type: OrganizationType.School,
    } as OrganizationEntity,
  };
}

import { HttpModule, Module } from '@nestjs/common';
import { InjuriesService } from './injuries.service';
import { InjuriesController } from './injuries.controller';
import { TypeOrmModule } from '@nestjs/typeorm';
import { SharedModule } from '../shared/shared.module';
import { InjuryRepository } from './injury.repository';
import { UserRepository } from '../users/users.repository';
import { NoteRepository } from '../notes/note.repository';
import { AppConfigService } from '../../config/config.service';

@Module({
  providers: [InjuriesService],
  controllers: [InjuriesController],
  imports: [
    HttpModule.registerAsync({ useClass: AppConfigService }),
    TypeOrmModule.forFeature([InjuryRepository, UserRepository, NoteRepository]),
    SharedModule,
  ],
})
export class InjuriesModule {}

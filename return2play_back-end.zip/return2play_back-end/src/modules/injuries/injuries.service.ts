import {
  ConflictException,
  ForbiddenException,
  HttpService,
  HttpStatus,
  Inject,
  Injectable,
  Logger,
  LoggerService,
  NotFoundException,
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import moment from 'moment';
import { Not } from 'typeorm';
import { AppConfigService } from '../../config/config.service';
import { AppointmentEntity } from '../appointments/entities/appointment.entity';
import { AppointmentStatus, AppointmentType } from '../appointments/types';
// import { AppointmentType as ClinicAppointmentType } from '../clinics/types';
import { NoteRepository } from '../notes/note.repository';
import { S3BucketManager } from '../shared/helpers/s3bucket/s3bucket.manager';
import { IFile } from '../shared/helpers/s3bucket/types';
import { FindManyResponse } from '../shared/types';
import { checkMembership, getContentType } from '../shared/utils/common.utils';
import { UserRole } from '../users/types';
import { UserRepository } from '../users/users.repository';
import {
  CreateNonSportConcussionBody,
  CreateNonSportOtherInjuryBody,
  CreateSportConcussionBody,
  CreateSportOtherInjuryBody,
} from './dtos/create-injury.dto';
import { FindOneInjuryPagination, InjuryFiltersQuery } from './dtos/find-injury.dto';
import {
  UpdateConcussionInjuryStatusBody,
  UpdateHeadInjuryStatusBody,
  UpdateInjuryBody,
  UpdateOtherInjuryStatusBody,
} from './dtos/update-injury.dto';
import { InjuryEntity } from './entities/injury.entity';
import { InjuryRepository } from './injury.repository';
import { GetOneInjuryResponse, InjuryGroup, InjuryStatus } from './types';

@Injectable()
export class InjuriesService {
  constructor(
    @InjectRepository(InjuryRepository)
    private injuryRepo: InjuryRepository,
    @InjectRepository(UserRepository)
    private userRepo: UserRepository,
    @InjectRepository(NoteRepository)
    private noteRepo: NoteRepository,
    private s3Bucket: S3BucketManager,
    private httpService: HttpService,
    private configService: AppConfigService,
    @Inject(Logger)
    private logger: LoggerService
  ) {}

  async createNonSportConcussion(concussion: CreateNonSportConcussionBody): Promise<void> {
    const { playerId } = concussion;
    const isPlayerExists = await this.userRepo.findIfUserExits({ id: playerId, role: UserRole.Player });

    if (!isPlayerExists) {
      throw new NotFoundException('Player does not exist');
    }

    const isHasAccessToPlayer = await this.injuryRepo.isHasAccessToPlayer(concussion.playerId);

    if (!isHasAccessToPlayer) {
      throw new ForbiddenException('User does not have access to create injury for this player');
    }

    const injuries = await this.injuryRepo.findActiveConcussion(playerId);

    if (injuries.length) {
      throw new ConflictException('Concussion injury already exists');
    }

    const injury = await this.injuryRepo.createNonSportConcussion(concussion);
    await this.httpService
      .post(`http://${this.configService.aws.mailerHost}/injury/${injury.id}`)
      .toPromise()
      .catch((err) => {
        this.logger.error(`Sending emails on creation non sport concussion failed with error: ${err}`);
      });

    return;
  }

  async createSportConcussion(concussion: CreateSportConcussionBody): Promise<void> {
    const { playerId, organizationId } = concussion;

    const isPlayerExists = await this.userRepo.findIfUserExits({ id: playerId, role: UserRole.Player });
    if (!isPlayerExists) {
      throw new NotFoundException('Player does not exist');
    }

    const isHasAccessToPlayer = await this.injuryRepo.isHasAccessToPlayer(playerId);
    if (!isHasAccessToPlayer) {
      throw new ForbiddenException('User does not have access to create injury for this player');
    }

    const isPartOfOrganization = await this.injuryRepo.isPlayerPartOfOrganization(playerId, organizationId);

    if (!isPartOfOrganization && concussion.organizationId) {
      const errorObject = {
        statusCode: HttpStatus.FORBIDDEN,
        field: 'playerId',
        message: 'Player is not part of given organization',
      };
      throw new ForbiddenException(errorObject);
    }

    const injuries = await this.injuryRepo.findActiveConcussion(playerId);

    if (injuries.length) {
      throw new ConflictException('Concussion injury already exists');
    }

    const injury = await this.injuryRepo.createSportConcussion(concussion);

    await this.httpService
      .post(`http://${this.configService.aws.mailerHost}/injury/${injury.id}`)
      .toPromise()
      .catch((err) => {
        this.logger.error(`Sending emails on creation sport concussion failed with error: ${err}`);
      });

    return;
  }

  async createSportHeadInjury(headInjury: CreateSportConcussionBody): Promise<void> {
    const { playerId, organizationId } = headInjury;

    const isPlayerExists = await this.userRepo.findIfUserExits({ id: playerId, role: UserRole.Player });

    if (!isPlayerExists) {
      throw new NotFoundException('Player does not exist');
    }

    const isHasAccessToPlayer = await this.injuryRepo.isHasAccessToPlayer(playerId);

    if (!isHasAccessToPlayer) {
      throw new ForbiddenException('User does not have access to create injury for this player');
    }

    const isPartOfOrganization = await this.injuryRepo.isPlayerPartOfOrganization(playerId, organizationId);

    if (!isPartOfOrganization && headInjury.organizationId) {
      const errorObject = {
        statusCode: HttpStatus.FORBIDDEN,
        field: 'playerId',
        message: 'Player is not part of given organization',
      };
      throw new ForbiddenException(errorObject);
    }

    const injuries = await this.injuryRepo.findActiveHeadInjury(playerId);

    if (injuries.length) {
      throw new ConflictException('Head injury already exists');
    }

    const injury = await this.injuryRepo.createSportHeadInjury(headInjury);

    await this.httpService
      .post(`http://${this.configService.aws.mailerHost}/injury/${injury.id}`)
      .toPromise()
      .catch((err) => {
        this.logger.error(`Sending emails on creation sport head injury failed with error: ${err}`);
      });
  }

  async createNonSportHeadInjury(headInjury: CreateNonSportConcussionBody): Promise<void> {
    const { playerId } = headInjury;

    const isPlayerExists = await this.userRepo.findIfUserExits({ id: playerId, role: UserRole.Player });

    if (!isPlayerExists) {
      throw new NotFoundException('Player does not exist');
    }

    const isHasAccessToPlayer = await this.injuryRepo.isHasAccessToPlayer(headInjury.playerId);

    if (!isHasAccessToPlayer) {
      throw new ForbiddenException('User does not have access to create injury for this player');
    }

    const injuries = await this.injuryRepo.findActiveHeadInjury(playerId);

    if (injuries.length) {
      throw new ConflictException('Head injury already exists');
    }

    const injury = await this.injuryRepo.createNonSportHeadInjury(headInjury);

    await this.httpService
      .post(`http://${this.configService.aws.mailerHost}/injury/${injury.id}`)
      .toPromise()
      .catch((err) => {
        this.logger.error(`Sending emails on creation non sport concussion failed with error: ${err}`);
      });
  }

  async createNonSportOtherInjury(injuryBody: CreateNonSportOtherInjuryBody): Promise<void> {
    const { playerId } = injuryBody;

    const isPlayerExists = await this.userRepo.findIfUserExits({ id: playerId, role: UserRole.Player });

    if (!isPlayerExists) {
      throw new NotFoundException('Player does not exist');
    }

    const isHasAccessToPlayer = await this.injuryRepo.isHasAccessToPlayer(playerId);

    if (!isHasAccessToPlayer) {
      throw new ForbiddenException('User does not have access to create injury for this player');
    }

    const injury = await this.injuryRepo.createNonSportOtherInjury(injuryBody);
    await this.httpService
      .post(`http://${this.configService.aws.mailerHost}/injury/${injury.id}`)
      .toPromise()
      .catch((err) => {
        this.logger.error(`Sending emails on creation non sport other injury failed with error: ${err}`);
      });

    return;
  }

  async createSportOtherInjury(injuryBody: CreateSportOtherInjuryBody): Promise<void> {
    const { playerId } = injuryBody;

    const isPlayerExists = await this.userRepo.findIfUserExits({ id: playerId, role: UserRole.Player });

    if (!isPlayerExists) {
      throw new NotFoundException('Player does not exist');
    }

    const isHasAccessToPlayer = await this.injuryRepo.isHasAccessToPlayer(playerId);

    if (!isHasAccessToPlayer) {
      throw new ForbiddenException('User does not have access to create injury for this player');
    }

    const injury = await this.injuryRepo.createSportOtherInjury(injuryBody);
    await this.httpService
      .post(`http://${this.configService.aws.mailerHost}/injury/${injury.id}`)
      .toPromise()
      .catch((err) => {
        this.logger.error(`Sending emails on creation sport otherinjury failed with error: ${err}`);
      });

    return;
  }

  async updateOtherInjuryStatus(injuryId: string, body: UpdateOtherInjuryStatusBody): Promise<void> {
    const injury = await this.injuryRepo.findInjury({ id: injuryId, injuryGroup: InjuryGroup.Other });

    if (!injury) {
      throw new NotFoundException('Injury does not exists');
    }

    const isHasAccessToPlayer = await this.injuryRepo.isHasAccessToPlayer(injury.user.id);

    if (!isHasAccessToPlayer) {
      throw new ForbiddenException('User does not have access to create injury for this player');
    }

    await this.noteRepo.create(body.noteText, body.isSensitive, injury);

    await this.injuryRepo.updateOtherInjuryStatus(injuryId, { ...body });
    await this.httpService
      .post(`http://${this.configService.aws.mailerHost}/injury/update/${injury.id}`)
      .toPromise()
      .catch((err) => {
        this.logger.error(`Sending emails on update other injury failed with error: ${err}`);
      });

    return;
  }

  async updateInjury(injuryId: string, body: UpdateInjuryBody): Promise<void> {
    const injury = await this.injuryRepo.findInjury({ id: injuryId });

    if (!injury) {
      throw new NotFoundException('Injury does not exists');
    }

    const isHasAccessToPlayer = await this.injuryRepo.isHasAccessToPlayer(injury.user.id);

    if (!isHasAccessToPlayer) {
      throw new ForbiddenException('User does not have access to create injury for this player');
    }

    await this.injuryRepo.updateInjury(injuryId, {
      ...body,
    });
  }

  async updateConcussionInjuryStatus(
    injuryId: string,
    body: UpdateConcussionInjuryStatusBody,
    certificate: IFile
  ): Promise<void> {
    const injury = await this.injuryRepo.findInjury({ id: injuryId, injuryGroup: InjuryGroup.Concussion });

    if (!injury) {
      throw new NotFoundException('Injury does not exists');
    }

    const isHasAccessToPlayer = await this.injuryRepo.isHasAccessToPlayer(injury.user.id);

    if (!isHasAccessToPlayer) {
      throw new ForbiddenException('User does not have access to create injury for this player');
    }

    let certificateLink: string;

    if (certificate) {
      const extension = certificate.mimetype.match(/\w+$/)[0];
      const key = this.getLogoS3Key(injury.id, extension);
      const contentType = getContentType(extension);
      certificateLink = await this.s3Bucket.upload(key, contentType, certificate);
    }

    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const newAssessment = await this.injuryRepo.updateConcussionInjuryStatus(injuryId, {
      ...body,
      injury,
      certificateLink,
    });
    this.httpService
      .post(`http://${this.configService.aws.mailerHost}/assessment/${newAssessment.id}`)
      .toPromise()
      .catch((err) => {
        this.logger.error(`Sending emails on update concussion failed with error: ${err}`);
      });

    return;
  }

  async updateHeadInjuryStatus(injuryId: string, body: UpdateHeadInjuryStatusBody, certificate: IFile): Promise<void> {
    const injury = await this.injuryRepo.findInjury({ id: injuryId, injuryGroup: InjuryGroup.HeadInjury });

    if (!injury) {
      throw new NotFoundException('Injury does not exists');
    }

    const isHasAccessToPlayer = await this.injuryRepo.isHasAccessToPlayer(injury.user.id);

    if (!isHasAccessToPlayer) {
      throw new ForbiddenException('User does not have access to create injury for this player');
    }

    let certificateLink: string;

    if (certificate) {
      const extension = certificate.mimetype.match(/\w+$/)[0];
      const key = this.getLogoS3Key(injury.id, extension);
      const contentType = getContentType(extension);
      certificateLink = await this.s3Bucket.upload(key, contentType, certificate);
    }

    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const newAssessment = await this.injuryRepo.updateHeadInjuryStatus(injuryId, {
      ...body,
      injury,
      certificateLink,
    });
    this.httpService
      .post(`http://${this.configService.aws.mailerHost}/assessment/${newAssessment.id}`)
      .toPromise()
      .catch((err) => {
        this.logger.error(`Sending emails on update concussion failed with error: ${err}`);
      });

    return;
  }

  async getPlayerInjury(injuryId: string, injuryPagination: FindOneInjuryPagination): Promise<GetOneInjuryResponse> {
    const injury = await this.injuryRepo.findInjury({ id: injuryId });
    if (!injury) {
      this.logger.error(`Injury with id: ${injuryId} not found.`);
      throw new NotFoundException('Injury not found');
    }

    const isHasAccessToPlayer = await this.injuryRepo.isHasAccessToPlayer(injury.user.id);
    if (!isHasAccessToPlayer) {
      throw new ForbiddenException('User does not have access to injury of this player');
    }
    const playerInjury = await this.injuryRepo.getPlayerInjury(injury.id, injuryPagination);

    const hasPastAppointment = this.hasAppointmentStatus(playerInjury.appointments, AppointmentStatus.Completed);
    const hasUpcomingAppointment = this.hasAppointmentStatus(playerInjury.appointments, AppointmentStatus.New);

    const hasAdviceUpcomingAppointment = this.hasAppointmentType(
      playerInjury.appointments,
      AppointmentType.ConcussionAdvice
    );
    const hasFollowUpUpcomingAppointment = this.hasAppointmentType(
      playerInjury.appointments,
      AppointmentType.ConcussionFollowUp
    );

    playerInjury.user.hasMembership = checkMembership(
      playerInjury.user.player?.membership,
      playerInjury.user.player?.membershipExpirationDate
    );

    return {
      ...playerInjury,
      hasPastAppointment,
      hasUpcomingAppointment,
      hasAdviceUpcomingAppointment,
      hasFollowUpUpcomingAppointment,
    };
  }

  async findMany(query: InjuryFiltersQuery): Promise<FindManyResponse<InjuryEntity>> {
    const { dateFrom } = query;
    query.dateFrom = dateFrom ? moment(new Date(dateFrom)).subtract(1, 'days').toISOString() : dateFrom;

    const [data, totalItems] = await this.injuryRepo.findMany(query);
    const injuries = data.map((injury) => {
      const hasAdviceUpcomingAppointment = this.hasAppointmentType(
        injury.appointments,
        AppointmentType.ConcussionAdvice
      );

      const hasFollowUpUpcomingAppointment = this.hasAppointmentType(
        injury.appointments,
        AppointmentType.ConcussionFollowUp
      );

      return {
        ...injury,
        hasAdviceUpcomingAppointment,
        hasFollowUpUpcomingAppointment,
      };
    });

    return { data: injuries, totalItems };
  }

  async deleteOne(id: string): Promise<void> {
    const injury = await this.injuryRepo.findInjury({ id, status: Not(InjuryStatus.Deleted) });

    if (!injury) {
      throw new NotFoundException('Injury not found');
    }

    const isHasAccessToPlayer = await this.injuryRepo.isHasAccessToPlayer(injury.user.id);

    if (!isHasAccessToPlayer) {
      throw new ForbiddenException('User does not have access to injury of this player');
    }

    return await this.injuryRepo.deleteInjury(id);
  }

  private getLogoS3Key(id: string, extension: string): string {
    return `certificates/${id}_${new Date().getTime()}.${extension}`;
  }

  private hasAppointmentStatus(appointments: AppointmentEntity[], status: AppointmentStatus): boolean {
    return appointments?.some((appointment) => appointment.status === status);
  }

  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  private hasAppointmentType(appointments: AppointmentEntity[], type: AppointmentType): boolean {
    // appointments.some((appoint) => console.log(appoint?.timeSlot?.clinic?.medicalType));
    return appointments?.some((appointment) => appointment.status === AppointmentStatus.New);
  }
}

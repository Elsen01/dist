import {
  Column,
  CreateDateColumn,
  Entity,
  JoinColumn,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm';
import { InjuryBinarySymptomEntity } from '../../symptoms/entities/injuryBinarySymptom.entity';
import { InjuryOtherSymptomEntity } from '../../symptoms/entities/injuryOtherSymptom.entity';
import { InjuryRedFlagSymptomEntity } from '../../symptoms/entities/injuryRedFlagSymptom.entity';
import { InjurySymptomEntity } from '../../symptoms/entities/injurySymptom.entity';
import { InjuryEntity } from './injury.entity';

@Entity('injury_concussion_symptoms')
export class InjuryConcussionSymptomEntity {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @CreateDateColumn({ name: 'created_at' })
  createdAt: Date;

  @ManyToOne(() => InjuryEntity)
  @JoinColumn({ name: 'injury_id', referencedColumnName: 'id' })
  injury: InjuryEntity;

  @Column({ nullable: true })
  score: number;

  @OneToMany(() => InjuryBinarySymptomEntity, (binarySymptom) => binarySymptom.injury, {
    onDelete: 'CASCADE',
  })
  binarySymptoms?: InjuryBinarySymptomEntity[];

  @OneToMany(() => InjurySymptomEntity, (symptom) => symptom.injury, {
    onDelete: 'CASCADE',
  })
  symptoms?: InjurySymptomEntity[];

  @OneToMany(() => InjuryRedFlagSymptomEntity, (redFlagSymptom) => redFlagSymptom.injury, {
    onDelete: 'CASCADE',
  })
  redFlagSymptoms?: InjuryRedFlagSymptomEntity[];

  @OneToMany(() => InjuryOtherSymptomEntity, (otherSymptom) => otherSymptom.injury, {
    onDelete: 'CASCADE',
  })
  otherSymptoms?: InjuryOtherSymptomEntity[];

  @UpdateDateColumn({ name: 'updated_at' })
  updatedAt: Date;
}

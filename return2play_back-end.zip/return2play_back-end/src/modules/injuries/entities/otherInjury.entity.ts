import { BodySide, InjuryType } from './../types';
import {
  Column,
  CreateDateColumn,
  Entity,
  JoinColumn,
  ManyToOne,
  OneToOne,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm';
import { InjuryCategory } from '../types';
import { BodyPartEntity } from '../../body/entities/bodyPart.entity';
import { InjuryEntity } from './injury.entity';
import { BodyRegionEntity } from '../../body/entities/bodyRegion.entity';

@Entity('other_injuries')
export class OtherInjuryEntity {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ type: 'enum', enum: InjuryCategory })
  category: InjuryCategory;

  @Column({ type: 'enum', enum: InjuryType, nullable: true })
  type: InjuryType;

  @Column({ type: 'enum', enum: BodySide, name: 'body_side' })
  bodySide: BodySide;

  @Column({ length: 1000, name: 'suggested_restrictions', nullable: true })
  suggestedRestrictions: string;

  @OneToOne(() => InjuryEntity, (injury) => injury.otherInjury, { onDelete: 'CASCADE' })
  @JoinColumn({ name: 'injury_id' })
  injury: InjuryEntity;

  @ManyToOne(() => BodyRegionEntity, (bodyRegion) => bodyRegion.otherInjuries, { nullable: false })
  @JoinColumn({ name: 'body_region_id', referencedColumnName: 'id' })
  bodyRegion!: BodyRegionEntity;

  @ManyToOne(() => BodyPartEntity, (bodyPart) => bodyPart.otherInjuries, { nullable: false })
  @JoinColumn({ name: 'body_part_id', referencedColumnName: 'id' })
  bodyPart!: BodyPartEntity;

  @CreateDateColumn({ name: 'created_at' })
  createdAt: Date;

  @UpdateDateColumn({ name: 'updated_at' })
  updatedAt: Date;
}

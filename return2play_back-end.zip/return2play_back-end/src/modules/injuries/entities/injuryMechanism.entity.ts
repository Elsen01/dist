import { SportEntity } from '../../sports/entities/sport.entity';
import {
  Column,
  CreateDateColumn,
  Entity,
  JoinTable,
  ManyToMany,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm';

@Entity('injury_mechanisms')
export class InjuryMechanismEntity {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ length: 255 })
  name: string;

  @ManyToMany(() => SportEntity, (sport) => sport.injuryMechanisms)
  @JoinTable({
    name: 'sport_mechanisms',
    joinColumn: {
      name: 'mechanism_id',
      referencedColumnName: 'id',
    },
    inverseJoinColumn: {
      name: 'sport_id',
      referencedColumnName: 'id',
    },
  })
  sports: SportEntity[];

  @CreateDateColumn({ name: 'created_at' })
  createdAt: Date;

  @UpdateDateColumn({ name: 'updated_at' })
  updatedAt: Date;
}

import { InjuryMechanismEntity } from './injuryMechanism.entity';
import { SportEntity } from '../../sports/entities/sport.entity';
import { Column, Entity, JoinColumn, ManyToOne, OneToOne, PrimaryGeneratedColumn } from 'typeorm';
import { MatchTraining, PlaySide, TimePeriod } from '../types';
import { InjuryEntity } from './injury.entity';
import { OrganizationEntity } from '../../organizations/entities/organization.entity';

@Entity('sport_injuries')
export class SportInjuryEntity {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ name: 'match_training', type: 'enum', enum: MatchTraining, nullable: true })
  matchTraining: MatchTraining;

  @Column({ name: 'play_side', type: 'enum', enum: PlaySide, nullable: true })
  playSide?: PlaySide;

  @Column({ name: 'protective_headgear', nullable: true })
  protectiveHeadgear?: boolean;

  @Column({ name: 'mouth_guard', nullable: true })
  mouthGuard?: boolean;

  @Column({ name: 'time_period', type: 'enum', enum: TimePeriod, nullable: true })
  typePeriod: TimePeriod;

  @OneToOne(() => InjuryEntity, (injury) => injury.sportInjury, {
    onDelete: 'CASCADE',
    nullable: false,
  })
  @JoinColumn({ name: 'injury_id', referencedColumnName: 'id' })
  injury!: InjuryEntity;

  @ManyToOne(() => OrganizationEntity, (organization) => organization.sportInjuries, { nullable: true })
  @JoinColumn({ name: 'organization_id', referencedColumnName: 'id' })
  organization?: OrganizationEntity;

  @ManyToOne(() => SportEntity, { nullable: false })
  @JoinColumn({ name: 'sport_id', referencedColumnName: 'id' })
  sport!: SportEntity;

  @ManyToOne(() => InjuryMechanismEntity, { onDelete: 'CASCADE', nullable: true })
  @JoinColumn({ name: 'mechanism_id', referencedColumnName: 'id' })
  injuryMechanism!: InjuryMechanismEntity;
}

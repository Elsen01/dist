import { ExternalAssessmentEntity } from './../../assessments/entities/externalAssessment.entity';
import { UserEntity } from './../../users/entities/user.entity';
import {
  Column,
  CreateDateColumn,
  Entity,
  JoinColumn,
  ManyToOne,
  OneToMany,
  OneToOne,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm';
import { ActivityType, InjuredAt, InjuryGroup, InjuryStatus, PlayStatus } from '../types';
import { OtherInjuryEntity } from './otherInjury.entity';
import { SportInjuryEntity } from './sportInjury.entity';
import { InjuryConcussionSymptomEntity } from './injuryConcussionSymptom.entity';
import { NoteEntity } from '../../notes/entities/note.entity';
import { AppointmentEntity } from '../../appointments/entities/appointment.entity';

@Entity('injuries')
export class InjuryEntity {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ name: 'injury_group', type: 'enum', enum: InjuryGroup })
  injuryGroup: InjuryGroup;

  @Column({ name: 'activity_type', type: 'enum', enum: ActivityType })
  activityType: ActivityType;

  @Column({ name: 'accident_date', type: 'timestamptz' })
  accidentDate: Date;

  @CreateDateColumn({ name: 'created_at' })
  createdAt: Date;

  @Column({ name: 'injured_at', type: 'enum', enum: InjuredAt, nullable: true })
  injuredAt: InjuredAt;

  @Column({
    name: 'play_status',
    type: 'enum',
    enum: PlayStatus,
    enumName: 'injury_play_status_enum',
    default: PlayStatus.NotSafe,
  })
  playStatus: PlayStatus;

  @Column({ type: 'enum', enum: InjuryStatus, default: InjuryStatus.Active })
  status: InjuryStatus;

  @ManyToOne(() => UserEntity, { eager: true, nullable: false })
  @JoinColumn({ name: 'player_id', referencedColumnName: 'id' })
  user: UserEntity;

  @Column('boolean', { name: 'is_sensitive', default: false })
  isSensitive: boolean;

  @ManyToOne(() => UserEntity, { nullable: true })
  @JoinColumn({ name: 'reporter_id', referencedColumnName: 'id' })
  reporter?: UserEntity;

  @OneToMany(() => NoteEntity, (note) => note.injury)
  notes: NoteEntity[];

  @OneToMany(() => ExternalAssessmentEntity, (externalAssessment) => externalAssessment.injury, { eager: true })
  externalAssessment?: ExternalAssessmentEntity[];

  @OneToMany(() => InjuryConcussionSymptomEntity, (concussionSymptoms) => concussionSymptoms.injury)
  concussionSymptoms?: InjuryConcussionSymptomEntity[];

  @OneToOne(() => OtherInjuryEntity, (otherInjuryEntity) => otherInjuryEntity.injury, {
    onDelete: 'CASCADE',
  })
  otherInjury?: OtherInjuryEntity;

  @OneToOne(() => SportInjuryEntity, (sportInjuryEntity) => sportInjuryEntity.injury, {
    onDelete: 'CASCADE',
  })
  sportInjury?: SportInjuryEntity;

  @OneToMany(() => AppointmentEntity, (appointment) => appointment.injury)
  appointments?: AppointmentEntity[];

  @UpdateDateColumn({ name: 'updated_at' })
  updatedAt: Date;
}

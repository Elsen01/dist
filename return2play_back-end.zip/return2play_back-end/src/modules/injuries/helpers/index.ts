import { BadRequestException } from '@nestjs/common';
import { MulterOptions } from '@nestjs/platform-express/multer/interfaces/multer-options.interface';

export function multerOptions(): MulterOptions {
  const MAX_SIZE_IN_BYTES = 3000000; // 3 MB
  return {
    limits: {
      files: 1,
      fileSize: MAX_SIZE_IN_BYTES,
    },
    fileFilter: (req, file, callback): void => {
      if (!file.originalname.match(/\.(pdf|jpg|jpeg|png)$/)) {
        return callback(new BadRequestException('Only .pdf are allowed!'), false);
      }
      callback(null, true);
    },
  };
}

import { IDocumentedEndpoint } from '../shared/interfaces/swagger.interface';

export const CREATE_NON_SPORT_CONCUSSION: IDocumentedEndpoint = {
  OPERATION: {
    description:
      'Create a new `Injury concussion non-sport` within the system.`Super admins`, `organization admins`, `organization staff`, `parents`, `players` are allowed to perform this action',
  },
  SUCCESS: {
    description: '`Success` Injury was created',
  },
  PLAYER_NOT_FOUND: {
    description: '`API` Provided player not found',
  },
  INJURY_EXISTS: {
    description: '`API` Player with provided id already has concussion injury',
  },
  FORBIDDEN: {
    description: '`API` User has no permissions to create injury',
  },
  FAILURE: {
    description: '`API` Saved entity to the database failed',
  },
};

export const CREATE_SPORT_CONCUSSION: IDocumentedEndpoint = {
  OPERATION: {
    description:
      'Create a new `Injury concussion sport` within the system.`Super admins`, `organization admins`, `organization staff`, `parents`, `players` are allowed to perform this action',
  },
  SUCCESS: {
    description: '`Success` Injury was created',
  },
  PLAYER_NOT_FOUND: {
    description: '`API` Provided player not found',
  },
  INJURY_EXISTS: {
    description: '`API` Player with provided id already has concussion injury',
  },
  FORBIDDEN: {
    description: '`API` User has no permissions to create injury',
  },
  FAILURE: {
    description: '`API` Saved entity to the database failed',
  },
};

export const CREATE_NON_SPORT_OTHER_INJURY: IDocumentedEndpoint = {
  OPERATION: {
    description:
      'Create a new `Other Injury non sport` within the system.`Super admins`, `organization admins`, `organization staff`, `parents`, `players` are allowed to perform this action',
  },
  SUCCESS: {
    description: '`Success` Injury was created',
  },
  PLAYER_NOT_FOUND: {
    description: '`API` Provided player not found',
  },
  FORBIDDEN: {
    description: '`API` User has no permissions to create injury',
  },
  FAILURE: {
    description: '`API` Saved entity to the database failed',
  },
};

export const CREATE_SPORT_OTHER_INJURY: IDocumentedEndpoint = {
  OPERATION: {
    description:
      'Create a new `Other Injury sport` within the system.`Super admins`, `organization admins`, `organization staff`, `parents`, `players` are allowed to perform this action',
  },
  SUCCESS: {
    description: '`Success` Injury was created',
  },
  PLAYER_NOT_FOUND: {
    description: '`API` Provided player not found',
  },
  FORBIDDEN: {
    description: '`API` User has no permissions to create injury',
  },
  FAILURE: {
    description: '`API` Saved entity to the database failed',
  },
};

export const UPDATE_OTHER_INJURY_STATUS: IDocumentedEndpoint = {
  OPERATION: {
    description:
      'Update play status of `Other Injury` within the system.`Super admins`, `organization admins`, `organization staff`, `parents`, `players` are allowed to perform this action',
  },
  SUCCESS: {
    description: '`Success` Injury status was updated',
  },
  INJURY_NOT_FOUND: {
    description: '`API` Provided other injury not found',
  },
  FORBIDDEN: {
    description: '`API` User has no permissions to update injury',
  },
  FAILURE: {
    description: '`API` Saved entity to the database failed',
  },
};

export const UPDATE_CONCUSSION_INJURY_STATUS: IDocumentedEndpoint = {
  OPERATION: {
    description:
      'Update play status of `Concussion Injury` within the system.`Super admins`, `organization admins`, `organization staff`, `parents`, `players` are allowed to perform this action',
  },
  SUCCESS: {
    description: '`Success` Injury status was updated',
  },
  INJURY_NOT_FOUND: {
    description: '`API` Provided other injury not found',
  },
  FORBIDDEN: {
    description: '`API` User has no permissions to update injury',
  },
  FAILURE: {
    description: '`API` Saved entity to the database failed',
  },
};

export const UPDATE_HEAD_INJURY_STATUS: IDocumentedEndpoint = {
  OPERATION: {
    description:
      'Update play status of `Head Injury` within the system.`Super admins`, `organization admins`, `organization staff`, `parents`, `players` are allowed to perform this action',
  },
  SUCCESS: {
    description: '`Success` Injury status was updated',
  },
  INJURY_NOT_FOUND: {
    description: '`API` Provided other injury not found',
  },
  FORBIDDEN: {
    description: '`API` User has no permissions to update injury',
  },
  FAILURE: {
    description: '`API` Saved entity to the database failed',
  },
};

export const GET_PLAYER_INJURY_DETAILS: IDocumentedEndpoint = {
  OPERATION: {
    description:
      'Get details of `Injury` of a certain player.`Super admins`, `organization admins`, `organization staff`, `parents`, `players` are allowed to perform this action',
  },
  SUCCESS: {
    description: '`Success` Player info is returned',
  },
  INJURY_NOT_FOUND: {
    description: '`API` Injury is not found within the system',
  },
  FORBIDDEN: {
    description: '`API` User has no permissions to get this injury info',
  },
  FAILURE: {
    description: '`API` Error occurs during select an entity',
  },
};

export const GET_INJURY_LIST: IDocumentedEndpoint = {
  OPERATION: {
    description:
      'Get `Injury` list of all players or a certain player.`Super admins`, `organization admins`, `organization staff`, `parents`, `players` are allowed to perform this action',
  },
  SUCCESS: {
    description: '`Success` Injury list is returned',
  },
  FORBIDDEN: {
    description: '`API` User has no permissions to get injury list',
  },
  FAILURE: {
    description: '`API` Error occurs during select an entity',
  },
};

export const DELETE_INJURY: IDocumentedEndpoint = {
  OPERATION: {
    description:
      'Delete `Injury` change status of injury from `Active` to `Deleted`.`Super admins`, `organization admins` are allowed to perform this action',
  },
  SUCCESS: {
    description: '`Success` Injury deleted',
  },
  FORBIDDEN: {
    description: '`API` User has no permissions to delete injury',
  },
  FAILURE: {
    description: '`API` Error occurs during update an entity',
  },
};

import { NoteEntity } from '../notes/entities/note.entity';
import { UserEntity } from '../users/entities/user.entity';
import { CreateBinarySymptom, CreateOtherSymptom, CreateRedFlagSymptom, CreateSymptom } from './dtos/create-injury.dto';
import { UpdateConcussionInjuryStatusBody } from './dtos/update-injury.dto';
import { InjuryEntity } from './entities/injury.entity';
import { InjuryConcussionSymptomEntity } from './entities/injuryConcussionSymptom.entity';

export enum InjuryGroup {
  Concussion = 'Concussion',
  Other = 'Other',
  HeadInjury = 'Head Injury (possible concussion)',
}

export enum InjuryCategory {
  NewInjury = 'New Injury',
  AggravatedOldInjury = 'Aggravated old injury',
  Overuse = 'Overuse',
  Biomechanical = 'Biomechanical',
  Idiopathic = 'Idiopathic',
}

export enum InjuryType {
  GrazeAbrasion = 'Graze/Abrasion',
  BruiseContusion = 'Bruise/Contusion',
  Blister = 'Blister',
  CrushInjury = 'Crush injury',
  CutLaceration = 'Cut/Laceration',
  Dislocation = 'Dislocation',
  FractureBrokenBone = 'Fracture/Broken bone',
  SprainLigaments = 'Sprain (ligaments)',
  StrainMuscle = 'Strain (muscle)',
}

export enum BodySide {
  Left = 'Left',
  Right = 'Right',
  NA = 'N/A',
}

export enum PlayStatus {
  Cleared = 'Cleared',
  Safe = 'Safe to play',
  ReduceActivity = 'Reduced level of activity',
  NotSafe = 'Not safe to play',
}

export enum ActivityType {
  Sport = 'Sport',
  NonSport = 'Non-sport',
}

export enum MatchTraining {
  Match = 'Match',
  Training = 'Training',
}

export enum InjuredAt {
  Home = 'Home',
  SchoolAstro = 'School - Astro',
  SchoolClassroom = 'School - Classroom',
  SchoolCorridor = 'School - Corridor',
  SchoolFields = 'School - Fields',
  SchoolPlayground = 'School - Playground',
  SchoolWoods = 'School - Woods',
  Club = 'Club',
  Other = 'Other',
}

export enum PlaySide {
  Attack = 'Attack',
  Defence = 'Defence',
  NA = 'N/A',
}

export enum TimePeriod {
  FirstQuarter = 'First quarter',
  SecondQuarter = 'Second quarter',
  ThirdPeriod = 'Third quarter',
  FourthPeriod = 'Fourth quarter',
}

export type SaveSymptoms = {
  symptoms: CreateSymptom[];
  redFlagSymptoms: CreateRedFlagSymptom[];
  binarySymptoms: CreateBinarySymptom[];
  otherSymptoms: CreateOtherSymptom[];
};

export enum InjurySortOptions {
  Group = 'injury.injuryGroup',
  Activity = 'injury.activityType',
  Status = 'injury.playStatus',
  Organization = 'org.name',
  InjuryDate = 'injury.accidentDate',
}

export enum InjuryStatus {
  Active = 'Active',
  Deleted = 'Deleted',
}

export type GetOneInjuryNotesSymptomsPagination = Omit<InjuryEntity, 'notes' | 'concussionSymptoms' | 'user'> & {
  notes: { data: NoteEntity[]; totalItems: number };
} & {
  concussionSymptoms: { data: InjuryConcussionSymptomEntity[]; totalItems: number };
  user: UserEntity & { hasMembership?: boolean };
};

export type GetOneInjuryResponse = GetOneInjuryNotesSymptomsPagination & {
  hasPastAppointment: boolean;
  hasUpcomingAppointment: boolean;
  hasAdviceUpcomingAppointment: boolean;
  hasFollowUpUpcomingAppointment: boolean;
};

export type UpdateConcussionInjuryStatus = UpdateConcussionInjuryStatusBody & {
  certificateLink?: string;
  injury: InjuryEntity;
};

import { SymptomGradation } from '../../symptoms/types';
import { Type } from 'class-transformer';
import {
  InjuredAt,
  PlaySide,
  TimePeriod,
  MatchTraining,
  BodySide,
  InjuryType,
  InjuryCategory,
  PlayStatus,
} from '../types';
import {
  IsArray,
  IsBoolean,
  IsDateString,
  IsEnum,
  IsNotEmpty,
  IsOptional,
  IsString,
  IsUUID,
  MaxLength,
  ValidateNested,
} from 'class-validator';

export class CreateNonSportConcussionBody {
  @IsUUID()
  playerId: string;

  @IsEnum(InjuredAt)
  injuredAt: InjuredAt;

  @IsDateString()
  accidentDate: Date;

  @IsOptional()
  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => CreateSymptom)
  symptoms: CreateSymptom[];

  @IsBoolean()
  @IsOptional()
  isSensitive?: boolean;

  @IsOptional()
  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => CreateRedFlagSymptom)
  redFlagSymptoms: CreateRedFlagSymptom[];

  @IsOptional()
  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => CreateBinarySymptom)
  binarySymptoms: CreateBinarySymptom[];

  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => CreateOtherSymptom)
  @IsOptional()
  otherSymptoms: CreateOtherSymptom[];

  @IsString()
  @IsNotEmpty()
  noteText: string;
}

export class CreateSportConcussionBody {
  @IsUUID()
  playerId: string;

  @IsDateString()
  accidentDate: Date;

  @IsEnum(MatchTraining)
  matchTraining: MatchTraining;

  @IsEnum(PlaySide)
  playSide?: PlaySide;

  @IsBoolean()
  @IsOptional()
  protectiveHeadgear?: boolean;

  @IsBoolean()
  @IsOptional()
  mouthGuard?: boolean;

  @IsBoolean()
  @IsOptional()
  isSensitive?: boolean;

  @IsEnum(TimePeriod)
  typePeriod: TimePeriod;

  @IsUUID()
  @IsOptional()
  organizationId?: string;

  @IsUUID()
  sportId: string;

  @IsUUID()
  mechanismId: string;

  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => CreateSymptom)
  @IsOptional()
  symptoms: CreateSymptom[];

  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => CreateRedFlagSymptom)
  @IsOptional()
  redFlagSymptoms: CreateRedFlagSymptom[];

  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => CreateBinarySymptom)
  @IsOptional()
  binarySymptoms: CreateBinarySymptom[];

  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => CreateOtherSymptom)
  @IsOptional()
  otherSymptoms: CreateOtherSymptom[];

  @IsString()
  @IsNotEmpty()
  noteText: string;
}

export class CreateNonSportOtherInjuryBody {
  @IsUUID()
  playerId: string;

  @IsEnum(InjuredAt)
  injuredAt: InjuredAt;

  @IsDateString()
  accidentDate: Date;

  @IsEnum(BodySide)
  bodySide: BodySide;

  @IsEnum(PlayStatus)
  playStatus: PlayStatus;

  @IsBoolean()
  @IsOptional()
  isSensitive?: boolean;

  @IsUUID()
  bodyRegionId: string;

  @IsUUID()
  bodyPartId: string;

  @IsEnum(InjuryType)
  type: InjuryType;

  @IsEnum(InjuryCategory)
  category: InjuryCategory;

  @IsString()
  @MaxLength(1000)
  @IsOptional()
  suggestedRestrictions?: string;

  @IsString()
  @IsNotEmpty()
  noteText: string;
}

export class CreateSportOtherInjuryBody {
  @IsUUID()
  playerId: string;

  @IsEnum(MatchTraining)
  matchTraining: MatchTraining;

  @IsEnum(PlaySide)
  playSide?: PlaySide;

  @IsBoolean()
  @IsOptional()
  protectiveHeadgear?: boolean;

  @IsBoolean()
  @IsOptional()
  mouthGuard?: boolean;

  @IsBoolean()
  @IsOptional()
  isSensitive?: boolean;

  @IsEnum(TimePeriod)
  typePeriod: TimePeriod;

  @IsUUID()
  @IsOptional()
  organizationId?: string;

  @IsUUID()
  sportId: string;

  @IsUUID()
  mechanismId: string;

  @IsDateString()
  accidentDate: Date;

  @IsEnum(PlayStatus)
  playStatus: PlayStatus;

  @IsEnum(BodySide)
  bodySide: BodySide;

  @IsUUID()
  bodyRegionId: string;

  @IsUUID()
  bodyPartId: string;

  @IsEnum(InjuryType)
  type: InjuryType;

  @IsEnum(InjuryCategory)
  category: InjuryCategory;

  @IsString()
  @MaxLength(1000)
  @IsNotEmpty()
  @IsOptional()
  suggestedRestrictions?: string;

  @IsString()
  @IsNotEmpty()
  noteText: string;
}

export class CreateSymptom {
  @IsUUID()
  id: string;

  @IsEnum(SymptomGradation)
  value: SymptomGradation;
}

export class CreateRedFlagSymptom {
  @IsUUID()
  id: string;

  @IsBoolean()
  isPresent: boolean;
}

export class CreateBinarySymptom {
  @IsUUID()
  id: string;

  @IsBoolean()
  isPresent: boolean;
}

export class CreateOtherSymptom {
  @IsUUID()
  id: string;

  @IsString()
  @MaxLength(255)
  @IsNotEmpty()
  value: string;
}

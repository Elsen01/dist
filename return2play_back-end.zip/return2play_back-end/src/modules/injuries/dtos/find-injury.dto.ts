import { InjurySortOptions, PlayStatus } from './../types';
import { IsEnum, IsOptional, IsString, MinLength, MaxLength, IsUUID, IsDateString, IsNumber } from 'class-validator';

import { Type } from 'class-transformer';
import { PaginationDto } from '../../shared/shared.dto';
import { Order } from '../../shared/types';

export class InjuryFiltersQuery extends PaginationDto {
  @IsEnum(InjurySortOptions)
  @IsOptional()
  sort? = InjurySortOptions.InjuryDate;

  @IsEnum(Order)
  @IsOptional()
  order? = Order.DESC;

  @IsUUID('all', { each: true })
  @IsOptional()
  sportIds?: string[];

  @IsString()
  @MinLength(1)
  @MaxLength(100)
  @IsOptional()
  searchWord?: string;

  @IsUUID('all', { each: true })
  @IsOptional()
  organizationIds?: string[];

  @IsUUID('all', { each: true })
  @IsOptional()
  playerIds?: string[];

  @IsDateString()
  @IsOptional()
  dateFrom?: string;

  @IsDateString()
  @IsOptional()
  dateTo?: string;

  @IsUUID()
  @IsOptional()
  excludeInjuryId?: string;

  @IsEnum(PlayStatus, { each: true })
  @IsOptional()
  playStatus?: PlayStatus[];
}

export class FindOneInjuryPagination {
  @IsNumber()
  @Type(() => Number)
  notesLimit: number;

  @IsNumber()
  @Type(() => Number)
  notesPage: number;

  @IsNumber()
  @Type(() => Number)
  symptomsLimit: number;

  @IsNumber()
  @Type(() => Number)
  symptomsPage: number;
}

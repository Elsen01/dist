import { ApiPropertyOptional } from '@nestjs/swagger';
import { IsBoolean, IsDateString, IsEnum, IsNotEmpty, IsOptional, IsString, MaxLength } from 'class-validator';
import { InjuryGroup, PlayStatus } from '../types';

export class UpdateOtherInjuryStatusBody {
  @IsEnum(PlayStatus)
  playStatus: PlayStatus;

  @IsBoolean()
  @IsOptional()
  isSensitive?: boolean;

  @IsString()
  @IsNotEmpty()
  noteText: string;
}

export class UpdateInjuryBody {
  @IsEnum(InjuryGroup)
  injuryGroup: InjuryGroup;
}

export class UpdateConcussionInjuryStatusBody {
  @IsString()
  @IsNotEmpty()
  noteText: string;

  @IsString()
  @MaxLength(255)
  @IsNotEmpty()
  doctorFirstName: string;

  @IsBoolean()
  @IsOptional()
  isSensitive?: boolean;

  @IsString()
  @MaxLength(255)
  @IsNotEmpty()
  doctorLastName: string;

  @IsEnum(PlayStatus)
  newPlayStatus: PlayStatus;

  @ApiPropertyOptional({ type: 'file' })
  @IsOptional()
  certificate: any;

  @IsDateString()
  appointmentDate: Date;
}

export class UpdateInjuryStatusBody {
  @IsOptional()
  attendStatus: string;
}

export class UpdateHeadInjuryStatusBody {
  @IsString()
  @IsNotEmpty()
  noteText: string;

  @IsString()
  @MaxLength(255)
  @IsNotEmpty()
  doctorFirstName: string;

  @IsString()
  @MaxLength(255)
  @IsNotEmpty()
  doctorLastName: string;

  @IsBoolean()
  @IsOptional()
  isSensitive?: boolean;

  @IsEnum(PlayStatus)
  newPlayStatus: PlayStatus;

  @ApiPropertyOptional({ type: 'file' })
  @IsOptional()
  certificate: any;

  @IsDateString()
  appointmentDate: Date;
}

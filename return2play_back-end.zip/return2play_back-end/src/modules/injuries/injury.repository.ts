import { NotFoundException, UnprocessableEntityException } from '@nestjs/common';
import { EntityRepository, FindConditions, ObjectLiteral, QueryRunner, SelectQueryBuilder } from 'typeorm';
import { ExternalAssessmentEntity } from '../assessments/entities/externalAssessment.entity';
import { BodyPartEntity } from '../body/entities/bodyPart.entity';
import { BodyRegionEntity } from '../body/entities/bodyRegion.entity';
import { NoteEntity } from '../notes/entities/note.entity';
import { NoteRepository } from '../notes/note.repository';
import { OrganizationEntity } from '../organizations/entities/organization.entity';
import { PlayerEntity } from '../players/entities/player.entity';
import { BaseRepository } from '../shared/base.repository';
import { RoleManager } from '../shared/helpers/accessManager/role.manager';
import { getEntityInstance, stringToArray } from '../shared/utils/common.utils';
import { SportEntity } from '../sports/entities/sport.entity';
import { SymptomRepository } from '../symptoms/symptom.repository';
import { UserEntity } from '../users/entities/user.entity';
import { UserRole } from '../users/types';
import {
  CreateNonSportConcussionBody,
  CreateNonSportOtherInjuryBody,
  CreateSportConcussionBody,
  CreateSportOtherInjuryBody,
} from './dtos/create-injury.dto';
import { FindOneInjuryPagination, InjuryFiltersQuery } from './dtos/find-injury.dto';
import { UpdateInjuryBody, UpdateOtherInjuryStatusBody } from './dtos/update-injury.dto';
import { InjuryEntity } from './entities/injury.entity';
import { InjuryConcussionSymptomEntity } from './entities/injuryConcussionSymptom.entity';
import { InjuryMechanismEntity } from './entities/injuryMechanism.entity';
import { OtherInjuryEntity } from './entities/otherInjury.entity';
import { SportInjuryEntity } from './entities/sportInjury.entity';
import {
  ActivityType,
  GetOneInjuryNotesSymptomsPagination,
  InjuryGroup,
  InjuryStatus,
  PlayStatus,
  UpdateConcussionInjuryStatus,
} from './types';

@EntityRepository(InjuryEntity)
export class InjuryRepository extends BaseRepository<InjuryEntity> {
  private readonly roleManager = RoleManager.getInstance();

  async createNonSportConcussion(concussion: CreateNonSportConcussionBody): Promise<InjuryEntity> {
    const reporter = getEntityInstance(this.roleManager.userId, UserEntity);
    const user = getEntityInstance(concussion.playerId, UserEntity);

    const createNew = async (runner: QueryRunner): Promise<InjuryEntity> => {
      const injury = await runner.manager
        .getRepository(InjuryEntity)
        .save({
          ...concussion,
          reporter,
          user,
          activityType: ActivityType.NonSport,
          injuryGroup: InjuryGroup.Concussion,
          playStatus: PlayStatus.NotSafe,
        })
        .catch((err) => {
          throw new UnprocessableEntityException(err.message);
        });

      if (concussion.symptoms) {
        const concussionSymptoms = await runner.manager
          .getCustomRepository(SymptomRepository)
          .calculateAndSaveSymptom(runner, concussion.symptoms, injury);

        await runner.manager
          .getCustomRepository(SymptomRepository)
          .saveSymptoms(runner, concussionSymptoms, concussion);
      }

      await runner.manager
        .getCustomRepository(NoteRepository)
        .create(concussion.noteText, concussion.isSensitive, injury);

      return injury;
    };

    return await this.runTransaction(createNew);
  }

  async createSportConcussion(concussion: CreateSportConcussionBody): Promise<InjuryEntity> {
    const reporter = getEntityInstance(this.roleManager.userId, UserEntity);

    const user = getEntityInstance(concussion.playerId, UserEntity);

    const organization = getEntityInstance(concussion.organizationId, OrganizationEntity);

    const sport = getEntityInstance(concussion.sportId, SportEntity);

    const injuryMechanism = getEntityInstance(concussion.mechanismId, InjuryMechanismEntity);

    const createNew = async (runner: QueryRunner): Promise<InjuryEntity> => {
      const injury = await runner.manager.getRepository(InjuryEntity).save({
        ...concussion,
        reporter,
        user,
        activityType: ActivityType.Sport,
        injuryGroup: InjuryGroup.Concussion,
        playStatus: PlayStatus.NotSafe,
      });

      const sportInjury = { ...concussion, sport, organization, injuryMechanism, injury };

      !organization.id ? delete sportInjury.organization : null;

      await runner.manager.getRepository(SportInjuryEntity).save(sportInjury);

      const concussionSymptoms = await runner.manager
        .getCustomRepository(SymptomRepository)
        .calculateAndSaveSymptom(runner, concussion.symptoms, injury);

      await runner.manager.getCustomRepository(SymptomRepository).saveSymptoms(runner, concussionSymptoms, concussion);

      await runner.manager
        .getCustomRepository(NoteRepository)
        .create(concussion.noteText, concussion.isSensitive, injury);

      return injury;
    };

    return await this.runTransaction(createNew);
  }

  async createNonSportHeadInjury(headInjury: CreateNonSportConcussionBody): Promise<InjuryEntity> {
    const reporter = getEntityInstance(this.roleManager.userId, UserEntity);

    const user = getEntityInstance(headInjury.playerId, UserEntity);

    const createNew = async (runner: QueryRunner): Promise<InjuryEntity> => {
      const injury = await runner.manager
        .getRepository(InjuryEntity)
        .save({
          ...headInjury,
          reporter,
          user,
          activityType: ActivityType.NonSport,
          injuryGroup: InjuryGroup.HeadInjury,
          playStatus: PlayStatus.NotSafe,
        })
        .catch((err) => {
          throw new UnprocessableEntityException(err.message);
        });

      if (headInjury.symptoms) {
        const headInjurySymptoms = await runner.manager
          .getCustomRepository(SymptomRepository)
          .calculateAndSaveSymptom(runner, headInjury.symptoms, injury);

        await runner.manager
          .getCustomRepository(SymptomRepository)
          .saveSymptoms(runner, headInjurySymptoms, headInjury);
      }

      await runner.manager
        .getCustomRepository(NoteRepository)
        .create(headInjury.noteText, headInjury.isSensitive, injury);

      return injury;
    };

    return await this.runTransaction(createNew);
  }

  async createSportHeadInjury(headInjury: CreateSportConcussionBody): Promise<InjuryEntity> {
    const reporter = getEntityInstance(this.roleManager.userId, UserEntity);
    const user = getEntityInstance(headInjury.playerId, UserEntity);
    const organization = getEntityInstance(headInjury.organizationId, OrganizationEntity);
    const sport = getEntityInstance(headInjury.sportId, SportEntity);
    const injuryMechanism = getEntityInstance(headInjury.mechanismId, InjuryMechanismEntity);

    const createNew = async (runner: QueryRunner): Promise<InjuryEntity> => {
      const injury = await runner.manager.getRepository(InjuryEntity).save({
        ...headInjury,
        reporter,
        user,
        activityType: ActivityType.Sport,
        injuryGroup: InjuryGroup.HeadInjury,
        playStatus: PlayStatus.NotSafe,
      });

      const sportInjury = { ...headInjury, organization, sport, injuryMechanism, injury };

      !organization.id ? delete sportInjury.organization : null;

      await runner.manager.getRepository(SportInjuryEntity).save(sportInjury);

      const headInjurySymptoms = await runner.manager
        .getCustomRepository(SymptomRepository)
        .calculateAndSaveSymptom(runner, headInjury.symptoms, injury);

      await runner.manager.getCustomRepository(SymptomRepository).saveSymptoms(runner, headInjurySymptoms, headInjury);

      await runner.manager
        .getCustomRepository(NoteRepository)
        .create(headInjury.noteText, headInjury.isSensitive, injury);

      return injury;
    };

    return await this.runTransaction(createNew);
  }

  async createNonSportOtherInjury(injuryBody: CreateNonSportOtherInjuryBody): Promise<InjuryEntity> {
    const reporter = getEntityInstance(this.roleManager.userId, UserEntity);
    const user = getEntityInstance(injuryBody.playerId, UserEntity);
    const bodyRegion = getEntityInstance(injuryBody.bodyRegionId, BodyRegionEntity);
    const bodyPart = getEntityInstance(injuryBody.bodyPartId, BodyPartEntity);

    const createNew = async (runner: QueryRunner): Promise<InjuryEntity> => {
      const injury = await runner.manager
        .getRepository(InjuryEntity)
        .save({
          ...injuryBody,
          reporter,
          activityType: ActivityType.NonSport,
          injuryGroup: InjuryGroup.Other,
          user,
        })
        .catch((err) => {
          throw new UnprocessableEntityException(err.message);
        });

      await runner.manager.getRepository(OtherInjuryEntity).save({ ...injuryBody, injury, bodyRegion, bodyPart });

      await runner.manager
        .getCustomRepository(NoteRepository)
        .create(injuryBody.noteText, injuryBody.isSensitive, injury);

      if (injuryBody.suggestedRestrictions) {
        await runner.manager
          .getCustomRepository(NoteRepository)
          .create(injuryBody.suggestedRestrictions, injuryBody.isSensitive, injury);
      }

      return injury;
    };

    return await this.runTransaction(createNew);
  }

  async createSportOtherInjury(injuryBody: CreateSportOtherInjuryBody): Promise<InjuryEntity> {
    const reporter = getEntityInstance(this.roleManager.userId, UserEntity);
    const user = getEntityInstance(injuryBody.playerId, UserEntity);
    const bodyRegion = getEntityInstance(injuryBody.bodyRegionId, BodyRegionEntity);
    const bodyPart = getEntityInstance(injuryBody.bodyPartId, BodyPartEntity);
    const organization = getEntityInstance(injuryBody.organizationId, OrganizationEntity);
    const sport = getEntityInstance(injuryBody.sportId, SportEntity);
    const injuryMechanism = getEntityInstance(injuryBody.mechanismId, InjuryMechanismEntity);

    const createNew = async (runner: QueryRunner): Promise<InjuryEntity> => {
      const injury = await runner.manager.getRepository(InjuryEntity).save({
        ...injuryBody,
        reporter,
        activityType: ActivityType.Sport,
        injuryGroup: InjuryGroup.Other,
        user,
      });

      const sportInjury = { ...injuryBody, organization, sport, injuryMechanism, injury };

      !organization.id ? delete sportInjury.organization : null;

      await runner.manager.getRepository(SportInjuryEntity).save(sportInjury);

      await runner.manager.getRepository(OtherInjuryEntity).save({ ...injuryBody, injury, bodyRegion, bodyPart });

      await runner.manager
        .getCustomRepository(NoteRepository)
        .create(injuryBody.noteText, injuryBody.isSensitive, injury);

      if (injuryBody.suggestedRestrictions) {
        await runner.manager
          .getCustomRepository(NoteRepository)
          .create(injuryBody.suggestedRestrictions, injuryBody.isSensitive, injury);
      }

      return injury;
    };

    return await this.runTransaction(createNew);
  }

  async updateOtherInjuryStatus(id: string, body: UpdateOtherInjuryStatusBody): Promise<void> {
    const { playStatus, noteText } = body;

    const updateTransaction = async (runner: QueryRunner): Promise<void> => {
      const author = getEntityInstance(this.roleManager.userId, UserEntity);

      const injury = getEntityInstance(id, InjuryEntity);

      await runner.manager.save(NoteEntity, { injury, text: noteText, author });

      await runner.manager.update(InjuryEntity, id, { playStatus }).catch((err) => {
        throw new UnprocessableEntityException(err.message);
      });
    };

    return this.runTransaction(updateTransaction);
  }

  async findInjuryWithLastAppointment(injuryId: string): Promise<InjuryEntity> {
    return this.repository
      .createQueryBuilder('injury')
      .leftJoinAndSelect('injury.appointments', 'appointment')
      .leftJoinAndSelect('appointment.timeSlot', 'timeSlot')
      .where('injury.id = :injuryId', { injuryId })
      .orderBy('timeSlot.date', 'DESC')
      .addOrderBy('timeSlot.startTime', 'DESC')
      .getOne();
  }

  async updateInjury(id: string, body: UpdateInjuryBody): Promise<void> {
    const { injuryGroup } = body;
    const updateTransaction = async (runner: QueryRunner): Promise<void> => {
      await runner.manager.update(InjuryEntity, id, { injuryGroup });

      return;
    };

    return await this.runTransaction(updateTransaction);
  }

  async updateConcussionInjuryStatus(
    id: string,
    body: UpdateConcussionInjuryStatus
  ): Promise<ExternalAssessmentEntity> {
    const { newPlayStatus, noteText, injury } = body;
    const updateTransaction = async (runner: QueryRunner): Promise<ExternalAssessmentEntity> => {
      const assessment = await runner.manager.save(ExternalAssessmentEntity, { ...body });

      await runner.manager.update(InjuryEntity, id, { playStatus: newPlayStatus });

      const author = getEntityInstance(this.roleManager.userId, UserEntity);
      await runner.manager.save(NoteEntity, { injury, text: noteText, author });

      return assessment;
    };

    return await this.runTransaction(updateTransaction);
  }

  async updateHeadInjuryStatus(id: string, body: UpdateConcussionInjuryStatus): Promise<ExternalAssessmentEntity> {
    const { newPlayStatus, noteText, injury } = body;
    const updateTransaction = async (runner: QueryRunner): Promise<ExternalAssessmentEntity> => {
      const assessment = await runner.manager.save(ExternalAssessmentEntity, { ...body });

      await runner.manager.update(InjuryEntity, id, { playStatus: newPlayStatus });

      const author = getEntityInstance(this.roleManager.userId, UserEntity);
      await runner.manager.save(NoteEntity, { injury, text: noteText, author });

      return assessment;
    };

    return await this.runTransaction(updateTransaction);
  }

  async isPlayerPartOfOrganization(playerId: string, organizationId: string): Promise<boolean> {
    const player = await this.getRepositoryFor(UserEntity)
      .createQueryBuilder('user')
      .select('user.id')
      .leftJoin('user.organizations', 'org')
      .where('user.id = :playerId', { playerId })
      .andWhere('org.id = :organizationId', { organizationId })
      .getOne();

    return Boolean(player);
  }

  public async isHasAccessToPlayer(playerId: string): Promise<boolean> {
    const isSuperAdminDoctor =
      this.roleManager.role === UserRole.SuperAdmin || this.roleManager.role === UserRole.Doctor;
    if (isSuperAdminDoctor) {
      return true;
    }

    if (this.roleManager.role === UserRole.Player) {
      return playerId === this.roleManager.userId;
    }

    if (this.roleManager.role === UserRole.Parent) {
      const player = await this.createQueryBuilderFor(PlayerEntity, 'player')
        .select('player.userId')
        .leftJoin('player.parents', 'parent')
        .where('player.userId = :playerId', { playerId })
        .andWhere('parent.id = :parentId', { parentId: this.roleManager.userId })
        .getOne();

      return Boolean(player);
    } else {
      const orgIds = await this.getOrganizationIds(this.roleManager.userId);

      const player = await this.createQueryBuilderFor(UserEntity, 'user')
        .select('user.id')
        .leftJoin('user.organizations', 'org')
        .where('user.id = :playerId', { playerId })
        .andWhere('org.id IN (:...orgIds)', { orgIds })
        .getOne();

      return Boolean(player);
    }
  }

  async deleteInjury(id: string): Promise<void> {
    await this.repository.update(id, { status: InjuryStatus.Deleted }).catch((err) => {
      throw new UnprocessableEntityException(err.message);
    });

    return;
  }

  async findInjury(
    condition: string | ObjectLiteral | FindConditions<InjuryEntity> | FindConditions<InjuryEntity>[]
  ): Promise<InjuryEntity> {
    return await this.repository
      .findOne({
        where: condition,
      })
      .catch((err) => {
        throw new UnprocessableEntityException(err.message);
      });
  }

  async findInjuryForAppointment(
    condition: string | ObjectLiteral | FindConditions<InjuryEntity> | FindConditions<InjuryEntity>[] | any | void
  ): Promise<InjuryEntity> {
    const queryBuilder = this.repository.createQueryBuilder('injury');
    return await queryBuilder
      .where('id = :id', { id: condition.id })
      .orWhere('injury_group IN (:...injuryGroup)', {
        injuryGroup: [InjuryGroup.Concussion, InjuryGroup.HeadInjury],
      })
      .orWhere('play_status IN (:...playStatus)', {
        playStatus: [PlayStatus.ReduceActivity, PlayStatus.NotSafe],
      })
      .getOne()
      .catch((err) => {
        throw new UnprocessableEntityException(err.message);
      });
  }

  findActiveHeadInjury(playerId: string): Promise<InjuryEntity[]> {
    return this.repository
      .createQueryBuilder('injury')
      .leftJoin('injury.user', 'user')
      .where('user.id = :playerId', { playerId })
      .andWhere('injury.injuryGroup = :injuryGroup', { injuryGroup: InjuryGroup.HeadInjury })
      .andWhere('injury.status = :injuryStatus', { injuryStatus: InjuryStatus.Active })
      .andWhere('(injury.playStatus <> :cleared', {
        cleared: PlayStatus.Cleared,
      })
      .andWhere('injury.playStatus <> :safe)', { safe: PlayStatus.Safe })
      .getMany();
  }

  findActiveConcussion(playerId: string): Promise<InjuryEntity[]> {
    return this.repository
      .createQueryBuilder('injury')
      .leftJoin('injury.user', 'user')
      .where('user.id = :playerId', { playerId })
      .andWhere('injury.injuryGroup = :injuryGroup', { injuryGroup: InjuryGroup.Concussion })
      .andWhere('injury.status = :injuryStatus', { injuryStatus: InjuryStatus.Active })
      .andWhere('(injury.playStatus <> :cleared', {
        cleared: PlayStatus.Cleared,
      })
      .andWhere('injury.playStatus <> :safe)', { safe: PlayStatus.Safe })
      .getMany();
  }

  async findMany(query: InjuryFiltersQuery): Promise<[InjuryEntity[], number]> {
    const selectQuery = this.getSelectQueryFindMany(query);

    const playerIds = await this.getPlayersIdByAccessRights(stringToArray(query.playerIds));

    const isSuperAdminDoctor =
      this.roleManager.role === UserRole.SuperAdmin || this.roleManager.role === UserRole.Doctor;

    selectQuery.andWhere(playerIds?.length ? 'user.id IN (:...playerIds)' : `${isSuperAdminDoctor}`, { playerIds });

    return await selectQuery.getManyAndCount().catch((err) => {
      throw new UnprocessableEntityException(err.message);
    });
  }

  async getPlayerInjury(
    injuryId: string,
    injuryPagination: FindOneInjuryPagination
  ): Promise<GetOneInjuryNotesSymptomsPagination> {
    const { notesLimit, notesPage, symptomsLimit, symptomsPage } = injuryPagination;
    try {
      const injury: InjuryEntity = await this.repository
        .createQueryBuilder('injury')
        .innerJoinAndSelect('injury.user', 'user')
        .leftJoinAndSelect('user.organizations', 'org')
        .leftJoinAndSelect('injury.appointments', 'appointment')
        .leftJoinAndSelect('appointment.timeSlot', 'timeSlot')
        .leftJoinAndSelect('timeSlot.clinic', 'clinic')
        .leftJoinAndSelect('user.player', 'player')
        .leftJoinAndSelect('injury.reporter', 'reporter')
        .leftJoinAndSelect('injury.sportInjury', 'si')
        .leftJoinAndSelect('si.sport', 's')
        .leftJoinAndSelect('si.organization', 'organization')
        .leftJoinAndSelect('si.injuryMechanism', 'im')
        .leftJoinAndSelect('injury.otherInjury', 'oi')
        .leftJoinAndSelect('oi.bodyPart', 'bp')
        .leftJoinAndSelect('oi.bodyRegion', 'br')
        .where('injury.id = :injuryId', { injuryId })
        .andWhere('injury.status != :status', { status: InjuryStatus.Deleted })
        .getOne();

      if (!injury) {
        throw new NotFoundException('Injury not found');
      }

      const notesResponse = await this.getRepositoryFor(NoteEntity)
        .createQueryBuilder('notes')
        .leftJoinAndSelect('notes.author', 'author')
        .where({ injury: injuryId })
        .orderBy('notes.createdAt', 'DESC')
        .skip(notesLimit * notesPage)
        .take(notesLimit)
        .getManyAndCount();

      const symptomsResponse = await this.getRepositoryFor(InjuryConcussionSymptomEntity)
        .createQueryBuilder('concussionSymptoms')
        .leftJoinAndSelect('concussionSymptoms.symptoms', 'symptoms')
        .leftJoinAndSelect('symptoms.symptom', 'symptom')
        .leftJoinAndSelect('concussionSymptoms.binarySymptoms', 'binarySymptoms')
        .leftJoinAndSelect('binarySymptoms.binarySymptom', 'binarySymptom')
        .leftJoinAndSelect('concussionSymptoms.redFlagSymptoms', 'redFlagSymptoms')
        .leftJoinAndSelect('redFlagSymptoms.redFlagSymptom', 'redFlagSymptom')
        .leftJoinAndSelect('concussionSymptoms.otherSymptoms', 'otherSymptoms')
        .leftJoinAndSelect('otherSymptoms.otherSymptom', 'otherSymptom')
        .where({ injury: injuryId })
        .orderBy('concussionSymptoms.createdAt', 'DESC')
        .skip(symptomsLimit * symptomsPage)
        .take(symptomsLimit)
        .getManyAndCount();

      return {
        ...injury,
        notes: { data: notesResponse[0], totalItems: notesResponse[1] },
        concussionSymptoms: { data: symptomsResponse[0], totalItems: symptomsResponse[1] },
      };
    } catch (err) {
      return err;
    }
  }

  async findInjuryByConcussionSymptomId(id: string): Promise<InjuryEntity> {
    return this.createQueryBuilder('injury')
      .leftJoinAndSelect('injury.concussionSymptoms', 'concussionSymptom')
      .leftJoinAndSelect('injury.user', 'player')
      .where('concussionSymptom.id = :id', { id })
      .andWhere('injury.status <> :status', { status: InjuryStatus.Deleted })
      .getOne();
  }

  private getSelectQueryFindMany(query: InjuryFiltersQuery): SelectQueryBuilder<InjuryEntity> {
    const {
      organizationIds,
      sportIds,
      dateFrom,
      dateTo,
      sort,
      order,
      page,
      limit,
      searchWord,
      excludeInjuryId,
      playStatus,
    } = query;
    const organizationIdArray = stringToArray(organizationIds);
    const sportIdArray = stringToArray(sportIds);
    const playStatusArray = stringToArray(playStatus);

    const [firstName, lastName] = searchWord ? searchWord?.split(' ', 2) : '';

    return this.repository
      .createQueryBuilder('injury')
      .addSelect(['org.id', 'org.name'])
      .leftJoinAndSelect('injury.user', 'user')
      .leftJoinAndSelect('injury.appointments', 'appointment')
      .leftJoinAndSelect('appointment.timeSlot', 'timeSlot')
      .leftJoinAndSelect('timeSlot.clinic', 'clinic')
      .leftJoinAndSelect('user.player', 'player')
      .leftJoinAndSelect('injury.reporter', 'reporter')
      .leftJoin('user.organizations', 'organizations')
      .leftJoinAndSelect('injury.sportInjury', 'si')
      .leftJoinAndSelect('injury.otherInjury', 'oi')
      .leftJoin('si.organization', 'org')
      .leftJoinAndSelect('si.sport', 'sport')
      .where(sportIdArray ? 'sport.id IN (:...sportIdArray)' : 'true', { sportIdArray })
      .andWhere(organizationIdArray?.length ? 'organizations.id IN (:...orgIds)' : 'true', {
        orgIds: organizationIdArray,
      })
      .andWhere(dateFrom ? 'injury.accidentDate > :dateFrom' : 'true', { dateFrom })
      .andWhere(dateTo ? 'injury.accidentDate < :dateTo' : 'true', { dateTo })
      .andWhere(
        searchWord
          ? `(to_tsvector('simple', f_concat_ws(' ', user.firstName , user.lastName))
          @@ plainto_tsquery('simple', :searchWord) OR user.firstName ILIKE :searchWord OR user.lastName ILIKE :searchWord OR 
          (user.firstName ILIKE :firstName AND user.lastName ILIKE :lastName) OR (user.lastName ILIKE :firstName AND user.firstName ILIKE :lastName))`
          : 'true',
        {
          searchWord: `%${searchWord}%`,
          firstName: `%${firstName}%`,
          lastName: `%${lastName}%`,
        }
      )
      .andWhere('injury.status <> :status', { status: InjuryStatus.Deleted })
      .andWhere(excludeInjuryId ? 'injury.id <> :excludeInjuryId' : 'true', { excludeInjuryId })
      .andWhere(playStatusArray?.length ? 'injury.playStatus IN (:...playStatusArray)' : 'true', { playStatusArray })
      .orderBy(sort, order)
      .skip(limit * page)
      .take(limit);
  }

  private async getPlayersIdByAccessRights(playerIds: string[]): Promise<string[]> {
    try {
      const isSuperAdminDoctor =
        this.roleManager.role === UserRole.SuperAdmin || this.roleManager.role === UserRole.Doctor;

      if (isSuperAdminDoctor) {
        return playerIds;
      }

      if (this.roleManager.role === UserRole.Player) {
        return [this.roleManager.userId];
      }

      if (this.roleManager.role === UserRole.Parent) {
        const players = await this.createQueryBuilderFor(PlayerEntity, 'player')
          .select('player.userId')
          .leftJoin('player.parents', 'parent')
          .andWhere('parent.id = :parentId', { parentId: this.roleManager.userId })
          .getMany();

        const playersToReturn = playerIds?.length
          ? players.filter((player) => playerIds.includes(player.userId))
          : players;

        return playersToReturn.map((res) => res.userId);
      } else {
        const orgIds = await this.getOrganizationIds(this.roleManager.userId);

        const players = await this.createQueryBuilderFor(UserEntity, 'user')
          .select('user.id')
          .leftJoin('user.organizations', 'org')
          .where('user.role = :role', { role: UserRole.Player })
          .andWhere('org.id IN (:...orgIds)', { orgIds })
          .getMany();

        const playersToReturn = playerIds?.length ? players.filter((player) => playerIds.includes(player.id)) : players;

        return playersToReturn.map((res) => res.id);
      }
    } catch (err) {
      throw new UnprocessableEntityException(err.message);
    }
  }

  private async getOrganizationIds(userId: string): Promise<string[]> {
    const res = await this.getRepositoryFor(OrganizationEntity)
      .createQueryBuilder('org')
      .select('org.id')
      .leftJoin('org.users', 'user')
      .where('user.id = :userId', { userId })
      .getMany()
      .catch((err) => {
        throw new UnprocessableEntityException(err.message);
      });

    return res.map((org) => org.id);
  }
}

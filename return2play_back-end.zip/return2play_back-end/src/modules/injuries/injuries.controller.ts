import {
  Body,
  Controller,
  Delete,
  Get,
  HttpCode,
  HttpStatus,
  Param,
  Post,
  Put,
  Query,
  UploadedFile,
  UseGuards,
  UseInterceptors,
} from '@nestjs/common';
import { FileInterceptor } from '@nestjs/platform-express';
import {
  ApiBearerAuth,
  ApiConflictResponse,
  ApiConsumes,
  ApiForbiddenResponse,
  ApiNoContentResponse,
  ApiNotFoundResponse,
  ApiOkResponse,
  ApiOperation,
  ApiTags,
  ApiUnprocessableEntityResponse,
} from '@nestjs/swagger';
import { Roles } from '../shared/decorators/roles.decorator';
import { CognitoGuard } from '../shared/guards/cognito.guard';
import { RolesGuard } from '../shared/guards/roles.guard';
import { IFile } from '../shared/helpers/s3bucket/types';
import { IdDto } from '../shared/shared.dto';
import { FindManyResponse } from '../shared/types';
import { UserRole } from '../users/types';
import {
  CreateNonSportConcussionBody,
  CreateNonSportOtherInjuryBody,
  CreateSportConcussionBody,
  CreateSportOtherInjuryBody,
} from './dtos/create-injury.dto';
import { FindOneInjuryPagination, InjuryFiltersQuery } from './dtos/find-injury.dto';
import {
  UpdateConcussionInjuryStatusBody,
  UpdateHeadInjuryStatusBody,
  UpdateInjuryBody,
  UpdateOtherInjuryStatusBody,
} from './dtos/update-injury.dto';
import { InjuryEntity } from './entities/injury.entity';
import { multerOptions } from './helpers';
import { InjuriesService } from './injuries.service';
import {
  CREATE_NON_SPORT_CONCUSSION,
  CREATE_NON_SPORT_OTHER_INJURY,
  CREATE_SPORT_CONCUSSION,
  CREATE_SPORT_OTHER_INJURY,
  DELETE_INJURY,
  GET_INJURY_LIST,
  GET_PLAYER_INJURY_DETAILS,
  UPDATE_CONCUSSION_INJURY_STATUS,
  UPDATE_HEAD_INJURY_STATUS,
  UPDATE_OTHER_INJURY_STATUS,
} from './swagger';
import { GetOneInjuryResponse } from './types';

@ApiTags('Injuries')
@UseGuards(CognitoGuard, RolesGuard)
@Roles(UserRole.SuperAdmin, UserRole.OrganizationAdmin, UserRole.MedicalStaff, UserRole.Doctor)
@ApiBearerAuth()
@Controller('injuries')
export class InjuriesController {
  constructor(private service: InjuriesService) {}

  @ApiOperation(CREATE_NON_SPORT_CONCUSSION.OPERATION)
  @ApiNoContentResponse(CREATE_NON_SPORT_CONCUSSION.SUCCESS)
  @ApiForbiddenResponse(CREATE_NON_SPORT_CONCUSSION.FORBIDDEN)
  @ApiUnprocessableEntityResponse(CREATE_NON_SPORT_CONCUSSION.FAILURE)
  @ApiNotFoundResponse(CREATE_NON_SPORT_CONCUSSION.PLAYER_NOT_FOUND)
  @ApiConflictResponse(CREATE_NON_SPORT_CONCUSSION.INJURY_EXISTS)
  @HttpCode(HttpStatus.NO_CONTENT)
  @Roles(UserRole.Parent, UserRole.Player, UserRole.StaffUser)
  @Post('/concussion/nonsport')
  createNonSportConcussion(@Body() body: CreateNonSportConcussionBody): Promise<void> {
    return this.service.createNonSportConcussion(body);
  }

  @ApiOperation(CREATE_SPORT_CONCUSSION.OPERATION)
  @ApiNoContentResponse(CREATE_SPORT_CONCUSSION.SUCCESS)
  @ApiForbiddenResponse(CREATE_SPORT_CONCUSSION.FORBIDDEN)
  @ApiUnprocessableEntityResponse(CREATE_SPORT_CONCUSSION.FAILURE)
  @ApiNotFoundResponse(CREATE_SPORT_CONCUSSION.PLAYER_NOT_FOUND)
  @ApiConflictResponse(CREATE_SPORT_CONCUSSION.INJURY_EXISTS)
  @HttpCode(HttpStatus.NO_CONTENT)
  @Roles(UserRole.Parent, UserRole.Player, UserRole.StaffUser)
  @Post('/concussion/sport')
  createSportConcussion(@Body() body: CreateSportConcussionBody): Promise<void> {
    return this.service.createSportConcussion(body);
  }

  @ApiOperation(CREATE_SPORT_OTHER_INJURY.OPERATION)
  @ApiNoContentResponse(CREATE_SPORT_OTHER_INJURY.SUCCESS)
  @ApiForbiddenResponse(CREATE_SPORT_OTHER_INJURY.FORBIDDEN)
  @ApiUnprocessableEntityResponse(CREATE_SPORT_OTHER_INJURY.FAILURE)
  @ApiNotFoundResponse(CREATE_SPORT_OTHER_INJURY.PLAYER_NOT_FOUND)
  @HttpCode(HttpStatus.NO_CONTENT)
  @Roles(UserRole.Parent, UserRole.Player, UserRole.StaffUser)
  @Post('headinjury/sport')
  createSportHeadInjury(@Body() body: CreateSportConcussionBody): Promise<void> {
    return this.service.createSportHeadInjury(body);
  }

  @ApiOperation(CREATE_NON_SPORT_CONCUSSION.OPERATION)
  @ApiNoContentResponse(CREATE_NON_SPORT_CONCUSSION.SUCCESS)
  @ApiForbiddenResponse(CREATE_NON_SPORT_CONCUSSION.FORBIDDEN)
  @ApiUnprocessableEntityResponse(CREATE_NON_SPORT_CONCUSSION.FAILURE)
  @ApiNotFoundResponse(CREATE_NON_SPORT_CONCUSSION.PLAYER_NOT_FOUND)
  @ApiConflictResponse(CREATE_NON_SPORT_CONCUSSION.INJURY_EXISTS)
  @HttpCode(HttpStatus.NO_CONTENT)
  @Roles(UserRole.Parent, UserRole.Player, UserRole.StaffUser)
  @Post('headinjury/nonsport')
  createNonSportHeadInjury(@Body() body: CreateNonSportConcussionBody): Promise<void> {
    return this.service.createNonSportHeadInjury(body);
  }

  @ApiOperation(UPDATE_OTHER_INJURY_STATUS.OPERATION)
  @ApiNoContentResponse(UPDATE_OTHER_INJURY_STATUS.SUCCESS)
  @ApiForbiddenResponse(UPDATE_OTHER_INJURY_STATUS.FORBIDDEN)
  @ApiUnprocessableEntityResponse(UPDATE_OTHER_INJURY_STATUS.FAILURE)
  @ApiNotFoundResponse(UPDATE_OTHER_INJURY_STATUS.INJURY_NOT_FOUND)
  @HttpCode(HttpStatus.NO_CONTENT)
  @Roles(UserRole.Parent, UserRole.Player, UserRole.StaffUser)
  @Put(':id')
  async updateInjury(@Param() param: IdDto, @Body() body: UpdateInjuryBody): Promise<void> {
    return await this.service.updateInjury(param.id, body);
  }

  @ApiOperation(CREATE_NON_SPORT_OTHER_INJURY.OPERATION)
  @ApiNoContentResponse(CREATE_NON_SPORT_OTHER_INJURY.SUCCESS)
  @ApiForbiddenResponse(CREATE_NON_SPORT_OTHER_INJURY.FORBIDDEN)
  @ApiUnprocessableEntityResponse(CREATE_NON_SPORT_OTHER_INJURY.FAILURE)
  @ApiNotFoundResponse(CREATE_NON_SPORT_OTHER_INJURY.PLAYER_NOT_FOUND)
  @HttpCode(HttpStatus.NO_CONTENT)
  @Roles(UserRole.Parent, UserRole.Player, UserRole.StaffUser)
  @Post('/other/nonsport')
  createNonSportOtherInjury(@Body() body: CreateNonSportOtherInjuryBody): Promise<void> {
    return this.service.createNonSportOtherInjury(body);
  }

  @ApiOperation(CREATE_SPORT_OTHER_INJURY.OPERATION)
  @ApiNoContentResponse(CREATE_SPORT_OTHER_INJURY.SUCCESS)
  @ApiForbiddenResponse(CREATE_SPORT_OTHER_INJURY.FORBIDDEN)
  @ApiUnprocessableEntityResponse(CREATE_SPORT_OTHER_INJURY.FAILURE)
  @ApiNotFoundResponse(CREATE_SPORT_OTHER_INJURY.PLAYER_NOT_FOUND)
  @HttpCode(HttpStatus.NO_CONTENT)
  @Roles(UserRole.Parent, UserRole.Player, UserRole.StaffUser)
  @Post('other/sport')
  createSportOtherInjury(@Body() body: CreateSportOtherInjuryBody): Promise<void> {
    return this.service.createSportOtherInjury(body);
  }

  @ApiOperation(UPDATE_OTHER_INJURY_STATUS.OPERATION)
  @ApiNoContentResponse(UPDATE_OTHER_INJURY_STATUS.SUCCESS)
  @ApiForbiddenResponse(UPDATE_OTHER_INJURY_STATUS.FORBIDDEN)
  @ApiUnprocessableEntityResponse(UPDATE_OTHER_INJURY_STATUS.FAILURE)
  @ApiNotFoundResponse(UPDATE_OTHER_INJURY_STATUS.INJURY_NOT_FOUND)
  @HttpCode(HttpStatus.NO_CONTENT)
  @Roles(UserRole.Parent, UserRole.Player, UserRole.StaffUser)
  @Put('/other/:id')
  async updateOtherInjuryStatus(@Param() param: IdDto, @Body() body: UpdateOtherInjuryStatusBody): Promise<void> {
    return await this.service.updateOtherInjuryStatus(param.id, body);
  }

  @ApiOperation(UPDATE_CONCUSSION_INJURY_STATUS.OPERATION)
  @ApiNoContentResponse(UPDATE_CONCUSSION_INJURY_STATUS.SUCCESS)
  @ApiForbiddenResponse(UPDATE_CONCUSSION_INJURY_STATUS.FORBIDDEN)
  @ApiUnprocessableEntityResponse(UPDATE_CONCUSSION_INJURY_STATUS.FAILURE)
  @ApiNotFoundResponse(UPDATE_CONCUSSION_INJURY_STATUS.INJURY_NOT_FOUND)
  @HttpCode(HttpStatus.NO_CONTENT)
  @Roles(UserRole.Parent, UserRole.Player, UserRole.StaffUser)
  @ApiConsumes('multipart/form-data')
  @UseInterceptors(FileInterceptor('certificate', multerOptions()))
  @Put('/concussion/:id')
  async updateConcussionInjuryStatus(
    @Param() param: IdDto,
    @Body() body: UpdateConcussionInjuryStatusBody,
    @UploadedFile() certificate: IFile
  ): Promise<void> {
    return await this.service.updateConcussionInjuryStatus(param.id, body, certificate);
  }

  @ApiOperation(UPDATE_HEAD_INJURY_STATUS.OPERATION)
  @ApiNoContentResponse(UPDATE_HEAD_INJURY_STATUS.SUCCESS)
  @ApiForbiddenResponse(UPDATE_HEAD_INJURY_STATUS.FORBIDDEN)
  @ApiUnprocessableEntityResponse(UPDATE_HEAD_INJURY_STATUS.FAILURE)
  @ApiNotFoundResponse(UPDATE_HEAD_INJURY_STATUS.INJURY_NOT_FOUND)
  @HttpCode(HttpStatus.NO_CONTENT)
  @Roles(UserRole.Parent, UserRole.Player, UserRole.StaffUser)
  @ApiConsumes('multipart/form-data')
  @UseInterceptors(FileInterceptor('certificate', multerOptions()))
  @Put('/headinjury/:id')
  async updateHeadInjuryStatus(
    @Param() param: IdDto,
    @Body() body: UpdateHeadInjuryStatusBody,
    @UploadedFile() certificate: IFile
  ): Promise<void> {
    return await this.service.updateHeadInjuryStatus(param.id, body, certificate);
  }

  @ApiOperation(GET_PLAYER_INJURY_DETAILS.OPERATION)
  @ApiOkResponse(GET_PLAYER_INJURY_DETAILS.SUCCESS)
  @ApiForbiddenResponse(GET_PLAYER_INJURY_DETAILS.FORBIDDEN)
  @ApiUnprocessableEntityResponse(GET_PLAYER_INJURY_DETAILS.FAILURE)
  @ApiNotFoundResponse(GET_PLAYER_INJURY_DETAILS.INJURY_NOT_FOUND)
  @HttpCode(HttpStatus.OK)
  @Roles(UserRole.Parent, UserRole.Player, UserRole.StaffUser, UserRole.Doctor)
  @Get('/:id')
  getPlayerInjury(
    @Query() injuryPagination: FindOneInjuryPagination,
    @Param() param: IdDto
  ): Promise<GetOneInjuryResponse> {
    return this.service.getPlayerInjury(param.id, injuryPagination);
  }

  @ApiOperation(GET_INJURY_LIST.OPERATION)
  @ApiOkResponse(GET_INJURY_LIST.SUCCESS)
  @ApiForbiddenResponse(GET_INJURY_LIST.FORBIDDEN)
  @ApiUnprocessableEntityResponse(GET_INJURY_LIST.FAILURE)
  @Roles(UserRole.Parent, UserRole.Player, UserRole.StaffUser, UserRole.Doctor)
  @Get()
  findMany(@Query() query: InjuryFiltersQuery): Promise<FindManyResponse<InjuryEntity>> {
    return this.service.findMany(query);
  }

  @ApiOperation(DELETE_INJURY.OPERATION)
  @ApiNoContentResponse(DELETE_INJURY.SUCCESS)
  @ApiForbiddenResponse(DELETE_INJURY.FORBIDDEN)
  @ApiUnprocessableEntityResponse(DELETE_INJURY.FAILURE)
  @HttpCode(HttpStatus.NO_CONTENT)
  @Roles(UserRole.Parent, UserRole.Player, UserRole.StaffUser)
  @Delete('/:id')
  async deleteOne(@Param() param: IdDto): Promise<void> {
    return await this.service.deleteOne(param.id);
  }
}

import { IsNotEmpty } from 'class-validator';

export class SocsBody {
  @IsNotEmpty()
  signature: any;
}

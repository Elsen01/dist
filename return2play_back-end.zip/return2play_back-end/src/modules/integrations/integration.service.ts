import { ImportsManager } from '../shared/helpers/imports/imports.manager';
import { WondeStudentEntity } from '../players/entities/wondeStudent.entity';
import { WondeSchoolEntity } from '../organizations/entities/wondeSchool.entity';
import { OrganizationRepository } from '../organizations/organizations.repository';
import { UserEntity } from '../users/entities/user.entity';
import {
  Inject,
  Injectable,
  InternalServerErrorException,
  Logger,
  LoggerService,
  NotFoundException,
  UnauthorizedException,
  UnprocessableEntityException,
} from '@nestjs/common';
import { Wonde } from '../shared/helpers/wonde/wonde.manager';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Gender, UserRole } from '../users/types';
import { OrganizationStatus, OrganizationType } from '../organizations/types';

import { PlayerImportDto } from '../imports/dto/import-player.dto';
import { SocsResponse, WondeWebhookBody } from './types';
import { callPromisesSequentially } from '../shared/utils/common.utils';
import { InjuryCategory, InjuryStatus, PlayStatus } from '../injuries/types';
import { TagRepository } from '../tags/tags.repository';
import { uniqBy } from 'lodash';
import { UserRepository } from '../users/users.repository';
import { NewTag } from '../players/dtos/create-player.dto';

@Injectable()
export class IntegrationService {
  constructor(
    private wonde: Wonde,
    @InjectRepository(UserEntity)
    private userRepo: Repository<UserEntity>,
    @InjectRepository(WondeSchoolEntity)
    private wondeSchoolRepo: Repository<WondeSchoolEntity>,
    @InjectRepository(WondeStudentEntity)
    private wondeStudentRepo: Repository<WondeStudentEntity>,
    private organizationRepo: OrganizationRepository,
    private tagRepo: TagRepository,
    @Inject(Logger)
    private logger: LoggerService,
    private importsManager: ImportsManager,
    private customUserRepo: UserRepository
  ) {}

  async synchronizeUsersBySchool(schoolId: string): Promise<void> {
    try {
      const school = await this.organizationRepo.findWondeSchoolById(schoolId);

      if (!school) {
        this.logger.error(`School with wonde id: ${schoolId} not found`);
        throw new NotFoundException('School not found');
      }

      const {
        wondeId,
        lastUpdate,
        organization: { id: organizationId },
      } = school;

      const students = await this.wonde.getAllStudentsBySchool(wondeId, lastUpdate.toDateString());
      //const employees = await this.wonde.getAllEmployeesBySchool(wondeId, lastUpdate.toDateString());

      const [existentTags] = await this.tagRepo.findMany({ limit: null, page: 0, organizationIds: [organizationId] });

      const playerImport: PlayerImportDto[] = students.map((student) => {
        const employeeIds = student.classes?.data.reduce((acc, cl) => {
          const ids = cl.employees?.data.map((employee) => employee.id);

          return [...acc, ...ids];
        }, [] as string[]);

        if (student.year?.data?.employees?.data?.length) {
          employeeIds.push(...student.year.data.employees.data.map((em) => em?.id));
        }

        //const employeesDetails = employees.filter((value) => employeeIds.includes(value.id));

        // const additional: AdditionalRecipientImportDto[] = employeesDetails.map((emp) => ({
        //   email: emp.contact_details.data.emails.email,
        //   firstName: emp.forename,
        //   lastName: emp.surname,
        // }));

        const parents = student.contacts.data
          .filter((p) => p.contact_details.data.emails.email)
          .map((parent) =>
            this.userRepo.create({
              email: parent.contact_details.data.emails.email,
              firstName: parent.forename ?? 'Mr/Mrs',
              lastName: parent.surname ?? 'Mr/Mrs',
              role: UserRole.Parent,
            })
          );

        const tags: string[] = [];
        const newTags: NewTag[] = [];
        student.classes?.data.forEach(({ id, name }) => {
          const isExistent = existentTags.find(
            (exTag) => exTag.name === name && exTag.organization.id === organizationId
          );

          isExistent ? tags.push(id) : newTags.push({ name, organizationId });
        });

        const { id: wondeId, mis_id: misId, updated_at, ...restStudent } = student;

        const wondeStudent = this.wondeStudentRepo.create({
          ...restStudent,
          wondeId,
          misId,
          lastUpdate: new Date(),
          wondeLastModify: updated_at.date,
        });

        const gender = student.gender === 'MALE' ? Gender.Male : Gender.Female;

        return {
          email: student.contact_details.data.emails.email,
          parents,
          birthday: student.date_of_birth.date,
          firstName: student.forename,
          lastName: student.surname,
          gender,
          tags,
          newTags,
          wondeStudent,
        };
      });

      const importPlayersEmail = playerImport.map((p) => p.email);
      const parentEmails = playerImport.flatMap((p) => p.parents.map((pr) => pr.email));
      const importParentsEmail = parentEmails.filter((e) => e);

      const wondeStudentNameAndDob = students.reduce((acc, val): string[] => {
        const str = `${val.forename} ${val.surname} ${val.date_of_birth.date.toString().slice(0, -16)}`;
        return [...acc, str];
      }, [] as string[]);

      const existingPlayersByNamesDoB = await this.customUserRepo.findByFistLastNamesAndDoBString(
        wondeStudentNameAndDob,
        school.organization.id
      );

      const existingPlayersByEmail = await this.customUserRepo.findManyPlayerByEmail(importPlayersEmail);

      const existingPlayers = uniqBy(
        [...existingPlayersByEmail, ...existingPlayersByNamesDoB],
        (val) => `${val.firstName} ${val.lastName} ${val.birthday.toString()}`
      );

      const existingPlayersEmail = existingPlayers.map((p) => p.email?.toLowerCase());
      const existingPlayersWondeId = existingPlayers.map((p) => p.wondeStudent?.wondeId);

      const existingPlayersImport = playerImport.filter(
        (p) =>
          existingPlayersEmail.includes(p.email?.toLowerCase()) ||
          existingPlayersWondeId.includes(p.wondeStudent.wondeId)
      );

      return this.organizationRepo.runTransaction(
        this.importsManager.createManyFromWonde,
        playerImport,
        [school.organization.id],
        existingPlayersImport,
        importParentsEmail,
        existingPlayers
      );
    } catch (err) {
      this.logger.error(err);
      throw new UnprocessableEntityException(err.message);
    }
  }

  async synchronizeSchools(): Promise<void> {
    const wondeSchools = await this.wonde.getAllApprovedSchools();

    const organizations = wondeSchools.map((school) => {
      const {
        address_line_1: address1,
        address_line_2: address2,
        address_postcode: postcode,
        address_town: town,
      } = school.address;

      const { id: wondeId, establishment_number: establishmentNumber, la_code: laCode, ...rest } = school;

      const wondeSchool = this.wondeSchoolRepo.create({
        wondeId,
        establishmentNumber,
        laCode,
        lastUpdate: new Date(),
        ...rest,
      });

      return this.organizationRepo.createOne({
        ...rest,
        address1,
        address2,
        postcode,
        town,
        wondeSchool,
        type: OrganizationType.School,
      });
    });

    await this.organizationRepo.saveMany(organizations).catch((err) => {
      throw new UnauthorizedException(err.message);
    });
  }

  async saveSchool(body: WondeWebhookBody): Promise<void> {
    try {
      this.logger.log(`Wonde school synchronization started. School data: ${body}`);

      const { data: wondeSchool } = await this.wonde.getSchoolById(body.school_id);

      const school = await this.organizationRepo.createWondeSchool(wondeSchool);

      await this.synchronizeUsersBySchool(school.wondeSchool.id);
      this.logger.log(`Wonde school synchronization finished.`);
    } catch (err) {
      this.logger.error(`Webhook school synchronization failed. Error: ${err.message}, DataL ${body}`);
      throw new UnprocessableEntityException(err.message);
    }
  }

  async synchronizeAllSchoolUsers(): Promise<void> {
    try {
      const schools = await this.organizationRepo.findWondeSchools({ status: OrganizationStatus.Active });
      const promises = schools.map((school) => this.synchronizeUsersBySchool(school.wondeSchool?.wondeId));

      callPromisesSequentially(promises, (err) =>
        this.logger.error(`Error during cronjob synchronization. ${err.message}`)
      );
    } catch (err) {
      throw new InternalServerErrorException(err.message);
    }
  }

  async socsIntegration(id: string): Promise<SocsResponse[]> {
    const organization = await this.organizationRepo.findOne(id);

    if (!organization) {
      throw new NotFoundException('School not found');
    }

    const socsResponse: SocsResponse[] = organization.users.map((user) => {
      const activeInjury = user.injuries.filter(
        (i) =>
          i.status === InjuryStatus.Active &&
          (i.playStatus === PlayStatus.NotSafe || i.playStatus === PlayStatus.ReduceActivity)
      );

      const injuries = activeInjury.map((injury) => ({
        r2p_injury_id: injury.id,
        date_of_injury: injury.accidentDate,
        injury_category: injury.otherInjury?.category ?? InjuryCategory.NewInjury,
        injury_type: injury.otherInjury?.type ?? injury.injuryGroup,
      }));

      return {
        socs_id: user.player.socsId,
        player_status: user.player.playStatus,
        r2p_person_id: user.id,
        injuries,
      };
    });

    return socsResponse;
  }

  async synchronizeExistingStudents(): Promise<void> {
    const wondeStudents = await this.wonde.getAllStudentsBySchool('A226010872');

    const wondeStudentsEmail = wondeStudents.map((data) => data.contact_details.data.emails.email);

    const wondeStudentNameAndDob = wondeStudents.reduce((acc, val): string[] => {
      const str = `${val.forename} ${val.surname} ${val.date_of_birth.date.toString().slice(0, -16)}`;
      return [...acc, str];
    }, [] as string[]);

    const existingPlayersByNamesDoB = await this.customUserRepo.findByFistLastNamesAndDoBString(
      wondeStudentNameAndDob,
      '5d949e24-7983-43fb-8552-dff0bd53830f'
    );

    const existingPlayersByEmail = await this.customUserRepo.findManyPlayerByEmail(wondeStudentsEmail);

    const existingPlayers = uniqBy([...existingPlayersByEmail, ...existingPlayersByNamesDoB], (val) => val.email);

    const playersToSave: UserEntity[] = [];

    existingPlayers.forEach((exPlayer) => {
      const exPlayerNamesDoB = `${exPlayer.firstName} ${exPlayer.lastName} ${exPlayer.birthday.toString()}`;
      const matchedWondeStudent = wondeStudents.find(
        (ws) => `${ws.forename} ${ws.surname} ${ws.date_of_birth.date.toString().slice(0, -16)}` === exPlayerNamesDoB
      );

      if (matchedWondeStudent && !exPlayer.wondeStudent?.id) {
        const wondeStudent = this.wondeStudentRepo.create({
          wondeId: matchedWondeStudent.id,
          misId: matchedWondeStudent.mis_id,
          lastUpdate: new Date(),
          wondeLastModify: matchedWondeStudent.updated_at.date,
        });

        playersToSave.push({ ...exPlayer, wondeStudent });
      }
    });

    await this.userRepo.save(playersToSave);
  }
}

import { OrganizationRepository } from '../organizations/organizations.repository';
import { UserEntity } from '../users/entities/user.entity';
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { SharedModule } from '../shared/shared.module';
import { IntegrationController } from './integration.controller';
import { IntegrationService } from './integration.service';
import { AdditionalRecipientEntity } from '../additional-recipients/entities/recipient.entity';
import { WondeSchoolEntity } from '../organizations/entities/wondeSchool.entity';
import { WondeStudentEntity } from '../players/entities/wondeStudent.entity';
import { TagRepository } from '../tags/tags.repository';
import { UserRepository } from '../users/users.repository';
import { PlayerEntity } from '../players/entities/player.entity';

@Module({
  controllers: [IntegrationController],
  providers: [IntegrationService],
  imports: [
    SharedModule,
    TypeOrmModule.forFeature([
      PlayerEntity,
      WondeSchoolEntity,
      UserEntity,
      TagRepository,
      AdditionalRecipientEntity,
      OrganizationRepository,
      WondeStudentEntity,
      UserRepository,
    ]),
  ],
})
export class IntegrationModule {}

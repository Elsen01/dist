import { PlayStatus } from '../injuries/types';

export interface WondeWebhookBody {
  payload_type: string;
  school_id: string;
  school_name: string;
  school_token: string;
  school_la_code: string;
  school_urn: string;
  school_establishment_number: string;
}

export interface SocsResponse {
  r2p_person_id: string;
  socs_id?: string;
  player_status: PlayStatus;
  injuries: SocsInjuryResponse[];
}

export interface SocsInjuryResponse {
  r2p_injury_id: string;
  date_of_injury: Date;
  injury_category: string;
  injury_type: string;
}

import { IntegrationService } from './integration.service';
import { Controller, Get, Param, UseGuards } from '@nestjs/common';
import { ApiTags } from '@nestjs/swagger';
import { SocsResponse } from './types';
import { IdDto } from '../shared/shared.dto';
import { SignatureGuard } from '../shared/guards/signature.guard';
//import { Cron } from '@nestjs/schedule';

@ApiTags('Integrations')
@Controller('integrations')
export class IntegrationController {
  constructor(private service: IntegrationService) {}

  @Get('/wonde/students')
  get(): Promise<void> {
    return this.service.synchronizeUsersBySchool('ae722632-6fd0-441c-a4c5-ffef8bb367bb');
  }

  @Get('/wonde/schools')
  synchronizeSchools(): Promise<void> {
    return this.service.synchronizeSchools();
  }

  //@Cron('0 0 4 * * 1-7') -- commented for now, don't want to run synchronization
  @Get('/wonde/all')
  synchronizeAllSchoolUsers(): void {
    this.service.synchronizeAllSchoolUsers();
  }

  // @Post('/wonde/webhook')
  // webhook(@Body() body: WondeWebhookBody): Promise<void> {
  //   return this.service.saveSchool(body);
  // }

  @UseGuards(SignatureGuard)
  @Get('/socs/organization/:id')
  socsIntegration(@Param() param: IdDto): Promise<SocsResponse[]> {
    return this.service.socsIntegration(param.id);
  }

  @Get('/wonde/sync')
  sync(): Promise<void> {
    return this.service.synchronizeExistingStudents();
  }
}

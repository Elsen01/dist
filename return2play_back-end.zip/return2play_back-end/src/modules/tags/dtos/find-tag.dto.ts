import { PaginationDto } from './../../shared/shared.dto';
import { IsBoolean, IsOptional, IsString, IsUUID } from 'class-validator';
import { Transform } from 'class-transformer';

export class TagFiltersQuery extends PaginationDto {
  @IsUUID('all', { each: true })
  @IsOptional()
  organizationIds?: string[];

  @IsUUID()
  @IsOptional()
  playerId?: string;

  @IsBoolean()
  @Transform(({ value }) => {
    switch (value) {
      case 'true':
        return true;
      case 'false':
        return false;
      default:
        return value;
    }
  })
  @IsOptional()
  usedOnly?: boolean;

  @IsString()
  @IsOptional()
  searchName?: string;
}

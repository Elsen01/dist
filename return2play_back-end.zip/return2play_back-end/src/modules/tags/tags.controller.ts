import { TagsService } from './tags.service';
import { Controller, Get, Query, UseGuards } from '@nestjs/common';
import { TagEntity } from './entities/tag.entity';
import { TagFiltersQuery } from './dtos/find-tag.dto';
import {
  ApiBearerAuth,
  ApiForbiddenResponse,
  ApiNotFoundResponse,
  ApiOkResponse,
  ApiOperation,
  ApiTags,
  ApiUnprocessableEntityResponse,
} from '@nestjs/swagger';
import { CognitoGuard } from '../shared/guards/cognito.guard';
import { RolesGuard } from '../shared/guards/roles.guard';
import { Roles } from '../shared/decorators/roles.decorator';
import { UserRole } from '../users/types';
import { GET_MANY } from './swagger';
import { FindManyResponse } from '../shared/types';

@ApiTags('Tags')
@UseGuards(CognitoGuard, RolesGuard)
@Roles(UserRole.SuperAdmin, UserRole.OrganizationAdmin, UserRole.MedicalStaff, UserRole.Parent, UserRole.StaffUser)
@ApiBearerAuth()
@Controller('tags')
export class TagsController {
  constructor(private service: TagsService) {}

  @ApiOperation(GET_MANY.OPERATION)
  @ApiOkResponse({ ...GET_MANY.SUCCESS })
  @ApiNotFoundResponse(GET_MANY.NOT_FOUND)
  @ApiForbiddenResponse(GET_MANY.FORBIDDEN)
  @ApiUnprocessableEntityResponse(GET_MANY.FAILURE)
  @Get()
  findMany(@Query() query: TagFiltersQuery): Promise<FindManyResponse<TagEntity>> {
    return this.service.findMany(query);
  }
}

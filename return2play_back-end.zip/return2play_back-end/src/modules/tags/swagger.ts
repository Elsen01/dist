import { IDocumentedEndpoint } from '../shared/interfaces/swagger.interface';

export const GET_MANY: IDocumentedEndpoint = {
  OPERATION: {
    description:
      'Get list of all tags or tags of particular organizations. Only `super admins` and `organization admins` are allowed to perform this action',
  },
  SUCCESS: {
    description: '`Success` Tags info is returned',
  },
  FAILURE: {
    description: '`API` Error occurs during select an entity',
  },
  NOT_FOUND: {
    description: '`API` Tags are not found within the system',
  },
  FORBIDDEN: {
    description: '`API` User has no permissions to get tags',
  },
};

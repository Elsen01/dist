import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { FindManyResponse } from '../shared/types';
import { TagFiltersQuery } from './dtos/find-tag.dto';
import { TagEntity } from './entities/tag.entity';
import { TagRepository } from './tags.repository';

@Injectable()
export class TagsService {
  constructor(
    @InjectRepository(TagRepository)
    private tagRepo: TagRepository
  ) {}

  async findMany(query: TagFiltersQuery): Promise<FindManyResponse<TagEntity>> {
    const tagsResponse = await this.tagRepo.findMany(query);

    return { data: tagsResponse[0], totalItems: tagsResponse[1] };
  }
}

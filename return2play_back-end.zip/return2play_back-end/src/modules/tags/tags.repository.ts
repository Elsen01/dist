import { UnprocessableEntityException } from '@nestjs/common';
import { AbstractRepository, EntityRepository, QueryRunner } from 'typeorm';
import { OrganizationEntity } from '../organizations/entities/organization.entity';
import { RoleManager } from '../shared/helpers/accessManager/role.manager';
import { getEntityInstance, stringToArray } from '../shared/utils/common.utils';
import { NewTag } from '../users/dtos/create-user.dto';
import { UserRole } from '../users/types';
import { TagFiltersQuery } from './dtos/find-tag.dto';
import { TagEntity } from './entities/tag.entity';

@EntityRepository(TagEntity)
export class TagRepository extends AbstractRepository<TagEntity> {
  private readonly roleManager = RoleManager.getInstance();

  async createMany(tag: { name: string }[]): Promise<TagEntity[]> {
    return await this.repository.save(tag);
  }

  public async getTags(runner: QueryRunner, tags: string[], newTags: NewTag[]): Promise<TagEntity[]> {
    const tagsToSave: TagEntity[] = [];

    if (tags?.length) {
      const newTagsEntity = tags.map((id) => getEntityInstance(id, TagEntity));
      tagsToSave.push(...newTagsEntity);
    }

    if (newTags?.length) {
      const newTagsEntity = (await runner.manager.save(
        TagEntity,
        newTags.map((tag) => ({
          name: tag.name,
          organization: getEntityInstance(tag.organizationId, OrganizationEntity),
        }))
      )) as TagEntity[];

      tagsToSave.push(...newTagsEntity);
    }

    return tagsToSave;
  }

  public async findMany(query: TagFiltersQuery): Promise<[TagEntity[], number]> {
    const { organizationIds, limit, page, playerId, usedOnly, searchName } = query;
    const orgIds = stringToArray(organizationIds);

    const tagQuery = this.repository
      .createQueryBuilder('tag')
      .addSelect('org.id')
      .leftJoin('tag.organization', 'org')
      .leftJoin('tag.users', 'user')
      .where(orgIds?.length ? 'org.id IN (:...orgIds)' : 'true', { orgIds })
      .andWhere(usedOnly ? 'user.id IS NOT NULL' : 'true')
      .andWhere(playerId ? 'user.id = :playerId' : 'true', { playerId })
      .andWhere(searchName ? 'tag.name ILIKE :searchName' : 'true', { searchName: `%${searchName}%` })
      .take(limit)
      .skip(limit * page);

    const isAdmins =
      this.roleManager.role === UserRole.OrganizationAdmin ||
      this.roleManager.role === UserRole.StaffUser ||
      this.roleManager.role === UserRole.MedicalStaff;

    if (isAdmins) {
      const adminOrgIds = await this.getOrganizationIds(this.roleManager.userId);

      tagQuery.andWhere(adminOrgIds.length ? 'org.id IN (:...adminOrgIds)' : 'false', { adminOrgIds: adminOrgIds });
    }

    return tagQuery.getManyAndCount();
  }

  private async getOrganizationIds(userId: string): Promise<string[]> {
    const res = await this.getRepositoryFor(OrganizationEntity)
      .createQueryBuilder('org')
      .select('org.id')
      .leftJoin('org.users', 'user')
      .where('user.id = :userId', { userId })
      .getMany()
      .catch((err) => {
        throw new UnprocessableEntityException(err.message);
      });

    return res.map((org) => org.id);
  }
}

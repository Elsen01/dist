import { HttpModule, MiddlewareConsumer, Module, NestModule } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ScheduleModule } from '@nestjs/schedule';
import configurations from '../config/configurations';
import { AppConfigService } from '../config/config.service';
import { OrganizationsModule } from './organizations/organizations.module';
import { UsersModule } from './users/users.module';
import { AuthModule } from './auth/auth.module';
import { AppController } from './app.controller';
import { PlayersModule } from './players/players.module';
import { DoctorsModule } from './doctors/doctors.module';
import { TagsModule } from './tags/tags.module';
import { InjuriesModule } from './injuries/injuries.module';
import { SportsModule } from './sports/sports.module';
import { NotesModule } from './notes/notes.module';
import { SymptomsModule } from './symptoms/symptoms.module';
import { ClinicsModule } from './clinics/clinics.module';
import { BodyModule } from './body/body.module';
import { ReportsModule } from './reports/reports.module';
import { AppointmentsModule } from './appointments/appointments.module';
import { AssessmentsModule } from './assessments/assessments.module';
import { PaymentsModule } from './payments/payments.module';
import { RecipientsModule } from './additional-recipients/recipients.module';
import { ContextMiddleware } from './middlewares/context.middleware';
import { BullModule } from './bull/bull.module';
import { WondeModule } from './wonde/wonde.module';
import { CognitoModule } from './cognito/cognito.module';
import { IntegrationModule } from './integrations/integration.module';
import { IsamsModule } from './isams/isams.module';
import { MyIPsModule } from './my-ips/my-ips.module';

@Module({
  imports: [
    ConfigModule.forRoot({
      load: [configurations],
      isGlobal: true,
    }),
    HttpModule.registerAsync({ useClass: AppConfigService }),
    TypeOrmModule.forRootAsync({ useClass: AppConfigService }),
    ScheduleModule.forRoot(),
    AuthModule,
    ClinicsModule,
    OrganizationsModule,
    UsersModule,
    PlayersModule,
    DoctorsModule,
    TagsModule,
    InjuriesModule,
    SportsModule,
    NotesModule,
    SymptomsModule,
    BodyModule,
    ReportsModule,
    AppointmentsModule,
    AssessmentsModule,
    PaymentsModule,
    RecipientsModule,
    WondeModule,
    IntegrationModule,
    BullModule,
    CognitoModule,
    IsamsModule,
    MyIPsModule,
  ],
  controllers: [AppController],
})
export class AppModule implements NestModule {
  configure(consumer: MiddlewareConsumer): void {
    consumer.apply(ContextMiddleware).forRoutes('*');
  }
}

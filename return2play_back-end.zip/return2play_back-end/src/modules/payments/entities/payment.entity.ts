import {
  Entity,
  JoinColumn,
  PrimaryGeneratedColumn,
  ManyToOne,
  Column,
  CreateDateColumn,
  UpdateDateColumn,
} from 'typeorm';
import { PlayerEntity } from '../../players/entities/player.entity';

@Entity('payments')
export class PaymentEntity {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ name: 'stripe_customer_id', length: 255 })
  stripeCustomerId: string;

  @Column({ name: 'payment_id', length: 255 })
  paymentId: string;

  @Column({ name: 'payer_email', length: 255 })
  payerEmail: string;

  @CreateDateColumn({ name: 'created_at' })
  createdAt: Date;

  @ManyToOne(() => PlayerEntity, (player) => player.payments, { nullable: false })
  @JoinColumn({ name: 'player_id' })
  player: PlayerEntity;

  @UpdateDateColumn({ name: 'updated_at' })
  updatedAt: Date;
}

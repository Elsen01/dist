import { PlayerEntity } from '../players/entities/player.entity';

export interface CreateSessionResponse {
  sessionId: string;
}

export enum StripeEventType {
  SessionComplete = 'checkout.session.completed',
  InvoicePaid = 'invoice.paid',
  InvoiceFailed = 'invoice.payment_failed',
}

export interface EventObject {
  customer: string;
  customer_email: string;
  metadata: {
    playerId: string;
  };
  payment_intent: string;
}

export interface CreatePayment {
  stripeCustomerId: string;
  paymentId: string;
  payerEmail: string;
  player: PlayerEntity;
  membershipExpirationDate: Date;
}

import { IsEmail, IsNotEmpty, IsOptional, IsUUID } from 'class-validator';

export class CreateSessionBody {
  @IsUUID()
  playerId: string;

  @IsEmail()
  payerEmail: string;

  @IsNotEmpty()
  @IsOptional()
  successUrl: string;

  @IsNotEmpty()
  @IsOptional()
  cancelUrl: string;
}

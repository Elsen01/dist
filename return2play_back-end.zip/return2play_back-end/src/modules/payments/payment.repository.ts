import { EntityRepository, QueryRunner } from 'typeorm';
import { PlayerEntity } from '../players/entities/player.entity';
import { BaseRepository } from '../shared/base.repository';
import { PaymentEntity } from './entities/payment.entity';
import { CreatePayment } from './types';

@EntityRepository(PaymentEntity)
export class PaymentRepository extends BaseRepository<PaymentEntity> {
  async savePayment(payment: CreatePayment): Promise<void> {
    const { membershipExpirationDate, player } = payment;
    const savePayment = async (runner: QueryRunner): Promise<void> => {
      await runner.manager.getRepository(PaymentEntity).save(payment);
      await runner.manager
        .getRepository(PlayerEntity)
        .update(player.userId, { membershipExpirationDate, membership: player.membership });

      return;
    };

    return this.runTransaction(savePayment);
  }
}

import {
  ConflictException,
  HttpService,
  Inject,
  Injectable,
  Logger,
  LoggerService,
  NotFoundException,
  UnprocessableEntityException,
} from '@nestjs/common';
import moment from 'moment';
import Stripe from 'stripe';
import { AppConfigService } from '../../config/config.service';
import { PlayerEntity } from '../players/entities/player.entity';
import { Membership } from '../players/types';
import { checkExpiredMembership } from '../shared/utils/common.utils';
import { PlayerRepository } from './../players/player.repository';
import { StripeManager } from './../shared/helpers/stripe/stripe.manager';
import { CreateSessionBody } from './dtos/create-payment.dto';
import { PaymentRepository } from './payment.repository';
import { CreateSessionResponse, EventObject, StripeEventType } from './types';

@Injectable()
export class PaymentsService {
  constructor(
    private playerRepo: PlayerRepository,
    private paymentRepo: PaymentRepository,
    private stripe: StripeManager,
    private configService: AppConfigService,
    @Inject(Logger) private logger: LoggerService,
    private httpService: HttpService
  ) {}

  async createSession(body: CreateSessionBody): Promise<CreateSessionResponse> {
    const { playerId } = body;
    const player = await this.playerRepo.findOne(playerId);

    if (!player) {
      throw new NotFoundException('Player with provided id does not exist');
    }

    if (player.membership === Membership.School) {
      throw new ConflictException('Player already school member');
    }

    const isHasOpenConcussion = await this.playerRepo.findIsHasOpenInjury(player.userId);

    const priceId =
      isHasOpenConcussion && player.membership === Membership.NonMember
        ? this.configService.stripe.priceId120
        : this.configService.stripe.priceId30;

    const { id: sessionId } = await this.stripe.createCheckoutSession({ ...body, priceId }).catch((err) => {
      throw new UnprocessableEntityException(err.message);
    });

    return { sessionId };
  }

  async handleWebhook(payload: Buffer, signature: string): Promise<void> {
    try {
      const event = this.stripe.createWebhookEvent(payload, signature);

      switch (event.type) {
        case StripeEventType.SessionComplete:
          await this.onSuccessPayment(event);
          break;
        default:
          break;
      }

      return;
    } catch (err) {
      throw new UnprocessableEntityException(err);
    }
  }

  async updateMembershipStatus(): Promise<void> {
    const limit = 10000;
    let page = 0;
    let stop = false;
    const expiredMembers: PlayerEntity[] = [];

    try {
      do {
        const players = await this.playerRepo.findManyForMembershipUpdate(limit, page);

        players.forEach((player) => {
          const isExpired = player.membershipExpirationDate
            ? checkExpiredMembership(player.membershipExpirationDate)
            : false;

          if (isExpired) {
            player.membership = Membership.NonMember;
            expiredMembers.push(player);
          }
        });

        await this.playerRepo.updateMany(expiredMembers);

        if (players.length < limit) {
          stop = true;
        }
        page++;
      } while (!stop);

      if (expiredMembers.length) {
        const playerIds = expiredMembers.map((player) => player.userId);
        await this.httpService
          .post(`http://${this.configService.aws.mailerHost}/membership/expired`, { playerIds })
          .toPromise();
      }

      return;
    } catch (err) {
      this.logger.log(`Update of membership status failed on page: ${page}. Error: ${err.message}`);
    }
  }

  async twoWeeksExpirationHandler(): Promise<void> {
    const limit = 10000;
    let page = 0;
    let stop = false;
    const expiredMembers: PlayerEntity[] = [];

    try {
      do {
        const players = await this.playerRepo.findTwoWeeksMembershipExpiration(limit, page);
        expiredMembers.push(...players);

        if (players.length < limit) {
          stop = true;
        }
        page++;
      } while (!stop);

      if (expiredMembers.length) {
        const playerIds = expiredMembers.map((player) => player.userId);
        await this.httpService
          .post(`http://${this.configService.aws.mailerHost}/membership/renewal`, {
            playerIds,
          })
          .toPromise();
      }
    } catch (err) {
      this.logger.log(`Update of membership status failed on page: ${page}. Error: ${err.message}`);
    }
  }

  async getPriceForPlayer(playerId: string): Promise<{ price: string }> {
    const player = await this.playerRepo.findOne(playerId);

    if (!player) {
      throw new NotFoundException('Player not found');
    }

    const isHasOpenConcussion = await this.playerRepo.findIsHasOpenInjury(playerId);

    const price = isHasOpenConcussion && player.membership === Membership.NonMember ? '120' : '30';

    return { price };
  }

  private async onSuccessPayment(event: Stripe.Event): Promise<void> {
    const {
      customer: stripeCustomerId,
      metadata: { playerId },
      payment_intent: paymentId,
      customer_email: payerEmail,
    } = event.data.object as EventObject;

    try {
      const player = await this.playerRepo.findOne(playerId);

      player.membership = Membership.Regular;

      const membershipExpirationDate = this.getNewMembershipExpirationDate(player.membershipExpirationDate);

      await this.paymentRepo.savePayment({ stripeCustomerId, player, payerEmail, paymentId, membershipExpirationDate });
    } catch (err) {
      this.logger.log(`Error during payment process for player ${payerEmail}: ${err.message}`);
    }
  }

  private getNewMembershipExpirationDate(oldExpirationDate?: Date): Date {
    const createdDate = oldExpirationDate ? moment(oldExpirationDate) : moment(new Date());

    return createdDate.add(1, 'year').toDate();
  }
}

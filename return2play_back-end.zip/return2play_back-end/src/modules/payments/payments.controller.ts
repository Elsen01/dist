import { ALL_ROLES, UserRole } from './../users/types';
import { PaymentsService } from './payments.service';
import { CreateSessionResponse } from './types';
import { Body, Controller, Get, HttpCode, HttpStatus, Post, Req, Param, UseGuards } from '@nestjs/common';
import { CreateSessionBody } from './dtos/create-payment.dto';
import { Request } from 'express';
import { CRON_TWO_WEEKS_EXPIRATION, STRIPE_HEADER } from '../shared/constants';
import { Cron } from '@nestjs/schedule';
import { CRON_UPDATE_MEMBERSHIP } from './../shared/constants';
import { IdDto } from '../shared/shared.dto';
import { CognitoGuard } from '../shared/guards/cognito.guard';
import { RolesGuard } from '../shared/guards/roles.guard';
import { Roles } from '../shared/decorators/roles.decorator';
import { ApiBearerAuth } from '@nestjs/swagger';
import { CognitoManager } from '../shared/helpers/cognito/cognito.manager';

@Controller('payments')
export class PaymentsController {
  constructor(private service: PaymentsService, private cognito: CognitoManager) {}
  @Post('/session')
  createSession(@Body() body: CreateSessionBody): Promise<CreateSessionResponse> {
    return this.service.createSession(body);
  }

  @Post('/webhook')
  @HttpCode(HttpStatus.OK)
  async webhook(@Req() req: Request): Promise<void> {
    const signature = req.headers[STRIPE_HEADER] as string;

    return await this.service.handleWebhook(req.body, signature);
  }

  @UseGuards(CognitoGuard, RolesGuard)
  @Roles(...ALL_ROLES)
  @ApiBearerAuth()
  @Get('/price/:id')
  async priceForPlayer(@Param() param: IdDto): Promise<{ price: string }> {
    return await this.service.getPriceForPlayer(param.id);
  }

  @Get('/test')
  async test(): Promise<string> {
    const res = await this.cognito.listUsersByRole(UserRole.Player);
    const res1 = await this.cognito.listUsersByRole(UserRole.Parent);
    const res2 = await this.cognito.listUsersByRole(UserRole.OrganizationAdmin);
    const res3 = await this.cognito.listUsersByRole(UserRole.StaffUser);
    const res4 = await this.cognito.listUsersByRole(UserRole.SuperAdmin);

    return [...res, ...res1, ...res2, ...res3, ...res4].map((u) => `'${u.Username}'`).join(',');
  }

  @Cron(CRON_UPDATE_MEMBERSHIP)
  updateMembershipStatus(): Promise<void> {
    return this.service.updateMembershipStatus();
  }

  @Cron(CRON_TWO_WEEKS_EXPIRATION)
  checkTwoWeeksExpiration(): Promise<void> {
    return this.service.twoWeeksExpirationHandler();
  }
}

import { NoteEntity } from '../notes/entities/note.entity';
import { InjuryStatus } from '../injuries/types';
import { ExternalAssessmentEntity } from './entities/externalAssessment.entity';
import { RoleManager } from '../shared/helpers/accessManager/role.manager';
import { GrtpEntity } from './entities/grtp.entity';
import { UnprocessableEntityException } from '@nestjs/common';
import { AbstractRepository, DeepPartial, EntityRepository, QueryRunner } from 'typeorm';
import { CreateAssessmentBody } from './dtos/create-assessment.dto';
import { AssessmentEntity } from './entities/assessment.entity';
import { DecidedOutcome, CertificateGenerationResponse } from './types';
import { UserRole } from '../users/types';
import { PlayStatus } from '../injuries/types';
import { QueryDeepPartialEntity } from 'typeorm/query-builder/QueryPartialEntity';
import { AppointmentStatus } from '../appointments/types';
import moment from 'moment';
import { InjuryEntity } from '../injuries/entities/injury.entity';
import { AppointmentEntity } from '../appointments/entities/appointment.entity';

@EntityRepository(AssessmentEntity)
export class AssessmentRepository extends AbstractRepository<AssessmentEntity> {
  private roleManager = RoleManager.getInstance();

  async createOne(
    body: CreateAssessmentBody,
    appointment: AppointmentEntity,
    generateCertificate: (assessment: AssessmentEntity) => Promise<CertificateGenerationResponse> | Promise<any>
  ): Promise<AssessmentEntity> {
    const { decidedOutcome, injuryNote, returnToPlay, startGentlePELessons } = body;
    console.log('salam9');

    const createAssessmentTransition = async (runner: QueryRunner): Promise<AssessmentEntity> => {
      const assessment = await runner.manager.save(AssessmentEntity, {
        ...body,
        appointment,
      });
      console.log('salam10');

      if (decidedOutcome === DecidedOutcome.GRTP) {
        await runner.manager.save(GrtpEntity, { ...body, assessment });
      }
      console.log('salam11');

      if (injuryNote) {
        await runner.manager.save(NoteEntity, {
          author: appointment.doctor.user,
          injury: appointment.injury,
          text: injuryNote,
        });
      }
      console.log('salam12');

      const dateNow = moment(new Date()).utc().format('YYYY-MM-DD');
      console.log('salam13');

      let decidedDate;
      switch (decidedOutcome) {
        case DecidedOutcome.GRTP:
          decidedDate = moment(startGentlePELessons).format('YYYY-MM-DD');
          break;
        case DecidedOutcome.Clear:
          decidedDate = moment(returnToPlay).format('YYYY-MM-DD');
          break;
      }
      console.log('salam14');

      if (decidedDate && decidedDate === dateNow) {
        await this.updateInjuryPlayStatus(decidedOutcome, appointment.injury.id, runner);
      }
      console.log('salam15');

      await runner.manager.update(AppointmentEntity, { id: appointment.id }, { status: AppointmentStatus.Completed });
      console.log({ assessment });

      console.log('salam16');
      const links = await generateCertificate(assessment);
      console.log({ links });

      console.log('salam17');

      await this.manager.getCustomRepository(AssessmentRepository).updateCertificateLinks(assessment.id, links);

      return assessment;
    };

    return await this.runTransaction(createAssessmentTransition);
  }

  async findById(id: string): Promise<AssessmentEntity> {
    return await this.createQueryBuilder('assessment')
      .leftJoinAndSelect('assessment.grtp', 'grtp')
      .leftJoinAndSelect('assessment.appointment', 'appointment')
      .leftJoinAndSelect('appointment.timeSlot', 'timeSlot')
      .leftJoinAndSelect('appointment.doctor', 'doctor')
      .leftJoinAndSelect('doctor.user', 'docUser')
      .leftJoinAndSelect('appointment.player', 'player')
      .leftJoinAndSelect('appointment.injury', 'injury')
      .leftJoinAndSelect('injury.sportInjury', 'sportInjury')
      .leftJoinAndSelect('sportInjury.organization', 'organization')
      .leftJoinAndSelect('player.user', 'user')
      .leftJoinAndSelect('user.organizations', 'org')
      .where('assessment.id = :id', { id })
      .getOne()
      .catch((err) => {
        throw new UnprocessableEntityException(err.message);
      });
  }

  async findExternalById(id: string): Promise<ExternalAssessmentEntity> {
    return await this.manager
      .getRepository(ExternalAssessmentEntity)
      .createQueryBuilder('externalAssessment')
      .leftJoinAndSelect('externalAssessment.injury', 'injury')
      .where('externalAssessment.id = :id', { id })
      .getOne()
      .catch((err) => {
        throw new UnprocessableEntityException(err.message);
      });
  }

  async findManyByPlayer(playerId: string): Promise<AssessmentEntity[]> {
    return await this.createQueryBuilder('assessment')
      .leftJoinAndSelect('assessment.appointment', 'appointment')
      .leftJoinAndSelect('appointment.doctor', 'doctor')
      .leftJoinAndSelect('doctor.user', 'docUser')
      .leftJoinAndSelect('appointment.timeSlot', 'timeSlot')
      .where('appointment.player_id = :playerId', { playerId })
      .orderBy('timeSlot.date', 'DESC')
      .getMany()
      .catch((err) => {
        throw new UnprocessableEntityException(err.message);
      });
  }

  async findManyByInjury(injuryId: string): Promise<AssessmentEntity[]> {
    return await this.createQueryBuilder('assessment')
      .leftJoinAndSelect('assessment.appointment', 'appointment')
      .leftJoinAndSelect('appointment.doctor', 'doctor')
      .leftJoinAndSelect('doctor.user', 'docUser')
      .leftJoinAndSelect('appointment.timeSlot', 'timeSlot')
      .where('appointment.injury_id = :injuryId', { injuryId })
      .orderBy('timeSlot.date', 'DESC')
      .getMany()
      .catch((err) => {
        throw new UnprocessableEntityException(err.message);
      });
  }

  async findExternalAssessmentsByPlayer(playerId: string): Promise<ExternalAssessmentEntity[]> {
    return await this.manager
      .getRepository(ExternalAssessmentEntity)
      .createQueryBuilder('externalAssessment')
      .leftJoin('externalAssessment.injury', 'injury')
      .leftJoin('injury.user', 'player')
      .where('player.id = :playerId', { playerId })
      .andWhere('injury.status = :status', { status: InjuryStatus.Active })
      .orderBy('externalAssessment.appointmentDate', 'DESC')
      .getMany()
      .catch((err) => {
        throw new UnprocessableEntityException(err.message);
      });
  }

  async findExternalAssessmentsByInjury(injuryId: string): Promise<ExternalAssessmentEntity[]> {
    return await this.manager
      .getRepository(ExternalAssessmentEntity)
      .createQueryBuilder('externalAssessment')
      .leftJoin('externalAssessment.injury', 'injury')
      .leftJoin('injury.user', 'player')
      .where('injury.id = :injuryId', { injuryId })
      .andWhere('injury.status = :status', { status: InjuryStatus.Active })
      .orderBy('externalAssessment.appointmentDate', 'DESC')
      .getMany()
      .catch((err) => {
        throw new UnprocessableEntityException(err.message);
      });
  }

  createEntity(entityLike: DeepPartial<AssessmentEntity>): AssessmentEntity {
    return this.repository.create(entityLike);
  }

  hasAccessToAppointment(appointment: AppointmentEntity): boolean {
    if (this.roleManager.role === UserRole.Doctor) {
      return appointment.doctor.userId === this.roleManager.userId;
    }

    return true;
  }

  async updateCertificateLinks(
    id: string,
    { timetableLink, certificateLink }: CertificateGenerationResponse
  ): Promise<void> {
    await this.updateAssessment(id, { certificateLink });
    await this.updateGrtp(id, { timetableLink });

    return;
  }

  private async updateAssessment(id: string, partialEntity: QueryDeepPartialEntity<AssessmentEntity>): Promise<void> {
    await this.repository.update(id, partialEntity).catch((err) => {
      throw new UnprocessableEntityException(err.message);
    });

    return;
  }

  private async updateGrtp(assessmentId: string, partialEntity: QueryDeepPartialEntity<GrtpEntity>): Promise<void> {
    await this.manager.update(GrtpEntity, { assessment: { id: assessmentId } }, partialEntity).catch((err) => {
      throw new UnprocessableEntityException(err.message);
    });

    return;
  }

  private async updateInjuryPlayStatus(
    decidedOutcome: DecidedOutcome,
    injuryId: string,
    runner: QueryRunner
  ): Promise<void> {
    let playStatus: PlayStatus;

    switch (decidedOutcome) {
      case DecidedOutcome.Clear:
        playStatus = PlayStatus.Safe;
        break;
      case DecidedOutcome.GRTP:
        playStatus = PlayStatus.ReduceActivity;
        break;
      default:
        playStatus = PlayStatus.NotSafe;
        break;
    }
    await runner.manager.update(InjuryEntity, injuryId, { playStatus });

    return;
  }

  private async runTransaction(transactionalFn: (manager: QueryRunner) => Promise<any>): Promise<any> {
    const queryRunner = this.manager.connection.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();
    try {
      const response = await transactionalFn(queryRunner);
      await queryRunner.commitTransaction();

      return response;
    } catch (err) {
      await queryRunner.rollbackTransaction();
      throw new UnprocessableEntityException(err.message);
    } finally {
      await queryRunner.release();
    }
  }

  async updatePlayerStatus(): Promise<void> {
    const updateStatus = async (runner: QueryRunner): Promise<void> => {
      const playStatuses = [PlayStatus.NotSafe, PlayStatus.ReduceActivity];
      const assessmentsInjuries = await this.manager
        .getRepository(AssessmentEntity)
        .createQueryBuilder('assessment')
        .select(['assessment.returnToPlay', 'assessment.decidedOutcome', 'grtp.startGentlePELessons'])
        .leftJoinAndSelect('assessment.grtp', 'grtp')
        .leftJoinAndSelect('assessment.appointment', 'appointment')
        .leftJoinAndSelect('appointment.injury', 'injury')
        .where('injury.status = :status', { status: InjuryStatus.Active })
        .andWhere('injury.playStatus IN (:...playStatuses)', { playStatuses })
        .getMany()
        .catch((err) => {
          throw new UnprocessableEntityException(err.message);
        });

      const dateNow = moment(new Date()).format('YYYY-MM-DD');

      for (let i = 0; i < assessmentsInjuries.length; i++) {
        let decidedDate;
        switch (assessmentsInjuries[i].decidedOutcome) {
          case DecidedOutcome.GRTP:
            decidedDate = String(assessmentsInjuries[i].grtp.startGentlePELessons);
            break;
          case DecidedOutcome.Clear:
            decidedDate = String(assessmentsInjuries[i].returnToPlay);
            break;
        }

        if (decidedDate === dateNow) {
          await this.updateInjuryPlayStatus(
            assessmentsInjuries[i].decidedOutcome,
            assessmentsInjuries[i].appointment.injury.id,
            runner
          );
        }
      }
    };
    return await this.runTransaction(updateStatus);
  }
}

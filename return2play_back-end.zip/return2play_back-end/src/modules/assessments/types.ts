import { AssessmentEntity } from './entities/assessment.entity';
import { ExternalAssessmentEntity } from './entities/externalAssessment.entity';

export enum DecidedOutcome {
  GRTP = 'GRTP',
  RemainGRTP = 'Remain in GRTP',
  NotYetFit = 'Not yet fit - re-review in 1 week',
  ReturnCompleteRest = 'Return to complete rest',
  ReferMDT = 'Refer to MDT',
  ReferExternal = 'Refer for external care',
  FitReturnPlay = 'Fit to return to play',
  Clear = 'Clear injury',
}

export enum ListUsed {
  A = 'A',
  B = 'B',
  C = 'C',
  D = 'D',
  E = 'E',
  F = 'F',
}

export interface CertificateGenerationResponse {
  timetableLink: string;
  certificateLink: string;
}

export interface AssessmentsResponse {
  assessments: AssessmentEntity[];
  externalAssessments: ExternalAssessmentEntity[];
}

export interface GRTPDates {
  startGentlePELessons: Date;

  normalPELessons: Date;

  nonContactTraining: Date;

  noRestrictionsTraining: Date;
}

import {
  ConflictException,
  ForbiddenException,
  HttpService,
  HttpStatus,
  Inject,
  Injectable,
  Logger,
  LoggerService,
  NotFoundException,
  UnprocessableEntityException,
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import moment from 'moment';
import { AppConfigService } from '../../config/config.service';
import { AppointmentRepository } from '../appointments/appointment.repository';
import { AppointmentStatus } from '../appointments/types';
import { PlayStatus } from '../injuries/types';
import { AwsSignManager } from '../shared/helpers/lambda/sign.manager';
import { InjuryRepository } from './../injuries/injury.repository';
import { PlayerRepository } from './../players/player.repository';
import { AssessmentRepository } from './assessment.repository';
import { CreateAssessmentBody } from './dtos/create-assessment.dto';
import { AssessmentEntity } from './entities/assessment.entity';
import { ExternalAssessmentEntity } from './entities/externalAssessment.entity';
import { AssessmentsResponse, CertificateGenerationResponse, DecidedOutcome, GRTPDates } from './types';

@Injectable()
export class AssessmentsService {
  constructor(
    @InjectRepository(AssessmentRepository)
    private assessmentRepo: AssessmentRepository,
    @InjectRepository(AppointmentRepository)
    private appointmentRepo: AppointmentRepository,
    @InjectRepository(PlayerRepository)
    private playerRepo: PlayerRepository,
    private httpService: HttpService,
    private configService: AppConfigService,
    private signManager: AwsSignManager,
    private injuryRepo: InjuryRepository,
    @Inject(Logger)
    private logger: LoggerService
  ) {}

  async createOne(body: CreateAssessmentBody): Promise<void> {
    try {
      console.log(111111111111111);

      const appointment = await this.appointmentRepo.findById(body.appointmentId, { status: AppointmentStatus.New });
      console.log(22222222222222);

      if (!appointment) {
        throw new NotFoundException('Appointment not found');
      }
      console.log(3333333333333);

      const { decidedOutcome, returnToPlay, startGentlePELessons } = body;
      const currentInjuryStatus = appointment.injury.playStatus;

      let newInjuryStatus;
      let decidedDate;
      switch (decidedOutcome) {
        case DecidedOutcome.GRTP:
          decidedDate = moment(startGentlePELessons).format('DD/MM/YYYY');
          newInjuryStatus = PlayStatus.ReduceActivity;
          break;
        case DecidedOutcome.Clear:
          decidedDate = moment(returnToPlay).format('DD/MM/YYYY');
          newInjuryStatus = PlayStatus.Safe;
          break;
        default:
          decidedDate = moment().format('DD/MM/YYYY');
          newInjuryStatus = PlayStatus.NotSafe;
          break;
      }
      console.log(444444444444444444);

      this.validateGRTPDates(body);
      console.log(555555555555555);

      const isHasAccess = this.assessmentRepo.hasAccessToAppointment(appointment);

      if (!isHasAccess) {
        throw new ForbiddenException('Doctor has no access to appointment');
      }
      console.log(666666666666666666);

      const assessment = await this.assessmentRepo.createOne(body, appointment, this.createCertificate.bind(this));
      console.log(77777777777777777777777);

      console.log('lambda:', `http://${this.configService.aws.mailerHost}/assessment/${assessment.id}`);

      try {
        await this.httpService
          .post(
            `http://${this.configService.aws.mailerHost}/assessment/${assessment.id}`,
            { currentInjuryStatus, newInjuryStatus, decidedDate },
            { timeout: 10000 }
          )
          .toPromise();
        console.log('EMailden sonraaa');
      } catch (err) {
        this.logger.error(
          `Error during sending request to 'mailer-service' with assessment id '${assessment.id}'. Error: ${err.message}`
        );
      }
    } catch (err) {
      throw new UnprocessableEntityException(err.message);
    }
  }

  async createCertificate(assessment: AssessmentEntity): Promise<CertificateGenerationResponse> {
    const stage = this.configService.stage;
    const { headers } = this.signManager.signRequest(`/${stage}/certificate`);
    console.log({ headers });
    console.log('url:', `https://${this.configService.aws.lambdaHost}/${stage}/certificate`);

    const url = `https://${this.configService.aws.lambdaHost}/${stage}/certificate`;
    const response = await this.httpService
      .post(url, assessment, {
        headers,
        timeout: 20000,
      })
      .toPromise()
      .catch((err) => {
        console.log('lamda error:', err);

        throw new UnprocessableEntityException(err.message);
      });

    return response.data as CertificateGenerationResponse;
  }

  async findOne(id: string): Promise<AssessmentEntity> {
    const assessment = await this.assessmentRepo.findById(id);

    if (!assessment) {
      throw new NotFoundException('Assessment not found');
    }

    return assessment;
  }

  async findExternalOne(id: string): Promise<ExternalAssessmentEntity> {
    const assessment = await this.assessmentRepo.findExternalById(id);

    if (!assessment) {
      throw new NotFoundException('Assessment not found');
    }

    return assessment;
  }

  async findManyByPlayer(playerId: string): Promise<AssessmentsResponse> {
    const player = await this.playerRepo.findById(playerId);

    if (!player) {
      throw new NotFoundException('Player not found');
    }

    const assessments = await this.assessmentRepo.findManyByPlayer(playerId);

    const externalAssessments = await this.assessmentRepo.findExternalAssessmentsByPlayer(playerId);

    return { assessments, externalAssessments };
  }

  async findManyByInjury(injuryId: string): Promise<AssessmentsResponse> {
    const injury = await this.injuryRepo.findInjury({ id: injuryId });

    if (!injury) {
      throw new NotFoundException('Player not found');
    }
    const assessments = await this.assessmentRepo.findManyByInjury(injuryId);

    const externalAssessments = await this.assessmentRepo.findExternalAssessmentsByInjury(injuryId);

    return { assessments, externalAssessments };
  }

  private validateDate(date: Date): boolean {
    const dateNow = moment(new Date());

    return moment(date).startOf('day').isSameOrAfter(dateNow.startOf('day'));
  }

  private validateGRTPDates(dates: GRTPDates): void {
    if (!this.validateDate(dates.startGentlePELessons)) {
      const errorObject = {
        statusCode: HttpStatus.CONFLICT,
        field: 'start date',
        message: 'Start date is not valid',
      };
      throw new ConflictException(errorObject);
    }

    if (!this.validateDate(dates.noRestrictionsTraining)) {
      const errorObject = {
        statusCode: HttpStatus.CONFLICT,
        field: 'non restrictions training date',
        message: 'No restriction training date is not valid',
      };
      throw new ConflictException(errorObject);
    }

    if (!this.validateDate(dates.nonContactTraining)) {
      const errorObject = {
        statusCode: HttpStatus.CONFLICT,
        field: 'non contact training date',
        message: 'Non contact training date is not valid',
      };
      throw new ConflictException(errorObject);
    }

    if (!this.validateDate(dates.normalPELessons)) {
      const errorObject = {
        statusCode: HttpStatus.CONFLICT,
        field: 'normal pe lessons date',
        message: 'Normal PE lessons date is not valid',
      };
      throw new ConflictException(errorObject);
    }
  }

  async updatePlayerStatus(): Promise<void> {
    return this.assessmentRepo.updatePlayerStatus();
  }
}

import { ExternalAssessmentEntity } from './entities/externalAssessment.entity';
import { IdDto } from './../shared/shared.dto';
import { CREATE_ONE } from './../doctors/swagger';
import { AssessmentsService } from './assessments.service';
import { Body, Controller, Get, Param, Post, UseGuards } from '@nestjs/common';
import {
  ApiBearerAuth,
  ApiForbiddenResponse,
  ApiNoContentResponse,
  ApiNotFoundResponse,
  ApiOkResponse,
  ApiOperation,
  ApiTags,
  ApiUnprocessableEntityResponse,
} from '@nestjs/swagger';
import { Roles } from '../shared/decorators/roles.decorator';
import { CognitoGuard } from '../shared/guards/cognito.guard';
import { RolesGuard } from '../shared/guards/roles.guard';
import { UserRole } from '../users/types';
import { CreateAssessmentBody } from './dtos/create-assessment.dto';
import { AssessmentEntity } from './entities/assessment.entity';
import { GET_MANY_BY_INJURY, GET_MAY, GET_ONE } from './swagger';
import { AssessmentsResponse } from './types';
import { Cron } from '@nestjs/schedule';
import { CRON_UPDATE_PLAY_STATUS } from '../shared/constants';

@ApiTags('Assessments')
@UseGuards(CognitoGuard, RolesGuard)
@ApiBearerAuth()
@Roles(UserRole.Doctor, UserRole.SuperAdmin)
@Controller('assessments')
export class AssessmentsController {
  constructor(private service: AssessmentsService) {}

  @ApiOperation(CREATE_ONE.OPERATION)
  @ApiNoContentResponse(CREATE_ONE.SUCCESS)
  @ApiUnprocessableEntityResponse(CREATE_ONE.FAILURE)
  @ApiForbiddenResponse(CREATE_ONE.FORBIDDEN)
  @ApiNotFoundResponse(CREATE_ONE.NOT_FOUND)
  @Post()
  async createOne(@Body() body: CreateAssessmentBody): Promise<void> {
    return await this.service.createOne(body);
  }

  @ApiOperation(GET_ONE.OPERATION)
  @ApiOkResponse(GET_ONE.SUCCESS)
  @ApiUnprocessableEntityResponse(GET_ONE.FAILURE)
  @ApiForbiddenResponse(GET_ONE.FORBIDDEN)
  @ApiNotFoundResponse(GET_ONE.NOT_FOUND)
  @Roles(UserRole.Parent, UserRole.Player, UserRole.StaffUser, UserRole.OrganizationAdmin, UserRole.MedicalStaff)
  @Get('/:id')
  async findOne(@Param() params: IdDto): Promise<AssessmentEntity> {
    return await this.service.findOne(params.id);
  }

  @ApiOperation(GET_ONE.OPERATION)
  @ApiOkResponse(GET_ONE.SUCCESS)
  @ApiUnprocessableEntityResponse(GET_ONE.FAILURE)
  @ApiForbiddenResponse(GET_ONE.FORBIDDEN)
  @ApiNotFoundResponse(GET_ONE.NOT_FOUND)
  @Roles(UserRole.Parent, UserRole.Player, UserRole.StaffUser, UserRole.OrganizationAdmin, UserRole.MedicalStaff)
  @Get('/:id/external')
  async findExternalOne(@Param() params: IdDto): Promise<ExternalAssessmentEntity> {
    return await this.service.findExternalOne(params.id);
  }

  @ApiOperation(GET_MAY.OPERATION)
  @ApiOkResponse(GET_MAY.SUCCESS)
  @ApiUnprocessableEntityResponse(GET_MAY.FAILURE)
  @ApiForbiddenResponse(GET_MAY.FORBIDDEN)
  @ApiNotFoundResponse(GET_MAY.NOT_FOUND)
  @Roles(UserRole.Parent, UserRole.Player, UserRole.StaffUser, UserRole.OrganizationAdmin, UserRole.MedicalStaff)
  @Get('/player/:id')
  async findManyByPlayer(@Param() params: IdDto): Promise<AssessmentsResponse> {
    return await this.service.findManyByPlayer(params.id);
  }

  @ApiOperation(GET_MANY_BY_INJURY.OPERATION)
  @ApiOkResponse(GET_MANY_BY_INJURY.SUCCESS)
  @ApiUnprocessableEntityResponse(GET_MANY_BY_INJURY.FAILURE)
  @ApiForbiddenResponse(GET_MANY_BY_INJURY.FORBIDDEN)
  @ApiNotFoundResponse(GET_MANY_BY_INJURY.NOT_FOUND)
  @Roles(UserRole.Parent, UserRole.Player, UserRole.StaffUser, UserRole.OrganizationAdmin, UserRole.MedicalStaff)
  @Get('/injury/:id')
  async findManyByInjury(@Param() params: IdDto): Promise<AssessmentsResponse> {
    return await this.service.findManyByInjury(params.id);
  }

  @Cron(CRON_UPDATE_PLAY_STATUS)
  updatePlayerStatus(): Promise<void> {
    return this.service.updatePlayerStatus();
  }
}

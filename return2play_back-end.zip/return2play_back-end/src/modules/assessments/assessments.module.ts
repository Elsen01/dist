import { AssessmentRepository } from './assessment.repository';
import { HttpModule, Module } from '@nestjs/common';
import { AssessmentsController } from './assessments.controller';
import { AssessmentsService } from './assessments.service';
import { TypeOrmModule } from '@nestjs/typeorm';
import { SharedModule } from '../shared/shared.module';
import { AppointmentRepository } from '../appointments/appointment.repository';
import { PlayerRepository } from '../players/player.repository';
import { AwsSignManager } from '../shared/helpers/lambda/sign.manager';
import { InjuryRepository } from '../injuries/injury.repository';
import { AppConfigService } from '../../config/config.service';

@Module({
  controllers: [AssessmentsController],
  providers: [AssessmentsService, AwsSignManager],
  imports: [
    HttpModule.registerAsync({ useClass: AppConfigService }),
    TypeOrmModule.forFeature([AssessmentRepository, AppointmentRepository, PlayerRepository, InjuryRepository]),
    SharedModule,
  ],
})
export class AssessmentsModule {}

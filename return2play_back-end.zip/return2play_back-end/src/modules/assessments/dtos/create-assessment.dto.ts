import { Type } from 'class-transformer';
import {
  IsDateString,
  IsOptional,
  IsString,
  IsEnum,
  IsNumber,
  ValidateIf,
  IsUUID,
  MaxLength,
  MinLength,
  IsDate,
  IsBoolean,
} from 'class-validator';
import { DecidedOutcome } from '../types';

export class CreateAssessmentBody {
  @IsUUID()
  appointmentId: string;

  @IsDateString()
  @IsOptional()
  returnToPlay: Date;

  @IsString()
  @MinLength(1)
  @MaxLength(1000)
  @IsOptional()
  injuryNote: string;

  @IsString()
  @MinLength(1)
  @MaxLength(1000)
  @IsOptional()
  outcomeNote: string;

  @IsEnum(DecidedOutcome)
  decidedOutcome: DecidedOutcome;

  @IsBoolean()
  isSymptomFree: boolean;

  @IsDateString()
  @IsOptional()
  firstCompletelySymptomFreeDate?: Date;

  @IsBoolean()
  @IsOptional()
  areSymptomWorsenedConcentration: boolean;

  @IsBoolean()
  @IsOptional()
  areSymptomWorsenedPhysical: boolean;

  @IsBoolean()
  hasPreviousConcussion: boolean;

  @IsDateString()
  @IsOptional()
  previousConcussionDate: Date;

  @IsNumber()
  @IsOptional()
  previousConcussionNumber: number;

  @ValidateIf((o) => o.decidedOutcome === DecidedOutcome.GRTP)
  @IsDate()
  @Type(() => Date)
  startGentlePELessons: Date;

  @ValidateIf((o) => o.decidedOutcome === DecidedOutcome.GRTP)
  @IsDate()
  @Type(() => Date)
  normalPELessons: Date;

  @ValidateIf((o) => o.decidedOutcome === DecidedOutcome.GRTP)
  @IsDate()
  @Type(() => Date)
  nonContactTraining: Date;

  @ValidateIf((o) => o.decidedOutcome === DecidedOutcome.GRTP)
  @IsDate()
  @Type(() => Date)
  noRestrictionsTraining: Date;
}

import { IDocumentedEndpoint } from '../shared/interfaces/swagger.interface';

export const CREATE_ONE: IDocumentedEndpoint = {
  OPERATION: {
    description: '`Doctor` can create assessment of appointment',
  },
  SUCCESS: {
    description: '`Success` Assessment was created',
  },
  FORBIDDEN: {
    description: '`API` User has no permissions to create assessment',
  },
  FAILURE: {
    description: '`API` Saved entity to the database failed',
  },
  NOT_FOUND: {
    description: '`API` `Appointment` not found within the system ',
  },
};

export const GET_ONE: IDocumentedEndpoint = {
  OPERATION: {
    description: '`Doctor` or `Super admin` can get particular assessment',
  },
  SUCCESS: {
    description: '`Success` Assessment was returned',
  },
  FORBIDDEN: {
    description: '`API` User has no permissions to get assessment',
  },
  FAILURE: {
    description: '`API` Select entity from the database failed',
  },
  NOT_FOUND: {
    description: '`API` `Assessment` not found within the system ',
  },
};

export const GET_MAY: IDocumentedEndpoint = {
  OPERATION: {
    description:
      '`Super admin`, `Doctor`, `Organization admin`, `Staff user`, `Parent`, `Player` can get assessments of particular player',
  },
  SUCCESS: {
    description: '`Success` Assessments was returned',
  },
  FORBIDDEN: {
    description: '`API` User has no permissions to get assessments',
  },
  FAILURE: {
    description: '`API` Select entity from the database failed',
  },
  NOT_FOUND: {
    description: '`API` `Player` not found within the system or user has no access to player',
  },
};

export const GET_MANY_BY_INJURY: IDocumentedEndpoint = {
  OPERATION: {
    description:
      '`Super admin`, `Doctor`, `Organization admin`, `Staff user`, `Parent`, `Player` can get assessments of particular injury',
  },
  SUCCESS: {
    description: '`Success` Assessments was returned',
  },
  FORBIDDEN: {
    description: '`API` User has no permissions to get assessments',
  },
  FAILURE: {
    description: '`API` Select entity from the database failed',
  },
  NOT_FOUND: {
    description: '`API` `Injury` not found within the system or user has no access to player ',
  },
};

import {
  Column,
  CreateDateColumn,
  Entity,
  JoinColumn,
  ManyToOne,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm';
import { InjuryEntity } from '../../injuries/entities/injury.entity';
import { PlayStatus } from '../../injuries/types';

@Entity('external_assessments')
export class ExternalAssessmentEntity {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ name: 'doctor_first_name', length: 255, nullable: true })
  doctorFirstName: string;

  @Column({ name: 'doctor_last_name', length: 255, nullable: true })
  doctorLastName: string;

  @Column({ name: 'certificate_link', nullable: true })
  certificateLink: string;

  @Column({ name: 'appointment_date', type: 'timestamptz', nullable: true })
  appointmentDate: Date;

  @Column({ name: 'new_play_status', type: 'enum', enum: PlayStatus, nullable: true })
  newPlayStatus: PlayStatus;

  @ManyToOne(() => InjuryEntity, { nullable: false })
  @JoinColumn({ name: 'injury_id', referencedColumnName: 'id' })
  injury: InjuryEntity;

  @CreateDateColumn({ name: 'created_at' })
  createdAt: Date;

  @UpdateDateColumn({ name: 'updated_at' })
  updatedAt: Date;
}

import { GrtpEntity } from './grtp.entity';
import {
  Column,
  CreateDateColumn,
  Entity,
  JoinColumn,
  OneToOne,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm';
import { DecidedOutcome } from '../types';
import { AppointmentEntity } from '../../appointments/entities/appointment.entity';

@Entity('assessments')
export class AssessmentEntity {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @OneToOne(() => AppointmentEntity, (appointment) => appointment.assessment, { nullable: false })
  @JoinColumn({ name: 'appointment_id' })
  appointment: AppointmentEntity;

  @Column({ name: 'outcome_note', length: 1000, nullable: true })
  outcomeNote?: string;

  @OneToOne(() => GrtpEntity, (grtp) => grtp.assessment)
  grtp?: GrtpEntity;

  @Column({ name: 'return_to_play_date', type: 'date', nullable: true })
  returnToPlay: Date;

  @Column({ type: 'enum', enum: DecidedOutcome, name: 'decided_outcome' })
  decidedOutcome: DecidedOutcome;

  @Column({ name: 'certificate_link', nullable: true })
  certificateLink: string;

  @Column({ name: 'is_symptom_free', default: true })
  isSymptomFree: boolean;

  @Column({ name: 'first_completely_symptom_free_date', nullable: true, type: 'date' })
  firstCompletelySymptomFreeDate?: Date;

  @Column({ name: 'are_symptom_worsened_concentration', nullable: true })
  areSymptomWorsenedConcentration: boolean;

  @Column({ name: 'are_symptom_worsened_physical', nullable: true })
  areSymptomWorsenedPhysical: boolean;

  @Column({ name: 'has_previous_concussion', default: false })
  hasPreviousConcussion: boolean;

  @Column({ name: 'previous_concussion_date', type: 'date', nullable: true })
  previousConcussionDate: Date;

  @Column({ name: 'previous_concussion_number', nullable: true })
  previousConcussionNumber: number;

  @CreateDateColumn({ name: 'created_at' })
  createdAt: Date;

  @UpdateDateColumn({ name: 'updated_at' })
  updatedAt: Date;
}

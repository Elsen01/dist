import {
  Column,
  CreateDateColumn,
  Entity,
  JoinColumn,
  OneToOne,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm';
import { AssessmentEntity } from './assessment.entity';

@Entity('grtp')
export class GrtpEntity {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ name: 'start_gentle_pe_lessons_date', type: 'date', nullable: true })
  startGentlePELessons: Date;

  @Column({ name: 'normal_pe_lessons_date', type: 'date' })
  normalPELessons: Date;

  @Column({ name: 'non_contact_training_date', type: 'date' })
  nonContactTraining: Date;

  @Column({ name: 'no_restrictions_training_date', type: 'date' })
  noRestrictionsTraining: Date;

  @Column({ name: 'timetable_link', nullable: true })
  timetableLink: string;

  @OneToOne(() => AssessmentEntity, (assessment) => assessment.grtp)
  @JoinColumn({ name: 'assessment_id' })
  assessment: AssessmentEntity;

  @CreateDateColumn({ name: 'created_at' })
  createdAt: Date;

  @UpdateDateColumn({ name: 'updated_at' })
  updatedAt: Date;
}

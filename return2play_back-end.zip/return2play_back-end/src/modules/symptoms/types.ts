import { BinarySymptomEntity } from './entities/binarySymptom.entity';
import { OtherSymptomEntity } from './entities/otherSymptom.entity';
import { RedFlagSymptomEntity } from './entities/redFlagSymptom.entity';
import { SymptomEntity } from './entities/symptom.entity';

export enum SymptomGradation {
  Zero = '0',
  One = '1',
  Two = '2',
  Three = '3',
  Four = '4',
  Five = '5',
  Six = '6',
}

export class SymptomsListsResponse {
  symptoms: SymptomEntity[];
  redFlagSymptoms: RedFlagSymptomEntity[];
  binarySymptoms: BinarySymptomEntity[];
  otherSymptoms: OtherSymptomEntity[];
}

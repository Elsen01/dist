import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { InjuryRepository } from '../injuries/injury.repository';
import { SharedModule } from '../shared/shared.module';
import { SymptomRepository } from './symptom.repository';
import { SymptomsController } from './symptoms.controller';
import { SymptomsService } from './symptoms.service';

@Module({
  controllers: [SymptomsController],
  providers: [SymptomsService],
  imports: [TypeOrmModule.forFeature([InjuryRepository, SymptomRepository]), SharedModule],
})
export class SymptomsModule {}

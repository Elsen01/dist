import { Column, CreateDateColumn, Entity, OneToMany, PrimaryGeneratedColumn, UpdateDateColumn } from 'typeorm';
import { InjuryConcussionSymptomEntity } from '../../injuries/entities/injuryConcussionSymptom.entity';

@Entity('binary_symptoms')
export class BinarySymptomEntity {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ length: 255 })
  name: string;

  @Column({ length: 255, nullable: true })
  type: string;

  @OneToMany(() => InjuryConcussionSymptomEntity, (injury) => injury.binarySymptoms, {
    onDelete: 'CASCADE',
  })
  injuries: InjuryConcussionSymptomEntity[];

  @CreateDateColumn({ name: 'created_at' })
  createdAt: Date;

  @UpdateDateColumn({ name: 'updated_at' })
  updatedAt: Date;
}

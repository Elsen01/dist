import { SymptomEntity } from './symptom.entity';
import { Column, Entity, JoinColumn, ManyToOne, PrimaryGeneratedColumn } from 'typeorm';
import { SymptomGradation } from '../types';
import { InjuryConcussionSymptomEntity } from '../../injuries/entities/injuryConcussionSymptom.entity';

@Entity('injury_symptoms')
export class InjurySymptomEntity {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ enum: SymptomGradation, type: 'enum' })
  value: SymptomGradation;

  @ManyToOne(() => InjuryConcussionSymptomEntity, (concussionInjury) => concussionInjury.symptoms, {
    nullable: false,
    onDelete: 'CASCADE',
  })
  @JoinColumn({ name: 'injury_id' })
  injury!: InjuryConcussionSymptomEntity;

  @ManyToOne(() => SymptomEntity, (symptom) => symptom.injuries, { nullable: false, onDelete: 'CASCADE' })
  @JoinColumn({ name: 'symptom_id' })
  symptom!: SymptomEntity;
}

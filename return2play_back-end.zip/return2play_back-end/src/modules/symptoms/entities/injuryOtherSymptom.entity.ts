import { OtherSymptomEntity } from './otherSymptom.entity';
import { Column, Entity, JoinColumn, ManyToOne, PrimaryGeneratedColumn } from 'typeorm';
import { InjuryConcussionSymptomEntity } from '../../injuries/entities/injuryConcussionSymptom.entity';

@Entity('injury_other_symptoms')
export class InjuryOtherSymptomEntity {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ length: 255 })
  value: string;

  @ManyToOne(() => InjuryConcussionSymptomEntity, (injury) => injury.binarySymptoms, {
    nullable: false,
    onDelete: 'CASCADE',
  })
  @JoinColumn({ name: 'injury_id' })
  injury!: InjuryConcussionSymptomEntity;

  @ManyToOne(() => OtherSymptomEntity, (symptom) => symptom.injuries, { nullable: false, onDelete: 'CASCADE' })
  @JoinColumn({ name: 'other_symptom_id' })
  otherSymptom!: OtherSymptomEntity;
}

import { Column, Entity, OneToMany, PrimaryGeneratedColumn } from 'typeorm';
import { InjuryConcussionSymptomEntity } from '../../injuries/entities/injuryConcussionSymptom.entity';

@Entity('other_symptoms')
export class OtherSymptomEntity {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ length: 500 })
  name: string;

  @Column({ length: 255, nullable: true })
  type: string;

  @OneToMany(() => InjuryConcussionSymptomEntity, (concussionInjury) => concussionInjury.symptoms, {
    onDelete: 'CASCADE',
  })
  injuries: InjuryConcussionSymptomEntity[];
}

import { RedFlagSymptomEntity } from './redFlagSymptom.entity';
import { Column, Entity, JoinColumn, ManyToOne, PrimaryGeneratedColumn } from 'typeorm';
import { InjuryConcussionSymptomEntity } from '../../injuries/entities/injuryConcussionSymptom.entity';

@Entity('injury_red_flag_symptoms')
export class InjuryRedFlagSymptomEntity {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column()
  isPresent: boolean;

  @ManyToOne(() => InjuryConcussionSymptomEntity, (concussionInjury) => concussionInjury.redFlagSymptoms, {
    nullable: false,
    onDelete: 'CASCADE',
  })
  @JoinColumn({ name: 'injury_id' })
  injury!: InjuryConcussionSymptomEntity;

  @ManyToOne(() => RedFlagSymptomEntity, (symptom) => symptom.injuries, { nullable: false, onDelete: 'CASCADE' })
  @JoinColumn({ name: 'red_flag_symptom_id' })
  redFlagSymptom!: RedFlagSymptomEntity;
}

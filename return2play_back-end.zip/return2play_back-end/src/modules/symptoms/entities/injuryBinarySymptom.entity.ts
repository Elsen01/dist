import { BinarySymptomEntity } from './binarySymptom.entity';
import { Column, Entity, JoinColumn, ManyToOne, PrimaryGeneratedColumn } from 'typeorm';
import { InjuryConcussionSymptomEntity } from '../../injuries/entities/injuryConcussionSymptom.entity';

@Entity('injury_binary_symptoms')
export class InjuryBinarySymptomEntity {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column()
  isPresent: boolean;

  @ManyToOne(() => InjuryConcussionSymptomEntity, (injury) => injury.binarySymptoms, {
    nullable: false,
    onDelete: 'CASCADE',
  })
  @JoinColumn({ name: 'injury_id' })
  injury!: InjuryConcussionSymptomEntity;

  @ManyToOne(() => BinarySymptomEntity, (symptom) => symptom.injuries, { nullable: false, onDelete: 'CASCADE' })
  @JoinColumn({ name: 'binary_symptom_id' })
  binarySymptom!: BinarySymptomEntity;
}

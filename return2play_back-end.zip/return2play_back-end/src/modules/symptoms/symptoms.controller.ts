import { ADD_MANY, GET_SYMPTOMS_BY_INJURY, GET_SYMPTOMS_LISTS } from './swagger';
import { SymptomsService } from './symptoms.service';
import { Body, Controller, Get, HttpCode, HttpStatus, Param, Post, UseGuards } from '@nestjs/common';
import {
  ApiBearerAuth,
  ApiForbiddenResponse,
  ApiNoContentResponse,
  ApiNotFoundResponse,
  ApiOkResponse,
  ApiOperation,
  ApiTags,
  ApiUnprocessableEntityResponse,
} from '@nestjs/swagger';
import { Roles } from '../shared/decorators/roles.decorator';
import { CognitoGuard } from '../shared/guards/cognito.guard';
import { RolesGuard } from '../shared/guards/roles.guard';
import { ALL_ROLES } from '../users/types';
import { CreateInjurySymptomBody } from './dtos/create-injurySymptom.dto';
import { SymptomsListsResponse } from './types';
import { InjuryConcussionSymptomEntity } from '../injuries/entities/injuryConcussionSymptom.entity';
import { IdDto } from '../shared/shared.dto';

@ApiTags('Symptoms')
@UseGuards(CognitoGuard, RolesGuard)
@Roles(...ALL_ROLES)
@ApiBearerAuth()
@Controller('symptoms')
export class SymptomsController {
  constructor(private service: SymptomsService) {}

  @ApiOperation(ADD_MANY.OPERATION)
  @ApiNoContentResponse(ADD_MANY.SUCCESS)
  @ApiForbiddenResponse(ADD_MANY.FORBIDDEN)
  @ApiUnprocessableEntityResponse(ADD_MANY.FAILURE)
  @ApiNotFoundResponse(ADD_MANY.INJURY_NOT_FOUND)
  @HttpCode(HttpStatus.NO_CONTENT)
  @Post('/add')
  addNewSymptoms(@Body() body: CreateInjurySymptomBody): Promise<void> {
    return this.service.addNewInjurySymptoms(body);
  }

  @ApiOperation(GET_SYMPTOMS_LISTS.OPERATION)
  @ApiOkResponse({ ...GET_SYMPTOMS_LISTS.SUCCESS, type: SymptomsListsResponse })
  @ApiUnprocessableEntityResponse(GET_SYMPTOMS_LISTS.FAILURE)
  @ApiForbiddenResponse(GET_SYMPTOMS_LISTS.FORBIDDEN)
  @Get()
  async getSymptomsLists(): Promise<SymptomsListsResponse> {
    return await this.service.getSymptomsLists();
  }

  @ApiOperation(GET_SYMPTOMS_BY_INJURY.OPERATION)
  @ApiOkResponse(GET_SYMPTOMS_BY_INJURY.SUCCESS)
  @ApiUnprocessableEntityResponse(GET_SYMPTOMS_BY_INJURY.FAILURE)
  @ApiForbiddenResponse(GET_SYMPTOMS_BY_INJURY.FORBIDDEN)
  @ApiNotFoundResponse(GET_SYMPTOMS_BY_INJURY.NOT_FOUND)
  @Get('/injury/:id')
  async getSymptomsByInjury(@Param() param: IdDto): Promise<InjuryConcussionSymptomEntity[]> {
    return await this.service.getSymptomsByInjury(param.id);
  }

  @Get('/:id')
  async getSymptomsById(@Param() param: IdDto): Promise<InjuryConcussionSymptomEntity> {
    return await this.service.getSymptomsById(param.id);
  }
}

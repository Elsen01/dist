import { InjuryStatus } from './../injuries/types';
import { ForbiddenException, Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { InjuryConcussionSymptomEntity } from '../injuries/entities/injuryConcussionSymptom.entity';
import { InjuryRepository } from '../injuries/injury.repository';
import { InjuryGroup } from '../injuries/types';
import { CreateInjurySymptomBody } from './dtos/create-injurySymptom.dto';
import { SymptomRepository } from './symptom.repository';
import { SymptomsListsResponse } from './types';
import { In, Not } from 'typeorm';

@Injectable()
export class SymptomsService {
  constructor(
    @InjectRepository(InjuryRepository)
    private injuryRepo: InjuryRepository,
    @InjectRepository(SymptomRepository)
    private symptomRepo: SymptomRepository
  ) {}

  async addNewInjurySymptoms(symptoms: CreateInjurySymptomBody): Promise<void> {
    const injury = await this.injuryRepo.findInjury({
      id: symptoms.injuryId,
      injuryGroup: In([InjuryGroup.Concussion, InjuryGroup.HeadInjury]),
    });

    if (!injury) {
      throw new NotFoundException('Injury does not exists');
    }

    const isHasAccessToPlayer = this.injuryRepo.isHasAccessToPlayer(injury.user.id);

    if (!isHasAccessToPlayer) {
      throw new ForbiddenException('User does not have access to create injury for this player');
    }

    return await this.symptomRepo.addNewInjurySymptoms(symptoms, injury);
  }

  async getSymptomsLists(): Promise<SymptomsListsResponse> {
    return await this.symptomRepo.findSymptomsLists();
  }

  async getSymptomsByInjury(injuryId: string): Promise<InjuryConcussionSymptomEntity[]> {
    const injury = await this.injuryRepo.findInjury({
      id: injuryId,
      injuryGroup: InjuryGroup.Concussion,
      status: Not(InjuryStatus.Deleted),
    });

    if (!injury) {
      throw new NotFoundException('Concussion injury does not exists');
    }

    const isHasAccessToPlayer = this.injuryRepo.isHasAccessToPlayer(injury.user.id);

    if (!isHasAccessToPlayer) {
      throw new ForbiddenException('User does not have access to create injury for this player');
    }

    return await this.symptomRepo.findSymptomsByInjury(injuryId);
  }

  async getSymptomsById(injuryConcussionSymptomId: string): Promise<InjuryConcussionSymptomEntity> {
    const injury = await this.injuryRepo.findInjuryByConcussionSymptomId(injuryConcussionSymptomId);

    if (!injury) {
      throw new NotFoundException('Concussion injury does not exists');
    }

    const isHasAccessToPlayer = this.injuryRepo.isHasAccessToPlayer(injury.user.id);

    if (!isHasAccessToPlayer) {
      throw new ForbiddenException('User does not have access to create injury for this player');
    }

    return await this.symptomRepo.findOneConcussionSymptoms(injuryConcussionSymptomId);
  }
}

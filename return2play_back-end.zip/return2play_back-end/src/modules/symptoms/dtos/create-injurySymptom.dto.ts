import {
  CreateBinarySymptom,
  CreateOtherSymptom,
  CreateRedFlagSymptom,
  CreateSymptom,
} from './../../injuries/dtos/create-injury.dto';
import { Type } from 'class-transformer';
import { IsArray, IsOptional, IsUUID, ValidateNested } from 'class-validator';

export class CreateInjurySymptomBody {
  @IsUUID()
  injuryId: string;

  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => CreateSymptom)
  @IsOptional()
  symptoms: CreateSymptom[];

  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => CreateRedFlagSymptom)
  @IsOptional()
  redFlagSymptoms: CreateRedFlagSymptom[];

  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => CreateBinarySymptom)
  @IsOptional()
  binarySymptoms: CreateBinarySymptom[];

  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => CreateOtherSymptom)
  @IsOptional()
  otherSymptoms: CreateOtherSymptom[];
}

import { IDocumentedEndpoint } from '../shared/interfaces/swagger.interface';

export const ADD_MANY: IDocumentedEndpoint = {
  OPERATION: {
    description:
      'Add a new `Symptoms` within the system to existing `Injury`. All users roles are allowed to perform this action',
  },
  SUCCESS: {
    description: '`Success` Symptoms were added',
  },
  INJURY_NOT_FOUND: {
    description: '`API` Provided injury do not exist',
  },
  FORBIDDEN: {
    description: '`API` User has no permissions to add symptoms to this player',
  },
  FAILURE: {
    description: '`API` Saved entity to the database failed',
  },
};

export const GET_SYMPTOMS_LISTS: IDocumentedEndpoint = {
  OPERATION: {
    description:
      'Get list of all types of `Symptoms` within the system. All users roles are allowed to perform this action',
  },
  SUCCESS: {
    description: '`Success` Symptoms are returned',
  },
  FORBIDDEN: {
    description: '`API` User has no permissions to get symptoms lists',
  },
  FAILURE: {
    description: '`API` Select entity from the database failed',
  },
};

export const GET_SYMPTOMS_BY_INJURY: IDocumentedEndpoint = {
  OPERATION: {
    description:
      'Get `Symptoms` for particular `Injury` within the system. All users roles are allowed to perform this action',
  },
  SUCCESS: {
    description: '`Success` Symptoms are returned',
  },
  FORBIDDEN: {
    description: '`API` User has no permissions to get symptoms',
  },
  FAILURE: {
    description: '`API` Select entity from the database failed',
  },
  NOT_FOUND: {
    description: '`API` Concussion injury does not exist',
  },
};

import { OtherSymptomEntity } from './entities/otherSymptom.entity';
import { InjuryOtherSymptomEntity } from './entities/injuryOtherSymptom.entity';
import { UnprocessableEntityException } from '@nestjs/common';
import { EntityRepository, QueryRunner } from 'typeorm';
import { InjuryEntity } from '../injuries/entities/injury.entity';
import { SaveSymptoms } from '../injuries/types';
import { CreateInjurySymptomBody } from './dtos/create-injurySymptom.dto';
import { InjuryBinarySymptomEntity } from './entities/injuryBinarySymptom.entity';
import { InjuryRedFlagSymptomEntity } from './entities/injuryRedFlagSymptom.entity';
import { InjurySymptomEntity } from './entities/injurySymptom.entity';
import { SymptomsListsResponse } from './types';
import { InjuryConcussionSymptomEntity } from '../injuries/entities/injuryConcussionSymptom.entity';
import { BaseRepository } from '../shared/base.repository';
import { CreateSymptom } from '../injuries/dtos/create-injury.dto';
import { SymptomEntity } from './entities/symptom.entity';
import { RedFlagSymptomEntity } from './entities/redFlagSymptom.entity';
import { BinarySymptomEntity } from './entities/binarySymptom.entity';

@EntityRepository(InjuryConcussionSymptomEntity)
export class SymptomRepository extends BaseRepository<InjuryConcussionSymptomEntity> {
  async addNewInjurySymptoms(symptomsBody: CreateInjurySymptomBody, injury: InjuryEntity): Promise<void> {
    const createNew = async (runner: QueryRunner): Promise<void> => {
      const concussionSymptoms = await this.calculateAndSaveSymptom(runner, symptomsBody.symptoms, injury);

      await this.saveSymptoms(runner, concussionSymptoms, symptomsBody);
    };

    await this.runTransaction(createNew);

    return;
  }

  public async saveSymptoms(
    runner: QueryRunner,
    injury: InjuryConcussionSymptomEntity,
    { symptoms, redFlagSymptoms, binarySymptoms, otherSymptoms }: SaveSymptoms
  ): Promise<void> {
    if (symptoms?.length) {
      const injurySymptomRepo = runner.manager.getRepository(InjurySymptomEntity);

      const symptomsToSave = symptoms.map((symptom) =>
        injurySymptomRepo.create({
          symptom,
          value: symptom.value,
          injury,
        })
      );
      await injurySymptomRepo.save(symptomsToSave);
    }

    if (redFlagSymptoms?.length) {
      const redFlagSymptomRepo = runner.manager.getRepository(InjuryRedFlagSymptomEntity);

      const symptomsToSave = redFlagSymptoms.map((redFlagSymptom) =>
        redFlagSymptomRepo.create({
          redFlagSymptom,
          isPresent: redFlagSymptom.isPresent,
          injury,
        })
      );
      await redFlagSymptomRepo.save(symptomsToSave);
    }

    if (binarySymptoms?.length) {
      const binarySymptomRepo = runner.manager.getRepository(InjuryBinarySymptomEntity);

      const symptomsToSave = binarySymptoms.map((symptom) =>
        binarySymptomRepo.create({
          binarySymptom: symptom,
          isPresent: symptom.isPresent,
          injury,
        })
      );
      await binarySymptomRepo.save(symptomsToSave);
    }

    if (otherSymptoms?.length) {
      const otherSymptomRepo = runner.manager.getRepository(InjuryOtherSymptomEntity);

      const symptomsToSave = otherSymptoms.map((symptom) =>
        otherSymptomRepo.create({
          otherSymptom: symptom,
          value: symptom.value,
          injury,
        })
      );
      await otherSymptomRepo.save(symptomsToSave);
    }
  }

  async findSymptomsLists(): Promise<SymptomsListsResponse> {
    const symptoms = this.getRepositoryFor(SymptomEntity).find();
    const redFlagSymptoms = this.getRepositoryFor(RedFlagSymptomEntity).find();
    const binarySymptoms = this.getRepositoryFor(BinarySymptomEntity).find();
    const otherSymptoms = this.getRepositoryFor(OtherSymptomEntity).find();

    const response = await Promise.all([symptoms, redFlagSymptoms, binarySymptoms, otherSymptoms]).catch((err) => {
      throw new UnprocessableEntityException(err.message);
    });

    return {
      symptoms: response[0],
      redFlagSymptoms: response[1],
      binarySymptoms: response[2],
      otherSymptoms: response[3],
    };
  }

  async findSymptomsByInjury(injuryId: string): Promise<InjuryConcussionSymptomEntity[]> {
    return await this.repository
      .createQueryBuilder('concussionSymptoms')
      .leftJoinAndSelect('concussionSymptoms.symptoms', 'symptoms')
      .leftJoinAndSelect('symptoms.symptom', 'symptom')
      .leftJoinAndSelect('concussionSymptoms.binarySymptoms', 'binarySymptoms')
      .leftJoinAndSelect('binarySymptoms.binarySymptom', 'binarySymptom')
      .leftJoinAndSelect('concussionSymptoms.redFlagSymptoms', 'redFlagSymptoms')
      .leftJoinAndSelect('redFlagSymptoms.redFlagSymptom', 'redFlagSymptom')
      .leftJoinAndSelect('concussionSymptoms.otherSymptoms', 'otherSymptoms')
      .leftJoinAndSelect('otherSymptoms.otherSymptom', 'otherSymptom')
      .where('concussionSymptoms.injury_id = :injuryId', { injuryId })
      .getMany()
      .catch((err) => {
        throw new UnprocessableEntityException(err.message);
      });
  }

  async findOneConcussionSymptoms(injuryConcussionSymptomId: string): Promise<InjuryConcussionSymptomEntity> {
    return await this.repository
      .createQueryBuilder('concussionSymptoms')
      .leftJoinAndSelect('concussionSymptoms.symptoms', 'symptoms')
      .leftJoinAndSelect('symptoms.symptom', 'symptom')
      .leftJoinAndSelect('concussionSymptoms.binarySymptoms', 'binarySymptoms')
      .leftJoinAndSelect('binarySymptoms.binarySymptom', 'binarySymptom')
      .leftJoinAndSelect('concussionSymptoms.redFlagSymptoms', 'redFlagSymptoms')
      .leftJoinAndSelect('redFlagSymptoms.redFlagSymptom', 'redFlagSymptom')
      .leftJoinAndSelect('concussionSymptoms.otherSymptoms', 'otherSymptoms')
      .leftJoinAndSelect('otherSymptoms.otherSymptom', 'otherSymptom')
      .where('concussionSymptoms.id = :injuryConcussionSymptomId', { injuryConcussionSymptomId })
      .getOne()
      .catch((err) => {
        throw new UnprocessableEntityException(err.message);
      });
  }

  async calculateAndSaveSymptom(
    runner: QueryRunner,
    symptoms: CreateSymptom[],
    injury: InjuryEntity
  ): Promise<InjuryConcussionSymptomEntity> {
    const score = symptoms?.length ? this.calculateSymptomsScore(symptoms) : 0;

    return await runner.manager.getRepository(InjuryConcussionSymptomEntity).save({ injury, score });
  }

  private calculateSymptomsScore(symptoms: CreateSymptom[]): number {
    return symptoms.reduce((tot, symptom) => tot + Number(symptom.value), 0);
  }
}

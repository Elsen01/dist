import { BullModule as NestBullModule } from '@nestjs/bull';
import { Module } from '@nestjs/common';
import { AppConfigModule } from '../../config/config.module';
import { AppConfigService } from '../../config/config.service';

@Module({
  imports: [
    NestBullModule.forRootAsync({
      imports: [AppConfigModule],
      inject: [AppConfigService],
      useFactory: ({ bull }: AppConfigService) => bull,
    }),
  ],
  exports: [NestBullModule],
})
export class BullModule {}

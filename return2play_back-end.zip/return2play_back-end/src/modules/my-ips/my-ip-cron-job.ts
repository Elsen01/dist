import { Inject, Injectable, Logger, LoggerService } from '@nestjs/common';
import { SchedulerRegistry } from '@nestjs/schedule';
import { MyIPsConfigService } from '../../config/my-ips-config/my-ips-config.service';
import { AbstractCronJob } from '../shared/abstract-cron-job';
import { MyIPsService } from './my-ips.service';

@Injectable()
export class MyIPsCronJon extends AbstractCronJob {
  constructor(
    @Inject(Logger) logger: LoggerService,
    schedulerRegistry: SchedulerRegistry,
    private readonly config: MyIPsConfigService,
    private readonly service: MyIPsService
  ) {
    super(config.cronJobName, logger, schedulerRegistry, {
      cronTime: config.cronTime,
      timeZone: config.cronTimeZone,
    });
  }

  /**
   * Async handler for 'MyIPs Cron Job'
   */
  async handleCron(): Promise<void> {
    if (!this.config.isCronON) {
      return this.logger.log(`Cron Job '${this.name}' is switched off for this env`);
    }

    await this.service.refreshIP();
    await this.service.clearOldItems();
  }
}

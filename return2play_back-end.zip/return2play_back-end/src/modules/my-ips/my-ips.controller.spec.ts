import { Test, TestingModule } from '@nestjs/testing';
import { MyIPsController } from './my-ips.controller';

describe('MyIPsController', () => {
  let controller: MyIPsController;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [MyIPsController],
    }).compile();

    controller = module.get<MyIPsController>(MyIPsController);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });
});

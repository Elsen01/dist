import { Inject, Injectable, Logger, LoggerService } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { LessThan, Repository } from 'typeorm';
import axios, { AxiosInstance } from 'axios';
import subDays from 'date-fns/subDays';

import axiosRetry from 'axios-retry';
import { MyIPEntity } from './entities/my-ip.entity';
import { MyIPsConfigService } from '../../config/my-ips-config/my-ips-config.service';

@Injectable()
export class MyIPsService {
  private readonly api: AxiosInstance;

  constructor(
    @InjectRepository(MyIPEntity)
    private readonly repository: Repository<MyIPEntity>,
    @Inject(Logger)
    private readonly logger: LoggerService,
    private readonly configService: MyIPsConfigService
  ) {
    this.api = axios.create();
    axiosRetry(this.api, configService.retryConfig);
  }

  async getAll(): Promise<MyIPEntity[]> {
    return this.repository.find();
  }

  async refreshIP(): Promise<void> {
    let address: string;
    try {
      address = await this.getMyIP();
    } catch (err) {
      this.logger.error(`Error during fetching IP address ${err.message}`);
    }

    if (!address) {
      return;
    }

    const lastActiveAt = new Date();
    await this.repository
      .createQueryBuilder('item')
      .insert()
      .values({
        address,
        lastActiveAt,
      })
      .onConflict(`("address") DO UPDATE SET "lastActiveAt" = :lastActiveAt`)
      .setParameter('lastActiveAt', lastActiveAt)
      .execute();
  }

  async clearOldItems(): Promise<void> {
    const yesterday = subDays(new Date(), 1);
    await this.repository.delete({ lastActiveAt: LessThan(yesterday) });
  }

  private async getMyIP(): Promise<string> {
    const { data } = await this.api.get<{ ip: string }>(this.configService.urlToGetIP);
    return data.ip;
  }
}

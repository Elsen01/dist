import { Test, TestingModule } from '@nestjs/testing';
import { MyIPsCronJon } from './my-ip-cron-job';

describe('MyIPsCronJon', () => {
  let provider: MyIPsCronJon;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [MyIPsCronJon],
    }).compile();

    provider = module.get<MyIPsCronJon>(MyIPsCronJon);
  });

  it('should be defined', () => {
    expect(provider).toBeDefined();
  });
});

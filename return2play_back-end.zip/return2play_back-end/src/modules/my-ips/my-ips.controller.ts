import { Controller, Get, UseGuards } from '@nestjs/common';
import { MyIPsService } from './my-ips.service';
import { UserRole } from '../users/types';
import { Roles } from '../shared/decorators/roles.decorator';
import { CognitoGuard } from '../shared/guards/cognito.guard';
import { RolesGuard } from '../shared/guards/roles.guard';
import { MyIPEntity } from './entities/my-ip.entity';

@UseGuards(CognitoGuard, RolesGuard)
@Roles(UserRole.SuperAdmin)
@Controller('/my-ips')
export class MyIPsController {
  constructor(private service: MyIPsService) {}

  @Get()
  getMany(): Promise<MyIPEntity[]> {
    return this.service.getAll();
  }
}

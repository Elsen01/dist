import { Logger, Module } from '@nestjs/common';
import { MyIPsService } from './my-ips.service';
import { TypeOrmModule } from '@nestjs/typeorm';
import { MyIPsCronJon } from './my-ip-cron-job';
import { MyIPsConfigModule } from '../../config/my-ips-config/my-ips-config.module';
import { UsersModule } from '../users/users.module';
import { MyIPEntity } from './entities/my-ip.entity';
import { MyIPsController } from './my-ips.controller';
import { SharedModule } from '../shared/shared.module';

@Module({
  imports: [TypeOrmModule.forFeature([MyIPEntity]), MyIPsConfigModule, UsersModule, SharedModule],
  providers: [MyIPsService, MyIPsCronJon, Logger],
  exports: [MyIPsService],
  controllers: [MyIPsController],
})
export class MyIPsModule {}

import { Test, TestingModule } from '@nestjs/testing';
import { MyIPsService } from './my-ips.service';

describe('MyIPsService', () => {
  let service: MyIPsService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [MyIPsService],
    }).compile();

    service = module.get<MyIPsService>(MyIPsService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});

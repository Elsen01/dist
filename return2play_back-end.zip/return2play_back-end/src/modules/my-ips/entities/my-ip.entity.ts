import { Column, CreateDateColumn, Entity, PrimaryGeneratedColumn, UpdateDateColumn } from 'typeorm';

@Entity('my_ips')
export class MyIPEntity {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @CreateDateColumn({ type: 'timestamp', readonly: true })
  createdAt: Date;

  @UpdateDateColumn({ type: 'timestamp', readonly: true })
  updatedAt: Date;

  @Column({ unique: true })
  address: string;

  @Column({ type: 'timestamp', nullable: true })
  lastActiveAt: Date;
}

import { Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { TypeOrmModuleOptions, TypeOrmOptionsFactory } from '@nestjs/typeorm';
import { IAwsConfig, ICognitoConfig, IStripeConfig, IWondeConfig } from './config.interfaces';
import { AxiosRequestConfig } from 'axios';
import { BullModuleOptions } from '@nestjs/bull';
import { RedisOptions } from 'ioredis';

@Injectable()
export class AppConfigService implements TypeOrmOptionsFactory {
  constructor(private config: ConfigService) {}

  get cognito(): ICognitoConfig {
    return this.config.get<ICognitoConfig>('cognito');
  }

  get environment(): string {
    return this.config.get<string>('environment');
  }

  get frontendUrl(): string {
    return this.config.get<string>('frontendUrl');
  }

  get stage(): string {
    return this.config.get<string>('stage');
  }

  get http(): AxiosRequestConfig {
    return this.config.get<AxiosRequestConfig>('http');
  }

  get serverPort(): number {
    return this.config.get<number>('serverPort');
  }

  get aws(): IAwsConfig {
    return this.config.get<IAwsConfig>('aws');
  }

  get stripe(): IStripeConfig {
    return this.config.get<IStripeConfig>('stripe');
  }

  get wonde(): IWondeConfig {
    return this.config.get<IWondeConfig>('wonde');
  }

  get bull(): BullModuleOptions {
    return this.config.get<BullModuleOptions>('bull');
  }

  createTypeOrmOptions(): TypeOrmModuleOptions {
    return this.config.get<TypeOrmModuleOptions>('database');
  }

  createHttpOptions(): AxiosRequestConfig {
    return this.config.get<AxiosRequestConfig>('http');
  }

  get redis(): RedisOptions {
    return this.config.get<RedisOptions>('redis');
  }
}

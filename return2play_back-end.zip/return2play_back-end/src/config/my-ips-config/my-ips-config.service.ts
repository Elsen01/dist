import { HttpStatus, Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { AxiosError } from 'axios';
import { IAxiosRetryConfig, exponentialDelay } from 'axios-retry';

const DEFAULT_CRON_TIME = '0 */30 7-23 * * *';
const RETRY_TIMES = 4; // first time of request is 0 retry time
const DEFAULT_CRON_TIMEZONE = 'Europe/London';
const DEFAULT_MY_IPS_URL = 'https://api.ipify.org?format=json';

@Injectable()
export class MyIPsConfigService {
  constructor(private readonly configService: ConfigService) {}

  get cronJobName(): string {
    return 'My IPs Cron Job';
  }
  get cronTime(): string {
    return this.configService.get('MY_IPS_CRON_TIME', DEFAULT_CRON_TIME);
  }

  get cronTimeZone(): string {
    return this.configService.get('MY_IPS_CRON_TIME_ZONE', DEFAULT_CRON_TIMEZONE);
  }

  get isCronON(): boolean {
    return !(this.configService.get('MY_IPS_SYNC_SWITCHED_OFF', 'false').toLowerCase() === 'true');
  }

  get retryConfig(): IAxiosRetryConfig {
    return {
      retries: RETRY_TIMES,
      retryCondition: this.getRetryCondition(),
      retryDelay: exponentialDelay,
    };
  }

  get urlToGetIP(): string {
    return this.configService.get('MY_IPS_URL', DEFAULT_MY_IPS_URL);
  }

  getRetryCondition(): (err: AxiosError) => boolean {
    return (err: AxiosError): boolean => {
      const { response } = err;
      if (!response || !response.status || !this.getRetryStatusCodes().includes(response.status)) {
        return false;
      }
      return true;
    };
  }

  private getRetryStatusCodes(): ReadonlyArray<number> {
    return [
      HttpStatus.TOO_MANY_REQUESTS,
      HttpStatus.INTERNAL_SERVER_ERROR,
      HttpStatus.NOT_IMPLEMENTED,
      HttpStatus.BAD_GATEWAY,
      HttpStatus.SERVICE_UNAVAILABLE,
      HttpStatus.GATEWAY_TIMEOUT,
      HttpStatus.HTTP_VERSION_NOT_SUPPORTED,
      520,
    ];
  }
}

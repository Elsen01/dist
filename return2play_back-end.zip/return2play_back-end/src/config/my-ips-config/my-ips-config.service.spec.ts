import { Test, TestingModule } from '@nestjs/testing';
import { MyIPsConfigService } from './my-ips-config.service';

describe('MyIPsConfigService', () => {
  let service: MyIPsConfigService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [MyIPsConfigService],
    }).compile();

    service = module.get<MyIPsConfigService>(MyIPsConfigService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});

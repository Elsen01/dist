import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { MyIPsConfigService } from './my-ips-config.service';

@Module({
  imports: [ConfigModule],
  providers: [MyIPsConfigService],
  exports: [MyIPsConfigService],
})
export class MyIPsConfigModule {}

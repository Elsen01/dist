import { BullModuleOptions } from '@nestjs/bull';
import { TypeOrmModuleOptions } from '@nestjs/typeorm';
import { AxiosRequestConfig } from 'axios';
import { RedisOptions } from 'ioredis';
import { Stripe } from 'stripe';

export interface ICognitoConfig {
  UserPoolId: string;
  ClientId: string;
  Issuer: string;
}

export interface IAwsConfig {
  region: string;
  accessKeyId: string;
  secretAccessKey: string;
  s3Bucket: string;
  lambdaHost: string;
  mailerHost: string;
  csvTemplateLink: string;
}

export interface IStripeConfig {
  apiKey: string;
  config: Stripe.StripeConfig;
  webhookSecret: string;
  successUrl: string;
  cancelUrl: string;
  priceId30: string;
  priceId120: string;
}

export interface IWondeConfig {
  apiKey: string;
  schoolPerPage: number;
  clintId: string;
  clintSecret: string;
  authUri: string;
  tokenUri: string;
  redirectUri: string;
  apiUri: string;
  studentInclude: string;
  employeeInclude: string;
}

export interface IConfig {
  environment: string;
  stage: string;
  serverPort: number;
  frontendUrl: string;
  cognito: ICognitoConfig;
  aws: IAwsConfig;
  database: TypeOrmModuleOptions;
  http: AxiosRequestConfig;
  stripe: IStripeConfig;
  wonde: IWondeConfig;
  bull: BullModuleOptions;
  redis: RedisOptions;
}

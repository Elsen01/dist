import { Test, TestingModule } from '@nestjs/testing';
import { IsamsConfigService } from './isams-config.service';

describe('IsamsConfigService', () => {
  let service: IsamsConfigService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [IsamsConfigService],
    }).compile();

    service = module.get<IsamsConfigService>(IsamsConfigService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});

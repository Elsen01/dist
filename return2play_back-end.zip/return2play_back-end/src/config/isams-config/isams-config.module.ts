import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { IsamsConfigService } from './isams-config.service';

@Module({
  imports: [ConfigModule],
  providers: [IsamsConfigService],
  exports: [IsamsConfigService],
})
export class IsamsConfigModule {}

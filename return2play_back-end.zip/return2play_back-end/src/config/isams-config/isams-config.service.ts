import { HttpStatus, Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { AxiosError } from 'axios';
import { IAxiosRetryConfig, exponentialDelay } from 'axios-retry';

export const ISAMS_QUEUE_NAME = 'isams';
export const ISAMS_COMMAND_SYNC = 'sync';

const DEFAULT_CRON_TIME = '0 30 2 * * *';
const RETRY_TIMES = 4; // first time of request is 0 retry time
const DEFAULT_CRON_TIMEZONE = 'Europe/London';

@Injectable()
export class IsamsConfigService {
  constructor(private readonly configService: ConfigService) {}

  get cronJobName(): string {
    return 'iSAMS Cron Job';
  }
  get cronTime(): string {
    return this.configService.get('ISAMS_CRON_TIME', DEFAULT_CRON_TIME);
  }

  get cronTimeZone(): string {
    return this.configService.get('ISAMS_CRON_TIME_ZONE', DEFAULT_CRON_TIMEZONE);
  }

  get isCronON(): boolean {
    return !(this.configService.get('ISAMS_SYNC_SWITCHED_OFF', 'false').toLowerCase() === 'true');
  }

  get retryConfig(): IAxiosRetryConfig {
    return {
      retries: RETRY_TIMES,
      retryCondition: this.getRetryCondition(),
      retryDelay: exponentialDelay,
    };
  }

  getRetryCondition(): (err: AxiosError) => boolean {
    return (err: AxiosError): boolean => {
      const { response } = err;
      if (!response || !response.status || !this.getRetryStatusCodes().includes(response.status)) {
        return false;
      }
      return true;
    };
  }

  private getRetryStatusCodes(): ReadonlyArray<number> {
    return [
      HttpStatus.TOO_MANY_REQUESTS,
      HttpStatus.INTERNAL_SERVER_ERROR,
      HttpStatus.NOT_IMPLEMENTED,
      HttpStatus.BAD_GATEWAY,
      HttpStatus.SERVICE_UNAVAILABLE,
      HttpStatus.GATEWAY_TIMEOUT,
      HttpStatus.HTTP_VERSION_NOT_SUPPORTED,
      520,
    ];
  }
}

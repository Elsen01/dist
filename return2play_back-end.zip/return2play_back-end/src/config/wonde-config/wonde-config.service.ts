import { HttpStatus, Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { AxiosError } from 'axios';
import { exponentialDelay } from 'axios-retry';

import { HttpClientConfig } from '../../modules/shared/base-http-client';

const DEFAULT_CRON_TIME = '0 0 2 * * *';
const DEFAULT_CRON_TIMEZONE = 'Europe/London';
const DEFAULT_API_URL = 'https://api.wonde.com/v1.0';
const RETRY_TIMES = 4; // first time of request is 0 retry time

export const WONDE_SCHOOLS_QUEUE_NAME = 'wonde-schools';
export const WONDE_SCHOOLS_COMMAND_SYNC = 'sync';

@Injectable()
export class WondeConfigService {
  constructor(private readonly configService: ConfigService) {}

  get cronJobName(): string {
    return 'Wonde Cron Job';
  }
  get cronTime(): string {
    return this.configService.get('WONDE_CRON_TIME', DEFAULT_CRON_TIME);
  }

  get cronTimeZone(): string {
    return this.configService.get('WONDE_CRON_TIME_ZONE', DEFAULT_CRON_TIMEZONE);
  }

  get isCronON(): boolean {
    return !(this.configService.get('WONDE_SYNC_SWITCHED_OFF', 'false').toLowerCase() === 'true');
  }

  get schoolsToSkip(): ReadonlyArray<string> {
    return ['A1930499544'];
  }

  get httpClientConfig(): HttpClientConfig {
    return {
      apiConfig: {
        baseURL: this.configService.get<string>('WONDE_API_URL', DEFAULT_API_URL),
        headers: { Authorization: `Bearer ${this.configService.get<string>('WONDE_API_KEY')}` },
      },
      retryConfig: {
        retry: true,
        retryOptions: {
          retries: RETRY_TIMES,
          retryCondition: this.getRetryCondition(),
          retryDelay: exponentialDelay,
        },
      },
      rateLimitConfig: { maxRequests: 10, perMilliseconds: 1000 },
    };
  }

  private getRetryCondition(): (err: AxiosError) => boolean {
    return (err: AxiosError): boolean => {
      const { response } = err;
      if (!response || !response.status || !this.getRetryStatusCodes().includes(response.status)) {
        return false;
      }
      return true;
    };
  }

  private getRetryStatusCodes(): ReadonlyArray<number> {
    return [
      HttpStatus.TOO_MANY_REQUESTS,
      HttpStatus.INTERNAL_SERVER_ERROR,
      HttpStatus.NOT_IMPLEMENTED,
      HttpStatus.BAD_GATEWAY,
      HttpStatus.SERVICE_UNAVAILABLE,
      HttpStatus.GATEWAY_TIMEOUT,
      HttpStatus.HTTP_VERSION_NOT_SUPPORTED,
    ];
  }
}

import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { WondeConfigService } from './wonde-config.service';

@Module({
  imports: [ConfigModule],
  providers: [WondeConfigService],
  exports: [WondeConfigService],
})
export class WondeConfigModule {}

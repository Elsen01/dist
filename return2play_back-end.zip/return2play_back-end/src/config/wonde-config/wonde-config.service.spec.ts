import { Test, TestingModule } from '@nestjs/testing';
import { WondeConfigService } from './wonde-config.service';

describe('WondeConfigService', () => {
  let service: WondeConfigService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [WondeConfigService],
    }).compile();

    service = module.get<WondeConfigService>(WondeConfigService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});

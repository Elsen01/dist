import { IConfig } from './config.interfaces';

export default (): IConfig => ({
  environment: process.env.NODE_ENV,
  stage: process.env.DEPLOYMENT_ENV,
  serverPort: Number(process.env.PORT),
  frontendUrl: process.env.FRONTEND_URL,
  cognito: {
    UserPoolId: process.env.USER_POOL_ID,
    ClientId: process.env.CLIENT_ID,
    Issuer: process.env.ISSUER,
  },
  aws: {
    accessKeyId: process.env.ACCESS_KEY_ID,
    secretAccessKey: process.env.SECRET_ACCESS_KEY,
    s3Bucket: process.env.S3_BUCKET,
    region: process.env.REGION,
    lambdaHost: process.env.LAMBDA_FUNCTION_URL,
    mailerHost: process.env.MAILER_BASE_URL,
    csvTemplateLink: process.env.CSV_TEMPLATE_LINK,
  },
  database: {
    name: 'default',
    host: process.env.TYPEORM_HOST,
    username: process.env.TYPEORM_USERNAME,
    password: process.env.TYPEORM_PASSWORD,
    database: process.env.TYPEORM_DATABASE,
    port: Number(process.env.TYPEORM_PORT),
  },
  http: {
    baseURL: process.env.MAILER_BASE_URL,
    timeout: 5000,
  },
  stripe: {
    apiKey: process.env.STRIPE_API_KEY,
    webhookSecret: process.env.STRIPE_WEBHOOK_SECRET,
    config: {
      apiVersion: '2020-08-27',
      typescript: true,
    },
    cancelUrl: process.env.CANCEL_URL,
    successUrl: process.env.SUCCESS_URL,
    priceId30: process.env.PRICE_ID_30,
    priceId120: process.env.PRICE_ID_120,
  },
  wonde: {
    apiKey: process.env.WONDE_API_KEY,
    schoolPerPage: 50,
    clintId: process.env.WONDE_CLIENT_ID,
    clintSecret: process.env.WONDE_CLIENT_SECRET,
    authUri: 'https://edu.wonde.com/oauth/authorize',
    tokenUri: 'https://api.wonde.com/oauth/token',
    redirectUri: 'https://043b1a092822.ngrok.io',
    apiUri: 'https://api.wonde.com/v1.0',
    studentInclude: 'contact_details,contacts.contact_details,classes.subject,classes.employees,year.employees,year',
    employeeInclude: 'contact_details',
  },
  bull: {
    defaultJobOptions: {
      removeOnComplete: true,
    },
    redis: {
      host: process.env.REDIS_HOST,
      port: process.env.REDIS_PORT && parseInt(process.env.REDIS_PORT),
    },
  },
  redis: {
    host: process.env.REDIS_HOST,
    port: process.env.REDIS_PORT && parseInt(process.env.REDIS_PORT),
  },
});

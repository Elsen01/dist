import { join } from 'path';
import { transports, format } from 'winston';
import { utilities } from 'nest-winston';
import CloudWatchTransport from 'winston-aws-cloudwatch';

const devLevels = {
  error: 0,
  warn: 1,
  info: 2, // for morgan http requests
  debug: 3, // for development proposes
};

const prodLevels = {
  error: 0,
  warn: 1,
  info: 2,
};

const consoleOptions: transports.ConsoleTransportOptions = {
  level: 'debug',
  format: format.combine(
    utilities.format.nestLike(),
    format.timestamp(),
    process.env.COLORIZED ? format.colorize({ level: true }) : format.uncolorize(),
    format.align()
  ),
};

const cloudWatchOptions = new CloudWatchTransport({
  logGroupName: process.env.DEPLOYMENT_ENV,
  logStreamName: `stream_${process.env.DEPLOYMENT_ENV}`,
  createLogGroup: true,
  createLogStream: true,
  submissionInterval: 2000,
  submissionRetryCount: 1,
  batchSize: 20,
  awsConfig: {
    accessKeyId: process.env.ACCESS_KEY_ID,
    secretAccessKey: process.env.SECRET_ACCESS_KEY,
    region: process.env.REGION,
  },
  formatLog: (item): string => `${item.level}: ${item.message} ${JSON.stringify(item.meta)}`,
});

const fileOptions: transports.FileTransportOptions = {
  level: 'info',
  filename: join(process.env.PWD ?? process.cwd(), '/logs/app.log'),
  handleExceptions: true,
  maxsize: 5242880, // 5MB
  maxFiles: 1,
  format: format.combine(
    format.timestamp({
      format: 'MM-DD-YYYY HH:mm:ss',
    }),
    format.json(),
    format.splat(),
    format.align()
  ),
};

const destinations = [new transports.Console(consoleOptions), new transports.File(fileOptions)];

export default {
  devLevels,
  prodLevels,
  transports: destinations,
  cloudWatchOptions,
};

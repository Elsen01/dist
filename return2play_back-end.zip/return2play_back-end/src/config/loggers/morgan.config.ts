import { LoggerService } from '@nestjs/common';
import morgan from 'morgan';

const format = ':method :url with status :status and spent time :response-time ms';

const configureStream = (logger: LoggerService): morgan.StreamOptions => ({
  write: (message: string): void => {
    logger.log(message, 'Morgan');
  },
});

export default {
  format,
  configureStream,
};

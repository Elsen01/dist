import { Test, TestingModule } from '@nestjs/testing';
import { CognitoConfigService } from './cognito-config.service';

describe('CognitoConfigService', () => {
  let service: CognitoConfigService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [CognitoConfigService],
    }).compile();

    service = module.get<CognitoConfigService>(CognitoConfigService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});

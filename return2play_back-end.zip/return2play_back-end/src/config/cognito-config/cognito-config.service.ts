import { Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { ClientConfiguration } from 'aws-sdk/clients/cognitoidentityserviceprovider';

@Injectable()
export class CognitoConfigService {
  constructor(private readonly configService: ConfigService) {}

  /**
   * Getter for AWS credentials
   */
  get aws(): ClientConfiguration {
    return {
      apiVersion: 'latest',
      region: this.configService.get('REGION'),
      credentials: {
        accessKeyId: this.configService.get('ACCESS_KEY_ID'),
        secretAccessKey: this.configService.get('SECRET_ACCESS_KEY'),
      },
    };
  }

  /**
   * Getter for AWS Cognito User Pool Id
   */
  get UserPoolId(): string {
    return this.configService.get('USER_POOL_ID');
  }
}

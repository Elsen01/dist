import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { CognitoConfigService } from './cognito-config.service';

@Module({
  imports: [ConfigModule],
  providers: [CognitoConfigService],
  exports: [CognitoConfigService],
})
export class CognitoConfigModule {}

import { PAYMENT_WEBHOOK } from './modules/shared/constants';
import { raw } from 'body-parser';
import { NestFactory } from '@nestjs/core';
import { SwaggerModule, DocumentBuilder } from '@nestjs/swagger';
import { ValidationPipe } from '@nestjs/common';
import { WinstonModule } from 'nest-winston';
import morgan from 'morgan';

import { AppModule } from './modules/app.module';
import { AppConfigService } from './config/config.service';
import winstonConfigs from './config/loggers/winston.config';
import morganConfigs from './config/loggers/morgan.config';

async function bootstrap(): Promise<void> {
  const app = await NestFactory.create(AppModule);
  const appConfigService: AppConfigService = app.get('AppConfigService');
  const isDevelopment = appConfigService.environment === ('development' || 'staging');

  app.use(PAYMENT_WEBHOOK, raw({ type: 'application/json' }));
  app.enableCors();

  if (isDevelopment) {
    // const options = new DocumentBuilder().setTitle('Return2Play').addBearerAuth().build();
    // const document = SwaggerModule.createDocument(app, options);
    // SwaggerModule.setup('docs', app, document);
    app.enableCors();
  } else {
    //app.enableCors({ origin: appConfigService.frontendUrl }); temporary
    app.enableCors();
  }

  const options = new DocumentBuilder().setTitle('Return2Play').addBearerAuth().build();
  const document = SwaggerModule.createDocument(app, options);
  SwaggerModule.setup('docs', app, document);

  const logger = WinstonModule.createLogger({
    levels: isDevelopment ? winstonConfigs.devLevels : winstonConfigs.prodLevels,
    transports: isDevelopment ? winstonConfigs.transports : winstonConfigs.cloudWatchOptions,
  });

  const httpLogger = morgan(morganConfigs.format, {
    stream: morganConfigs.configureStream(logger),
  });

  app.useLogger(logger);
  app.use(httpLogger);

  app.useGlobalPipes(new ValidationPipe({ whitelist: true, forbidNonWhitelisted: true }));

  const port = process.env.PORT || appConfigService.serverPort || 3000;
  await app.listen(port).then(() => {
    logger.log(`App is listening port ${port}`);
  });
}

bootstrap();

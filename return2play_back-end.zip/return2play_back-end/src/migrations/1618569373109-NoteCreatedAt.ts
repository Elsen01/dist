import {MigrationInterface, QueryRunner} from "typeorm";

export class NoteCreatedAt1618569373109 implements MigrationInterface {
    name = 'NoteCreatedAt1618569373109'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "notes" ADD COLUMN "created_at" TIMESTAMP DEFAULT NOW();`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "notes" DROP COLUMN "notes";`);
    }

}

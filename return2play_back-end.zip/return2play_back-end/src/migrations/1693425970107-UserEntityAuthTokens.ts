import {MigrationInterface, QueryRunner} from "typeorm";

export class UserEntityAuthTokens1693425970107 implements MigrationInterface {
    name = 'UserEntityAuthTokens1693425970107'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "users" ADD "idToken" character varying(500)`);
        await queryRunner.query(`ALTER TABLE "users" ADD "accessToken" character varying(500)`);
        await queryRunner.query(`ALTER TABLE "users" ADD "refreshToken" character varying(500)`);
        /*await queryRunner.query(`ALTER TYPE "injuries_injury_group_enum_old" RENAME TO "injuries_injury_group_enum_old_old"`);
        await queryRunner.query(`CREATE TYPE "injuries_injury_group_enum" AS ENUM('Concussion', 'Other', 'Head Injury (possible concussion)')`);
        await queryRunner.query(`ALTER TABLE "injuries" ALTER COLUMN "injury_group" TYPE "injuries_injury_group_enum" USING "injury_group"::"text"::"injuries_injury_group_enum"`);
        await queryRunner.query(`DROP TYPE "injuries_injury_group_enum_old_old"`);*/
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`CREATE TYPE "injuries_injury_group_enum_old_old" AS ENUM('Concussion', 'Head Injury', 'Head Injury (possible concussion)', 'Head Injury (suspected concussion)', 'Other')`);
        await queryRunner.query(`ALTER TABLE "injuries" ALTER COLUMN "injury_group" TYPE "injuries_injury_group_enum_old_old" USING "injury_group"::"text"::"injuries_injury_group_enum_old_old"`);
        await queryRunner.query(`DROP TYPE "injuries_injury_group_enum"`);
        await queryRunner.query(`ALTER TYPE "injuries_injury_group_enum_old_old" RENAME TO "injuries_injury_group_enum_old"`);
        await queryRunner.query(`ALTER TABLE "users" DROP COLUMN "refreshToken"`);
        await queryRunner.query(`ALTER TABLE "users" DROP COLUMN "accessToken"`);
        await queryRunner.query(`ALTER TABLE "users" DROP COLUMN "idToken"`);
    }

}

import { MigrationInterface, QueryRunner } from 'typeorm';

export class FixUserStatus1616592485920 implements MigrationInterface {
  name = 'FixUserStatus1616592485920';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TYPE "public"."users_status_enum" RENAME TO "users_status_enum_old"`);
    await queryRunner.query(`CREATE TYPE "users_status_enum" AS ENUM('Active', 'Inactive', 'Deleted')`);
    await queryRunner.query(`ALTER TABLE "users" ALTER COLUMN "status" DROP DEFAULT`);
    await queryRunner.query(
      `ALTER TABLE "users" ALTER COLUMN "status" TYPE "users_status_enum" USING "status"::"text"::"users_status_enum"`
    );
    await queryRunner.query(`ALTER TABLE "users" ALTER COLUMN "status" SET DEFAULT 'Inactive'`);
    await queryRunner.query(`DROP TYPE "users_status_enum_old"`);
    await queryRunner.query(`COMMENT ON COLUMN "users"."status" IS NULL`);
    await queryRunner.query(`ALTER TABLE "users" ALTER COLUMN "status" SET DEFAULT 'Inactive'`);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "users" ALTER COLUMN "status" SET DEFAULT 'Inactived'`);
    await queryRunner.query(`COMMENT ON COLUMN "users"."status" IS NULL`);
    await queryRunner.query(`CREATE TYPE "users_status_enum_old" AS ENUM('Actived', 'Inactived', 'Deleted')`);
    await queryRunner.query(`ALTER TABLE "users" ALTER COLUMN "status" DROP DEFAULT`);
    await queryRunner.query(
      `ALTER TABLE "users" ALTER COLUMN "status" TYPE "users_status_enum_old" USING "status"::"text"::"users_status_enum_old"`
    );
    await queryRunner.query(`ALTER TABLE "users" ALTER COLUMN "status" SET DEFAULT 'Inactive'`);
    await queryRunner.query(`DROP TYPE "users_status_enum"`);
    await queryRunner.query(`ALTER TYPE "users_status_enum_old" RENAME TO  "users_status_enum"`);
  }
}

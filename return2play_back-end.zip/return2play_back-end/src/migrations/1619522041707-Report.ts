import {MigrationInterface, QueryRunner} from "typeorm";

export class Report1619522041707 implements MigrationInterface {
    name = 'Report1619522041707'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`CREATE TYPE "reports_format_enum" AS ENUM('pdf', 'csv')`);
        await queryRunner.query(`CREATE TABLE "reports" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "format" "reports_format_enum" NOT NULL, "date" TIMESTAMP NOT NULL DEFAULT now(), "author_id" character varying NOT NULL, CONSTRAINT "PK_d9013193989303580053c0b5ef6" PRIMARY KEY ("id"))`);
        await queryRunner.query(`ALTER TABLE "reports" ADD CONSTRAINT "FK_af66c04d96c3fd3ba7612fdf5e9" FOREIGN KEY ("author_id") REFERENCES "users"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "reports" DROP CONSTRAINT "FK_af66c04d96c3fd3ba7612fdf5e9"`);
        await queryRunner.query(`DROP TABLE "reports"`);
        await queryRunner.query(`DROP TYPE "reports_format_enum"`);
    }

}

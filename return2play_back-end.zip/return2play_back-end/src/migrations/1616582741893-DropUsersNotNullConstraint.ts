import { MigrationInterface, QueryRunner } from 'typeorm';

export class DropUsersNotNullConstraint1616582741893 implements MigrationInterface {
  name = 'DropUsersNotNullConstraint1616582741893';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "users" ALTER COLUMN "gender" DROP NOT NULL`);
    await queryRunner.query(`COMMENT ON COLUMN "users"."gender" IS NULL`);
    await queryRunner.query(`ALTER TABLE "users" ALTER COLUMN "birthday" DROP NOT NULL`);
    await queryRunner.query(`COMMENT ON COLUMN "users"."birthday" IS NULL`);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`COMMENT ON COLUMN "users"."birthday" IS NULL`);
    await queryRunner.query(`ALTER TABLE "users" ALTER COLUMN "birthday" SET NOT NULL`);
    await queryRunner.query(`COMMENT ON COLUMN "users"."gender" IS NULL`);
    await queryRunner.query(`ALTER TABLE "users" ALTER COLUMN "gender" SET NOT NULL`);
  }
}

import {MigrationInterface, QueryRunner} from "typeorm";

export class BodyPartAndRegion1618310137656 implements MigrationInterface {
    name = 'BodyPartAndRegion1618310137656'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "injury_binary_symptoms" DROP CONSTRAINT "FK_c876e5840abcbf7c2429c488929"`);
        await queryRunner.query(`ALTER TABLE "injury_red_flag_symptoms" DROP CONSTRAINT "FK_9a9d8838b5f92cf8a553ac7df50"`);
        await queryRunner.query(`ALTER TABLE "injury_symptoms" DROP CONSTRAINT "FK_dc355e152cd37e6d7d4549f6dfe"`);
        await queryRunner.query(`CREATE TABLE "body_regions" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "name" character varying(255) NOT NULL, CONSTRAINT "PK_1619263684e2d3a6f7036757b51" PRIMARY KEY ("id"))`);
        await queryRunner.query(`CREATE TABLE "body_parts" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "name" character varying(255) NOT NULL, "body_region_id" uuid, CONSTRAINT "PK_3b85af620434917bf70513b1822" PRIMARY KEY ("id"))`);
        await queryRunner.query(`ALTER TABLE "body_parts" ADD CONSTRAINT "FK_b98c9bee0d15807cf50d54f4e2d" FOREIGN KEY ("body_region_id") REFERENCES "body_regions"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "injury_binary_symptoms" ADD CONSTRAINT "FK_c876e5840abcbf7c2429c488929" FOREIGN KEY ("binary_symptom_id") REFERENCES "binary_symptoms"("id") ON DELETE CASCADE ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "injury_red_flag_symptoms" ADD CONSTRAINT "FK_9a9d8838b5f92cf8a553ac7df50" FOREIGN KEY ("red_flag_symptom_id") REFERENCES "red_flag_symptoms"("id") ON DELETE CASCADE ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "injury_symptoms" ADD CONSTRAINT "FK_dc355e152cd37e6d7d4549f6dfe" FOREIGN KEY ("symptom_id") REFERENCES "symptoms"("id") ON DELETE CASCADE ON UPDATE NO ACTION`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "injury_symptoms" DROP CONSTRAINT "FK_dc355e152cd37e6d7d4549f6dfe"`);
        await queryRunner.query(`ALTER TABLE "injury_red_flag_symptoms" DROP CONSTRAINT "FK_9a9d8838b5f92cf8a553ac7df50"`);
        await queryRunner.query(`ALTER TABLE "injury_binary_symptoms" DROP CONSTRAINT "FK_c876e5840abcbf7c2429c488929"`);
        await queryRunner.query(`ALTER TABLE "body_parts" DROP CONSTRAINT "FK_b98c9bee0d15807cf50d54f4e2d"`);
        await queryRunner.query(`DROP TABLE "body_parts"`);
        await queryRunner.query(`DROP TABLE "body_regions"`);
        await queryRunner.query(`ALTER TABLE "injury_symptoms" ADD CONSTRAINT "FK_dc355e152cd37e6d7d4549f6dfe" FOREIGN KEY ("symptom_id") REFERENCES "symptoms"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "injury_red_flag_symptoms" ADD CONSTRAINT "FK_9a9d8838b5f92cf8a553ac7df50" FOREIGN KEY ("red_flag_symptom_id") REFERENCES "red_flag_symptoms"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "injury_binary_symptoms" ADD CONSTRAINT "FK_c876e5840abcbf7c2429c488929" FOREIGN KEY ("binary_symptom_id") REFERENCES "binary_symptoms"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
    }

}

import {MigrationInterface, QueryRunner} from "typeorm";

export class DropNotNullSportInjuryTimePeriod1624530539690 implements MigrationInterface {
    name = 'DropNotNullSportInjuryTimePeriod1624530539690'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "sport_injuries" ALTER COLUMN "time_period" DROP NOT NULL`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "sport_injuries" ALTER COLUMN "time_period" SET NOT NULL`);
    }

}

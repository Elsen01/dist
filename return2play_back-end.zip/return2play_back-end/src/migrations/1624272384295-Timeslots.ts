import {MigrationInterface, QueryRunner} from "typeorm";

export class Timeslots1624272384295 implements MigrationInterface {
    name = 'Timeslots1624272384295'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`CREATE TYPE "timeslots_status_enum" AS ENUM('Active', 'Inactive')`);
        await queryRunner.query(`CREATE TABLE "timeslots" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "start_time" TIME NOT NULL, "end_time" TIME NOT NULL, "date" date NOT NULL, "status" "timeslots_status_enum" NOT NULL DEFAULT 'Active', "booked" boolean NOT NULL DEFAULT false, "clinic_id" uuid, CONSTRAINT "PK_857018e7b0ab7cc1f8828f7543a" PRIMARY KEY ("id"))`);
        await queryRunner.query(`ALTER TABLE "assessments" DROP COLUMN "outcome_note"`);
        await queryRunner.query(`ALTER TABLE "appointments" ADD "timeslot_id" uuid NOT NULL`);
        await queryRunner.query(`ALTER TABLE "appointments" ADD CONSTRAINT "UQ_a80714689a4c3de9f5547a05c9c" UNIQUE ("timeslot_id")`);
        await queryRunner.query(`ALTER TABLE "appointments" ADD "injury_id" uuid NOT NULL`);
        await queryRunner.query(`ALTER TABLE "tags" DROP CONSTRAINT "FK_8f8033a570b04520455cc93ed3d"`);
        await queryRunner.query(`ALTER TABLE "tags" DROP CONSTRAINT "UQ_b3fd0b26c4e8d043bdf0d1bfab8"`);
        await queryRunner.query(`ALTER TABLE "tags" ALTER COLUMN "organization_id" SET NOT NULL`);
        await queryRunner.query(`ALTER TABLE "appointments" DROP CONSTRAINT "FK_55967cbb87411ed767fa9e3b60f"`);
        await queryRunner.query(`ALTER TABLE "appointments" DROP CONSTRAINT "FK_4cf26c3f972d014df5c68d503d2"`);
        await queryRunner.query(`ALTER TABLE "appointments" DROP COLUMN "location"`);
        await queryRunner.query(`ALTER TABLE "appointments" ADD "location" character varying(255)`);
        await queryRunner.query(`ALTER TYPE "appointments_status_enum" RENAME TO "appointments_status_enum_old"`);
        await queryRunner.query(`CREATE TYPE "appointments_status_enum" AS ENUM('new', 'completed', 'not attended')`);
        await queryRunner.query(`ALTER TABLE "appointments" ALTER COLUMN "status" DROP DEFAULT`);
        await queryRunner.query(`ALTER TABLE "appointments" ALTER COLUMN "status" TYPE "appointments_status_enum" USING "status"::"text"::"appointments_status_enum"`);
        await queryRunner.query(`ALTER TABLE "appointments" ALTER COLUMN "status" SET DEFAULT 'new'`);
        await queryRunner.query(`DROP TYPE "appointments_status_enum_old"`);
        await queryRunner.query(`ALTER TABLE "appointments" ALTER COLUMN "player_id" SET NOT NULL`);
        await queryRunner.query(`ALTER TABLE "appointments" ALTER COLUMN "doctor_id" SET NOT NULL`);
        await queryRunner.query(`ALTER TABLE "tags" ADD CONSTRAINT "UQ_b3fd0b26c4e8d043bdf0d1bfab8" UNIQUE ("name", "organization_id")`);
        await queryRunner.query(`ALTER TABLE "tags" ADD CONSTRAINT "FK_8f8033a570b04520455cc93ed3d" FOREIGN KEY ("organization_id") REFERENCES "organizations"("id") ON DELETE CASCADE ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "timeslots" ADD CONSTRAINT "FK_1aff887bd459420f80b1ac32287" FOREIGN KEY ("clinic_id") REFERENCES "clinics"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "appointments" ADD CONSTRAINT "FK_a80714689a4c3de9f5547a05c9c" FOREIGN KEY ("timeslot_id") REFERENCES "timeslots"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "appointments" ADD CONSTRAINT "FK_55967cbb87411ed767fa9e3b60f" FOREIGN KEY ("player_id") REFERENCES "players"("user_id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "appointments" ADD CONSTRAINT "FK_4cf26c3f972d014df5c68d503d2" FOREIGN KEY ("doctor_id") REFERENCES "doctors"("user_id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "appointments" ADD CONSTRAINT "FK_775044b289f96a9f8be710aa02e" FOREIGN KEY ("injury_id") REFERENCES "injuries"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "appointments" DROP CONSTRAINT "FK_775044b289f96a9f8be710aa02e"`);
        await queryRunner.query(`ALTER TABLE "appointments" DROP CONSTRAINT "FK_4cf26c3f972d014df5c68d503d2"`);
        await queryRunner.query(`ALTER TABLE "appointments" DROP CONSTRAINT "FK_55967cbb87411ed767fa9e3b60f"`);
        await queryRunner.query(`ALTER TABLE "appointments" DROP CONSTRAINT "FK_a80714689a4c3de9f5547a05c9c"`);
        await queryRunner.query(`ALTER TABLE "timeslots" DROP CONSTRAINT "FK_1aff887bd459420f80b1ac32287"`);
        await queryRunner.query(`ALTER TABLE "tags" DROP CONSTRAINT "FK_8f8033a570b04520455cc93ed3d"`);
        await queryRunner.query(`ALTER TABLE "tags" DROP CONSTRAINT "UQ_b3fd0b26c4e8d043bdf0d1bfab8"`);
        await queryRunner.query(`ALTER TABLE "appointments" ALTER COLUMN "doctor_id" DROP NOT NULL`);
        await queryRunner.query(`ALTER TABLE "appointments" ALTER COLUMN "player_id" DROP NOT NULL`);
        await queryRunner.query(`CREATE TYPE "appointments_status_enum_old" AS ENUM('new', 'completed')`);
        await queryRunner.query(`ALTER TABLE "appointments" ALTER COLUMN "status" DROP DEFAULT`);
        await queryRunner.query(`ALTER TABLE "appointments" ALTER COLUMN "status" TYPE "appointments_status_enum_old" USING "status"::"text"::"appointments_status_enum_old"`);
        await queryRunner.query(`ALTER TABLE "appointments" ALTER COLUMN "status" SET DEFAULT 'new'`);
        await queryRunner.query(`DROP TYPE "appointments_status_enum"`);
        await queryRunner.query(`ALTER TYPE "appointments_status_enum_old" RENAME TO "appointments_status_enum"`);
        await queryRunner.query(`ALTER TABLE "appointments" DROP COLUMN "location"`);
        await queryRunner.query(`ALTER TABLE "appointments" ADD "location" character varying NOT NULL`);
        await queryRunner.query(`ALTER TABLE "appointments" ADD CONSTRAINT "FK_4cf26c3f972d014df5c68d503d2" FOREIGN KEY ("doctor_id") REFERENCES "doctors"("user_id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "appointments" ADD CONSTRAINT "FK_55967cbb87411ed767fa9e3b60f" FOREIGN KEY ("player_id") REFERENCES "players"("user_id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "tags" ALTER COLUMN "organization_id" DROP NOT NULL`);
        await queryRunner.query(`ALTER TABLE "tags" ADD CONSTRAINT "UQ_b3fd0b26c4e8d043bdf0d1bfab8" UNIQUE ("name", "organization_id")`);
        await queryRunner.query(`ALTER TABLE "tags" ADD CONSTRAINT "FK_8f8033a570b04520455cc93ed3d" FOREIGN KEY ("organization_id") REFERENCES "organizations"("id") ON DELETE CASCADE ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "appointments" DROP COLUMN "injury_id"`);
        await queryRunner.query(`ALTER TABLE "appointments" DROP CONSTRAINT "UQ_a80714689a4c3de9f5547a05c9c"`);
        await queryRunner.query(`ALTER TABLE "appointments" DROP COLUMN "timeslot_id"`);
        await queryRunner.query(`ALTER TABLE "assessments" ADD "outcome_note" character varying(1000)`);
        await queryRunner.query(`DROP TABLE "timeslots"`);
        await queryRunner.query(`DROP TYPE "timeslots_status_enum"`);
    }

}

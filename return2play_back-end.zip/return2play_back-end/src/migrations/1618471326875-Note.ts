import {MigrationInterface, QueryRunner} from "typeorm";

export class Note1618471326875 implements MigrationInterface {
    name = 'Note1618471326875'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`CREATE TABLE "notes" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "text" character varying(1000) NOT NULL, "injury_id" uuid NOT NULL, CONSTRAINT "PK_af6206538ea96c4e77e9f400c3d" PRIMARY KEY ("id"))`);
        await queryRunner.query(`ALTER TABLE "notes" ADD CONSTRAINT "FK_562336fd3543a525e928bffd662" FOREIGN KEY ("injury_id") REFERENCES "injuries"("id") ON DELETE CASCADE ON UPDATE NO ACTION`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "notes" DROP CONSTRAINT "FK_562336fd3543a525e928bffd662"`);
        await queryRunner.query(`DROP TABLE "notes"`);
    }

}

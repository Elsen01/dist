import {MigrationInterface, QueryRunner} from "typeorm";

export class DropNotNullSportInjuryMechanism1624531725288 implements MigrationInterface {
    name = 'DropNotNullSportInjuryMechanism1624531725288'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "sport_injuries" DROP CONSTRAINT "FK_3b2bafcc20315ef1c0491ec1336"`);
        await queryRunner.query(`ALTER TABLE "sport_injuries" ALTER COLUMN "mechanism_id" DROP NOT NULL`);
        await queryRunner.query(`ALTER TABLE "sport_injuries" ADD CONSTRAINT "FK_3b2bafcc20315ef1c0491ec1336" FOREIGN KEY ("mechanism_id") REFERENCES "injury_mechanisms"("id") ON DELETE CASCADE ON UPDATE NO ACTION`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "sport_injuries" DROP CONSTRAINT "FK_3b2bafcc20315ef1c0491ec1336"`);
        await queryRunner.query(`ALTER TABLE "sport_injuries" ALTER COLUMN "mechanism_id" SET NOT NULL`);
        await queryRunner.query(`ALTER TABLE "sport_injuries" ADD CONSTRAINT "FK_3b2bafcc20315ef1c0491ec1336" FOREIGN KEY ("mechanism_id") REFERENCES "injury_mechanisms"("id") ON DELETE CASCADE ON UPDATE NO ACTION`);
    }

}

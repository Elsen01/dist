import {MigrationInterface, QueryRunner} from "typeorm";

export class FixIsSocs1625825990311 implements MigrationInterface {
    name = 'FixIsSocs1625825990311'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "organizations" ALTER COLUMN "is_socs" DROP NOT NULL`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "organizations" ALTER COLUMN "is_socs" SET NOT NULL`);
    }

}

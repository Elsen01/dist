import { MigrationInterface, QueryRunner } from 'typeorm';

export class OrganizationLogo1617028132446 implements MigrationInterface {
  name = 'OrganizationLogo1617028132446';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "organizations" ADD "logo" character varying`);
    await queryRunner.query(
      `ALTER TABLE "organizations" ADD CONSTRAINT "UQ_a579d88c61ea408bda4be5eab7d" UNIQUE ("logo")`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "organizations" DROP CONSTRAINT "UQ_a579d88c61ea408bda4be5eab7d"`);
    await queryRunner.query(`ALTER TABLE "organizations" DROP COLUMN "logo"`);
  }
}

import { MigrationInterface, QueryRunner } from 'typeorm';

export class ISAMS1672301479014 implements MigrationInterface {
  name = 'ISAMS1672301479014';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`CREATE TYPE "isams_sync_logs_level_enum" AS ENUM('info', 'warning', 'error')`);
    await queryRunner.query(
      `CREATE TABLE "isams_sync_logs" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "message" character varying, "description" text, "errorDetails" text, "level" "isams_sync_logs_level_enum" NOT NULL DEFAULT 'info', "createdAt" TIMESTAMP NOT NULL DEFAULT now(), "updatedAt" TIMESTAMP NOT NULL DEFAULT now(), "syncId" uuid NOT NULL, CONSTRAINT "PK_7b25ec48f60dbadc35c27cca831" PRIMARY KEY ("id"))`
    );
    await queryRunner.query(`CREATE INDEX "IDX_ec6282b05e04f51585163ad1cd" ON "isams_sync_logs" ("level") `);
    await queryRunner.query(`CREATE INDEX "IDX_9c2085bbe7d3945c34e7cf3c9a" ON "isams_sync_logs" ("syncId") `);
    await queryRunner.query(`CREATE TYPE "isams_syncs_result_enum" AS ENUM('success', 'failed', 'partly_success')`);
    await queryRunner.query(
      `CREATE TABLE "isams_syncs" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "createdAt" TIMESTAMP NOT NULL DEFAULT now(), "updatedAt" TIMESTAMP NOT NULL DEFAULT now(), "startedAt" TIMESTAMP, "receivedAt" TIMESTAMP, "finishedAt" TIMESTAMP, "result" "isams_syncs_result_enum", "organizationId" uuid NOT NULL, CONSTRAINT "PK_7adc658b763dae611d20441dc4d" PRIMARY KEY ("id"))`
    );
    await queryRunner.query(`CREATE INDEX "IDX_ccd900290c638efab3bf6ecf87" ON "isams_syncs" ("result") `);
    await queryRunner.query(`CREATE INDEX "IDX_a652319bba58af36d07caaddd7" ON "isams_syncs" ("organizationId") `);
    await queryRunner.query(`ALTER TABLE "organizations" ADD "isams_url" character varying`);
    await queryRunner.query(`ALTER TABLE "organizations" ADD "isams_key" character varying`);
    await queryRunner.query(
      `ALTER TABLE "isams_sync_logs" ADD CONSTRAINT "FK_9c2085bbe7d3945c34e7cf3c9ab" FOREIGN KEY ("syncId") REFERENCES "isams_syncs"("id") ON DELETE CASCADE ON UPDATE NO ACTION`
    );
    await queryRunner.query(
      `ALTER TABLE "isams_syncs" ADD CONSTRAINT "FK_a652319bba58af36d07caaddd76" FOREIGN KEY ("organizationId") REFERENCES "organizations"("id") ON DELETE CASCADE ON UPDATE NO ACTION`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "isams_syncs" DROP CONSTRAINT "FK_a652319bba58af36d07caaddd76"`);
    await queryRunner.query(`ALTER TABLE "isams_sync_logs" DROP CONSTRAINT "FK_9c2085bbe7d3945c34e7cf3c9ab"`);
    await queryRunner.query(`ALTER TABLE "organizations" DROP COLUMN "isams_key"`);
    await queryRunner.query(`ALTER TABLE "organizations" DROP COLUMN "isams_url"`);
    await queryRunner.query(`DROP INDEX "IDX_a652319bba58af36d07caaddd7"`);
    await queryRunner.query(`DROP INDEX "IDX_ccd900290c638efab3bf6ecf87"`);
    await queryRunner.query(`DROP TABLE "isams_syncs"`);
    await queryRunner.query(`DROP TYPE "isams_syncs_result_enum"`);
    await queryRunner.query(`DROP INDEX "IDX_9c2085bbe7d3945c34e7cf3c9a"`);
    await queryRunner.query(`DROP INDEX "IDX_ec6282b05e04f51585163ad1cd"`);
    await queryRunner.query(`DROP TABLE "isams_sync_logs"`);
    await queryRunner.query(`DROP TYPE "isams_sync_logs_level_enum"`);
  }
}

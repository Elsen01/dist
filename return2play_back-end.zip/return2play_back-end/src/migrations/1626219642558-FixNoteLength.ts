import {MigrationInterface, QueryRunner} from "typeorm";

export class FixNoteLength1626219642558 implements MigrationInterface {
    name = 'FixNoteLength1626219642558'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "notes" DROP COLUMN "text"`);
        await queryRunner.query(`ALTER TABLE "notes" ADD "text" character varying NOT NULL`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "notes" DROP COLUMN "text"`);
        await queryRunner.query(`ALTER TABLE "notes" ADD "text" character varying(1000) NOT NULL`);
    }

}

import {MigrationInterface, QueryRunner} from "typeorm";

export class ChangeWondeSchool1622549022317 implements MigrationInterface {
    name = 'ChangeWondeSchool1622549022317'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "wonde_schools" ALTER COLUMN "establishment_number" DROP NOT NULL`);
        await queryRunner.query(`ALTER TABLE "wonde_schools" ALTER COLUMN "la_code" DROP NOT NULL`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "wonde_schools" ALTER COLUMN "la_code" SET NOT NULL`);
        await queryRunner.query(`ALTER TABLE "wonde_schools" ALTER COLUMN "establishment_number" SET NOT NULL`);
    }

}

import {MigrationInterface, QueryRunner} from "typeorm";

export class Assessments1620217227893 implements MigrationInterface {
    name = 'Assessments1620217227893'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`CREATE TABLE "grtp" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "start_date" date NOT NULL, "gentle_pe_lessons_date" date NOT NULL, "normal_pe_lessons_date" date NOT NULL, "non_contact_training_date" date NOT NULL, "no_restrictions_training_date" date NOT NULL, "assessment_id" uuid, CONSTRAINT "REL_91255c4d66041a4699273d8ff1" UNIQUE ("assessment_id"), CONSTRAINT "PK_aec3f9a576a3bb16b4b37bc738a" PRIMARY KEY ("id"))`);
        await queryRunner.query(`CREATE TYPE "scat_list_used_immediate_memory_enum" AS ENUM('A', 'B', 'C', 'D', 'E', 'F')`);
        await queryRunner.query(`CREATE TYPE "scat_list_used_digits_backwards_enum" AS ENUM('A', 'B', 'C', 'D', 'E', 'F')`);
        await queryRunner.query(`CREATE TABLE "scat" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "orientation" integer NOT NULL, "immediate_memory" integer NOT NULL, "list_used_immediate_memory" "scat_list_used_immediate_memory_enum" NOT NULL, "digits_backwards" integer NOT NULL, "list_used_digits_backwards" "scat_list_used_digits_backwards_enum" NOT NULL, "months_in_reverse" integer NOT NULL, "double_leg" integer NOT NULL, "single_leg" integer NOT NULL, "tandem_leg" integer NOT NULL, "note" character varying(1000) NOT NULL, CONSTRAINT "PK_1df6f5ecd9e8a548d9e1a0aad88" PRIMARY KEY ("id"))`);
        await queryRunner.query(`CREATE TYPE "assessments_decided_outcome_enum" AS ENUM('GRTP', 'Not yet fit - re-review in 1 week', 'Refer to MDT', 'Refer for external care', 'Clear injury')`);
        await queryRunner.query(`CREATE TABLE "assessments" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "return_to_play_date" date, "outcome_note" character varying(1000), "decided_outcome" "assessments_decided_outcome_enum" NOT NULL, "certificate_link" character varying NOT NULL, "appointment_id" uuid NOT NULL, "scat_id" uuid NOT NULL, CONSTRAINT "REL_e621f7ff8b4f943d42567f273d" UNIQUE ("appointment_id"), CONSTRAINT "REL_6032f38de9322e78c966d6c04f" UNIQUE ("scat_id"), CONSTRAINT "PK_a3442bd80a00e9111cefca57f6c" PRIMARY KEY ("id"))`);
        await queryRunner.query(`ALTER TABLE "grtp" ADD CONSTRAINT "FK_91255c4d66041a4699273d8ff1a" FOREIGN KEY ("assessment_id") REFERENCES "assessments"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "assessments" ADD CONSTRAINT "FK_e621f7ff8b4f943d42567f273d5" FOREIGN KEY ("appointment_id") REFERENCES "appointments"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "assessments" ADD CONSTRAINT "FK_6032f38de9322e78c966d6c04f2" FOREIGN KEY ("scat_id") REFERENCES "scat"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "assessments" DROP CONSTRAINT "FK_6032f38de9322e78c966d6c04f2"`);
        await queryRunner.query(`ALTER TABLE "assessments" DROP CONSTRAINT "FK_e621f7ff8b4f943d42567f273d5"`);
        await queryRunner.query(`ALTER TABLE "grtp" DROP CONSTRAINT "FK_91255c4d66041a4699273d8ff1a"`);
        await queryRunner.query(`DROP TABLE "assessments"`);
        await queryRunner.query(`DROP TYPE "assessments_decided_outcome_enum"`);
        await queryRunner.query(`DROP TABLE "scat"`);
        await queryRunner.query(`DROP TYPE "scat_list_used_digits_backwards_enum"`);
        await queryRunner.query(`DROP TYPE "scat_list_used_immediate_memory_enum"`);
        await queryRunner.query(`DROP TABLE "grtp"`);
    }

}

import {MigrationInterface, QueryRunner} from "typeorm";

export class ExternalAssessments1620387814443 implements MigrationInterface {
    name = 'ExternalAssessments1620387814443'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`CREATE TYPE "external_assessments_new_play_status_enum" AS ENUM('Safe to play', 'Reduced level of activity', 'Not safe to play', 'Cleared')`);
        await queryRunner.query(`CREATE TABLE "external_assessments" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "doctor_first_name" character varying(255) NOT NULL, "doctor_last_name" character varying(255) NOT NULL, "certificate_link" character varying, "new_play_status" "external_assessments_new_play_status_enum" NOT NULL, "created_at" TIMESTAMP NOT NULL DEFAULT now(), "injury_id" uuid NOT NULL, CONSTRAINT "PK_1b6d5eeaafd194e6781af28982d" PRIMARY KEY ("id"))`);
        await queryRunner.query(`ALTER TABLE "external_assessments" ADD CONSTRAINT "FK_cc87d7e9b682d33374d6eb7812a" FOREIGN KEY ("injury_id") REFERENCES "injuries"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "external_assessments" DROP CONSTRAINT "FK_cc87d7e9b682d33374d6eb7812a"`);
        await queryRunner.query(`DROP TABLE "external_assessments"`);
        await queryRunner.query(`DROP TYPE "external_assessments_new_play_status_enum"`);
    }

}

import {MigrationInterface, QueryRunner} from "typeorm";

export class UpdateClinicSchedule1619517538671 implements MigrationInterface {
    name = 'UpdateClinicSchedule1619517538671'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "doctor_clinic_schedule" RENAME COLUMN "day" TO "days"`);
        await queryRunner.query(`ALTER TYPE "public"."doctor_clinic_schedule_day_enum" RENAME TO "doctor_clinic_schedule_days_enum"`);
        await queryRunner.query(`CREATE TYPE "clinics_type_enum" AS ENUM('one-time', 'recurring')`);
        await queryRunner.query(`ALTER TABLE "clinics" ADD "type" "clinics_type_enum" NOT NULL DEFAULT 'one-time'`);
        await queryRunner.query(`ALTER TABLE "clinics" ADD "schedule_id" uuid`);
        await queryRunner.query(`ALTER TABLE "doctor_clinic_schedule" DROP COLUMN "days"`);
        await queryRunner.query(`ALTER TABLE "doctor_clinic_schedule" ADD "days" text NOT NULL`);
        await queryRunner.query(`ALTER TABLE "clinics" ADD CONSTRAINT "FK_88648bb1654b6cd00d259c84e41" FOREIGN KEY ("schedule_id") REFERENCES "doctor_clinic_schedule"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "clinics" DROP CONSTRAINT "FK_88648bb1654b6cd00d259c84e41"`);
        await queryRunner.query(`ALTER TABLE "doctor_clinic_schedule" DROP COLUMN "days"`);
        await queryRunner.query(`ALTER TABLE "doctor_clinic_schedule" ADD "days" "doctor_clinic_schedule_days_enum" NOT NULL`);
        await queryRunner.query(`ALTER TABLE "clinics" DROP COLUMN "schedule_id"`);
        await queryRunner.query(`ALTER TABLE "clinics" DROP COLUMN "type"`);
        await queryRunner.query(`DROP TYPE "clinics_type_enum"`);
        await queryRunner.query(`ALTER TYPE "doctor_clinic_schedule_days_enum" RENAME TO "doctor_clinic_schedule_day_enum"`);
        await queryRunner.query(`ALTER TABLE "doctor_clinic_schedule" RENAME COLUMN "days" TO "day"`);
    }

}

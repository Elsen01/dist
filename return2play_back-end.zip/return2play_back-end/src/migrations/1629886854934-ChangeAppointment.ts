import {MigrationInterface, QueryRunner} from "typeorm";

export class ChangeAppointment1629886854934 implements MigrationInterface {
    name = 'ChangeAppointment1629886854934'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "appointments" DROP CONSTRAINT "FK_a80714689a4c3de9f5547a05c9c"`);
        await queryRunner.query(`ALTER TABLE "appointments" ADD CONSTRAINT "FK_a80714689a4c3de9f5547a05c9c" FOREIGN KEY ("timeslot_id") REFERENCES "timeslots"("id") ON DELETE CASCADE ON UPDATE NO ACTION`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "appointments" DROP CONSTRAINT "FK_a80714689a4c3de9f5547a05c9c"`);
        await queryRunner.query(`ALTER TABLE "appointments" ADD CONSTRAINT "FK_a80714689a4c3de9f5547a05c9c" FOREIGN KEY ("timeslot_id") REFERENCES "timeslots"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
    }

}

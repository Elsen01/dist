import {MigrationInterface, QueryRunner} from "typeorm";

export class ClinicAllOrganization1627901165257 implements MigrationInterface {
    name = 'ClinicAllOrganization1627901165257'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "clinics" ADD "all_organizations" boolean`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "clinics" DROP COLUMN "all_organizations"`);
    }

}

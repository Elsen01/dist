import {MigrationInterface, QueryRunner} from "typeorm";

export class WondeMetadata1622041530230 implements MigrationInterface {
    name = 'WondeMetadata1622041530230'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`CREATE TABLE "wonde_schools" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "wonde_id" character varying(255) NOT NULL, "establishment_number" character varying(255) NOT NULL, "la_code" character varying(255) NOT NULL, "last_update" TIMESTAMP WITH TIME ZONE NOT NULL, "organization_id" uuid NOT NULL, CONSTRAINT "REL_2a6c18bd5494f4a0e137c48a93" UNIQUE ("organization_id"), CONSTRAINT "PK_485fa6a7f1d644bcde038e36a03" PRIMARY KEY ("id"))`);
        await queryRunner.query(`CREATE TABLE "wonde_student" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "wonde_id" character varying(255) NOT NULL, "mis_id" character varying(255) NOT NULL, "wonde_last_modify" TIMESTAMP WITH TIME ZONE NOT NULL, "last_update" TIMESTAMP WITH TIME ZONE NOT NULL, "player_id" character varying NOT NULL, CONSTRAINT "REL_9d20640cce4ce5ace3da471062" UNIQUE ("player_id"), CONSTRAINT "PK_9aade5d4b7c866acdc5cedd5cc3" PRIMARY KEY ("id"))`);
        await queryRunner.query(`ALTER TABLE "tags" DROP CONSTRAINT "FK_8f8033a570b04520455cc93ed3d"`);
        await queryRunner.query(`ALTER TABLE "tags" ALTER COLUMN "organization_id" SET NOT NULL`);
        await queryRunner.query(`ALTER TABLE "tags" ADD CONSTRAINT "UQ_b3fd0b26c4e8d043bdf0d1bfab8" UNIQUE ("name", "organization_id")`);
        await queryRunner.query(`ALTER TABLE "wonde_schools" ADD CONSTRAINT "FK_2a6c18bd5494f4a0e137c48a93d" FOREIGN KEY ("organization_id") REFERENCES "organizations"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "tags" ADD CONSTRAINT "FK_8f8033a570b04520455cc93ed3d" FOREIGN KEY ("organization_id") REFERENCES "organizations"("id") ON DELETE CASCADE ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "wonde_student" ADD CONSTRAINT "FK_9d20640cce4ce5ace3da4710627" FOREIGN KEY ("player_id") REFERENCES "users"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "wonde_student" DROP CONSTRAINT "FK_9d20640cce4ce5ace3da4710627"`);
        await queryRunner.query(`ALTER TABLE "tags" DROP CONSTRAINT "FK_8f8033a570b04520455cc93ed3d"`);
        await queryRunner.query(`ALTER TABLE "wonde_schools" DROP CONSTRAINT "FK_2a6c18bd5494f4a0e137c48a93d"`);
        await queryRunner.query(`ALTER TABLE "tags" DROP CONSTRAINT "UQ_b3fd0b26c4e8d043bdf0d1bfab8"`);
        await queryRunner.query(`ALTER TABLE "tags" ALTER COLUMN "organization_id" DROP NOT NULL`);
        await queryRunner.query(`ALTER TABLE "tags" ADD CONSTRAINT "FK_8f8033a570b04520455cc93ed3d" FOREIGN KEY ("organization_id") REFERENCES "organizations"("id") ON DELETE CASCADE ON UPDATE NO ACTION`);
        await queryRunner.query(`DROP TABLE "wonde_student"`);
        await queryRunner.query(`DROP TABLE "wonde_schools"`);
    }

}

import {MigrationInterface, QueryRunner} from "typeorm";

export class DropNotNullExternalAssessmentDate1625065382178 implements MigrationInterface {
    name = 'DropNotNullExternalAssessmentDate1625065382178'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "external_assessments" ALTER COLUMN "appointment_date" DROP NOT NULL`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "external_assessments" ALTER COLUMN "appointment_date" SET NOT NULL`);
    }

}

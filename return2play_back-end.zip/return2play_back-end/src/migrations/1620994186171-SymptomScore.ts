import {MigrationInterface, QueryRunner} from "typeorm";

export class SymptomScore1620994186171 implements MigrationInterface {
    name = 'SymptomScore1620994186171'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "injury_concussion_symptoms" ADD "score" integer`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "injury_concussion_symptoms" DROP COLUMN "score"`);
    }

}

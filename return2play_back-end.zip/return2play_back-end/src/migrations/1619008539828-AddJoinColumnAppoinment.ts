import {MigrationInterface, QueryRunner} from "typeorm";

export class AddJoinColumnAppoinment1619008539828 implements MigrationInterface {
    name = 'AddJoinColumnAppoinment1619008539828'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`CREATE TYPE "doctor_clinic_schedule_day_enum" AS ENUM('Mon', 'Tue', 'Wed', 'Thur', 'Fri')`);
        await queryRunner.query(`CREATE TYPE "doctor_clinic_schedule_format_enum" AS ENUM('face-to-face', 'telemedicine')`);
        await queryRunner.query(`CREATE TYPE "doctor_clinic_schedule_medical_type_enum" AS ENUM('concussion advice', 'concussion follow up')`);
        await queryRunner.query(`CREATE TABLE "doctor_clinic_schedule" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "start_time" TIME NOT NULL, "end_time" TIME NOT NULL, "day" "doctor_clinic_schedule_day_enum" NOT NULL, "format" "doctor_clinic_schedule_format_enum" NOT NULL, "medical_type" "doctor_clinic_schedule_medical_type_enum" NOT NULL, "doctor_id" character varying, CONSTRAINT "PK_e8c88283e6cbdd3ec5965c63c96" PRIMARY KEY ("id"))`);
        await queryRunner.query(`CREATE TYPE "clinics_format_enum" AS ENUM('face-to-face', 'telemedicine')`);
        await queryRunner.query(`CREATE TYPE "clinics_medical_type_enum" AS ENUM('concussion advice', 'concussion follow up')`);
        await queryRunner.query(`CREATE TABLE "clinics" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "start_time" TIME NOT NULL, "end_time" TIME NOT NULL, "date" date NOT NULL, "format" "clinics_format_enum" NOT NULL, "medical_type" "clinics_medical_type_enum" NOT NULL, "doctor_id" character varying, CONSTRAINT "PK_5513b659e4d12b01a8ab3956abc" PRIMARY KEY ("id"))`);
        await queryRunner.query(`CREATE TYPE "appointments_status_enum" AS ENUM('new', 'completed')`);
        await queryRunner.query(`CREATE TABLE "appointments" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "location" character varying NOT NULL, "status" "appointments_status_enum" NOT NULL DEFAULT 'new', "playerUserId" character varying, "doctor_id" character varying, CONSTRAINT "PK_4a437a9a27e948726b8bb3e36ad" PRIMARY KEY ("id"))`);
        await queryRunner.query(`ALTER TABLE "injuries" DROP CONSTRAINT "FK_d168998070d708fdf6062bb8f4d"`);
        await queryRunner.query(`ALTER TABLE "injuries" DROP CONSTRAINT "FK_a899be362ce73d0ba4b67fdea95"`);
        await queryRunner.query(`ALTER TABLE "injuries" ALTER COLUMN "player_id" DROP NOT NULL`);
        await queryRunner.query(`ALTER TABLE "injuries" ALTER COLUMN "reporter_id" DROP NOT NULL`);
        await queryRunner.query(`ALTER TABLE "injuries" ADD CONSTRAINT "FK_d168998070d708fdf6062bb8f4d" FOREIGN KEY ("player_id") REFERENCES "users"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "injuries" ADD CONSTRAINT "FK_a899be362ce73d0ba4b67fdea95" FOREIGN KEY ("reporter_id") REFERENCES "users"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "doctor_clinic_schedule" ADD CONSTRAINT "FK_59c95c45b32aec2ea8a893ed5a7" FOREIGN KEY ("doctor_id") REFERENCES "doctors"("user_id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "clinics" ADD CONSTRAINT "FK_f21fc3b0d46d769836fa1d22603" FOREIGN KEY ("doctor_id") REFERENCES "doctors"("user_id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "appointments" ADD CONSTRAINT "FK_db12e4cfd8370cf7eb810df3365" FOREIGN KEY ("playerUserId") REFERENCES "players"("user_id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "appointments" ADD CONSTRAINT "FK_4cf26c3f972d014df5c68d503d2" FOREIGN KEY ("doctor_id") REFERENCES "doctors"("user_id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "appointments" DROP CONSTRAINT "FK_4cf26c3f972d014df5c68d503d2"`);
        await queryRunner.query(`ALTER TABLE "appointments" DROP CONSTRAINT "FK_db12e4cfd8370cf7eb810df3365"`);
        await queryRunner.query(`ALTER TABLE "clinics" DROP CONSTRAINT "FK_f21fc3b0d46d769836fa1d22603"`);
        await queryRunner.query(`ALTER TABLE "doctor_clinic_schedule" DROP CONSTRAINT "FK_59c95c45b32aec2ea8a893ed5a7"`);
        await queryRunner.query(`ALTER TABLE "injuries" DROP CONSTRAINT "FK_a899be362ce73d0ba4b67fdea95"`);
        await queryRunner.query(`ALTER TABLE "injuries" DROP CONSTRAINT "FK_d168998070d708fdf6062bb8f4d"`);
        await queryRunner.query(`ALTER TABLE "injuries" ALTER COLUMN "reporter_id" SET NOT NULL`);
        await queryRunner.query(`ALTER TABLE "injuries" ALTER COLUMN "player_id" SET NOT NULL`);
        await queryRunner.query(`ALTER TABLE "injuries" ADD CONSTRAINT "FK_a899be362ce73d0ba4b67fdea95" FOREIGN KEY ("reporter_id") REFERENCES "users"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "injuries" ADD CONSTRAINT "FK_d168998070d708fdf6062bb8f4d" FOREIGN KEY ("player_id") REFERENCES "users"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
        await queryRunner.query(`DROP TABLE "appointments"`);
        await queryRunner.query(`DROP TYPE "appointments_status_enum"`);
        await queryRunner.query(`DROP TABLE "clinics"`);
        await queryRunner.query(`DROP TYPE "clinics_medical_type_enum"`);
        await queryRunner.query(`DROP TYPE "clinics_format_enum"`);
        await queryRunner.query(`DROP TABLE "doctor_clinic_schedule"`);
        await queryRunner.query(`DROP TYPE "doctor_clinic_schedule_medical_type_enum"`);
        await queryRunner.query(`DROP TYPE "doctor_clinic_schedule_format_enum"`);
        await queryRunner.query(`DROP TYPE "doctor_clinic_schedule_day_enum"`);
    }

}

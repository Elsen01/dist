import {MigrationInterface, QueryRunner} from "typeorm";

export class changeScheduledMedicalType1692603605417 implements MigrationInterface {
    name = 'changeScheduledMedicalType1692603605417'

    public async up(queryRunner: QueryRunner): Promise<void> {
        // await queryRunner.query(`ALTER TYPE "injuries_injury_group_enum_old" RENAME TO "injuries_injury_group_enum_old_old"`);
        // await queryRunner.query(`CREATE TYPE "injuries_injury_group_enum" AS ENUM('Concussion', 'Other', 'Head Injury (possible concussion)')`);
        // await queryRunner.query(`ALTER TABLE "injuries" ALTER COLUMN "injury_group" TYPE "injuries_injury_group_enum" USING "injury_group"::"text"::"injuries_injury_group_enum"`);
        // await queryRunner.query(`DROP TYPE "injuries_injury_group_enum_old_old"`);
        // await queryRunner.query(`ALTER TABLE "doctor_clinic_schedule" DROP COLUMN "medical_type"`);
        // await queryRunner.query(`DROP TYPE "public"."doctor_clinic_schedule_medical_type_enum"`);
        // await queryRunner.query(`ALTER TABLE "doctor_clinic_schedule" ADD "medical_type" text`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "doctor_clinic_schedule" DROP COLUMN "medical_type"`);
        await queryRunner.query(`CREATE TYPE "public"."doctor_clinic_schedule_medical_type_enum" AS ENUM('all appointments', 'concussion advice', 'concussion final clearance', 'concussion follow up')`);
        await queryRunner.query(`ALTER TABLE "doctor_clinic_schedule" ADD "medical_type" "doctor_clinic_schedule_medical_type_enum" NOT NULL`);
        await queryRunner.query(`CREATE TYPE "injuries_injury_group_enum_old_old" AS ENUM('Concussion', 'Head Injury', 'Head Injury (possible concussion)', 'Head Injury (suspected concussion)', 'Other')`);
        await queryRunner.query(`ALTER TABLE "injuries" ALTER COLUMN "injury_group" TYPE "injuries_injury_group_enum_old_old" USING "injury_group"::"text"::"injuries_injury_group_enum_old_old"`);
        await queryRunner.query(`DROP TYPE "injuries_injury_group_enum"`);
        await queryRunner.query(`ALTER TYPE "injuries_injury_group_enum_old_old" RENAME TO "injuries_injury_group_enum_old"`);
    }

}

import {MigrationInterface, QueryRunner} from "typeorm";

export class InjuryStatus1618840697666 implements MigrationInterface {
    name = 'InjuryStatus1618840697666'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`CREATE TYPE "injuries_status_enum" AS ENUM('Active', 'Deleted')`);
        await queryRunner.query(`ALTER TABLE "injuries" ADD "status" "injuries_status_enum" NOT NULL DEFAULT 'Active'`);
        await queryRunner.query(`ALTER TABLE "notes" ALTER COLUMN "created_at" SET NOT NULL`);
        await queryRunner.query(`COMMENT ON COLUMN "notes"."created_at" IS NULL`);
        await queryRunner.query(`ALTER TYPE "public"."injuries_play_status_enum" RENAME TO "injuries_play_status_enum_old"`);
        await queryRunner.query(`CREATE TYPE "injuries_play_status_enum" AS ENUM('Safe to play', 'Reduced level of activity', 'Not safe to play', 'Cleared')`);
        await queryRunner.query(`ALTER TABLE "injuries" ALTER COLUMN "play_status" DROP DEFAULT`);
        await queryRunner.query(`ALTER TABLE "injuries" ALTER COLUMN "play_status" TYPE "injuries_play_status_enum" USING "play_status"::"text"::"injuries_play_status_enum"`);
        await queryRunner.query(`ALTER TABLE "injuries" ALTER COLUMN "play_status" SET DEFAULT 'Not safe to play'`);
        await queryRunner.query(`DROP TYPE "injuries_play_status_enum_old"`);
        await queryRunner.query(`COMMENT ON COLUMN "injuries"."play_status" IS NULL`);
        await queryRunner.query(`ALTER TYPE "public"."players_play_status_enum" RENAME TO "players_play_status_enum_old"`);
        await queryRunner.query(`CREATE TYPE "players_play_status_enum" AS ENUM('Safe to play', 'Reduced level of activity', 'Not safe to play', 'Cleared')`);
        await queryRunner.query(`ALTER TABLE "players" ALTER COLUMN "play_status" DROP DEFAULT`);
        await queryRunner.query(`ALTER TABLE "players" ALTER COLUMN "play_status" TYPE "players_play_status_enum" USING "play_status"::"text"::"players_play_status_enum"`);
        await queryRunner.query(`ALTER TABLE "players" ALTER COLUMN "play_status" SET DEFAULT 'Not safe to play'`);
        await queryRunner.query(`DROP TYPE "players_play_status_enum_old"`);
        await queryRunner.query(`COMMENT ON COLUMN "players"."play_status" IS NULL`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`COMMENT ON COLUMN "players"."play_status" IS NULL`);
        await queryRunner.query(`CREATE TYPE "players_play_status_enum_old" AS ENUM('Safe to play', 'Reduced level of activity', 'Not safe to play')`);
        await queryRunner.query(`ALTER TABLE "players" ALTER COLUMN "play_status" DROP DEFAULT`);
        await queryRunner.query(`ALTER TABLE "players" ALTER COLUMN "play_status" TYPE "players_play_status_enum_old" USING "play_status"::"text"::"players_play_status_enum_old"`);
        await queryRunner.query(`ALTER TABLE "players" ALTER COLUMN "play_status" SET DEFAULT 'Not safe to play'`);
        await queryRunner.query(`DROP TYPE "players_play_status_enum"`);
        await queryRunner.query(`ALTER TYPE "players_play_status_enum_old" RENAME TO  "players_play_status_enum"`);
        await queryRunner.query(`COMMENT ON COLUMN "injuries"."play_status" IS NULL`);
        await queryRunner.query(`CREATE TYPE "injuries_play_status_enum_old" AS ENUM('Safe to play', 'Reduced level of activity', 'Not safe to play')`);
        await queryRunner.query(`ALTER TABLE "injuries" ALTER COLUMN "play_status" DROP DEFAULT`);
        await queryRunner.query(`ALTER TABLE "injuries" ALTER COLUMN "play_status" TYPE "injuries_play_status_enum_old" USING "play_status"::"text"::"injuries_play_status_enum_old"`);
        await queryRunner.query(`ALTER TABLE "injuries" ALTER COLUMN "play_status" SET DEFAULT 'Not safe to play'`);
        await queryRunner.query(`DROP TYPE "injuries_play_status_enum"`);
        await queryRunner.query(`ALTER TYPE "injuries_play_status_enum_old" RENAME TO  "injuries_play_status_enum"`);
        await queryRunner.query(`COMMENT ON COLUMN "notes"."created_at" IS NULL`);
        await queryRunner.query(`ALTER TABLE "notes" ALTER COLUMN "created_at" DROP NOT NULL`);
        await queryRunner.query(`ALTER TABLE "injuries" DROP COLUMN "status"`);
        await queryRunner.query(`DROP TYPE "injuries_status_enum"`);
    }

}

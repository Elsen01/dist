import {MigrationInterface, QueryRunner} from "typeorm";

export class SeedOtherInjury1619076659021 implements MigrationInterface {

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`INSERT INTO other_symptoms ("name") VALUES ('How different are you acting compared to your usual self?')`)
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`DELETE FROM other_symptoms WHERE "name" = 'How different are you acting compared to your usual self?'`)
    }

}

import {MigrationInterface, QueryRunner} from "typeorm";

export class DropNotNullsExternalAssessment1625057303592 implements MigrationInterface {
    name = 'DropNotNullsExternalAssessment1625057303592'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "external_assessments" ALTER COLUMN "doctor_first_name" DROP NOT NULL`);
        await queryRunner.query(`ALTER TABLE "external_assessments" ALTER COLUMN "doctor_last_name" DROP NOT NULL`);
        await queryRunner.query(`ALTER TABLE "external_assessments" ALTER COLUMN "new_play_status" DROP NOT NULL`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "external_assessments" ALTER COLUMN "new_play_status" SET NOT NULL`);
        await queryRunner.query(`ALTER TABLE "external_assessments" ALTER COLUMN "doctor_last_name" SET NOT NULL`);
        await queryRunner.query(`ALTER TABLE "external_assessments" ALTER COLUMN "doctor_first_name" SET NOT NULL`);
    }

}

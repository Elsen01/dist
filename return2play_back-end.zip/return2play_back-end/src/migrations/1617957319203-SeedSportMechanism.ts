import {MigrationInterface, QueryRunner} from "typeorm";

export class SeedSportMechanism1617957319203 implements MigrationInterface {

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            INSERT INTO sports
                (name) 
            VALUES 
                ('Athletics'),
                ('Basketball'),
                ('Boxing'),
                ('Cricket'),
                ('Cycling'),
                ('Equestrian'),
                ('Football'),
                ('Hockey'),
                ('Lacrosse'),
                ('Martial Arts'),
                ('Netball'),
                ('Non-Sport'),
                ('Other'),
                ('Rowing'),
                ('Rugby League'),
                ('Rugby Sevens'),
                ('Rugby Union'),
                ('Sailing'),
                ('Snowsports'),
                ('Swimming'),
                ('Tennis');`
        );

        await queryRunner.query(`
        INSERT INTO injury_mechanisms
            (name) 
        VALUES 
            ('Direct head blow'),
            ('Other'),
            ('Batting'),
            ('Fielding'),
            ('Collision'),
            ('Fall'),
            ('Header'),
            ('Collision with player'),
            ('Hit by ball'),
            ('Hit by stick'),
            ('Scrum'),
            ('Tackled player'),
            ('Tackling player'),
            ('Maul'),
            ('Ruck'),
            ('Line-out'),
            ('Collision - Person'),
            ('Collision - Wall'),
            ('Diving');`
        );

        await queryRunner.query(`
            INSERT INTO sport_mechanisms
                (mechanism_id, sport_id) 
            SELECT
                im.id AS mechanism_id,
                s.id AS sport_id
            FROM
                injury_mechanisms im,
                sports s
            WHERE
                im."name" = 'Direct head blow'
                AND (s."name" = 'Athletics'
                OR s."name" = 'Basketball'
                OR s."name" = 'Boxing'
                OR s."name" = 'Cricket'
                OR s."name" = 'Martial Arts'
                OR s."name" = 'Netball'
                OR s."name" = 'Non-Sport'
                OR s."name" = 'Other'
                OR s."name" = 'Rowing'
                OR s."name" = 'Sailing'
                OR s."name" = 'Snowsports'
                OR s."name" = 'Tennis')`
        );

        await queryRunner.query(`
            INSERT INTO sport_mechanisms
                (mechanism_id, sport_id) 
            SELECT
                im.id AS mechanism_id,
                s.id AS sport_id
            FROM
                injury_mechanisms im,
                sports s
            WHERE
                im."name" = 'Other'`
        );

        await queryRunner.query(`
            INSERT INTO sport_mechanisms
                (mechanism_id, sport_id) 
            SELECT
                im.id AS mechanism_id,
                s.id AS sport_id
            FROM
                injury_mechanisms im,
                sports s
            WHERE
                im."name" = 'Fielding' 
                AND s."name" = 'Cricket'`
        );

        await queryRunner.query(`
            INSERT INTO sport_mechanisms
                (mechanism_id, sport_id) 
            SELECT
                im.id AS mechanism_id,
                s.id AS sport_id
            FROM
                injury_mechanisms im,
                sports s
            WHERE
                im."name" = 'Batting' 
                AND s."name" = 'Cricket'`
        );

        await queryRunner.query(`
            INSERT INTO sport_mechanisms
                (mechanism_id, sport_id) 
            SELECT
                im.id AS mechanism_id,
                s.id AS sport_id
            FROM
                injury_mechanisms im,
                sports s
            WHERE
                im."name" = 'Collision'
                AND (s."name" = 'Cycling'
                OR s."name" = 'Equestrian'
                OR s."name" = 'Football'
                OR s."name" = 'Snowsports')`
        );

        await queryRunner.query(`
            INSERT INTO sport_mechanisms
                (mechanism_id, sport_id) 
            SELECT
                im.id AS mechanism_id,
                s.id AS sport_id
            FROM
                injury_mechanisms im,
                sports s
            WHERE
                im."name" = 'Fall'
                AND (s."name" = 'Cycling'
                OR s."name" = 'Equestrian'
                OR s."name" = 'Snowsports')`
        );

        await queryRunner.query(`
            INSERT INTO sport_mechanisms
                (mechanism_id, sport_id) 
            SELECT
                im.id AS mechanism_id,
                s.id AS sport_id
            FROM
                injury_mechanisms im,
                sports s
            WHERE
                im."name" = 'Header' 
                AND s."name" = 'Football'`
        );

        await queryRunner.query(`
            INSERT INTO sport_mechanisms
                (mechanism_id, sport_id) 
            SELECT
                im.id AS mechanism_id,
                s.id AS sport_id
            FROM
                injury_mechanisms im,
                sports s
            WHERE
                im."name" = 'Collision with player'
                AND (s."name" = 'Hockey'
                OR s."name" = 'Lacrosse'
                OR s."name" = 'Netball'
                OR s."name" = 'Rugby League'
                OR s."name" = 'Rugby Sevens'
                OR s."name" = 'Rugby Union')`
        );

        await queryRunner.query(`
            INSERT INTO sport_mechanisms
                (mechanism_id, sport_id) 
            SELECT
                im.id AS mechanism_id,
                s.id AS sport_id
            FROM
                injury_mechanisms im,
                sports s
            WHERE
                im."name" = 'Hit by ball'
                AND (s."name" = 'Hockey'
                OR s."name" = 'Lacrosse')`
        );

        await queryRunner.query(`
            INSERT INTO sport_mechanisms
                (mechanism_id, sport_id) 
            SELECT
                im.id AS mechanism_id,
                s.id AS sport_id
            FROM
                injury_mechanisms im,
                sports s
            WHERE
                im."name" = 'Hit by stick'
                AND (s."name" = 'Hockey'
                OR s."name" = 'Lacrosse')`
        );

        await queryRunner.query(`
            INSERT INTO sport_mechanisms
                (mechanism_id, sport_id) 
            SELECT
                im.id AS mechanism_id,
                s.id AS sport_id
            FROM
                injury_mechanisms im,
                sports s
            WHERE
                im."name" = 'Scrum'
                AND (s."name" = 'Rugby League'
                OR s."name" = 'Rugby Sevens'
                OR s."name" = 'Rugby Union')`
        );

        await queryRunner.query(`
            INSERT INTO sport_mechanisms
                (mechanism_id, sport_id) 
            SELECT
                im.id AS mechanism_id,
                s.id AS sport_id
            FROM
                injury_mechanisms im,
                sports s
            WHERE
                im."name" = 'Tackled player'
                AND (s."name" = 'Rugby League'
                OR s."name" = 'Rugby Sevens'
                OR s."name" = 'Rugby Union')`
        );

        await queryRunner.query(`
            INSERT INTO sport_mechanisms
                (mechanism_id, sport_id) 
            SELECT
                im.id AS mechanism_id,
                s.id AS sport_id
            FROM
                injury_mechanisms im,
                sports s
            WHERE
                im."name" = 'Tackling player'
                AND (s."name" = 'Rugby League'
                OR s."name" = 'Rugby Sevens'
                OR s."name" = 'Rugby Union')`
        );

        await queryRunner.query(`
            INSERT INTO sport_mechanisms
                (mechanism_id, sport_id) 
            SELECT
                im.id AS mechanism_id,
                s.id AS sport_id
            FROM
                injury_mechanisms im,
                sports s
            WHERE
                im."name" = 'Maul'
                AND (s."name" = 'Rugby Sevens'
                OR s."name" = 'Rugby Union')`
        );

        await queryRunner.query(`
            INSERT INTO sport_mechanisms
                (mechanism_id, sport_id) 
            SELECT
                im.id AS mechanism_id,
                s.id AS sport_id
            FROM
                injury_mechanisms im,
                sports s
            WHERE
                im."name" = 'Ruck'
                AND (s."name" = 'Rugby Sevens'
                OR s."name" = 'Rugby Union')`
        );

        await queryRunner.query(`
            INSERT INTO sport_mechanisms
                (mechanism_id, sport_id) 
            SELECT
                im.id AS mechanism_id,
                s.id AS sport_id
            FROM
                injury_mechanisms im,
                sports s
            WHERE
                im."name" = 'Line-out'
                AND s."name" = 'Rugby Union'`
        );

        await queryRunner.query(`
            INSERT INTO sport_mechanisms
                (mechanism_id, sport_id) 
            SELECT
                im.id AS mechanism_id,
                s.id AS sport_id
            FROM
                injury_mechanisms im,
                sports s
            WHERE
                 s."name" = 'Swimming'
                 AND (im."name" = 'Collision - Person'
                 OR im."name" = 'Collision - Person'
                 OR im."name" = 'Diving')`
        );
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`DELETE FROM sports`);
        await queryRunner.query(`DELETE FROM injury_mechanisms`);

    }

}

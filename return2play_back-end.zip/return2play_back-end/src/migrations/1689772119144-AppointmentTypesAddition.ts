import {MigrationInterface, QueryRunner} from "typeorm";

export class AppointmentTypesAddition1689772119144 implements MigrationInterface {
    name = 'AppointmentTypesAddition1689772119144'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TYPE "clinics_medical_type_enum" RENAME TO "clinics_medical_type_enum_old"`);
        await queryRunner.query(`CREATE TYPE "clinics_medical_type_enum" AS ENUM('concussion advice', 'concussion follow up', 'concussion final clearance', 'all appointments')`);
        await queryRunner.query(`ALTER TABLE "clinics" ALTER COLUMN "medical_type" TYPE "clinics_medical_type_enum" USING "medical_type"::"text"::"clinics_medical_type_enum"`);
        await queryRunner.query(`DROP TYPE "clinics_medical_type_enum_old"`);
        // await queryRunner.query(`ALTER TYPE "injuries_injury_group_enum" RENAME TO "injuries_injury_group_enum_old"`);
        // await queryRunner.query(`CREATE TYPE "injuries_injury_group_enum" AS ENUM('Concussion', 'Other', 'Head Injury (possible concussion)')`);
        await queryRunner.query(`ALTER TABLE "injuries" ALTER COLUMN "injury_group" TYPE "injuries_injury_group_enum" USING "injury_group"::"text"::"injuries_injury_group_enum"`);
        // await queryRunner.query(`DROP TYPE "injuries_injury_group_enum_old"`);
        await queryRunner.query(`ALTER TYPE "doctor_clinic_schedule_medical_type_enum" RENAME TO "doctor_clinic_schedule_medical_type_enum_old"`);
        await queryRunner.query(`CREATE TYPE "doctor_clinic_schedule_medical_type_enum" AS ENUM('concussion advice', 'concussion follow up', 'concussion final clearance', 'all appointments')`);
        await queryRunner.query(`ALTER TABLE "doctor_clinic_schedule" ALTER COLUMN "medical_type" TYPE "doctor_clinic_schedule_medical_type_enum" USING "medical_type"::"text"::"doctor_clinic_schedule_medical_type_enum"`);
        await queryRunner.query(`DROP TYPE "doctor_clinic_schedule_medical_type_enum_old"`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`CREATE TYPE "doctor_clinic_schedule_medical_type_enum_old" AS ENUM('all appointments', 'concussion advice', 'concussion follow up')`);
        await queryRunner.query(`ALTER TABLE "doctor_clinic_schedule" ALTER COLUMN "medical_type" TYPE "doctor_clinic_schedule_medical_type_enum_old" USING "medical_type"::"text"::"doctor_clinic_schedule_medical_type_enum_old"`);
        await queryRunner.query(`DROP TYPE "doctor_clinic_schedule_medical_type_enum"`);
        await queryRunner.query(`ALTER TYPE "doctor_clinic_schedule_medical_type_enum_old" RENAME TO "doctor_clinic_schedule_medical_type_enum"`);
        await queryRunner.query(`CREATE TYPE "injuries_injury_group_enum_old" AS ENUM('Concussion', 'Head Injury', 'Head Injury (possible concussion)', 'Head Injury (suspected concussion)', 'Other')`);
        await queryRunner.query(`ALTER TABLE "injuries" ALTER COLUMN "injury_group" TYPE "injuries_injury_group_enum_old" USING "injury_group"::"text"::"injuries_injury_group_enum_old"`);
        await queryRunner.query(`DROP TYPE "injuries_injury_group_enum"`);
        await queryRunner.query(`ALTER TYPE "injuries_injury_group_enum_old" RENAME TO "injuries_injury_group_enum"`);
        await queryRunner.query(`CREATE TYPE "clinics_medical_type_enum_old" AS ENUM('all appointments', 'concussion advice', 'concussion follow up')`);
        await queryRunner.query(`ALTER TABLE "clinics" ALTER COLUMN "medical_type" TYPE "clinics_medical_type_enum_old" USING "medical_type"::"text"::"clinics_medical_type_enum_old"`);
        await queryRunner.query(`DROP TYPE "clinics_medical_type_enum"`);
        await queryRunner.query(`ALTER TYPE "clinics_medical_type_enum_old" RENAME TO "clinics_medical_type_enum"`);
    }

}

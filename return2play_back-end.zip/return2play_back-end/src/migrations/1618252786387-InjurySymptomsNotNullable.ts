import {MigrationInterface, QueryRunner} from "typeorm";

export class InjurySymptomsNotNullable1618252786387 implements MigrationInterface {
    name = 'InjurySymptomsNotNullable1618252786387'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "sport_injuries" DROP CONSTRAINT "FK_e7da844ae0ba304db882369881c"`);
        await queryRunner.query(`ALTER TABLE "sport_injuries" DROP CONSTRAINT "FK_0cfe91f6a4cd7ba8550997db08c"`);
        await queryRunner.query(`ALTER TABLE "sport_injuries" DROP CONSTRAINT "FK_1febf8e84be6a17a0bfe5db4d8a"`);
        await queryRunner.query(`ALTER TABLE "sport_injuries" DROP CONSTRAINT "FK_3b2bafcc20315ef1c0491ec1336"`);
        await queryRunner.query(`ALTER TABLE "sport_injuries" ALTER COLUMN "injury_id" SET NOT NULL`);
        await queryRunner.query(`COMMENT ON COLUMN "sport_injuries"."injury_id" IS NULL`);
        await queryRunner.query(`ALTER TABLE "sport_injuries" ALTER COLUMN "organization_id" SET NOT NULL`);
        await queryRunner.query(`COMMENT ON COLUMN "sport_injuries"."organization_id" IS NULL`);
        await queryRunner.query(`ALTER TABLE "sport_injuries" ALTER COLUMN "sport_id" SET NOT NULL`);
        await queryRunner.query(`COMMENT ON COLUMN "sport_injuries"."sport_id" IS NULL`);
        await queryRunner.query(`ALTER TABLE "sport_injuries" ALTER COLUMN "mechanism_id" SET NOT NULL`);
        await queryRunner.query(`COMMENT ON COLUMN "sport_injuries"."mechanism_id" IS NULL`);
        await queryRunner.query(`ALTER TABLE "sport_injuries" ADD CONSTRAINT "FK_e7da844ae0ba304db882369881c" FOREIGN KEY ("injury_id") REFERENCES "injuries"("id") ON DELETE CASCADE ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "sport_injuries" ADD CONSTRAINT "FK_0cfe91f6a4cd7ba8550997db08c" FOREIGN KEY ("organization_id") REFERENCES "organizations"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "sport_injuries" ADD CONSTRAINT "FK_1febf8e84be6a17a0bfe5db4d8a" FOREIGN KEY ("sport_id") REFERENCES "sports"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "sport_injuries" ADD CONSTRAINT "FK_3b2bafcc20315ef1c0491ec1336" FOREIGN KEY ("mechanism_id") REFERENCES "injury_mechanisms"("id") ON DELETE CASCADE ON UPDATE NO ACTION`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "sport_injuries" DROP CONSTRAINT "FK_3b2bafcc20315ef1c0491ec1336"`);
        await queryRunner.query(`ALTER TABLE "sport_injuries" DROP CONSTRAINT "FK_1febf8e84be6a17a0bfe5db4d8a"`);
        await queryRunner.query(`ALTER TABLE "sport_injuries" DROP CONSTRAINT "FK_0cfe91f6a4cd7ba8550997db08c"`);
        await queryRunner.query(`ALTER TABLE "sport_injuries" DROP CONSTRAINT "FK_e7da844ae0ba304db882369881c"`);
        await queryRunner.query(`COMMENT ON COLUMN "sport_injuries"."mechanism_id" IS NULL`);
        await queryRunner.query(`ALTER TABLE "sport_injuries" ALTER COLUMN "mechanism_id" DROP NOT NULL`);
        await queryRunner.query(`COMMENT ON COLUMN "sport_injuries"."sport_id" IS NULL`);
        await queryRunner.query(`ALTER TABLE "sport_injuries" ALTER COLUMN "sport_id" DROP NOT NULL`);
        await queryRunner.query(`COMMENT ON COLUMN "sport_injuries"."organization_id" IS NULL`);
        await queryRunner.query(`ALTER TABLE "sport_injuries" ALTER COLUMN "organization_id" DROP NOT NULL`);
        await queryRunner.query(`COMMENT ON COLUMN "sport_injuries"."injury_id" IS NULL`);
        await queryRunner.query(`ALTER TABLE "sport_injuries" ALTER COLUMN "injury_id" DROP NOT NULL`);
        await queryRunner.query(`ALTER TABLE "sport_injuries" ADD CONSTRAINT "FK_3b2bafcc20315ef1c0491ec1336" FOREIGN KEY ("mechanism_id") REFERENCES "injury_mechanisms"("id") ON DELETE CASCADE ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "sport_injuries" ADD CONSTRAINT "FK_1febf8e84be6a17a0bfe5db4d8a" FOREIGN KEY ("sport_id") REFERENCES "sports"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "sport_injuries" ADD CONSTRAINT "FK_0cfe91f6a4cd7ba8550997db08c" FOREIGN KEY ("organization_id") REFERENCES "organizations"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "sport_injuries" ADD CONSTRAINT "FK_e7da844ae0ba304db882369881c" FOREIGN KEY ("injury_id") REFERENCES "injuries"("id") ON DELETE CASCADE ON UPDATE NO ACTION`);
    }

}

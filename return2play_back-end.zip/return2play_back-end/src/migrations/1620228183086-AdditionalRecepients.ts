import {MigrationInterface, QueryRunner} from "typeorm";

export class AdditionalRecepients1620228183086 implements MigrationInterface {
    name = 'AdditionalRecepients1620228183086'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`CREATE TYPE "additional_recepients_status_enum" AS ENUM('Active', 'Deleted')`);
        await queryRunner.query(`CREATE TABLE "additional_recepients" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "first_name" character varying NOT NULL, "last_name" character varying NOT NULL, "email" character varying NOT NULL, "info" text, "status" "additional_recepients_status_enum" NOT NULL DEFAULT 'Active', "created_at" TIMESTAMP NOT NULL DEFAULT now(), "player_id" character varying, CONSTRAINT "PK_915619c48399690e56657516dfd" PRIMARY KEY ("id"))`);
        await queryRunner.query(`ALTER TABLE "additional_recepients" ADD CONSTRAINT "FK_3c3f68b09b6f07915acf6f360d9" FOREIGN KEY ("player_id") REFERENCES "players"("user_id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "additional_recepients" DROP CONSTRAINT "FK_3c3f68b09b6f07915acf6f360d9"`);
        await queryRunner.query(`DROP TABLE "additional_recepients"`);
        await queryRunner.query(`DROP TYPE "additional_recepients_status_enum"`);
    }

}

import {MigrationInterface, QueryRunner} from "typeorm";

export class ChangeGRTP1627299531461 implements MigrationInterface {
    name = 'ChangeGRTP1627299531461'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "grtp" DROP COLUMN "start_date"`);
        await queryRunner.query(`ALTER TABLE "grtp" DROP COLUMN "gentle_pe_lessons_date"`);
        await queryRunner.query(`ALTER TABLE "grtp" ADD "start_gentle_pe_lessons_date" date`);
        await queryRunner.query(`ALTER TYPE "organizations_schooltype_enum" RENAME TO "organizations_schooltype_enum_old"`);
        await queryRunner.query(`CREATE TYPE "organizations_schooltype_enum" AS ENUM('Boarding School', 'Day School', 'Prep School', 'Mixed School')`);
        await queryRunner.query(`ALTER TABLE "organizations" ALTER COLUMN "schoolType" TYPE "organizations_schooltype_enum" USING "schoolType"::"text"::"organizations_schooltype_enum"`);
        await queryRunner.query(`DROP TYPE "organizations_schooltype_enum_old"`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`CREATE TYPE "organizations_schooltype_enum_old" AS ENUM('Boarding School', 'Day School')`);
        await queryRunner.query(`ALTER TABLE "organizations" ALTER COLUMN "schoolType" TYPE "organizations_schooltype_enum_old" USING "schoolType"::"text"::"organizations_schooltype_enum_old"`);
        await queryRunner.query(`DROP TYPE "organizations_schooltype_enum"`);
        await queryRunner.query(`ALTER TYPE "organizations_schooltype_enum_old" RENAME TO "organizations_schooltype_enum"`);
        await queryRunner.query(`ALTER TABLE "grtp" DROP COLUMN "start_gentle_pe_lessons_date"`);
        await queryRunner.query(`ALTER TABLE "grtp" ADD "gentle_pe_lessons_date" date NOT NULL`);
        await queryRunner.query(`ALTER TABLE "grtp" ADD "start_date" date NOT NULL`);
    }

}

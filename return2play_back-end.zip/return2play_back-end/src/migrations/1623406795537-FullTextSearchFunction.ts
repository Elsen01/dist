import {MigrationInterface, QueryRunner} from "typeorm";

export class FullTextSearchFunction1623406795537 implements MigrationInterface {

    public async up(queryRunner: QueryRunner): Promise<void> {
        queryRunner.query(`
            CREATE OR REPLACE FUNCTION f_concat_ws(text, VARIADIC text[])
            RETURNS text LANGUAGE sql IMMUTABLE AS 'SELECT array_to_string($2, $1)';`
        )
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        queryRunner.query(`
            DROP FUNCTION IF EXISTS f_concat_ws;`
        )
    }

}

import {MigrationInterface, QueryRunner} from "typeorm";

export class WondeIdUnique1633343523202 implements MigrationInterface {
    name = 'WondeIdUnique1633343523202'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "wonde_student" ADD CONSTRAINT "UQ_c8085e3694c1e6cbbd17207cc32" UNIQUE ("wonde_id")`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "wonde_student" DROP CONSTRAINT "UQ_c8085e3694c1e6cbbd17207cc32"`);
    }

}

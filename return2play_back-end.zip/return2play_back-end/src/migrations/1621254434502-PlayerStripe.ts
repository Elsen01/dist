import {MigrationInterface, QueryRunner} from "typeorm";

export class PlayerStripe1621254434502 implements MigrationInterface {
    name = 'PlayerStripe1621254434502'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "players" ADD "stripe_id" character varying`);
        await queryRunner.query(`ALTER TABLE "players" ADD "subscription_id" character varying`);
        await queryRunner.query(`ALTER TABLE "players" ADD "membership_expiration_date" TIMESTAMP WITH TIME ZONE`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "players" DROP COLUMN "membership_expiration_date"`);
        await queryRunner.query(`ALTER TABLE "players" DROP COLUMN "subscription_id"`);
        await queryRunner.query(`ALTER TABLE "players" DROP COLUMN "stripe_id"`);
    }

}

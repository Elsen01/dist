import {MigrationInterface, QueryRunner} from "typeorm";

export class RenameAdditionalRecipientInfo1624433654032 implements MigrationInterface {
    name = 'RenameAdditionalRecipientInfo1624433654032'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "additional_recepients" RENAME COLUMN "info" TO "additional_info"`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "additional_recepients" RENAME COLUMN "additional_info" TO "info"`);
    }

}

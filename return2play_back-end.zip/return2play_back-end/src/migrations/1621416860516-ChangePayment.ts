import {MigrationInterface, QueryRunner} from "typeorm";

export class ChangePayment1621416860516 implements MigrationInterface {
    name = 'ChangePayment1621416860516'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`CREATE TABLE "payments" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "stripe_customer_id" character varying(255) NOT NULL, "payment_id" character varying(255) NOT NULL, "payer_email" character varying(255) NOT NULL, "created_at" TIMESTAMP NOT NULL DEFAULT now(), "player_id" character varying NOT NULL, CONSTRAINT "PK_197ab7af18c93fbb0c9b28b4a59" PRIMARY KEY ("id"))`);
        await queryRunner.query(`ALTER TABLE "players" DROP COLUMN "stripe_id"`);
        await queryRunner.query(`ALTER TABLE "players" DROP COLUMN "subscription_id"`);
        await queryRunner.query(`ALTER TABLE "payments" ADD CONSTRAINT "FK_941ea5e223f5e8869d18109e7cd" FOREIGN KEY ("player_id") REFERENCES "players"("user_id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "payments" DROP CONSTRAINT "FK_941ea5e223f5e8869d18109e7cd"`);
        await queryRunner.query(`ALTER TABLE "players" ADD "subscription_id" character varying`);
        await queryRunner.query(`ALTER TABLE "players" ADD "stripe_id" character varying`);
        await queryRunner.query(`DROP TABLE "payments"`);
    }

}

import {MigrationInterface, QueryRunner} from "typeorm";

export class UserActiveDefault1627474540239 implements MigrationInterface {
    name = 'UserActiveDefault1627474540239'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "users" ALTER COLUMN "status" SET DEFAULT 'Active'`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "users" ALTER COLUMN "status" SET DEFAULT 'Inactive'`);
    }

}

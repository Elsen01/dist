import { MigrationInterface, QueryRunner } from 'typeorm';

export class Tag1617616275849 implements MigrationInterface {
  name = 'Tag1617616275849';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TABLE "tags" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "name" character varying NOT NULL, "organization_id" uuid, CONSTRAINT "PK_e7dc17249a1148a1970748eda99" PRIMARY KEY ("id"))`
    );
    await queryRunner.query(
      `CREATE TABLE "tags_users" ("tag_id" uuid NOT NULL, "user_id" character varying NOT NULL, CONSTRAINT "PK_ff018cc55114c92b40b6a878d30" PRIMARY KEY ("tag_id", "user_id"))`
    );
    await queryRunner.query(`CREATE INDEX "IDX_1d1f349176358e57815a7d6d48" ON "tags_users" ("tag_id") `);
    await queryRunner.query(`CREATE INDEX "IDX_68b368c508851ddb53cbdcd454" ON "tags_users" ("user_id") `);
    await queryRunner.query(`ALTER TABLE "doctors" DROP CONSTRAINT "FK_653c27d1b10652eb0c7bbbc4427"`);
    await queryRunner.query(`COMMENT ON COLUMN "doctors"."user_id" IS NULL`);
    await queryRunner.query(`ALTER TABLE "doctors" ADD CONSTRAINT "UQ_653c27d1b10652eb0c7bbbc4427" UNIQUE ("user_id")`);
    await queryRunner.query(
      `ALTER TABLE "tags" ADD CONSTRAINT "FK_8f8033a570b04520455cc93ed3d" FOREIGN KEY ("organization_id") REFERENCES "organizations"("id") ON DELETE CASCADE ON UPDATE NO ACTION`
    );
    await queryRunner.query(
      `ALTER TABLE "doctors" ADD CONSTRAINT "FK_653c27d1b10652eb0c7bbbc4427" FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE NO ACTION`
    );
    await queryRunner.query(
      `ALTER TABLE "tags_users" ADD CONSTRAINT "FK_1d1f349176358e57815a7d6d48f" FOREIGN KEY ("tag_id") REFERENCES "tags"("id") ON DELETE CASCADE ON UPDATE NO ACTION`
    );
    await queryRunner.query(
      `ALTER TABLE "tags_users" ADD CONSTRAINT "FK_68b368c508851ddb53cbdcd4541" FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE NO ACTION`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "tags_users" DROP CONSTRAINT "FK_68b368c508851ddb53cbdcd4541"`);
    await queryRunner.query(`ALTER TABLE "tags_users" DROP CONSTRAINT "FK_1d1f349176358e57815a7d6d48f"`);
    await queryRunner.query(`ALTER TABLE "doctors" DROP CONSTRAINT "FK_653c27d1b10652eb0c7bbbc4427"`);
    await queryRunner.query(`ALTER TABLE "tags" DROP CONSTRAINT "FK_8f8033a570b04520455cc93ed3d"`);
    await queryRunner.query(`ALTER TABLE "doctors" DROP CONSTRAINT "UQ_653c27d1b10652eb0c7bbbc4427"`);
    await queryRunner.query(`COMMENT ON COLUMN "doctors"."user_id" IS NULL`);
    await queryRunner.query(
      `ALTER TABLE "doctors" ADD CONSTRAINT "FK_653c27d1b10652eb0c7bbbc4427" FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE NO ACTION`
    );
    await queryRunner.query(`DROP INDEX "IDX_68b368c508851ddb53cbdcd454"`);
    await queryRunner.query(`DROP INDEX "IDX_1d1f349176358e57815a7d6d48"`);
    await queryRunner.query(`DROP TABLE "tags_users"`);
    await queryRunner.query(`DROP TABLE "tags"`);
  }
}

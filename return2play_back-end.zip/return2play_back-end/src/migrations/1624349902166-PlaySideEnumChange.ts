import {MigrationInterface, QueryRunner} from "typeorm";

export class PlaySideEnumChange1624349902166 implements MigrationInterface {
    name = 'PlaySideEnumChange1624349902166'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TYPE "sport_injuries_play_side_enum" RENAME TO "sport_injuries_play_side_enum_old"`);
        await queryRunner.query(`CREATE TYPE "sport_injuries_play_side_enum" AS ENUM('Attack', 'Defence', 'N/A')`);
        await queryRunner.query(`ALTER TABLE "sport_injuries" ALTER COLUMN "play_side" TYPE "sport_injuries_play_side_enum" USING "play_side"::"text"::"sport_injuries_play_side_enum"`);
        await queryRunner.query(`DROP TYPE "sport_injuries_play_side_enum_old"`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`CREATE TYPE "sport_injuries_play_side_enum_old" AS ENUM('Attack', 'Defence')`);
        await queryRunner.query(`ALTER TABLE "sport_injuries" ALTER COLUMN "play_side" TYPE "sport_injuries_play_side_enum_old" USING "play_side"::"text"::"sport_injuries_play_side_enum_old"`);
        await queryRunner.query(`DROP TYPE "sport_injuries_play_side_enum"`);
        await queryRunner.query(`ALTER TYPE "sport_injuries_play_side_enum_old" RENAME TO "sport_injuries_play_side_enum"`);
    }

}

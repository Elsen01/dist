import {MigrationInterface, QueryRunner} from "typeorm";

export class UserEntityAuthTokensLengthNvarchar1693428379861 implements MigrationInterface {
    name = 'UserEntityAuthTokensLengthNvarchar1693428379861'

    public async up(queryRunner: QueryRunner): Promise<void> {
        /*await queryRunner.query(`ALTER TYPE "injuries_injury_group_enum_old" RENAME TO "injuries_injury_group_enum_old_old"`);
        await queryRunner.query(`CREATE TYPE "injuries_injury_group_enum" AS ENUM('Concussion', 'Other', 'Head Injury (possible concussion)')`);
        await queryRunner.query(`ALTER TABLE "injuries" ALTER COLUMN "injury_group" TYPE "injuries_injury_group_enum" USING "injury_group"::"text"::"injuries_injury_group_enum"`);
        await queryRunner.query(`DROP TYPE "injuries_injury_group_enum_old_old"`);*/
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`CREATE TYPE "injuries_injury_group_enum_old_old" AS ENUM('Concussion', 'Head Injury', 'Head Injury (possible concussion)', 'Head Injury (suspected concussion)', 'Other')`);
        await queryRunner.query(`ALTER TABLE "injuries" ALTER COLUMN "injury_group" TYPE "injuries_injury_group_enum_old_old" USING "injury_group"::"text"::"injuries_injury_group_enum_old_old"`);
        await queryRunner.query(`DROP TYPE "injuries_injury_group_enum"`);
        await queryRunner.query(`ALTER TYPE "injuries_injury_group_enum_old_old" RENAME TO "injuries_injury_group_enum_old"`);
    }

}

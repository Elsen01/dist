import {MigrationInterface, QueryRunner} from "typeorm";

export class SportFix1619706652674 implements MigrationInterface {
    name = 'SportFix1619706652674'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "sports" ADD "protective_headgear" boolean`);
        await queryRunner.query(`ALTER TABLE "sports" ADD "mouthguard" boolean`);

        await queryRunner.query(`
            UPDATE sports
            SET protective_headgear = true
            WHERE name = 'Boxing' 
            OR name = 'Cricket'
            OR name = 'Cycling'
            OR name = 'Equestrian'
            OR name = 'Hockey'
            OR name = 'Lacrosse'
            OR name = 'Martial Arts'
            OR name = 'Rugby League'
            OR name = 'Rugby Sevens'
            OR name = 'Rugby Union'
            OR name = 'Snowsports';
        `);

        await queryRunner.query(`
            UPDATE sports
            SET mouthguard = true
            WHERE name = 'Boxing' 
            OR name = 'Martial Arts'
            OR name = 'Rugby League'
            OR name = 'Rugby Sevens'
            OR name = 'Rugby Union';
        `);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
        UPDATE sports
        SET protective_headgear = NULL
        WHERE name = 'Boxing' 
        OR name = 'Cricket'
        OR name = 'Cycling'
        OR name = 'Equestrian'
        OR name = 'Hockey'
        OR name = 'Lacrosse'
        OR name = 'Martial Arts'
        OR name = 'Rugby League'
        OR name = 'Rugby Sevens'
        OR name = 'Rugby Union'
        OR name = 'Snowsports';
    `);

    await queryRunner.query(`
        UPDATE sports
        SET mouthguard = NULL
        WHERE name = 'Boxing' 
        OR name = 'Martial Arts'
        OR name = 'Rugby League'
        OR name = 'Rugby Sevens'
        OR name = 'Rugby Union';
    `);
        await queryRunner.query(`ALTER TABLE "sports" DROP COLUMN "mouthguard"`);
        await queryRunner.query(`ALTER TABLE "sports" DROP COLUMN "protective_headgear"`);
    }

}

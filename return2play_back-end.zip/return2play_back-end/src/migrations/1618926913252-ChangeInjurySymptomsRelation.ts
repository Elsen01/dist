import {MigrationInterface, QueryRunner} from "typeorm";

export class ChangeInjurySymptomsRelation1618926913252 implements MigrationInterface {
    name = 'ChangeInjurySymptomsRelation1618926913252'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "injury_binary_symptoms" DROP CONSTRAINT "FK_702898f02b328c5c459e871d6bd"`);
        await queryRunner.query(`ALTER TABLE "injury_red_flag_symptoms" DROP CONSTRAINT "FK_80ea8116d85c424f8fd9f2a6525"`);
        await queryRunner.query(`ALTER TABLE "injury_symptoms" DROP CONSTRAINT "FK_ca44c02ad0647a3b369d29b5e64"`);
        await queryRunner.query(`CREATE TABLE "injury_concussion_symptoms" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "created_at" TIMESTAMP NOT NULL DEFAULT now(), "injury_id" uuid, CONSTRAINT "PK_0b4a38e327b99f3407958048c03" PRIMARY KEY ("id"))`);
        await queryRunner.query(`ALTER TABLE "injury_binary_symptoms" ADD "id" uuid NOT NULL DEFAULT uuid_generate_v4()`);
        await queryRunner.query(`ALTER TABLE "injury_binary_symptoms" DROP CONSTRAINT "PK_417c25cc9963026f4cef6aac6af"`);
        await queryRunner.query(`ALTER TABLE "injury_binary_symptoms" ADD CONSTRAINT "PK_3b7391e3656478bb8cf1b515115" PRIMARY KEY ("binary_symptom_id", "injury_id", "id")`);
        await queryRunner.query(`ALTER TABLE "injury_red_flag_symptoms" ADD "id" uuid NOT NULL DEFAULT uuid_generate_v4()`);
        await queryRunner.query(`ALTER TABLE "injury_red_flag_symptoms" DROP CONSTRAINT "PK_26e1c429a50c1ad1fb4c5d89932"`);
        await queryRunner.query(`ALTER TABLE "injury_red_flag_symptoms" ADD CONSTRAINT "PK_52340ad0ef8b9f224a2369aae48" PRIMARY KEY ("red_flag_symptom_id", "injury_id", "id")`);
        await queryRunner.query(`ALTER TABLE "injury_symptoms" ADD "id" uuid NOT NULL DEFAULT uuid_generate_v4()`);
        await queryRunner.query(`ALTER TABLE "injury_symptoms" DROP CONSTRAINT "PK_7f77f855bc4313dbd6e06832cf3"`);
        await queryRunner.query(`ALTER TABLE "injury_symptoms" ADD CONSTRAINT "PK_a56e6de3dc923579c2ac94edc53" PRIMARY KEY ("symptom_id", "injury_id", "id")`);
        await queryRunner.query(`ALTER TABLE "injury_binary_symptoms" DROP CONSTRAINT "FK_c876e5840abcbf7c2429c488929"`);
        await queryRunner.query(`ALTER TABLE "injury_binary_symptoms" DROP CONSTRAINT "PK_3b7391e3656478bb8cf1b515115"`);
        await queryRunner.query(`ALTER TABLE "injury_binary_symptoms" ADD CONSTRAINT "PK_0def10e81509ac1bf846a0ea7c7" PRIMARY KEY ("binary_symptom_id", "id")`);
        await queryRunner.query(`ALTER TABLE "injury_binary_symptoms" DROP CONSTRAINT "PK_0def10e81509ac1bf846a0ea7c7"`);
        await queryRunner.query(`ALTER TABLE "injury_binary_symptoms" ADD CONSTRAINT "PK_4b13e13e26bd5b500b62fdf2e33" PRIMARY KEY ("id")`);
        await queryRunner.query(`ALTER TABLE "injury_red_flag_symptoms" DROP CONSTRAINT "FK_9a9d8838b5f92cf8a553ac7df50"`);
        await queryRunner.query(`ALTER TABLE "injury_red_flag_symptoms" DROP CONSTRAINT "PK_52340ad0ef8b9f224a2369aae48"`);
        await queryRunner.query(`ALTER TABLE "injury_red_flag_symptoms" ADD CONSTRAINT "PK_fba722c3184ed65a970984a43c2" PRIMARY KEY ("red_flag_symptom_id", "id")`);
        await queryRunner.query(`ALTER TABLE "injury_red_flag_symptoms" DROP CONSTRAINT "PK_fba722c3184ed65a970984a43c2"`);
        await queryRunner.query(`ALTER TABLE "injury_red_flag_symptoms" ADD CONSTRAINT "PK_f9bbfb7921d272916c48cc4c77a" PRIMARY KEY ("id")`);
        await queryRunner.query(`ALTER TABLE "injury_symptoms" DROP CONSTRAINT "FK_dc355e152cd37e6d7d4549f6dfe"`);
        await queryRunner.query(`ALTER TABLE "injury_symptoms" DROP CONSTRAINT "PK_a56e6de3dc923579c2ac94edc53"`);
        await queryRunner.query(`ALTER TABLE "injury_symptoms" ADD CONSTRAINT "PK_16040f2170961edf4cff397e8f6" PRIMARY KEY ("symptom_id", "id")`);
        await queryRunner.query(`ALTER TABLE "injury_symptoms" DROP CONSTRAINT "PK_16040f2170961edf4cff397e8f6"`);
        await queryRunner.query(`ALTER TABLE "injury_symptoms" ADD CONSTRAINT "PK_9ca50ccd39cb35834ae5196c416" PRIMARY KEY ("id")`);
        await queryRunner.query(`ALTER TABLE "injury_binary_symptoms" ADD CONSTRAINT "FK_702898f02b328c5c459e871d6bd" FOREIGN KEY ("injury_id") REFERENCES "injury_concussion_symptoms"("id") ON DELETE CASCADE ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "injury_binary_symptoms" ADD CONSTRAINT "FK_c876e5840abcbf7c2429c488929" FOREIGN KEY ("binary_symptom_id") REFERENCES "binary_symptoms"("id") ON DELETE CASCADE ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "injury_red_flag_symptoms" ADD CONSTRAINT "FK_80ea8116d85c424f8fd9f2a6525" FOREIGN KEY ("injury_id") REFERENCES "injury_concussion_symptoms"("id") ON DELETE CASCADE ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "injury_red_flag_symptoms" ADD CONSTRAINT "FK_9a9d8838b5f92cf8a553ac7df50" FOREIGN KEY ("red_flag_symptom_id") REFERENCES "red_flag_symptoms"("id") ON DELETE CASCADE ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "injury_symptoms" ADD CONSTRAINT "FK_ca44c02ad0647a3b369d29b5e64" FOREIGN KEY ("injury_id") REFERENCES "injury_concussion_symptoms"("id") ON DELETE CASCADE ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "injury_symptoms" ADD CONSTRAINT "FK_dc355e152cd37e6d7d4549f6dfe" FOREIGN KEY ("symptom_id") REFERENCES "symptoms"("id") ON DELETE CASCADE ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "injury_concussion_symptoms" ADD CONSTRAINT "FK_6c2cf28640fded8f18044e6614c" FOREIGN KEY ("injury_id") REFERENCES "injuries"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "injury_concussion_symptoms" DROP CONSTRAINT "FK_6c2cf28640fded8f18044e6614c"`);
        await queryRunner.query(`ALTER TABLE "injury_symptoms" DROP CONSTRAINT "FK_dc355e152cd37e6d7d4549f6dfe"`);
        await queryRunner.query(`ALTER TABLE "injury_symptoms" DROP CONSTRAINT "FK_ca44c02ad0647a3b369d29b5e64"`);
        await queryRunner.query(`ALTER TABLE "injury_red_flag_symptoms" DROP CONSTRAINT "FK_9a9d8838b5f92cf8a553ac7df50"`);
        await queryRunner.query(`ALTER TABLE "injury_red_flag_symptoms" DROP CONSTRAINT "FK_80ea8116d85c424f8fd9f2a6525"`);
        await queryRunner.query(`ALTER TABLE "injury_binary_symptoms" DROP CONSTRAINT "FK_c876e5840abcbf7c2429c488929"`);
        await queryRunner.query(`ALTER TABLE "injury_binary_symptoms" DROP CONSTRAINT "FK_702898f02b328c5c459e871d6bd"`);
        await queryRunner.query(`ALTER TABLE "injury_symptoms" DROP CONSTRAINT "PK_9ca50ccd39cb35834ae5196c416"`);
        await queryRunner.query(`ALTER TABLE "injury_symptoms" ADD CONSTRAINT "PK_16040f2170961edf4cff397e8f6" PRIMARY KEY ("symptom_id", "id")`);
        await queryRunner.query(`ALTER TABLE "injury_symptoms" DROP CONSTRAINT "PK_16040f2170961edf4cff397e8f6"`);
        await queryRunner.query(`ALTER TABLE "injury_symptoms" ADD CONSTRAINT "PK_a56e6de3dc923579c2ac94edc53" PRIMARY KEY ("symptom_id", "injury_id", "id")`);
        await queryRunner.query(`ALTER TABLE "injury_symptoms" ADD CONSTRAINT "FK_dc355e152cd37e6d7d4549f6dfe" FOREIGN KEY ("symptom_id") REFERENCES "symptoms"("id") ON DELETE CASCADE ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "injury_red_flag_symptoms" DROP CONSTRAINT "PK_f9bbfb7921d272916c48cc4c77a"`);
        await queryRunner.query(`ALTER TABLE "injury_red_flag_symptoms" ADD CONSTRAINT "PK_fba722c3184ed65a970984a43c2" PRIMARY KEY ("red_flag_symptom_id", "id")`);
        await queryRunner.query(`ALTER TABLE "injury_red_flag_symptoms" DROP CONSTRAINT "PK_fba722c3184ed65a970984a43c2"`);
        await queryRunner.query(`ALTER TABLE "injury_red_flag_symptoms" ADD CONSTRAINT "PK_52340ad0ef8b9f224a2369aae48" PRIMARY KEY ("red_flag_symptom_id", "injury_id", "id")`);
        await queryRunner.query(`ALTER TABLE "injury_red_flag_symptoms" ADD CONSTRAINT "FK_9a9d8838b5f92cf8a553ac7df50" FOREIGN KEY ("red_flag_symptom_id") REFERENCES "red_flag_symptoms"("id") ON DELETE CASCADE ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "injury_binary_symptoms" DROP CONSTRAINT "PK_4b13e13e26bd5b500b62fdf2e33"`);
        await queryRunner.query(`ALTER TABLE "injury_binary_symptoms" ADD CONSTRAINT "PK_0def10e81509ac1bf846a0ea7c7" PRIMARY KEY ("binary_symptom_id", "id")`);
        await queryRunner.query(`ALTER TABLE "injury_binary_symptoms" DROP CONSTRAINT "PK_0def10e81509ac1bf846a0ea7c7"`);
        await queryRunner.query(`ALTER TABLE "injury_binary_symptoms" ADD CONSTRAINT "PK_3b7391e3656478bb8cf1b515115" PRIMARY KEY ("binary_symptom_id", "injury_id", "id")`);
        await queryRunner.query(`ALTER TABLE "injury_binary_symptoms" ADD CONSTRAINT "FK_c876e5840abcbf7c2429c488929" FOREIGN KEY ("binary_symptom_id") REFERENCES "binary_symptoms"("id") ON DELETE CASCADE ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "injury_symptoms" DROP CONSTRAINT "PK_a56e6de3dc923579c2ac94edc53"`);
        await queryRunner.query(`ALTER TABLE "injury_symptoms" ADD CONSTRAINT "PK_7f77f855bc4313dbd6e06832cf3" PRIMARY KEY ("symptom_id", "injury_id")`);
        await queryRunner.query(`ALTER TABLE "injury_symptoms" DROP COLUMN "id"`);
        await queryRunner.query(`ALTER TABLE "injury_red_flag_symptoms" DROP CONSTRAINT "PK_52340ad0ef8b9f224a2369aae48"`);
        await queryRunner.query(`ALTER TABLE "injury_red_flag_symptoms" ADD CONSTRAINT "PK_26e1c429a50c1ad1fb4c5d89932" PRIMARY KEY ("red_flag_symptom_id", "injury_id")`);
        await queryRunner.query(`ALTER TABLE "injury_red_flag_symptoms" DROP COLUMN "id"`);
        await queryRunner.query(`ALTER TABLE "injury_binary_symptoms" DROP CONSTRAINT "PK_3b7391e3656478bb8cf1b515115"`);
        await queryRunner.query(`ALTER TABLE "injury_binary_symptoms" ADD CONSTRAINT "PK_417c25cc9963026f4cef6aac6af" PRIMARY KEY ("binary_symptom_id", "injury_id")`);
        await queryRunner.query(`ALTER TABLE "injury_binary_symptoms" DROP COLUMN "id"`);
        await queryRunner.query(`DROP TABLE "injury_concussion_symptoms"`);
        await queryRunner.query(`ALTER TABLE "injury_symptoms" ADD CONSTRAINT "FK_ca44c02ad0647a3b369d29b5e64" FOREIGN KEY ("injury_id") REFERENCES "injuries"("id") ON DELETE CASCADE ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "injury_red_flag_symptoms" ADD CONSTRAINT "FK_80ea8116d85c424f8fd9f2a6525" FOREIGN KEY ("injury_id") REFERENCES "injuries"("id") ON DELETE CASCADE ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "injury_binary_symptoms" ADD CONSTRAINT "FK_702898f02b328c5c459e871d6bd" FOREIGN KEY ("injury_id") REFERENCES "injuries"("id") ON DELETE CASCADE ON UPDATE NO ACTION`);
    }

}

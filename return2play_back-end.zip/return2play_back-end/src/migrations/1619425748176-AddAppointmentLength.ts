import {MigrationInterface, QueryRunner} from "typeorm";

export class AddAppointmentLength1619425748176 implements MigrationInterface {
    name = 'AddAppointmentLength1619425748176'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "doctor_clinic_schedule" ADD "appointment_length" integer NOT NULL`);
        await queryRunner.query(`ALTER TABLE "clinics" ADD "appointment_length" integer NOT NULL`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "clinics" DROP COLUMN "appointment_length"`);
        await queryRunner.query(`ALTER TABLE "doctor_clinic_schedule" DROP COLUMN "appointment_length"`);
    }

}

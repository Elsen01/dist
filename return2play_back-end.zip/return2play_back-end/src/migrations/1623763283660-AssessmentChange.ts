import {MigrationInterface, QueryRunner} from "typeorm";

export class AssessmentChange1623763283660 implements MigrationInterface {
    name = 'AssessmentChange1623763283660'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "assessments" DROP CONSTRAINT "FK_6032f38de9322e78c966d6c04f2"`);
        await queryRunner.query(`ALTER TABLE "assessments" DROP CONSTRAINT "REL_6032f38de9322e78c966d6c04f"`);
        await queryRunner.query(`ALTER TABLE "assessments" DROP COLUMN "scat_id"`);
        await queryRunner.query(`ALTER TABLE "assessments" ADD "is_symptom_free" boolean NOT NULL DEFAULT true`);
        await queryRunner.query(`ALTER TABLE "assessments" ADD "are_symptom_worsened_concentration" boolean`);
        await queryRunner.query(`ALTER TABLE "assessments" ADD "are_symptom_worsened_physical" boolean`);
        await queryRunner.query(`ALTER TABLE "assessments" ADD "has_previous_concussion" boolean NOT NULL DEFAULT false`);
        await queryRunner.query(`ALTER TABLE "assessments" ADD "previous_concussion_date" date`);
        await queryRunner.query(`ALTER TABLE "assessments" ADD "previous_concussion_number" integer`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "assessments" DROP COLUMN "previous_concussion_number"`);
        await queryRunner.query(`ALTER TABLE "assessments" DROP COLUMN "previous_concussion_date"`);
        await queryRunner.query(`ALTER TABLE "assessments" DROP COLUMN "has_previous_concussion"`);
        await queryRunner.query(`ALTER TABLE "assessments" DROP COLUMN "are_symptom_worsened_physical"`);
        await queryRunner.query(`ALTER TABLE "assessments" DROP COLUMN "are_symptom_worsened_concentration"`);
        await queryRunner.query(`ALTER TABLE "assessments" DROP COLUMN "is_symptom_free"`);
        await queryRunner.query(`ALTER TABLE "assessments" ADD "scat_id" uuid NOT NULL`);
        await queryRunner.query(`ALTER TABLE "assessments" ADD CONSTRAINT "REL_6032f38de9322e78c966d6c04f" UNIQUE ("scat_id")`);
        await queryRunner.query(`ALTER TABLE "assessments" ADD CONSTRAINT "FK_6032f38de9322e78c966d6c04f2" FOREIGN KEY ("scat_id") REFERENCES "scat"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
    }

}

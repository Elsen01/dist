import {MigrationInterface, QueryRunner} from "typeorm";

export class UpdateAppointmentRelation1619101631244 implements MigrationInterface {
    name = 'UpdateAppointmentRelation1619101631244'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "appointments" DROP CONSTRAINT "FK_db12e4cfd8370cf7eb810df3365"`);
        await queryRunner.query(`ALTER TABLE "appointments" RENAME COLUMN "playerUserId" TO "player_id"`);
        await queryRunner.query(`CREATE TYPE "doctor_clinic_schedule_status_enum" AS ENUM('active', 'inactive')`);
        await queryRunner.query(`ALTER TABLE "doctor_clinic_schedule" ADD "status" "doctor_clinic_schedule_status_enum" NOT NULL DEFAULT 'active'`);
        await queryRunner.query(`ALTER TABLE "injuries" DROP CONSTRAINT "FK_d168998070d708fdf6062bb8f4d"`);
        await queryRunner.query(`ALTER TABLE "injuries" DROP CONSTRAINT "FK_a899be362ce73d0ba4b67fdea95"`);
        await queryRunner.query(`ALTER TABLE "injuries" ALTER COLUMN "player_id" DROP NOT NULL`);
        await queryRunner.query(`ALTER TABLE "injuries" ALTER COLUMN "reporter_id" DROP NOT NULL`);
        await queryRunner.query(`ALTER TABLE "injuries" ADD CONSTRAINT "FK_d168998070d708fdf6062bb8f4d" FOREIGN KEY ("player_id") REFERENCES "users"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "injuries" ADD CONSTRAINT "FK_a899be362ce73d0ba4b67fdea95" FOREIGN KEY ("reporter_id") REFERENCES "users"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "appointments" ADD CONSTRAINT "FK_55967cbb87411ed767fa9e3b60f" FOREIGN KEY ("player_id") REFERENCES "players"("user_id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "appointments" DROP CONSTRAINT "FK_55967cbb87411ed767fa9e3b60f"`);
        await queryRunner.query(`ALTER TABLE "injuries" DROP CONSTRAINT "FK_a899be362ce73d0ba4b67fdea95"`);
        await queryRunner.query(`ALTER TABLE "injuries" DROP CONSTRAINT "FK_d168998070d708fdf6062bb8f4d"`);
        await queryRunner.query(`ALTER TABLE "injuries" ALTER COLUMN "reporter_id" SET NOT NULL`);
        await queryRunner.query(`ALTER TABLE "injuries" ALTER COLUMN "player_id" SET NOT NULL`);
        await queryRunner.query(`ALTER TABLE "injuries" ADD CONSTRAINT "FK_a899be362ce73d0ba4b67fdea95" FOREIGN KEY ("reporter_id") REFERENCES "users"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "injuries" ADD CONSTRAINT "FK_d168998070d708fdf6062bb8f4d" FOREIGN KEY ("player_id") REFERENCES "users"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "doctor_clinic_schedule" DROP COLUMN "status"`);
        await queryRunner.query(`DROP TYPE "doctor_clinic_schedule_status_enum"`);
        await queryRunner.query(`ALTER TABLE "appointments" RENAME COLUMN "player_id" TO "playerUserId"`);
        await queryRunner.query(`ALTER TABLE "appointments" ADD CONSTRAINT "FK_db12e4cfd8370cf7eb810df3365" FOREIGN KEY ("playerUserId") REFERENCES "players"("user_id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
    }

}

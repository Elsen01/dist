import { MigrationInterface, QueryRunner } from 'typeorm';

export class Organization1616153026380 implements MigrationInterface {
  name = 'Organization1616153026380';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`CREATE TYPE "organizations_type_enum" AS ENUM('School', 'Club')`);
    await queryRunner.query(`CREATE TYPE "organizations_status_enum" AS ENUM('Active', 'Inactive')`);
    await queryRunner.query(
      `CREATE TABLE "organizations" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "name" character varying(100) NOT NULL, "email" character varying(255), "phone" character varying(15), "website" character varying(1000), "created_at" TIMESTAMP NOT NULL DEFAULT now(), "address_1" character varying, "address_2" character varying, "postcode" character varying(11), "town" character varying(100), "county" character varying(100), "country" character varying(100), "type" "organizations_type_enum" NOT NULL, "status" "organizations_status_enum" NOT NULL DEFAULT 'Active', CONSTRAINT "PK_6b031fcd0863e3f6b44230163f9" PRIMARY KEY ("id"))`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP TABLE "organizations"`);
    await queryRunner.query(`DROP TYPE "organizations_status_enum"`);
    await queryRunner.query(`DROP TYPE "organizations_type_enum"`);
  }
}

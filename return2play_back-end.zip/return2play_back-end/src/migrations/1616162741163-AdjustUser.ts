import { MigrationInterface, QueryRunner } from 'typeorm';

export class AdjustUser1616162741163 implements MigrationInterface {
  name = 'AdjustUser1616162741163';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "users" DROP COLUMN "mobile_phone"`);
    await queryRunner.query(`ALTER TABLE "users" DROP COLUMN "home_phone"`);
    await queryRunner.query(`ALTER TABLE "organizations_users" DROP CONSTRAINT "FK_b5aa17c39b722cb9bc25a3d139d"`);
    await queryRunner.query(`ALTER TABLE "users" DROP CONSTRAINT "PK_a3ffb1c0c8416b9fc6f907b7433"`);
    await queryRunner.query(`ALTER TABLE "users" DROP COLUMN "id"`);
    await queryRunner.query(`ALTER TABLE "users" ADD "id" character varying NOT NULL`);
    await queryRunner.query(`ALTER TABLE "users" ADD CONSTRAINT "PK_a3ffb1c0c8416b9fc6f907b7433" PRIMARY KEY ("id")`);
    await queryRunner.query(`COMMENT ON COLUMN "users"."email" IS NULL`);
    await queryRunner.query(`ALTER TABLE "users" ADD CONSTRAINT "UQ_97672ac88f789774dd47f7c8be3" UNIQUE ("email")`);
    await queryRunner.query(`ALTER TYPE "public"."users_status_enum" RENAME TO "users_status_enum_old"`);
    await queryRunner.query(`CREATE TYPE "users_status_enum" AS ENUM('Actived', 'Inactived', 'Deleted')`);
    await queryRunner.query(`ALTER TABLE "users" ALTER COLUMN "status" DROP DEFAULT`);
    await queryRunner.query(
      `ALTER TABLE "users" ALTER COLUMN "status" TYPE "users_status_enum" USING "status"::"text"::"users_status_enum"`
    );
    await queryRunner.query(`ALTER TABLE "users" ALTER COLUMN "status" SET DEFAULT 'Inactived'`);
    await queryRunner.query(`DROP TYPE "users_status_enum_old"`);
    await queryRunner.query(`COMMENT ON COLUMN "users"."status" IS NULL`);
    await queryRunner.query(`ALTER TABLE "users" ALTER COLUMN "status" SET DEFAULT 'Inactived'`);
    await queryRunner.query(`COMMENT ON COLUMN "organizations"."name" IS NULL`);
    await queryRunner.query(`ALTER TABLE "organizations" DROP CONSTRAINT "UQ_9b7ca6d30b94fef571cff876884"`);
    await queryRunner.query(`COMMENT ON COLUMN "organizations"."email" IS NULL`);
    await queryRunner.query(`ALTER TABLE "organizations" DROP CONSTRAINT "UQ_4ad920935f4d4eb73fc58b40f72"`);
    await queryRunner.query(`COMMENT ON COLUMN "organizations"."phone" IS NULL`);
    await queryRunner.query(`ALTER TABLE "organizations" DROP CONSTRAINT "UQ_9ca925d77299102a8bc433676f7"`);
    await queryRunner.query(`COMMENT ON COLUMN "organizations"."website" IS NULL`);
    await queryRunner.query(`ALTER TABLE "organizations" DROP CONSTRAINT "UQ_7a216df910f26a061d6f89415d9"`);
    await queryRunner.query(`ALTER TABLE "organizations_users" DROP CONSTRAINT "PK_da93ab06ae4af19e3a142813950"`);
    await queryRunner.query(
      `ALTER TABLE "organizations_users" ADD CONSTRAINT "PK_c00bc2922da6310512964d28729" PRIMARY KEY ("organizationsId")`
    );
    await queryRunner.query(`DROP INDEX "IDX_b5aa17c39b722cb9bc25a3d139"`);
    await queryRunner.query(`ALTER TABLE "organizations_users" DROP COLUMN "usersId"`);
    await queryRunner.query(`ALTER TABLE "organizations_users" ADD "usersId" character varying NOT NULL`);
    await queryRunner.query(`ALTER TABLE "organizations_users" DROP CONSTRAINT "PK_c00bc2922da6310512964d28729"`);
    await queryRunner.query(
      `ALTER TABLE "organizations_users" ADD CONSTRAINT "PK_da93ab06ae4af19e3a142813950" PRIMARY KEY ("organizationsId", "usersId")`
    );
    await queryRunner.query(`CREATE INDEX "IDX_b5aa17c39b722cb9bc25a3d139" ON "organizations_users" ("usersId") `);
    await queryRunner.query(
      `ALTER TABLE "organizations_users" ADD CONSTRAINT "FK_b5aa17c39b722cb9bc25a3d139d" FOREIGN KEY ("usersId") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE NO ACTION`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "organizations_users" DROP CONSTRAINT "FK_b5aa17c39b722cb9bc25a3d139d"`);
    await queryRunner.query(`DROP INDEX "IDX_b5aa17c39b722cb9bc25a3d139"`);
    await queryRunner.query(`ALTER TABLE "organizations_users" DROP CONSTRAINT "PK_da93ab06ae4af19e3a142813950"`);
    await queryRunner.query(
      `ALTER TABLE "organizations_users" ADD CONSTRAINT "PK_c00bc2922da6310512964d28729" PRIMARY KEY ("organizationsId")`
    );
    await queryRunner.query(`ALTER TABLE "organizations_users" DROP COLUMN "usersId"`);
    await queryRunner.query(`ALTER TABLE "organizations_users" ADD "usersId" uuid NOT NULL`);
    await queryRunner.query(`CREATE INDEX "IDX_b5aa17c39b722cb9bc25a3d139" ON "organizations_users" ("usersId") `);
    await queryRunner.query(`ALTER TABLE "organizations_users" DROP CONSTRAINT "PK_c00bc2922da6310512964d28729"`);
    await queryRunner.query(
      `ALTER TABLE "organizations_users" ADD CONSTRAINT "PK_da93ab06ae4af19e3a142813950" PRIMARY KEY ("organizationsId", "usersId")`
    );
    await queryRunner.query(
      `ALTER TABLE "organizations" ADD CONSTRAINT "UQ_7a216df910f26a061d6f89415d9" UNIQUE ("website")`
    );
    await queryRunner.query(`COMMENT ON COLUMN "organizations"."website" IS NULL`);
    await queryRunner.query(
      `ALTER TABLE "organizations" ADD CONSTRAINT "UQ_9ca925d77299102a8bc433676f7" UNIQUE ("phone")`
    );
    await queryRunner.query(`COMMENT ON COLUMN "organizations"."phone" IS NULL`);
    await queryRunner.query(
      `ALTER TABLE "organizations" ADD CONSTRAINT "UQ_4ad920935f4d4eb73fc58b40f72" UNIQUE ("email")`
    );
    await queryRunner.query(`COMMENT ON COLUMN "organizations"."email" IS NULL`);
    await queryRunner.query(
      `ALTER TABLE "organizations" ADD CONSTRAINT "UQ_9b7ca6d30b94fef571cff876884" UNIQUE ("name")`
    );
    await queryRunner.query(`COMMENT ON COLUMN "organizations"."name" IS NULL`);
    await queryRunner.query(`ALTER TABLE "users" ALTER COLUMN "status" DROP DEFAULT`);
    await queryRunner.query(`COMMENT ON COLUMN "users"."status" IS NULL`);
    await queryRunner.query(`CREATE TYPE "users_status_enum_old" AS ENUM('Active', 'Inactive', 'Deleted')`);
    await queryRunner.query(`ALTER TABLE "users" ALTER COLUMN "status" DROP DEFAULT`);
    await queryRunner.query(
      `ALTER TABLE "users" ALTER COLUMN "status" TYPE "users_status_enum_old" USING "status"::"text"::"users_status_enum_old"`
    );
    await queryRunner.query(`ALTER TABLE "users" ALTER COLUMN "status" SET DEFAULT 'Inactived'`);
    await queryRunner.query(`DROP TYPE "users_status_enum"`);
    await queryRunner.query(`ALTER TYPE "users_status_enum_old" RENAME TO  "users_status_enum"`);
    await queryRunner.query(`ALTER TABLE "users" DROP CONSTRAINT "UQ_97672ac88f789774dd47f7c8be3"`);
    await queryRunner.query(`COMMENT ON COLUMN "users"."email" IS NULL`);
    await queryRunner.query(`ALTER TABLE "users" DROP CONSTRAINT "PK_a3ffb1c0c8416b9fc6f907b7433"`);
    await queryRunner.query(`ALTER TABLE "users" DROP COLUMN "id"`);
    await queryRunner.query(`ALTER TABLE "users" ADD "id" uuid NOT NULL DEFAULT uuid_generate_v4()`);
    await queryRunner.query(`ALTER TABLE "users" ADD CONSTRAINT "PK_a3ffb1c0c8416b9fc6f907b7433" PRIMARY KEY ("id")`);
    await queryRunner.query(
      `ALTER TABLE "organizations_users" ADD CONSTRAINT "FK_b5aa17c39b722cb9bc25a3d139d" FOREIGN KEY ("usersId") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE NO ACTION`
    );
    await queryRunner.query(`ALTER TABLE "users" ADD "home_phone" character varying(255)`);
    await queryRunner.query(`ALTER TABLE "users" ADD "mobile_phone" character varying(255) NOT NULL`);
  }
}

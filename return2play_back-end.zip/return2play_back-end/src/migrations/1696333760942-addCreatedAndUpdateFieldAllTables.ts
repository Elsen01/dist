import {MigrationInterface, QueryRunner} from "typeorm";

export class addCreatedAndUpdateFieldAllTables1696333760942 implements MigrationInterface {
    name = 'addCreatedAndUpdateFieldAllTables1696333760942'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`DROP INDEX "clinics_medical_type_index"`);
        await queryRunner.query(`DROP INDEX "users_email_index"`);
        await queryRunner.query(`DROP INDEX "users_first_name_last_name_index"`);
        await queryRunner.query(`ALTER TABLE "payments" ADD "updated_at" TIMESTAMP NOT NULL DEFAULT now()`);
        await queryRunner.query(`ALTER TABLE "wonde_schools" ADD "created_at" TIMESTAMP NOT NULL DEFAULT now()`);
        await queryRunner.query(`ALTER TABLE "wonde_schools" ADD "updated_at" TIMESTAMP NOT NULL DEFAULT now()`);
        await queryRunner.query(`ALTER TABLE "sports" ADD "created_at" TIMESTAMP NOT NULL DEFAULT now()`);
        await queryRunner.query(`ALTER TABLE "sports" ADD "updated_at" TIMESTAMP NOT NULL DEFAULT now()`);
        await queryRunner.query(`ALTER TABLE "injury_mechanisms" ADD "created_at" TIMESTAMP NOT NULL DEFAULT now()`);
        await queryRunner.query(`ALTER TABLE "injury_mechanisms" ADD "updated_at" TIMESTAMP NOT NULL DEFAULT now()`);
        await queryRunner.query(`ALTER TABLE "external_assessments" ADD "updated_at" TIMESTAMP NOT NULL DEFAULT now()`);
        await queryRunner.query(`ALTER TABLE "body_regions" ADD "created_at" TIMESTAMP NOT NULL DEFAULT now()`);
        await queryRunner.query(`ALTER TABLE "body_regions" ADD "updated_at" TIMESTAMP NOT NULL DEFAULT now()`);
        await queryRunner.query(`ALTER TABLE "body_parts" ADD "created_at" TIMESTAMP NOT NULL DEFAULT now()`);
        await queryRunner.query(`ALTER TABLE "body_parts" ADD "updated_at" TIMESTAMP NOT NULL DEFAULT now()`);
        await queryRunner.query(`ALTER TABLE "other_injuries" ADD "created_at" TIMESTAMP NOT NULL DEFAULT now()`);
        await queryRunner.query(`ALTER TABLE "other_injuries" ADD "updated_at" TIMESTAMP NOT NULL DEFAULT now()`);
        await queryRunner.query(`ALTER TABLE "binary_symptoms" ADD "created_at" TIMESTAMP NOT NULL DEFAULT now()`);
        await queryRunner.query(`ALTER TABLE "binary_symptoms" ADD "updated_at" TIMESTAMP NOT NULL DEFAULT now()`);
        await queryRunner.query(`ALTER TABLE "red_flag_symptoms" ADD "created_at" TIMESTAMP NOT NULL DEFAULT now()`);
        await queryRunner.query(`ALTER TABLE "red_flag_symptoms" ADD "updated_at" TIMESTAMP NOT NULL DEFAULT now()`);
        await queryRunner.query(`ALTER TABLE "symptoms" ADD "created_at" TIMESTAMP NOT NULL DEFAULT now()`);
        await queryRunner.query(`ALTER TABLE "symptoms" ADD "updated_at" TIMESTAMP NOT NULL DEFAULT now()`);
        await queryRunner.query(`ALTER TABLE "injury_concussion_symptoms" ADD "updated_at" TIMESTAMP NOT NULL DEFAULT now()`);
        await queryRunner.query(`ALTER TABLE "notes" ADD "updated_at" TIMESTAMP NOT NULL DEFAULT now()`);
        await queryRunner.query(`ALTER TABLE "grtp" ADD "created_at" TIMESTAMP NOT NULL DEFAULT now()`);
        await queryRunner.query(`ALTER TABLE "grtp" ADD "updated_at" TIMESTAMP NOT NULL DEFAULT now()`);
        await queryRunner.query(`ALTER TABLE "assessments" ADD "updated_at" TIMESTAMP NOT NULL DEFAULT now()`);
        await queryRunner.query(`ALTER TABLE "clinics" ADD "created_at" TIMESTAMP NOT NULL DEFAULT now()`);
        await queryRunner.query(`ALTER TABLE "clinics" ADD "updated_at" TIMESTAMP NOT NULL DEFAULT now()`);
        await queryRunner.query(`ALTER TABLE "timeslots" ADD "created_at" TIMESTAMP NOT NULL DEFAULT now()`);
        await queryRunner.query(`ALTER TABLE "timeslots" ADD "updated_at" TIMESTAMP NOT NULL DEFAULT now()`);
        await queryRunner.query(`ALTER TABLE "appointments" ADD "created_at" TIMESTAMP NOT NULL DEFAULT now()`);
        await queryRunner.query(`ALTER TABLE "appointments" ADD "updated_at" TIMESTAMP NOT NULL DEFAULT now()`);
        await queryRunner.query(`ALTER TABLE "injuries" ADD "updated_at" TIMESTAMP NOT NULL DEFAULT now()`);
        await queryRunner.query(`ALTER TABLE "tags" ADD "created_at" TIMESTAMP NOT NULL DEFAULT now()`);
        await queryRunner.query(`ALTER TABLE "tags" ADD "updated_at" TIMESTAMP NOT NULL DEFAULT now()`);
        await queryRunner.query(`ALTER TABLE "organizations" ADD "updated_at" TIMESTAMP NOT NULL DEFAULT now()`);
        await queryRunner.query(`ALTER TABLE "doctor_clinic_schedule" ADD "created_at" TIMESTAMP NOT NULL DEFAULT now()`);
        await queryRunner.query(`ALTER TABLE "doctor_clinic_schedule" ADD "updated_at" TIMESTAMP NOT NULL DEFAULT now()`);
        await queryRunner.query(`ALTER TABLE "doctors" ADD "created_at" TIMESTAMP NOT NULL DEFAULT now()`);
        await queryRunner.query(`ALTER TABLE "doctors" ADD "updated_at" TIMESTAMP NOT NULL DEFAULT now()`);
        await queryRunner.query(`ALTER TABLE "users" ADD "updated_at" TIMESTAMP NOT NULL DEFAULT now()`);
        await queryRunner.query(`ALTER TABLE "players" ADD "created_at" TIMESTAMP NOT NULL DEFAULT now()`);
        await queryRunner.query(`ALTER TABLE "players" ADD "updated_at" TIMESTAMP NOT NULL DEFAULT now()`);
        await queryRunner.query(`ALTER TABLE "additional_recepients" ADD "updated_at" TIMESTAMP NOT NULL DEFAULT now()`);
        await queryRunner.query(`ALTER TABLE "reports" ADD "updated_at" TIMESTAMP NOT NULL DEFAULT now()`);
        // await queryRunner.query(`ALTER TYPE "injuries_injury_group_enum" RENAME TO "injuries_injury_group_enum_old"`);
        // await queryRunner.query(`CREATE TYPE "injuries_injury_group_enum" AS ENUM('Concussion', 'Other', 'Head Injury (possible concussion)')`);
        await queryRunner.query(`ALTER TABLE "injuries" ALTER COLUMN "injury_group" TYPE "injuries_injury_group_enum" USING "injury_group"::"text"::"injuries_injury_group_enum"`);
        // await queryRunner.query(`DROP TYPE "injuries_injury_group_enum_old"`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`CREATE TYPE "injuries_injury_group_enum_old" AS ENUM('Concussion', 'Head Injury', 'Head Injury (possible concussion)', 'Head Injury (suspected concussion)', 'Other')`);
        await queryRunner.query(`ALTER TABLE "injuries" ALTER COLUMN "injury_group" TYPE "injuries_injury_group_enum_old" USING "injury_group"::"text"::"injuries_injury_group_enum_old"`);
        await queryRunner.query(`DROP TYPE "injuries_injury_group_enum"`);
        await queryRunner.query(`ALTER TYPE "injuries_injury_group_enum_old" RENAME TO "injuries_injury_group_enum"`);
        await queryRunner.query(`ALTER TABLE "reports" DROP COLUMN "updated_at"`);
        await queryRunner.query(`ALTER TABLE "additional_recepients" DROP COLUMN "updated_at"`);
        await queryRunner.query(`ALTER TABLE "players" DROP COLUMN "updated_at"`);
        await queryRunner.query(`ALTER TABLE "players" DROP COLUMN "created_at"`);
        await queryRunner.query(`ALTER TABLE "users" DROP COLUMN "updated_at"`);
        await queryRunner.query(`ALTER TABLE "doctors" DROP COLUMN "updated_at"`);
        await queryRunner.query(`ALTER TABLE "doctors" DROP COLUMN "created_at"`);
        await queryRunner.query(`ALTER TABLE "doctor_clinic_schedule" DROP COLUMN "updated_at"`);
        await queryRunner.query(`ALTER TABLE "doctor_clinic_schedule" DROP COLUMN "created_at"`);
        await queryRunner.query(`ALTER TABLE "organizations" DROP COLUMN "updated_at"`);
        await queryRunner.query(`ALTER TABLE "tags" DROP COLUMN "updated_at"`);
        await queryRunner.query(`ALTER TABLE "tags" DROP COLUMN "created_at"`);
        await queryRunner.query(`ALTER TABLE "injuries" DROP COLUMN "updated_at"`);
        await queryRunner.query(`ALTER TABLE "appointments" DROP COLUMN "updated_at"`);
        await queryRunner.query(`ALTER TABLE "appointments" DROP COLUMN "created_at"`);
        await queryRunner.query(`ALTER TABLE "timeslots" DROP COLUMN "updated_at"`);
        await queryRunner.query(`ALTER TABLE "timeslots" DROP COLUMN "created_at"`);
        await queryRunner.query(`ALTER TABLE "clinics" DROP COLUMN "updated_at"`);
        await queryRunner.query(`ALTER TABLE "clinics" DROP COLUMN "created_at"`);
        await queryRunner.query(`ALTER TABLE "assessments" DROP COLUMN "updated_at"`);
        await queryRunner.query(`ALTER TABLE "grtp" DROP COLUMN "updated_at"`);
        await queryRunner.query(`ALTER TABLE "grtp" DROP COLUMN "created_at"`);
        await queryRunner.query(`ALTER TABLE "notes" DROP COLUMN "updated_at"`);
        await queryRunner.query(`ALTER TABLE "injury_concussion_symptoms" DROP COLUMN "updated_at"`);
        await queryRunner.query(`ALTER TABLE "symptoms" DROP COLUMN "updated_at"`);
        await queryRunner.query(`ALTER TABLE "symptoms" DROP COLUMN "created_at"`);
        await queryRunner.query(`ALTER TABLE "red_flag_symptoms" DROP COLUMN "updated_at"`);
        await queryRunner.query(`ALTER TABLE "red_flag_symptoms" DROP COLUMN "created_at"`);
        await queryRunner.query(`ALTER TABLE "binary_symptoms" DROP COLUMN "updated_at"`);
        await queryRunner.query(`ALTER TABLE "binary_symptoms" DROP COLUMN "created_at"`);
        await queryRunner.query(`ALTER TABLE "other_injuries" DROP COLUMN "updated_at"`);
        await queryRunner.query(`ALTER TABLE "other_injuries" DROP COLUMN "created_at"`);
        await queryRunner.query(`ALTER TABLE "body_parts" DROP COLUMN "updated_at"`);
        await queryRunner.query(`ALTER TABLE "body_parts" DROP COLUMN "created_at"`);
        await queryRunner.query(`ALTER TABLE "body_regions" DROP COLUMN "updated_at"`);
        await queryRunner.query(`ALTER TABLE "body_regions" DROP COLUMN "created_at"`);
        await queryRunner.query(`ALTER TABLE "external_assessments" DROP COLUMN "updated_at"`);
        await queryRunner.query(`ALTER TABLE "injury_mechanisms" DROP COLUMN "updated_at"`);
        await queryRunner.query(`ALTER TABLE "injury_mechanisms" DROP COLUMN "created_at"`);
        await queryRunner.query(`ALTER TABLE "sports" DROP COLUMN "updated_at"`);
        await queryRunner.query(`ALTER TABLE "sports" DROP COLUMN "created_at"`);
        await queryRunner.query(`ALTER TABLE "wonde_schools" DROP COLUMN "updated_at"`);
        await queryRunner.query(`ALTER TABLE "wonde_schools" DROP COLUMN "created_at"`);
        await queryRunner.query(`ALTER TABLE "payments" DROP COLUMN "updated_at"`);
        await queryRunner.query(`CREATE INDEX "users_first_name_last_name_index" ON "users" ("first_name", "last_name") `);
        await queryRunner.query(`CREATE INDEX "users_email_index" ON "users" ("email") `);
        await queryRunner.query(`CREATE INDEX "clinics_medical_type_index" ON "clinics" ("medical_type") `);
    }

}

import { MigrationInterface, QueryRunner } from 'typeorm';

export class ParentPlayerRelation1617183838323 implements MigrationInterface {
  name = 'ParentPlayerRelation1617183838323';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TABLE "players_parents" ("player_id" character varying NOT NULL, "parent_id" character varying NOT NULL, CONSTRAINT "PK_56a2533292bedc115e49a75d435" PRIMARY KEY ("player_id", "parent_id"))`
    );
    await queryRunner.query(`CREATE INDEX "IDX_fa154c9f528e33ebbaed7c7298" ON "players_parents" ("player_id") `);
    await queryRunner.query(`CREATE INDEX "IDX_039d174a7e6c867091fa2f5d45" ON "players_parents" ("parent_id") `);
    await queryRunner.query(`ALTER TABLE "players" DROP CONSTRAINT "FK_ba3575d2fbe71fab7155366235e"`);
    await queryRunner.query(`COMMENT ON COLUMN "players"."user_id" IS NULL`);
    await queryRunner.query(`ALTER TABLE "players" ADD CONSTRAINT "UQ_ba3575d2fbe71fab7155366235e" UNIQUE ("user_id")`);
    await queryRunner.query(
      `ALTER TABLE "players" ADD CONSTRAINT "FK_ba3575d2fbe71fab7155366235e" FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE NO ACTION`
    );
    await queryRunner.query(
      `ALTER TABLE "players_parents" ADD CONSTRAINT "FK_fa154c9f528e33ebbaed7c72988" FOREIGN KEY ("player_id") REFERENCES "players"("user_id") ON DELETE CASCADE ON UPDATE NO ACTION`
    );
    await queryRunner.query(
      `ALTER TABLE "players_parents" ADD CONSTRAINT "FK_039d174a7e6c867091fa2f5d456" FOREIGN KEY ("parent_id") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE NO ACTION`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "players_parents" DROP CONSTRAINT "FK_039d174a7e6c867091fa2f5d456"`);
    await queryRunner.query(`ALTER TABLE "players_parents" DROP CONSTRAINT "FK_fa154c9f528e33ebbaed7c72988"`);
    await queryRunner.query(`ALTER TABLE "players" DROP CONSTRAINT "FK_ba3575d2fbe71fab7155366235e"`);
    await queryRunner.query(`ALTER TABLE "players" DROP CONSTRAINT "UQ_ba3575d2fbe71fab7155366235e"`);
    await queryRunner.query(`COMMENT ON COLUMN "players"."user_id" IS NULL`);
    await queryRunner.query(
      `ALTER TABLE "players" ADD CONSTRAINT "FK_ba3575d2fbe71fab7155366235e" FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE NO ACTION`
    );
    await queryRunner.query(`DROP INDEX "IDX_039d174a7e6c867091fa2f5d45"`);
    await queryRunner.query(`DROP INDEX "IDX_fa154c9f528e33ebbaed7c7298"`);
    await queryRunner.query(`DROP TABLE "players_parents"`);
  }
}

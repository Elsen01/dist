import { MigrationInterface, QueryRunner } from 'typeorm';

export class InjurySuspectedConcussion1659697449719 implements MigrationInterface {
  name = 'InjurySuspectedConcussion1659697449719';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TYPE "assessments_decided_outcome_enum" RENAME TO "assessments_decided_outcome_enum_old"`
    );
    await queryRunner.query(
      `CREATE TYPE "assessments_decided_outcome_enum" AS ENUM('GRTP', 'Remain in GRTP', 'Not yet fit - re-review in 1 week', 'Return to complete rest', 'Refer to MDT', 'Refer for external care', 'Fit to return to play', 'Clear injury')`
    );
    await queryRunner.query(
      `ALTER TABLE "assessments" ALTER COLUMN "decided_outcome" TYPE "assessments_decided_outcome_enum" USING "decided_outcome"::"text"::"assessments_decided_outcome_enum"`
    );
    await queryRunner.query(`DROP TYPE "assessments_decided_outcome_enum_old"`);
    await queryRunner.query(`ALTER TYPE "injuries_injury_group_enum" RENAME TO "injuries_injury_group_enum_old"`);
    await queryRunner.query(
      `CREATE TYPE "injuries_injury_group_enum" AS ENUM('Concussion', 'Other', 'Head Injury', 'Head Injury (suspected concussion)')`
    );
    await queryRunner.query(
      `ALTER TABLE "injuries" ALTER COLUMN "injury_group" TYPE "injuries_injury_group_enum" USING "injury_group"::"text"::"injuries_injury_group_enum"`
    );
    await queryRunner.query(`DROP TYPE "injuries_injury_group_enum_old"`);
    await queryRunner.query(`ALTER TABLE "organizations" ALTER COLUMN "is_socs" SET DEFAULT true`);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "organizations" ALTER COLUMN "is_socs" SET DEFAULT false`);
    await queryRunner.query(
      `CREATE TYPE "injuries_injury_group_enum_old" AS ENUM('Concussion', 'Head Injury', 'Other')`
    );
    await queryRunner.query(
      `ALTER TABLE "injuries" ALTER COLUMN "injury_group" TYPE "injuries_injury_group_enum_old" USING "injury_group"::"text"::"injuries_injury_group_enum_old"`
    );
    await queryRunner.query(`DROP TYPE "injuries_injury_group_enum"`);
    await queryRunner.query(`ALTER TYPE "injuries_injury_group_enum_old" RENAME TO "injuries_injury_group_enum"`);
    await queryRunner.query(
      `CREATE TYPE "assessments_decided_outcome_enum_old" AS ENUM('Clear injury', 'GRTP', 'Not yet fit - re-review in 1 week', 'Refer for external care', 'Refer to MDT')`
    );
    await queryRunner.query(
      `ALTER TABLE "assessments" ALTER COLUMN "decided_outcome" TYPE "assessments_decided_outcome_enum_old" USING "decided_outcome"::"text"::"assessments_decided_outcome_enum_old"`
    );
    await queryRunner.query(`DROP TYPE "assessments_decided_outcome_enum"`);
    await queryRunner.query(
      `ALTER TYPE "assessments_decided_outcome_enum_old" RENAME TO "assessments_decided_outcome_enum"`
    );
  }
}

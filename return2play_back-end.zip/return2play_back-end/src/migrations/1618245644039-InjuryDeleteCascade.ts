import {MigrationInterface, QueryRunner} from "typeorm";

export class InjuryDeleteCascade1618245644039 implements MigrationInterface {
    name = 'InjuryDeleteCascade1618245644039'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "sport_injuries" DROP CONSTRAINT "FK_e7da844ae0ba304db882369881c"`);
        await queryRunner.query(`ALTER TABLE "sport_injuries" DROP CONSTRAINT "FK_3b2bafcc20315ef1c0491ec1336"`);
        await queryRunner.query(`ALTER TABLE "concussion_injuries" DROP CONSTRAINT "FK_d86694cfcea4b2869d53dd7ea91"`);
        await queryRunner.query(`ALTER TABLE "injuries" DROP CONSTRAINT "FK_d168998070d708fdf6062bb8f4d"`);
        await queryRunner.query(`ALTER TABLE "injuries" DROP CONSTRAINT "FK_a899be362ce73d0ba4b67fdea95"`);
        await queryRunner.query(`COMMENT ON COLUMN "injuries"."player_id" IS NULL`);
        await queryRunner.query(`ALTER TABLE "injuries" DROP CONSTRAINT "REL_d168998070d708fdf6062bb8f4"`);
        await queryRunner.query(`COMMENT ON COLUMN "injuries"."reporter_id" IS NULL`);
        await queryRunner.query(`ALTER TABLE "injuries" DROP CONSTRAINT "REL_a899be362ce73d0ba4b67fdea9"`);
        await queryRunner.query(`ALTER TABLE "injuries" ADD CONSTRAINT "FK_d168998070d708fdf6062bb8f4d" FOREIGN KEY ("player_id") REFERENCES "users"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "injuries" ADD CONSTRAINT "FK_a899be362ce73d0ba4b67fdea95" FOREIGN KEY ("reporter_id") REFERENCES "users"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "sport_injuries" ADD CONSTRAINT "FK_e7da844ae0ba304db882369881c" FOREIGN KEY ("injury_id") REFERENCES "injuries"("id") ON DELETE CASCADE ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "sport_injuries" ADD CONSTRAINT "FK_3b2bafcc20315ef1c0491ec1336" FOREIGN KEY ("mechanism_id") REFERENCES "injury_mechanisms"("id") ON DELETE CASCADE ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "concussion_injuries" ADD CONSTRAINT "FK_d86694cfcea4b2869d53dd7ea91" FOREIGN KEY ("injury_id") REFERENCES "injuries"("id") ON DELETE CASCADE ON UPDATE NO ACTION`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "concussion_injuries" DROP CONSTRAINT "FK_d86694cfcea4b2869d53dd7ea91"`);
        await queryRunner.query(`ALTER TABLE "sport_injuries" DROP CONSTRAINT "FK_3b2bafcc20315ef1c0491ec1336"`);
        await queryRunner.query(`ALTER TABLE "sport_injuries" DROP CONSTRAINT "FK_e7da844ae0ba304db882369881c"`);
        await queryRunner.query(`ALTER TABLE "injuries" DROP CONSTRAINT "FK_a899be362ce73d0ba4b67fdea95"`);
        await queryRunner.query(`ALTER TABLE "injuries" DROP CONSTRAINT "FK_d168998070d708fdf6062bb8f4d"`);
        await queryRunner.query(`ALTER TABLE "injuries" ADD CONSTRAINT "REL_a899be362ce73d0ba4b67fdea9" UNIQUE ("reporter_id")`);
        await queryRunner.query(`COMMENT ON COLUMN "injuries"."reporter_id" IS NULL`);
        await queryRunner.query(`ALTER TABLE "injuries" ADD CONSTRAINT "REL_d168998070d708fdf6062bb8f4" UNIQUE ("player_id")`);
        await queryRunner.query(`COMMENT ON COLUMN "injuries"."player_id" IS NULL`);
        await queryRunner.query(`ALTER TABLE "injuries" ADD CONSTRAINT "FK_a899be362ce73d0ba4b67fdea95" FOREIGN KEY ("reporter_id") REFERENCES "users"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "injuries" ADD CONSTRAINT "FK_d168998070d708fdf6062bb8f4d" FOREIGN KEY ("player_id") REFERENCES "users"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "concussion_injuries" ADD CONSTRAINT "FK_d86694cfcea4b2869d53dd7ea91" FOREIGN KEY ("injury_id") REFERENCES "injuries"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "sport_injuries" ADD CONSTRAINT "FK_3b2bafcc20315ef1c0491ec1336" FOREIGN KEY ("mechanism_id") REFERENCES "injury_mechanisms"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "sport_injuries" ADD CONSTRAINT "FK_e7da844ae0ba304db882369881c" FOREIGN KEY ("injury_id") REFERENCES "injuries"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
    }

}

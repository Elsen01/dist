import {MigrationInterface, QueryRunner} from "typeorm";

export class AdditionalsAddCascade1621938248181 implements MigrationInterface {
    name = 'AdditionalsAddCascade1621938248181'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "additional_recepients" DROP CONSTRAINT "FK_3c3f68b09b6f07915acf6f360d9"`);
        await queryRunner.query(`ALTER TABLE "additional_recepients" ADD CONSTRAINT "FK_3c3f68b09b6f07915acf6f360d9" FOREIGN KEY ("player_id") REFERENCES "players"("user_id") ON DELETE CASCADE ON UPDATE NO ACTION`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "additional_recepients" DROP CONSTRAINT "FK_3c3f68b09b6f07915acf6f360d9"`);
        await queryRunner.query(`ALTER TABLE "additional_recepients" ADD CONSTRAINT "FK_3c3f68b09b6f07915acf6f360d9" FOREIGN KEY ("player_id") REFERENCES "players"("user_id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
    }

}

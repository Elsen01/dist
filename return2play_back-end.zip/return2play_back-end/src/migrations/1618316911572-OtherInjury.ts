import {MigrationInterface, QueryRunner} from "typeorm";

export class OtherInjury1618316911572 implements MigrationInterface {
    name = 'OtherInjury1618316911572'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`CREATE TYPE "other_injuries_category_enum" AS ENUM('New Injury', 'Aggravated old injury', 'Overuse', 'Biomechanical', 'Idiopathic')`);
        await queryRunner.query(`CREATE TYPE "other_injuries_type_enum" AS ENUM('Graze/Abrasion', 'Bruise/Contusion', 'Blister', 'Crush injury', 'Cut/Laceration', 'Dislocation', 'Fracture/Broken bone', 'Sprain (ligaments)', 'Strain (muscle)')`);
        await queryRunner.query(`CREATE TYPE "other_injuries_body_side_enum" AS ENUM('Left', 'Right', 'N/A')`);
        await queryRunner.query(`CREATE TABLE "other_injuries" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "category" "other_injuries_category_enum" NOT NULL, "type" "other_injuries_type_enum" NOT NULL, "body_side" "other_injuries_body_side_enum" NOT NULL, "suggested_restrictions" character varying(1000) NOT NULL, "injury_id" uuid, "body_region_id" uuid NOT NULL, "body_part_id" uuid NOT NULL, CONSTRAINT "REL_4fccdf91e2fd1eefd0c5227ad6" UNIQUE ("injury_id"), CONSTRAINT "PK_b760e08f66d8f4376b5dd4ce64f" PRIMARY KEY ("id"))`);
        await queryRunner.query(`ALTER TABLE "other_injuries" ADD CONSTRAINT "FK_4fccdf91e2fd1eefd0c5227ad64" FOREIGN KEY ("injury_id") REFERENCES "injuries"("id") ON DELETE CASCADE ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "other_injuries" ADD CONSTRAINT "FK_8dd3746e7947bf44a2f9039172a" FOREIGN KEY ("body_region_id") REFERENCES "body_regions"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "other_injuries" ADD CONSTRAINT "FK_6d42c0a668531f15ccef6c69746" FOREIGN KEY ("body_part_id") REFERENCES "body_parts"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "other_injuries" DROP CONSTRAINT "FK_6d42c0a668531f15ccef6c69746"`);
        await queryRunner.query(`ALTER TABLE "other_injuries" DROP CONSTRAINT "FK_8dd3746e7947bf44a2f9039172a"`);
        await queryRunner.query(`ALTER TABLE "other_injuries" DROP CONSTRAINT "FK_4fccdf91e2fd1eefd0c5227ad64"`);
        await queryRunner.query(`DROP TABLE "other_injuries"`);
        await queryRunner.query(`DROP TYPE "other_injuries_body_side_enum"`);
        await queryRunner.query(`DROP TYPE "other_injuries_type_enum"`);
        await queryRunner.query(`DROP TYPE "other_injuries_category_enum"`);
    }

}

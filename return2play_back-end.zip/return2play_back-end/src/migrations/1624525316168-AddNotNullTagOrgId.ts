import {MigrationInterface, QueryRunner} from "typeorm";

export class AddNotNullTagOrgId1624525316168 implements MigrationInterface {
    name = 'AddNotNullTagOrgId1624525316168'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "tags" DROP CONSTRAINT "FK_8f8033a570b04520455cc93ed3d"`);
        await queryRunner.query(`ALTER TABLE "tags" DROP CONSTRAINT "UQ_b3fd0b26c4e8d043bdf0d1bfab8"`);
        await queryRunner.query(`ALTER TABLE "tags" ALTER COLUMN "organization_id" SET NOT NULL`);
        await queryRunner.query(`ALTER TABLE "tags" ADD CONSTRAINT "UQ_b3fd0b26c4e8d043bdf0d1bfab8" UNIQUE ("name", "organization_id")`);
        await queryRunner.query(`ALTER TABLE "tags" ADD CONSTRAINT "FK_8f8033a570b04520455cc93ed3d" FOREIGN KEY ("organization_id") REFERENCES "organizations"("id") ON DELETE CASCADE ON UPDATE NO ACTION`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "tags" DROP CONSTRAINT "FK_8f8033a570b04520455cc93ed3d"`);
        await queryRunner.query(`ALTER TABLE "tags" DROP CONSTRAINT "UQ_b3fd0b26c4e8d043bdf0d1bfab8"`);
        await queryRunner.query(`ALTER TABLE "tags" ALTER COLUMN "organization_id" DROP NOT NULL`);
        await queryRunner.query(`ALTER TABLE "tags" ADD CONSTRAINT "UQ_b3fd0b26c4e8d043bdf0d1bfab8" UNIQUE ("name", "organization_id")`);
        await queryRunner.query(`ALTER TABLE "tags" ADD CONSTRAINT "FK_8f8033a570b04520455cc93ed3d" FOREIGN KEY ("organization_id") REFERENCES "organizations"("id") ON DELETE CASCADE ON UPDATE NO ACTION`);
    }

}

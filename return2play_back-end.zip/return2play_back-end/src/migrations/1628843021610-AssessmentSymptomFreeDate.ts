import {MigrationInterface, QueryRunner} from "typeorm";

export class AssessmentSymptomFreeDate1628843021610 implements MigrationInterface {
    name = 'AssessmentSymptomFreeDate1628843021610'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "assessments" ADD "first_completely_symptom_free_date" date`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "assessments" DROP COLUMN "first_completely_symptom_free_date"`);
    }

}

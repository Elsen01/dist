import { MigrationInterface, QueryRunner } from 'typeorm';

export class Injuries1617721012760 implements MigrationInterface {
  name = 'Injuries1617721012760';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`CREATE TYPE "injuries_injury_group_enum" AS ENUM('Concussion', 'Other')`);
    await queryRunner.query(`CREATE TYPE "injuries_activity_type_enum" AS ENUM('Sport', 'Non-sport')`);
    await queryRunner.query(
      `CREATE TABLE "injuries" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "injury_group" "injuries_injury_group_enum" NOT NULL, "activity_type" "injuries_activity_type_enum" NOT NULL, "accident_date" TIMESTAMP WITH TIME ZONE NOT NULL, "player_id" character varying, "reporter_id" character varying, CONSTRAINT "REL_d168998070d708fdf6062bb8f4" UNIQUE ("player_id"), CONSTRAINT "REL_a899be362ce73d0ba4b67fdea9" UNIQUE ("reporter_id"), CONSTRAINT "PK_7fee0e9dfd99db4c3205fd7601e" PRIMARY KEY ("id"))`
    );
    await queryRunner.query(`CREATE TYPE "sport_injuries_injured_at_enum" AS ENUM('Match', 'Training', 'Recreation')`);
    await queryRunner.query(`CREATE TYPE "sport_injuries_play_side_enum" AS ENUM('Attack', 'Defence')`);
    await queryRunner.query(
      `CREATE TYPE "sport_injuries_time_period_enum" AS ENUM('First quarter', 'Second quarter', 'Third quarter', 'Fourth quarter')`
    );
    await queryRunner.query(
      `CREATE TABLE "sport_injuries" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "injured_at" "sport_injuries_injured_at_enum" NOT NULL, "play_side" "sport_injuries_play_side_enum", "protective_headgear" boolean, "mouth_guard" boolean, "time_period" "sport_injuries_time_period_enum" NOT NULL, "injury_id" uuid, "organization_id" uuid, CONSTRAINT "REL_e7da844ae0ba304db882369881" UNIQUE ("injury_id"), CONSTRAINT "PK_a580e0b7aefcc6618aee7f6dfaa" PRIMARY KEY ("id"))`
    );
    await queryRunner.query(
      `ALTER TABLE "injuries" ADD CONSTRAINT "FK_d168998070d708fdf6062bb8f4d" FOREIGN KEY ("player_id") REFERENCES "users"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`
    );
    await queryRunner.query(
      `ALTER TABLE "injuries" ADD CONSTRAINT "FK_a899be362ce73d0ba4b67fdea95" FOREIGN KEY ("reporter_id") REFERENCES "users"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`
    );
    await queryRunner.query(
      `ALTER TABLE "sport_injuries" ADD CONSTRAINT "FK_e7da844ae0ba304db882369881c" FOREIGN KEY ("injury_id") REFERENCES "injuries"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`
    );
    await queryRunner.query(
      `ALTER TABLE "sport_injuries" ADD CONSTRAINT "FK_0cfe91f6a4cd7ba8550997db08c" FOREIGN KEY ("organization_id") REFERENCES "organizations"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "sport_injuries" DROP CONSTRAINT "FK_0cfe91f6a4cd7ba8550997db08c"`);
    await queryRunner.query(`ALTER TABLE "sport_injuries" DROP CONSTRAINT "FK_e7da844ae0ba304db882369881c"`);
    await queryRunner.query(`ALTER TABLE "injuries" DROP CONSTRAINT "FK_a899be362ce73d0ba4b67fdea95"`);
    await queryRunner.query(`ALTER TABLE "injuries" DROP CONSTRAINT "FK_d168998070d708fdf6062bb8f4d"`);
    await queryRunner.query(`DROP TABLE "sport_injuries"`);
    await queryRunner.query(`DROP TYPE "sport_injuries_time_period_enum"`);
    await queryRunner.query(`DROP TYPE "sport_injuries_play_side_enum"`);
    await queryRunner.query(`DROP TYPE "sport_injuries_injured_at_enum"`);
    await queryRunner.query(`DROP TABLE "injuries"`);
    await queryRunner.query(`DROP TYPE "injuries_activity_type_enum"`);
    await queryRunner.query(`DROP TYPE "injuries_injury_group_enum"`);
  }
}

import {MigrationInterface, QueryRunner} from "typeorm";

export class UpdatedFunctionToUpdatePlayStatus1630657259713 implements MigrationInterface {
    name = 'UpdatedFunctionToUpdatePlayStatus1630657259713'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`CREATE OR REPLACE FUNCTION update_play_status()
        RETURNS trigger AS $$
        DECLARE temprow record;
        DECLARE status_coefficient int = 0;
        BEGIN
            FOR temprow IN
                SELECT i.play_status, count(i.play_status) AS play_status_count
                FROM injuries i
                WHERE i.player_id = NEW.player_id AND i.status = 'Active'
                GROUP BY i.play_status
            LOOP
                IF (temprow.play_status = 'Not safe to play' AND temprow.play_status_count > 0) THEN
                    status_coefficient = 3;
                END IF;
            IF (temprow.play_status = 'Reduced level of activity' AND temprow.play_status_count > 0 AND status_coefficient <= 1) THEN
            status_coefficient = 2;
            END IF;
            IF (temprow.play_status_count > 0 AND status_coefficient = 0) THEN
            status_coefficient = 1;
            END IF;
            END LOOP;

            IF (status_coefficient = 3 ) THEN
                UPDATE players SET play_status = 'Not safe to play' WHERE user_id = NEW.player_id;
            END IF;
            IF (status_coefficient = 2) THEN
                UPDATE players SET play_status = 'Reduced level of activity' WHERE user_id = NEW.player_id;
            END IF;
            IF (status_coefficient = 1 OR status_coefficient = 0) THEN
                UPDATE players SET play_status = 'Safe to play' WHERE user_id = NEW.player_id;
            END IF;
        RETURN NULL;
    END $$ LANGUAGE plpgsql;`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`CREATE OR REPLACE FUNCTION update_play_status()
        RETURNS trigger AS $$
        DECLARE temprow record;
        DECLARE status_coefficient int = 0;
        BEGIN
            FOR temprow IN
                SELECT i.play_status, count(i.play_status) AS play_status_count
                FROM injuries i
                WHERE i.player_id = NEW.player_id AND i.status = 'Active'
                GROUP BY i.play_status
            LOOP
                IF (temprow.play_status = 'Not safe to play' AND temprow.play_status_count > 0) THEN
                    status_coefficient = 3;
                END IF;
            IF (temprow.play_status = 'Reduced level of activity' AND temprow.play_status_count > 0 AND status_coefficient < 1) THEN
            status_coefficient = 2;
            END IF;
            IF (temprow.play_status_count > 0 AND status_coefficient = 0) THEN
            status_coefficient = 1;
            END IF;
            END LOOP;

            IF (status_coefficient = 3 ) THEN
                UPDATE players SET play_status = 'Not safe to play'::players_play_status_enum WHERE user_id = NEW.player_id;
            END IF;
            IF (status_coefficient = 2) THEN
                UPDATE players SET play_status = 'Reduced level of activity'::players_play_status_enum WHERE user_id = NEW.player_id;
            END IF;
            IF (status_coefficient = 1 OR status_coefficient = 0) THEN
                UPDATE players SET play_status = 'Safe to play'::players_play_status_enum WHERE user_id = NEW.player_id;
            END IF;
        RETURN NULL;
    END $$ LANGUAGE plpgsql;`);
    }

}

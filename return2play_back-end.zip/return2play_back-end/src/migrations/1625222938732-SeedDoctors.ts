import {MigrationInterface, QueryRunner} from "typeorm";

export class SeedDoctors1625222938732 implements MigrationInterface {
    name = 'SeedDoctors1625222938732'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
        INSERT INTO users
        (id, email, first_name, last_name, status, gender, birthday, created_at, role)
        VALUES (uuid_generate_v4(), 'sambarke1@doctors.org.uk', 'Sam', 'Barke', 'Active', null, null, '2016-03-11 12:08:17', 'doctors'),
        (uuid_generate_v4(), 'Alex.maxwell@doctors.org.uk', 'Alex', 'Maxwell', 'Active', null, null, '2016-09-19 19:30:26', 'doctors'),
        (uuid_generate_v4(), 'tillysiva@hotmail.com', 'Tilly', 'Sivaramalingam', 'Active', null, null, '2017-01-03 15:33:54', 'doctors'),
        (uuid_generate_v4(), 'tim.mcewen@doctors.org.uk', 'Tim', 'McEwen', 'Active', null, null, '2017-10-06 15:03:23', 'doctors'),
        (uuid_generate_v4(), 'medical@return2play.org.uk', 'On-Call', 'Doctor', 'Active', null, null, '2018-09-24 20:17:52', 'doctors'),
        (uuid_generate_v4(), 'medical+harrow@return2play.org.uk', 'Harrow', 'School', 'Active', null, null, '2020-01-16 18:11:26', 'doctors'),
        (uuid_generate_v4(), 'medical+harrowschool@return2play.org.uk', 'Harrow', 'School -', 'Active', null, null, '2020-01-16 18:15:52', 'doctors'),
        (uuid_generate_v4(), 'medical+whitgiftschool@return2play.org.uk', 'Whitgift', 'School -', 'Active', null, null, '2020-01-17 12:29:33', 'doctors'),
        (uuid_generate_v4(), 'medical+trinityschool@return2play.org.uk', 'Trinity', 'School -', 'Active', null, null, '2020-01-17 12:31:01', 'doctors'),
        (uuid_generate_v4(), 'medical+reedsschool@return2play.org.uk', $$Reed's$$, 'School -', 'Active', null, null, '2020-01-17 12:33:13', 'doctors'),
        (uuid_generate_v4(), 'medical+stjohnsschool@return2play.org.uk', 'St John''s', 'School -', 'Active', null, null, '2020-01-17 12:34:24', 'doctors');
        `);

        await queryRunner.query(`
        INSERT INTO doctors
        (gmc, user_id, bio, picture)
        VALUES
        ('-', (SELECT id FROM users WHERE email = 'medical+whitgiftschool@return2play.org.uk'), null, null),
        ('--', (SELECT id FROM users WHERE email = 'medical+trinityschool@return2play.org.uk'), null, null),
        ('---', (SELECT id FROM users WHERE email = 'medical+reedsschool@return2play.org.uk'), null, null),
        ('----', (SELECT id FROM users WHERE email = 'medical+stjohnsschool@return2play.org.uk'), null, null),
        ('3286245', (SELECT id FROM users WHERE email = 'tillysiva@hotmail.com'), null, null),
        ('7084310', (SELECT id FROM users WHERE email = 'sambarke1@doctors.org.uk'), null, null),
        ('7134610', (SELECT id FROM users WHERE email = 'Alex.maxwell@doctors.org.uk'), null, null),
        ('7285071', (SELECT id FROM users WHERE email = 'tim.mcewen@doctors.org.uk'), null, null),
        ('See letter', (SELECT id FROM users WHERE email = 'medical+harrow@return2play.org.uk'), null, null),
        ('See note', (SELECT id FROM users WHERE email = 'medical+harrowschool@return2play.org.uk'), null, null),
        ('See notes', (SELECT id FROM users WHERE email = 'medical@return2play.org.uk'), null, null);
        `);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
        DELETE
        FROM users
        WHERE id IN ('sambarke1@doctors.org.uk',
                     'Alex.maxwell@doctors.org.uk',
                     'tillysiva@hotmail.com',
                     'tim.mcewen@doctors.org.uk',
                     'medical@return2play.org.uk',
                     'medical+harrow@return2play.org.uk',
                     'medical+harrowschool@return2play.org.uk',
                     'medical+whitgiftschool@return2play.org.uk',
                     'medical+trinityschool@return2play.org.uk',
                     'medical+reedsschool@return2play.org.uk',
                     'medical+stjohnsschool@return2play.org.uk');`);
    }

}

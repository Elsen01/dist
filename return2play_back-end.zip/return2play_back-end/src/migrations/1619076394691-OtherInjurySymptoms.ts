import {MigrationInterface, QueryRunner} from "typeorm";

export class OtherInjurySymptoms1619076394691 implements MigrationInterface {
    name = 'OtherInjurySymptoms1619076394691'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`CREATE TABLE "other_symptoms" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "name" character varying(500) NOT NULL, CONSTRAINT "PK_209024f38529c7e454bb393687c" PRIMARY KEY ("id"))`);
        await queryRunner.query(`CREATE TABLE "injury_other_symptoms" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "value" character varying(255) NOT NULL, "injury_id" uuid NOT NULL, "other_symptom_id" uuid NOT NULL, CONSTRAINT "PK_bd780f7956a16655cb566a8f5e0" PRIMARY KEY ("id"))`);
        await queryRunner.query(`ALTER TABLE "injuries" DROP CONSTRAINT "FK_d168998070d708fdf6062bb8f4d"`);
        await queryRunner.query(`ALTER TABLE "injuries" DROP CONSTRAINT "FK_a899be362ce73d0ba4b67fdea95"`);
        await queryRunner.query(`ALTER TABLE "injuries" ALTER COLUMN "player_id" SET NOT NULL`);
        await queryRunner.query(`ALTER TABLE "injuries" ALTER COLUMN "reporter_id" SET NOT NULL`);
        await queryRunner.query(`ALTER TABLE "injury_other_symptoms" ADD CONSTRAINT "FK_e1287fafcbe28f50f653f2926af" FOREIGN KEY ("injury_id") REFERENCES "injury_concussion_symptoms"("id") ON DELETE CASCADE ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "injury_other_symptoms" ADD CONSTRAINT "FK_0c2f3ce74433b92fb1a49955325" FOREIGN KEY ("other_symptom_id") REFERENCES "other_symptoms"("id") ON DELETE CASCADE ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "injuries" ADD CONSTRAINT "FK_d168998070d708fdf6062bb8f4d" FOREIGN KEY ("player_id") REFERENCES "users"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "injuries" ADD CONSTRAINT "FK_a899be362ce73d0ba4b67fdea95" FOREIGN KEY ("reporter_id") REFERENCES "users"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "injuries" DROP CONSTRAINT "FK_a899be362ce73d0ba4b67fdea95"`);
        await queryRunner.query(`ALTER TABLE "injuries" DROP CONSTRAINT "FK_d168998070d708fdf6062bb8f4d"`);
        await queryRunner.query(`ALTER TABLE "injury_other_symptoms" DROP CONSTRAINT "FK_0c2f3ce74433b92fb1a49955325"`);
        await queryRunner.query(`ALTER TABLE "injury_other_symptoms" DROP CONSTRAINT "FK_e1287fafcbe28f50f653f2926af"`);
        await queryRunner.query(`ALTER TABLE "injuries" ALTER COLUMN "reporter_id" DROP NOT NULL`);
        await queryRunner.query(`ALTER TABLE "injuries" ALTER COLUMN "player_id" DROP NOT NULL`);
        await queryRunner.query(`ALTER TABLE "injuries" ADD CONSTRAINT "FK_a899be362ce73d0ba4b67fdea95" FOREIGN KEY ("reporter_id") REFERENCES "users"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "injuries" ADD CONSTRAINT "FK_d168998070d708fdf6062bb8f4d" FOREIGN KEY ("player_id") REFERENCES "users"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
        await queryRunner.query(`DROP TABLE "injury_other_symptoms"`);
        await queryRunner.query(`DROP TABLE "other_symptoms"`);
    }

}

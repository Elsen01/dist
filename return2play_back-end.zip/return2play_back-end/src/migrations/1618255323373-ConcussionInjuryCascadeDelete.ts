import {MigrationInterface, QueryRunner} from "typeorm";

export class ConcussionInjuryCascadeDelete1618255323373 implements MigrationInterface {
    name = 'ConcussionInjuryCascadeDelete1618255323373'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "injury_binary_symptoms" DROP CONSTRAINT "FK_8d0d8e28e6db0c9d814d67bfb17"`);
        await queryRunner.query(`ALTER TABLE "injury_red_flag_symptoms" DROP CONSTRAINT "FK_5df5fba66a9df1e8f02ea93a8a0"`);
        await queryRunner.query(`ALTER TABLE "injury_symptoms" DROP CONSTRAINT "FK_907e930cdba84eeee8bb8a20c9f"`);
        await queryRunner.query(`ALTER TABLE "injury_binary_symptoms" ADD CONSTRAINT "FK_8d0d8e28e6db0c9d814d67bfb17" FOREIGN KEY ("concussion_injury_id") REFERENCES "concussion_injuries"("id") ON DELETE CASCADE ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "injury_red_flag_symptoms" ADD CONSTRAINT "FK_5df5fba66a9df1e8f02ea93a8a0" FOREIGN KEY ("concussion_injury_id") REFERENCES "concussion_injuries"("id") ON DELETE CASCADE ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "injury_symptoms" ADD CONSTRAINT "FK_907e930cdba84eeee8bb8a20c9f" FOREIGN KEY ("concussion_injury_id") REFERENCES "concussion_injuries"("id") ON DELETE CASCADE ON UPDATE NO ACTION`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "injury_symptoms" DROP CONSTRAINT "FK_907e930cdba84eeee8bb8a20c9f"`);
        await queryRunner.query(`ALTER TABLE "injury_red_flag_symptoms" DROP CONSTRAINT "FK_5df5fba66a9df1e8f02ea93a8a0"`);
        await queryRunner.query(`ALTER TABLE "injury_binary_symptoms" DROP CONSTRAINT "FK_8d0d8e28e6db0c9d814d67bfb17"`);
        await queryRunner.query(`ALTER TABLE "injury_symptoms" ADD CONSTRAINT "FK_907e930cdba84eeee8bb8a20c9f" FOREIGN KEY ("concussion_injury_id") REFERENCES "concussion_injuries"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "injury_red_flag_symptoms" ADD CONSTRAINT "FK_5df5fba66a9df1e8f02ea93a8a0" FOREIGN KEY ("concussion_injury_id") REFERENCES "concussion_injuries"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "injury_binary_symptoms" ADD CONSTRAINT "FK_8d0d8e28e6db0c9d814d67bfb17" FOREIGN KEY ("concussion_injury_id") REFERENCES "concussion_injuries"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
    }

}

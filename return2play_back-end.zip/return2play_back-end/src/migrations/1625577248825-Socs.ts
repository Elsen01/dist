import {MigrationInterface, QueryRunner} from "typeorm";

export class Socs1625577248825 implements MigrationInterface {
    name = 'Socs1625577248825'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "organizations" ADD "is_socs" boolean NOT NULL DEFAULT false`);
        await queryRunner.query(`ALTER TABLE "players" ADD "socs_id" character varying(255)`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "players" DROP COLUMN "socs_id"`);
        await queryRunner.query(`ALTER TABLE "organizations" DROP COLUMN "is_socs"`);
    }

}

import { MigrationInterface, QueryRunner } from 'typeorm';

export class ISAMSFilters1687942723952 implements MigrationInterface {
  name = 'ISAMSFilters1687942723952';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TABLE "isams_filters_templates" ("id" SERIAL NOT NULL, "createdAt" TIMESTAMP NOT NULL DEFAULT now(), "updatedAt" TIMESTAMP NOT NULL DEFAULT now(), "value" text NOT NULL, "description" character varying, "default" boolean NOT NULL DEFAULT false, "createdById" character varying NOT NULL, CONSTRAINT "PK_2e7456444e1cbc7155f0f93faa9" PRIMARY KEY ("id"))`
    );
    await queryRunner.query(`ALTER TABLE "organizations" ADD "isams_filters" text`);
    await queryRunner.query(`ALTER TABLE "organizations" ADD "isamsFiltersTemplateId" integer`);
    await queryRunner.query(
      `CREATE INDEX "IDX_fccadbb97f4b476c21c523a02a" ON "organizations" ("isamsFiltersTemplateId") `
    );
    await queryRunner.query(
      `ALTER TABLE "isams_filters_templates" ADD CONSTRAINT "FK_3078a20f327fc231f6bf1e0a507" FOREIGN KEY ("createdById") REFERENCES "users"("id") ON DELETE SET NULL ON UPDATE NO ACTION`
    );
    await queryRunner.query(
      `ALTER TABLE "organizations" ADD CONSTRAINT "FK_fccadbb97f4b476c21c523a02aa" FOREIGN KEY ("isamsFiltersTemplateId") REFERENCES "isams_filters_templates"("id") ON DELETE SET NULL ON UPDATE NO ACTION`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "organizations" DROP CONSTRAINT "FK_fccadbb97f4b476c21c523a02aa"`);
    await queryRunner.query(`ALTER TABLE "isams_filters_templates" DROP CONSTRAINT "FK_3078a20f327fc231f6bf1e0a507"`);
    await queryRunner.query(`DROP INDEX "IDX_fccadbb97f4b476c21c523a02a"`);
    await queryRunner.query(`ALTER TABLE "organizations" DROP COLUMN "isamsFiltersTemplateId"`);
    await queryRunner.query(`ALTER TABLE "organizations" DROP COLUMN "isams_filters"`);
    await queryRunner.query(`DROP TABLE "isams_filters_templates"`);
  }
}

import {MigrationInterface, QueryRunner} from "typeorm";

export class DeleteConcussionInjury1618484220232 implements MigrationInterface {
    name = 'DeleteConcussionInjury1618484220232'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "injury_binary_symptoms" DROP CONSTRAINT "FK_8d0d8e28e6db0c9d814d67bfb17"`);
        await queryRunner.query(`ALTER TABLE "injury_red_flag_symptoms" DROP CONSTRAINT "FK_5df5fba66a9df1e8f02ea93a8a0"`);
        await queryRunner.query(`ALTER TABLE "injury_symptoms" DROP CONSTRAINT "FK_907e930cdba84eeee8bb8a20c9f"`);
        await queryRunner.query(`ALTER TABLE "injury_binary_symptoms" RENAME COLUMN "concussion_injury_id" TO "injury_id"`);
        await queryRunner.query(`ALTER TABLE "injury_binary_symptoms" RENAME CONSTRAINT "PK_dd1a92683ad32826ab5565a2d9c" TO "PK_417c25cc9963026f4cef6aac6af"`);
        await queryRunner.query(`ALTER TABLE "injury_red_flag_symptoms" RENAME COLUMN "concussion_injury_id" TO "injury_id"`);
        await queryRunner.query(`ALTER TABLE "injury_red_flag_symptoms" RENAME CONSTRAINT "PK_71684f9e9a4d497744bff561dfe" TO "PK_26e1c429a50c1ad1fb4c5d89932"`);
        await queryRunner.query(`ALTER TABLE "injury_symptoms" RENAME COLUMN "concussion_injury_id" TO "injury_id"`);
        await queryRunner.query(`ALTER TABLE "injury_symptoms" RENAME CONSTRAINT "PK_5ae0526de66c16bc0b9fce6d19b" TO "PK_7f77f855bc4313dbd6e06832cf3"`);
        await queryRunner.query(`ALTER TABLE "injury_binary_symptoms" ADD CONSTRAINT "FK_702898f02b328c5c459e871d6bd" FOREIGN KEY ("injury_id") REFERENCES "injuries"("id") ON DELETE CASCADE ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "injury_red_flag_symptoms" ADD CONSTRAINT "FK_80ea8116d85c424f8fd9f2a6525" FOREIGN KEY ("injury_id") REFERENCES "injuries"("id") ON DELETE CASCADE ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "injury_symptoms" ADD CONSTRAINT "FK_ca44c02ad0647a3b369d29b5e64" FOREIGN KEY ("injury_id") REFERENCES "injuries"("id") ON DELETE CASCADE ON UPDATE NO ACTION`);
        await queryRunner.query(`DROP TABLE concussion_injuries`)
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`CREATE TABLE "concussion_injuries" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "injury_id" uuid, CONSTRAINT "REL_d86694cfcea4b2869d53dd7ea9" UNIQUE ("injury_id"), CONSTRAINT "PK_991ae73dc21c2778ca20b97f43e" PRIMARY KEY ("id"))`);
        await queryRunner.query(`ALTER TABLE "injury_symptoms" DROP CONSTRAINT "FK_ca44c02ad0647a3b369d29b5e64"`);
        await queryRunner.query(`ALTER TABLE "injury_red_flag_symptoms" DROP CONSTRAINT "FK_80ea8116d85c424f8fd9f2a6525"`);
        await queryRunner.query(`ALTER TABLE "injury_binary_symptoms" DROP CONSTRAINT "FK_702898f02b328c5c459e871d6bd"`);
        await queryRunner.query(`ALTER TABLE "injury_symptoms" RENAME CONSTRAINT "PK_7f77f855bc4313dbd6e06832cf3" TO "PK_5ae0526de66c16bc0b9fce6d19b"`);
        await queryRunner.query(`ALTER TABLE "injury_symptoms" RENAME COLUMN "injury_id" TO "concussion_injury_id"`);
        await queryRunner.query(`ALTER TABLE "injury_red_flag_symptoms" RENAME CONSTRAINT "PK_26e1c429a50c1ad1fb4c5d89932" TO "PK_71684f9e9a4d497744bff561dfe"`);
        await queryRunner.query(`ALTER TABLE "injury_red_flag_symptoms" RENAME COLUMN "injury_id" TO "concussion_injury_id"`);
        await queryRunner.query(`ALTER TABLE "injury_binary_symptoms" RENAME CONSTRAINT "PK_417c25cc9963026f4cef6aac6af" TO "PK_dd1a92683ad32826ab5565a2d9c"`);
        await queryRunner.query(`ALTER TABLE "injury_binary_symptoms" RENAME COLUMN "injury_id" TO "concussion_injury_id"`);
        await queryRunner.query(`ALTER TABLE "injury_symptoms" ADD CONSTRAINT "FK_907e930cdba84eeee8bb8a20c9f" FOREIGN KEY ("concussion_injury_id") REFERENCES "concussion_injuries"("id") ON DELETE CASCADE ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "injury_red_flag_symptoms" ADD CONSTRAINT "FK_5df5fba66a9df1e8f02ea93a8a0" FOREIGN KEY ("concussion_injury_id") REFERENCES "concussion_injuries"("id") ON DELETE CASCADE ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "injury_binary_symptoms" ADD CONSTRAINT "FK_8d0d8e28e6db0c9d814d67bfb17" FOREIGN KEY ("concussion_injury_id") REFERENCES "concussion_injuries"("id") ON DELETE CASCADE ON UPDATE NO ACTION`);
    }

}

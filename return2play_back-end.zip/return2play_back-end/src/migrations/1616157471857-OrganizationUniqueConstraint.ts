import { MigrationInterface, QueryRunner } from 'typeorm';

export class OrganizationUniqueConstraint1616157471857 implements MigrationInterface {
  name = 'OrganizationUniqueConstraint1616157471857';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`COMMENT ON COLUMN "organizations"."name" IS NULL`);
    await queryRunner.query(
      `ALTER TABLE "organizations" ADD CONSTRAINT "UQ_9b7ca6d30b94fef571cff876884" UNIQUE ("name")`
    );
    await queryRunner.query(`COMMENT ON COLUMN "organizations"."email" IS NULL`);
    await queryRunner.query(
      `ALTER TABLE "organizations" ADD CONSTRAINT "UQ_4ad920935f4d4eb73fc58b40f72" UNIQUE ("email")`
    );
    await queryRunner.query(`COMMENT ON COLUMN "organizations"."phone" IS NULL`);
    await queryRunner.query(
      `ALTER TABLE "organizations" ADD CONSTRAINT "UQ_9ca925d77299102a8bc433676f7" UNIQUE ("phone")`
    );
    await queryRunner.query(`COMMENT ON COLUMN "organizations"."website" IS NULL`);
    await queryRunner.query(
      `ALTER TABLE "organizations" ADD CONSTRAINT "UQ_7a216df910f26a061d6f89415d9" UNIQUE ("website")`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "organizations" DROP CONSTRAINT "UQ_7a216df910f26a061d6f89415d9"`);
    await queryRunner.query(`COMMENT ON COLUMN "organizations"."website" IS NULL`);
    await queryRunner.query(`ALTER TABLE "organizations" DROP CONSTRAINT "UQ_9ca925d77299102a8bc433676f7"`);
    await queryRunner.query(`COMMENT ON COLUMN "organizations"."phone" IS NULL`);
    await queryRunner.query(`ALTER TABLE "organizations" DROP CONSTRAINT "UQ_4ad920935f4d4eb73fc58b40f72"`);
    await queryRunner.query(`COMMENT ON COLUMN "organizations"."email" IS NULL`);
    await queryRunner.query(`ALTER TABLE "organizations" DROP CONSTRAINT "UQ_9b7ca6d30b94fef571cff876884"`);
    await queryRunner.query(`COMMENT ON COLUMN "organizations"."name" IS NULL`);
  }
}

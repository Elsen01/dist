import {MigrationInterface, QueryRunner} from "typeorm";

export class SeedBodyPartBodyRegion1618317840586 implements MigrationInterface {

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            INSERT INTO
                body_regions ("name")
            VALUES 
                ('Head/Neck'),
                ('Upper limb'),
                ('Chest/Abdomen'),
                ('Back'),
                ('Lower limb');
        `)

        await queryRunner.query(`
            INSERT INTO
                body_parts ("name", body_region_id)
            SELECT 'Scalp', br.id
            FROM body_regions br
            WHERE br.name = 'Head/Neck';

            INSERT INTO
                body_parts ("name", body_region_id)
            SELECT 'Face', br.id
            FROM body_regions br
            WHERE br.name = 'Head/Neck';

            INSERT INTO
                body_parts ("name", body_region_id)
            SELECT 'Eye', br.id
            FROM body_regions br
            WHERE br.name = 'Head/Neck';

            INSERT INTO
                body_parts ("name", body_region_id)
            SELECT 'Ear', br.id
            FROM body_regions br
            WHERE br.name = 'Head/Neck';

            INSERT INTO
                body_parts ("name", body_region_id)
            SELECT 'Nose', br.id
            FROM body_regions br
            WHERE br.name = 'Head/Neck';

            INSERT INTO
                body_parts ("name", body_region_id)
            SELECT 'Mouth', br.id
            FROM body_regions br
            WHERE br.name = 'Head/Neck';

            INSERT INTO
                body_parts ("name", body_region_id)
            SELECT 'Teeth', br.id
            FROM body_regions br
            WHERE br.name = 'Head/Neck';

            INSERT INTO
                body_parts ("name", body_region_id)
            SELECT 'Jaw', br.id
            FROM body_regions br
            WHERE br.name = 'Head/Neck';

            INSERT INTO
                body_parts ("name", body_region_id)
            SELECT 'Neck', br.id
            FROM body_regions br
            WHERE br.name = 'Head/Neck';
        `)

        await queryRunner.query(`
            INSERT INTO
                body_parts ("name", body_region_id)
            SELECT 'Collar Bone/Clavicle', br.id
            FROM body_regions br
            WHERE br.name = 'Upper limb';

            INSERT INTO
                body_parts ("name", body_region_id)
            SELECT 'Shoulder', br.id
            FROM body_regions br
            WHERE br.name = 'Upper limb';

            INSERT INTO
                body_parts ("name", body_region_id)
            SELECT 'Upper Arm', br.id
            FROM body_regions br
            WHERE br.name = 'Upper limb';

            INSERT INTO
                body_parts ("name", body_region_id)
            SELECT 'Elbow', br.id
            FROM body_regions br
            WHERE br.name = 'Upper limb';

            INSERT INTO
                body_parts ("name", body_region_id)
            SELECT 'Forearm', br.id
            FROM body_regions br
            WHERE br.name = 'Upper limb';

            INSERT INTO
                body_parts ("name", body_region_id)
            SELECT 'Wrist', br.id
            FROM body_regions br
            WHERE br.name = 'Upper limb';

            INSERT INTO
                body_parts ("name", body_region_id)
            SELECT 'Hand', br.id
            FROM body_regions br
            WHERE br.name = 'Upper limb';

            INSERT INTO
                body_parts ("name", body_region_id)
            SELECT 'Fingers/Thumb', br.id
            FROM body_regions br
            WHERE br.name = 'Upper limb';
        `)

        await queryRunner.query(`
            INSERT INTO
                body_parts ("name", body_region_id)
            SELECT 'Chest', br.id
            FROM body_regions br
            WHERE br.name = 'Chest/Abdomen';

            INSERT INTO
                body_parts ("name", body_region_id)
            SELECT 'Ribs', br.id
            FROM body_regions br
            WHERE br.name = 'Chest/Abdomen';

            INSERT INTO
                body_parts ("name", body_region_id)
            SELECT 'Abdomen', br.id
            FROM body_regions br
            WHERE br.name = 'Chest/Abdomen';

            INSERT INTO
                body_parts ("name", body_region_id)
            SELECT 'Flanks', br.id
            FROM body_regions br
            WHERE br.name = 'Chest/Abdomen';

            INSERT INTO
                body_parts ("name", body_region_id)
            SELECT 'Genitalia', br.id
            FROM body_regions br
            WHERE br.name = 'Chest/Abdomen';
        `)

        await queryRunner.query(`
            INSERT INTO
                body_parts ("name", body_region_id)
            SELECT 'Upper back', br.id
            FROM body_regions br
            WHERE br.name = 'Back';

            INSERT INTO
                body_parts ("name", body_region_id)
            SELECT 'Lower back', br.id
            FROM body_regions br
            WHERE br.name = 'Back';

            INSERT INTO
                body_parts ("name", body_region_id)
            SELECT 'Flanks', br.id
            FROM body_regions br
            WHERE br.name = 'Back';
        `)

        await queryRunner.query(`
            INSERT INTO
                body_parts ("name", body_region_id)
            SELECT 'Hip', br.id
            FROM body_regions br
            WHERE br.name = 'Lower limb';

            INSERT INTO
                body_parts ("name", body_region_id)
            SELECT 'Groin', br.id
            FROM body_regions br
            WHERE br.name = 'Lower limb';

            INSERT INTO
                body_parts ("name", body_region_id)
            SELECT 'Buttock', br.id
            FROM body_regions br
            WHERE br.name = 'Lower limb';

            INSERT INTO
                body_parts ("name", body_region_id)
            SELECT 'Upper Leg/Thigh', br.id
            FROM body_regions br
            WHERE br.name = 'Lower limb';

            INSERT INTO
                body_parts ("name", body_region_id)
            SELECT 'Knee', br.id
            FROM body_regions br
            WHERE br.name = 'Lower limb';

            INSERT INTO
                body_parts ("name", body_region_id)
            SELECT 'Lower Leg', br.id
            FROM body_regions br
            WHERE br.name = 'Lower limb';

            INSERT INTO
                body_parts ("name", body_region_id)
            SELECT 'Ankle', br.id
            FROM body_regions br
            WHERE br.name = 'Lower limb';

            INSERT INTO
                body_parts ("name", body_region_id)
            SELECT 'Foot', br.id
            FROM body_regions br
            WHERE br.name = 'Lower limb';

            INSERT INTO
                body_parts ("name", body_region_id)
            SELECT 'Toes', br.id
            FROM body_regions br
            WHERE br.name = 'Lower limb';
        `)
        
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`DELETE FROM body_regions`);
        await queryRunner.query(`DELETE FROM body_parts`);
    }

}

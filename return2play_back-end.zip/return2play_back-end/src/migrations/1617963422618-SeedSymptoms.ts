import {MigrationInterface, QueryRunner} from "typeorm";

export class SeedSymptoms1617963422618 implements MigrationInterface {

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            INSERT INTO red_flag_symptoms
                (name) 
            VALUES 
                ('Can''t recognize people or places'),
                ('Deteriorating consciousness'),
                ('Increasing confusion or irritability'),
                ('Looks very drowsy'),
                ('Repeated vomiting'),
                ('Seizures'),
                ('Severe Neck Pain'),
                ('Slurred speech'),
                ('Unusual behavior'),
                ('Weakness or numbness in limbs'),
                ('Worsening Headache');`
        );

        await queryRunner.query(`
            INSERT INTO binary_symptoms
                (name) 
            VALUES 
                ('Appears dazed or stunned'),
                ('Is confused about events'),
                ('Repeats questions'),
                ('Answers questions slowly'),
                ('Can''t recall events prior to the injury'),
                ('Can''t recall events after the injury'),
                ('Loses consciousness'),
                ('Shows behavior or personality changes'),
                ('Forgets class schedule or assignments'),
                ('Headache of “pressure” in head'),
                ('Nausea or vomiting'),
                ('Balance problems or dizziness'),
                ('Fatigue'),
                ('Blurry or double vision'),
                ('Sensitivity to light'),
                ('Sensitivity to noise'),
                ('Numbness or tingling'),
                ('Does not “feel right”'),
                ('Difficulty thinking clearly'),
                ('Difficulty concentrating'),
                ('Difficulty remembering'),
                ('Feeling more slowed down than usual'),
                ('Feeling sluggish, hazy, foggy or groggy'),
                ('Irritable'),
                ('Sad'),
                ('More emotional than usual'),
                ('Nervous'),
                ('Do symptoms get worse with physical activity?'),
                ('Do symptoms get worse with mental activity?');`
        );

        await queryRunner.query(`
        INSERT INTO symptoms
            (name) 
        VALUES 
            ('Headache'),
            ('Pressure in head'),
            ('Neck Pain'),
            ('Nausea or vomiting'),
            ('Dizziness'),
            ('Blurred Vision'),
            ('Balance problems'),
            ('Sensitivity to light'),
            ('Sensitivity to noise'),
            ('Feeling slowed down'),
            ('Feeling like "in a fog"'),
            ('Don''t feel right'),
            ('Difficulty concentrating'),
            ('Difficulty remembering'),
            ('Fatigue or low energy'),
            ('Confusion'),
            ('Drowsiness'),
            ('More emotional'),
            ('Irritability'),
            ('Sadness'),
            ('Nervous or Anxious'),
            ('Trouble falling asleep (if applicable)');`
        );
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`DELETE FROM red_flag_symptoms`);
        await queryRunner.query(`DELETE FROM binary_symptoms`);
        await queryRunner.query(`DELETE FROM symptoms`);
    }
}

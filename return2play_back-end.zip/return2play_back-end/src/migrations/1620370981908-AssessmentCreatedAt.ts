import {MigrationInterface, QueryRunner} from "typeorm";

export class AssessmentCreatedAt1620370981908 implements MigrationInterface {
    name = 'AssessmentCreatedAt1620370981908'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "assessments" ADD "created_at" TIMESTAMP NOT NULL DEFAULT now()`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "assessments" DROP COLUMN "created_at"`);
    }

}

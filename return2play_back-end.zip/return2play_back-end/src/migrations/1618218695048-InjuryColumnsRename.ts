import {MigrationInterface, QueryRunner} from "typeorm";

export class InjuryColumnsRename1618218695048 implements MigrationInterface {
    name = 'InjuryColumnsRename1618218695048'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "sport_injuries" RENAME COLUMN "injured_at" TO "match_training"`);
        await queryRunner.query(`ALTER TYPE "public"."sport_injuries_injured_at_enum" RENAME TO "sport_injuries_match_training_enum"`);
        await queryRunner.query(`CREATE TYPE "injuries_injured_at_enum" AS ENUM('Home', 'School - Astro', 'School - Classroom', 'School - Corridor', ' School - Fields', ' School - Playground', ' School - Woods', 'Club', 'Other')`);
        await queryRunner.query(`ALTER TABLE "injuries" ADD "injured_at" "injuries_injured_at_enum"`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "injuries" DROP COLUMN "injured_at"`);
        await queryRunner.query(`DROP TYPE "injuries_injured_at_enum"`);
        await queryRunner.query(`ALTER TYPE "sport_injuries_match_training_enum" RENAME TO "sport_injuries_injured_at_enum"`);
        await queryRunner.query(`ALTER TABLE "sport_injuries" RENAME COLUMN "match_training" TO "injured_at"`);
    }

}

import { MigrationInterface, QueryRunner } from 'typeorm';

export class addMyIPs1713351689829 implements MigrationInterface {
  name = 'addMyIPs1713351689829';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TABLE "my_ips" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "createdAt" TIMESTAMP NOT NULL DEFAULT now(), "updatedAt" TIMESTAMP NOT NULL DEFAULT now(), "address" character varying NOT NULL, "lastActiveAt" TIMESTAMP, CONSTRAINT "UQ_6d842db5069b50a670fe800c381" UNIQUE ("address"), CONSTRAINT "PK_c54dfaeaf4c9dde57dfe6c440b5" PRIMARY KEY ("id"))`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP TABLE "my_ips"`);
  }
}

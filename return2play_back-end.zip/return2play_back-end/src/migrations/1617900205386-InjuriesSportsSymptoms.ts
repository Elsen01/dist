import {MigrationInterface, QueryRunner} from "typeorm";

export class InjuriesSportsSymptoms1617900205386 implements MigrationInterface {
    name = 'InjuriesSportsSymptoms1617900205386'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`CREATE TABLE "sports" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "name" character varying(255) NOT NULL, CONSTRAINT "PK_4fa1063d368e1fd68ea63c7d860" PRIMARY KEY ("id"))`);
        await queryRunner.query(`CREATE TABLE "injury_mechanisms" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "name" character varying(255) NOT NULL, CONSTRAINT "PK_1d62b0c7f4399c7e0526a039b36" PRIMARY KEY ("id"))`);
        await queryRunner.query(`CREATE TABLE "concussion_injuries" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "injury_id" uuid, CONSTRAINT "REL_d86694cfcea4b2869d53dd7ea9" UNIQUE ("injury_id"), CONSTRAINT "PK_991ae73dc21c2778ca20b97f43e" PRIMARY KEY ("id"))`);
        await queryRunner.query(`CREATE TABLE "binary_symptoms" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "name" character varying(255) NOT NULL, CONSTRAINT "PK_90ae808687d68d1b79d8f34321f" PRIMARY KEY ("id"))`);
        await queryRunner.query(`CREATE TABLE "injury_binary_symptoms" ("concussion_injury_id" uuid NOT NULL, "binary_symptom_id" uuid NOT NULL, "isPresent" boolean NOT NULL, CONSTRAINT "PK_dd1a92683ad32826ab5565a2d9c" PRIMARY KEY ("concussion_injury_id", "binary_symptom_id"))`);
        await queryRunner.query(`CREATE TABLE "red_flag_symptoms" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "name" character varying(255) NOT NULL, CONSTRAINT "PK_ebf7644d2f036ac63d5e935b1e1" PRIMARY KEY ("id"))`);
        await queryRunner.query(`CREATE TABLE "injury_red_flag_symptoms" ("concussion_injury_id" uuid NOT NULL, "red_flag_symptom_id" uuid NOT NULL, "isPresent" boolean NOT NULL, CONSTRAINT "PK_71684f9e9a4d497744bff561dfe" PRIMARY KEY ("concussion_injury_id", "red_flag_symptom_id"))`);
        await queryRunner.query(`CREATE TABLE "symptoms" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "name" character varying(255) NOT NULL, CONSTRAINT "PK_7041f6c8f7afb75b9286c275a81" PRIMARY KEY ("id"))`);
        await queryRunner.query(`CREATE TYPE "injury_symptoms_value_enum" AS ENUM('0', '1', '2', '3', '4', '5', '6')`);
        await queryRunner.query(`CREATE TABLE "injury_symptoms" ("concussion_injury_id" uuid NOT NULL, "symptom_id" uuid NOT NULL, "value" "injury_symptoms_value_enum" NOT NULL, CONSTRAINT "PK_5ae0526de66c16bc0b9fce6d19b" PRIMARY KEY ("concussion_injury_id", "symptom_id"))`);
        await queryRunner.query(`CREATE TABLE "sport_mechanisms" ("mechanism_id" uuid NOT NULL, "sport_id" uuid NOT NULL, CONSTRAINT "PK_7e1348c556f31dac14a4e960ea5" PRIMARY KEY ("mechanism_id", "sport_id"))`);
        await queryRunner.query(`CREATE INDEX "IDX_a294069b6cfd466325e6080c44" ON "sport_mechanisms" ("mechanism_id") `);
        await queryRunner.query(`CREATE INDEX "IDX_ec66b3174bbbb17d83a99ef0ed" ON "sport_mechanisms" ("sport_id") `);
        await queryRunner.query(`ALTER TABLE "sport_injuries" ADD "sport_id" uuid`);
        await queryRunner.query(`ALTER TABLE "sport_injuries" ADD "mechanism_id" uuid`);
        await queryRunner.query(`ALTER TYPE "public"."sport_injuries_injured_at_enum" RENAME TO "sport_injuries_injured_at_enum_old"`);
        await queryRunner.query(`CREATE TYPE "sport_injuries_injured_at_enum" AS ENUM('Match', 'Training')`);
        await queryRunner.query(`ALTER TABLE "sport_injuries" ALTER COLUMN "injured_at" TYPE "sport_injuries_injured_at_enum" USING "injured_at"::"text"::"sport_injuries_injured_at_enum"`);
        await queryRunner.query(`DROP TYPE "sport_injuries_injured_at_enum_old"`);
        await queryRunner.query(`COMMENT ON COLUMN "sport_injuries"."injured_at" IS NULL`);
        await queryRunner.query(`ALTER TABLE "sport_injuries" ADD CONSTRAINT "FK_1febf8e84be6a17a0bfe5db4d8a" FOREIGN KEY ("sport_id") REFERENCES "sports"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "sport_injuries" ADD CONSTRAINT "FK_3b2bafcc20315ef1c0491ec1336" FOREIGN KEY ("mechanism_id") REFERENCES "injury_mechanisms"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "concussion_injuries" ADD CONSTRAINT "FK_d86694cfcea4b2869d53dd7ea91" FOREIGN KEY ("injury_id") REFERENCES "injuries"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "injury_binary_symptoms" ADD CONSTRAINT "FK_8d0d8e28e6db0c9d814d67bfb17" FOREIGN KEY ("concussion_injury_id") REFERENCES "concussion_injuries"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "injury_binary_symptoms" ADD CONSTRAINT "FK_c876e5840abcbf7c2429c488929" FOREIGN KEY ("binary_symptom_id") REFERENCES "binary_symptoms"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "injury_red_flag_symptoms" ADD CONSTRAINT "FK_5df5fba66a9df1e8f02ea93a8a0" FOREIGN KEY ("concussion_injury_id") REFERENCES "concussion_injuries"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "injury_red_flag_symptoms" ADD CONSTRAINT "FK_9a9d8838b5f92cf8a553ac7df50" FOREIGN KEY ("red_flag_symptom_id") REFERENCES "red_flag_symptoms"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "injury_symptoms" ADD CONSTRAINT "FK_907e930cdba84eeee8bb8a20c9f" FOREIGN KEY ("concussion_injury_id") REFERENCES "concussion_injuries"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "injury_symptoms" ADD CONSTRAINT "FK_dc355e152cd37e6d7d4549f6dfe" FOREIGN KEY ("symptom_id") REFERENCES "symptoms"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "sport_mechanisms" ADD CONSTRAINT "FK_a294069b6cfd466325e6080c44d" FOREIGN KEY ("mechanism_id") REFERENCES "injury_mechanisms"("id") ON DELETE CASCADE ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "sport_mechanisms" ADD CONSTRAINT "FK_ec66b3174bbbb17d83a99ef0ed6" FOREIGN KEY ("sport_id") REFERENCES "sports"("id") ON DELETE CASCADE ON UPDATE NO ACTION`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "sport_mechanisms" DROP CONSTRAINT "FK_ec66b3174bbbb17d83a99ef0ed6"`);
        await queryRunner.query(`ALTER TABLE "sport_mechanisms" DROP CONSTRAINT "FK_a294069b6cfd466325e6080c44d"`);
        await queryRunner.query(`ALTER TABLE "injury_symptoms" DROP CONSTRAINT "FK_dc355e152cd37e6d7d4549f6dfe"`);
        await queryRunner.query(`ALTER TABLE "injury_symptoms" DROP CONSTRAINT "FK_907e930cdba84eeee8bb8a20c9f"`);
        await queryRunner.query(`ALTER TABLE "injury_red_flag_symptoms" DROP CONSTRAINT "FK_9a9d8838b5f92cf8a553ac7df50"`);
        await queryRunner.query(`ALTER TABLE "injury_red_flag_symptoms" DROP CONSTRAINT "FK_5df5fba66a9df1e8f02ea93a8a0"`);
        await queryRunner.query(`ALTER TABLE "injury_binary_symptoms" DROP CONSTRAINT "FK_c876e5840abcbf7c2429c488929"`);
        await queryRunner.query(`ALTER TABLE "injury_binary_symptoms" DROP CONSTRAINT "FK_8d0d8e28e6db0c9d814d67bfb17"`);
        await queryRunner.query(`ALTER TABLE "concussion_injuries" DROP CONSTRAINT "FK_d86694cfcea4b2869d53dd7ea91"`);
        await queryRunner.query(`ALTER TABLE "sport_injuries" DROP CONSTRAINT "FK_3b2bafcc20315ef1c0491ec1336"`);
        await queryRunner.query(`ALTER TABLE "sport_injuries" DROP CONSTRAINT "FK_1febf8e84be6a17a0bfe5db4d8a"`);
        await queryRunner.query(`COMMENT ON COLUMN "sport_injuries"."injured_at" IS NULL`);
        await queryRunner.query(`CREATE TYPE "sport_injuries_injured_at_enum_old" AS ENUM('Match', 'Training', 'Recreation')`);
        await queryRunner.query(`ALTER TABLE "sport_injuries" ALTER COLUMN "injured_at" TYPE "sport_injuries_injured_at_enum_old" USING "injured_at"::"text"::"sport_injuries_injured_at_enum_old"`);
        await queryRunner.query(`DROP TYPE "sport_injuries_injured_at_enum"`);
        await queryRunner.query(`ALTER TYPE "sport_injuries_injured_at_enum_old" RENAME TO  "sport_injuries_injured_at_enum"`);
        await queryRunner.query(`ALTER TABLE "sport_injuries" DROP COLUMN "mechanism_id"`);
        await queryRunner.query(`ALTER TABLE "sport_injuries" DROP COLUMN "sport_id"`);
        await queryRunner.query(`DROP INDEX "IDX_ec66b3174bbbb17d83a99ef0ed"`);
        await queryRunner.query(`DROP INDEX "IDX_a294069b6cfd466325e6080c44"`);
        await queryRunner.query(`DROP TABLE "sport_mechanisms"`);
        await queryRunner.query(`DROP TABLE "injury_symptoms"`);
        await queryRunner.query(`DROP TYPE "injury_symptoms_value_enum"`);
        await queryRunner.query(`DROP TABLE "symptoms"`);
        await queryRunner.query(`DROP TABLE "injury_red_flag_symptoms"`);
        await queryRunner.query(`DROP TABLE "red_flag_symptoms"`);
        await queryRunner.query(`DROP TABLE "injury_binary_symptoms"`);
        await queryRunner.query(`DROP TABLE "binary_symptoms"`);
        await queryRunner.query(`DROP TABLE "concussion_injuries"`);
        await queryRunner.query(`DROP TABLE "injury_mechanisms"`);
        await queryRunner.query(`DROP TABLE "sports"`);
    }

}

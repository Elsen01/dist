import {MigrationInterface, QueryRunner} from "typeorm";

export class SeedSymptomsType1619452215233 implements MigrationInterface {

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            UPDATE binary_symptoms
            SET type = 'Additional Symptoms'
            WHERE name = 'Do symptoms get worse with physical activity?' OR name = 'Do symptoms get worse with mental activity?';
        `);

        await queryRunner.query(`
            UPDATE other_symptoms
            SET type = 'Additional Symptoms'
            WHERE name = 'How different are you acting compared to your usual self?';
        `);

        await queryRunner.query(`
            UPDATE binary_symptoms
            SET type = 'Observed signs'
            WHERE name = 'Appears dazed or stunned' 
                OR name = 'Is confused about events'
                OR name = 'Repeats questions'
                OR name = 'Answers questions slowly'
                OR name = 'Can''t recall events prior to the injury'
                OR name = 'Can''t recall events after the injury'
                OR name = 'Loses consciousness'
                OR name = 'Shows behavior or personality changes'
                OR name = 'Forgets class schedule or assignments';
        `);

        await queryRunner.query(`
            UPDATE binary_symptoms
            SET type = 'Physical symptoms'
            WHERE name = 'Headache of “pressure” in head' 
                OR name = 'Nausea or vomiting'
                OR name = 'Balance problems or dizziness'
                OR name = 'Fatigue'
                OR name = 'Blurry or double vision'
                OR name = 'Sensitivity to light'
                OR name = 'Sensitivity to noise'
                OR name = 'Numbness or tingling'
                OR name = 'Does not “feel right”';
        `);

        await queryRunner.query(`
            UPDATE binary_symptoms
            SET type = 'Cognitive symptoms'
            WHERE name = 'Difficulty thinking clearly' 
                OR name = 'Difficulty concentrating'
                OR name = 'Difficulty remembering'
                OR name = 'Feeling more slowed down than usual'
                OR name = 'Feeling sluggish, hazy, foggy or groggy';
        `);

        await queryRunner.query(`
            UPDATE binary_symptoms
            SET type = 'Emotional symptoms'
            WHERE name = 'Irritable' 
                OR name = 'Sad'
                OR name = 'Nervous'
                OR name = 'More emotional than usual';
        `);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            UPDATE binary_symptoms
            SET type = NULL
            WHERE name = 'Do symptoms get worse with physical activity?' OR name = 'Do symptoms get worse with mental activity?';
        `);

        await queryRunner.query(`
            UPDATE other_symptoms
            SET type = NULL
            WHERE name = 'How different are you acting compared to your usual self?';
        `);

        await queryRunner.query(`
            UPDATE binary_symptoms
            SET type = NULL
            WHERE name = 'Appears dazed or stunned' 
                OR name = 'Is confused about events'
                OR name = 'Repeats questions'
                OR name = 'Answers questions slowly'
                OR name = 'Can''t recall events prior to the injury'
                OR name = 'Can''t recall events after the injury'
                OR name = 'Loses consciousness'
                OR name = 'Shows behavior or personality changes'
                OR name = 'Forgets class schedule or assignments';
        `);

        await queryRunner.query(`
            UPDATE binary_symptoms
            SET type = NULL
            WHERE name = 'Headache of “pressure” in head' 
                OR name = 'Nausea or vomiting'
                OR name = 'Balance problems or dizziness'
                OR name = 'Fatigue'
                OR name = 'Blurry or double vision'
                OR name = 'Sensitivity to light'
                OR name = 'Sensitivity to noise'
                OR name = 'Numbness or tingling'
                OR name = 'Does not “feel right”';
        `);

        await queryRunner.query(`
            UPDATE binary_symptoms
            SET type = NULL
            WHERE name = 'Difficulty thinking clearly' 
                OR name = 'Difficulty concentrating'
                OR name = 'Difficulty remembering'
                OR name = 'Feeling more slowed down than usual'
                OR name = 'Feeling sluggish, hazy, foggy or groggy';
        `);

        await queryRunner.query(`
            UPDATE binary_symptoms
            SET type = NULL
            WHERE name = 'Irritable' 
                OR name = 'Sad'
                OR name = 'Nervous'
                OR name = 'More emotional than usual';
        `);
    }

}

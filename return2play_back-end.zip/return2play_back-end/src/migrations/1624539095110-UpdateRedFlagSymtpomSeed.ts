import {MigrationInterface, QueryRunner} from "typeorm";

export class UpdateRedFlagSymtpomSeed1624539095110 implements MigrationInterface {
    name = 'UpdateRedFlagSymtpomSeed1624539095110'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`UPDATE "red_flag_symptoms" 
        SET "name" = 'Can''t recognise people or places' 
        WHERE "name" = 'Can''t recognize people or places'`);
        await queryRunner.query(`UPDATE "red_flag_symptoms" 
        SET "name" = 'Unusual behaviour' 
        WHERE "name" = 'Unusual behavior'`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`UPDATE "red_flag_symptoms" 
        SET "name" = 'Unusual behavior' 
        WHERE "name" = 'Unusual behaviour'`);
        await queryRunner.query(`UPDATE "red_flag_symptoms" 
        SET "name" = 'Can''t recognize people or places' 
        WHERE "name" = 'Can''t recognise people or places'`);
    }

}

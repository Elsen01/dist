import {MigrationInterface, QueryRunner} from "typeorm";

export class ClinicScheduleAllOrganization1628691946554 implements MigrationInterface {
    name = 'ClinicScheduleAllOrganization1628691946554'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "doctor_clinic_schedule" ADD "all_organizations" boolean`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "doctor_clinic_schedule" DROP COLUMN "all_organizations"`);
    }

}

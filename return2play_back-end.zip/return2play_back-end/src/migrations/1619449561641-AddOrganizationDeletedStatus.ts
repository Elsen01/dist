import {MigrationInterface, QueryRunner} from "typeorm";

export class AddOrganizationDeletedStatus1619449561641 implements MigrationInterface {
    name = 'AddOrganizationDeletedStatus1619449561641'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TYPE "organizations_status_enum" RENAME TO "organizations_status_enum_old"`);
        await queryRunner.query(`CREATE TYPE "organizations_status_enum" AS ENUM('Active', 'Inactive', 'Deleted')`);
        await queryRunner.query(`ALTER TABLE "organizations" ALTER COLUMN "status" DROP DEFAULT`);
        await queryRunner.query(`ALTER TABLE "organizations" ALTER COLUMN "status" TYPE "organizations_status_enum" USING "status"::"text"::"organizations_status_enum"`);
        await queryRunner.query(`ALTER TABLE "organizations" ALTER COLUMN "status" SET DEFAULT 'Active'`);
        await queryRunner.query(`DROP TYPE "organizations_status_enum_old"`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`CREATE TYPE "organizations_status_enum_old" AS ENUM('Active', 'Inactive')`);
        await queryRunner.query(`ALTER TABLE "organizations" ALTER COLUMN "status" DROP DEFAULT`);
        await queryRunner.query(`ALTER TABLE "organizations" ALTER COLUMN "status" TYPE "organizations_status_enum_old" USING "status"::"text"::"organizations_status_enum_old"`);
        await queryRunner.query(`ALTER TABLE "organizations" ALTER COLUMN "status" SET DEFAULT 'Active'`);
        await queryRunner.query(`DROP TYPE "organizations_status_enum"`);
        await queryRunner.query(`ALTER TYPE "organizations_status_enum_old" RENAME TO "organizations_status_enum"`);
    }

}

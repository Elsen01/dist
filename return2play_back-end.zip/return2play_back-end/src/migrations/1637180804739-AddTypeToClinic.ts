import { MigrationInterface, QueryRunner } from 'typeorm';

export class AddTypeToClinic1637180804739 implements MigrationInterface {
  name = 'AddTypeToClinic1637180804739';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TYPE "clinics_medical_type_enum" RENAME TO "clinics_medical_type_enum_old"`);
    await queryRunner.query(
      `CREATE TYPE "clinics_medical_type_enum" AS ENUM('concussion advice', 'concussion follow up', 'all appointments')`
    );
    await queryRunner.query(
      `ALTER TABLE "clinics" ALTER COLUMN "medical_type" TYPE "clinics_medical_type_enum" USING "medical_type"::"text"::"clinics_medical_type_enum"`
    );
    await queryRunner.query(`DROP TYPE "clinics_medical_type_enum_old"`);
    await queryRunner.query(
      `ALTER TYPE "doctor_clinic_schedule_medical_type_enum" RENAME TO "doctor_clinic_schedule_medical_type_enum_old"`
    );
    await queryRunner.query(
      `CREATE TYPE "doctor_clinic_schedule_medical_type_enum" AS ENUM('concussion advice', 'concussion follow up', 'all appointments')`
    );
    await queryRunner.query(
      `ALTER TABLE "doctor_clinic_schedule" ALTER COLUMN "medical_type" TYPE "doctor_clinic_schedule_medical_type_enum" USING "medical_type"::"text"::"doctor_clinic_schedule_medical_type_enum"`
    );
    await queryRunner.query(`DROP TYPE "doctor_clinic_schedule_medical_type_enum_old"`);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TYPE "doctor_clinic_schedule_medical_type_enum_old" AS ENUM('concussion advice', 'concussion follow up')`
    );
    await queryRunner.query(
      `ALTER TABLE "doctor_clinic_schedule" ALTER COLUMN "medical_type" TYPE "doctor_clinic_schedule_medical_type_enum_old" USING "medical_type"::"text"::"doctor_clinic_schedule_medical_type_enum_old"`
    );
    await queryRunner.query(`DROP TYPE "doctor_clinic_schedule_medical_type_enum"`);
    await queryRunner.query(
      `ALTER TYPE "doctor_clinic_schedule_medical_type_enum_old" RENAME TO "doctor_clinic_schedule_medical_type_enum"`
    );
    await queryRunner.query(
      `CREATE TYPE "clinics_medical_type_enum_old" AS ENUM('concussion advice', 'concussion follow up')`
    );
    await queryRunner.query(
      `ALTER TABLE "clinics" ALTER COLUMN "medical_type" TYPE "clinics_medical_type_enum_old" USING "medical_type"::"text"::"clinics_medical_type_enum_old"`
    );
    await queryRunner.query(`DROP TYPE "clinics_medical_type_enum"`);
    await queryRunner.query(`ALTER TYPE "clinics_medical_type_enum_old" RENAME TO "clinics_medical_type_enum"`);
  }
}

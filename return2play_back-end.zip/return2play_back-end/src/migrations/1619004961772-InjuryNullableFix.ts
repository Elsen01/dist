import {MigrationInterface, QueryRunner} from "typeorm";

export class InjuryNullableFix1619004961772 implements MigrationInterface {
    name = 'InjuryNullableFix1619004961772'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "injuries" DROP CONSTRAINT "FK_d168998070d708fdf6062bb8f4d"`);
        await queryRunner.query(`ALTER TABLE "injuries" DROP CONSTRAINT "FK_a899be362ce73d0ba4b67fdea95"`);
        await queryRunner.query(`ALTER TABLE "injuries" ALTER COLUMN "player_id" SET NOT NULL`);
        await queryRunner.query(`ALTER TABLE "injuries" ALTER COLUMN "reporter_id" SET NOT NULL`);
        await queryRunner.query(`ALTER TABLE "injuries" ADD CONSTRAINT "FK_d168998070d708fdf6062bb8f4d" FOREIGN KEY ("player_id") REFERENCES "users"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "injuries" ADD CONSTRAINT "FK_a899be362ce73d0ba4b67fdea95" FOREIGN KEY ("reporter_id") REFERENCES "users"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "injuries" DROP CONSTRAINT "FK_a899be362ce73d0ba4b67fdea95"`);
        await queryRunner.query(`ALTER TABLE "injuries" DROP CONSTRAINT "FK_d168998070d708fdf6062bb8f4d"`);
        await queryRunner.query(`ALTER TABLE "injuries" ALTER COLUMN "reporter_id" DROP NOT NULL`);
        await queryRunner.query(`ALTER TABLE "injuries" ALTER COLUMN "player_id" DROP NOT NULL`);
        await queryRunner.query(`ALTER TABLE "injuries" ADD CONSTRAINT "FK_a899be362ce73d0ba4b67fdea95" FOREIGN KEY ("reporter_id") REFERENCES "users"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "injuries" ADD CONSTRAINT "FK_d168998070d708fdf6062bb8f4d" FOREIGN KEY ("player_id") REFERENCES "users"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
    }

}

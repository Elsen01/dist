import {MigrationInterface, QueryRunner} from "typeorm";

export class InjuryDateUpdate1621932922060 implements MigrationInterface {
    name = 'InjuryDateUpdate1621932922060'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "external_assessments" ADD "appointment_date" TIMESTAMP WITH TIME ZONE NOT NULL`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "external_assessments" DROP COLUMN "appointment_date"`);
    }

}

// import { SUPER_USER_EMAIL, SUPER_USER_ID } from "src/modules/shared/constants";
// import {MigrationInterface, QueryRunner} from "typeorm";

// export class SeedSuperUser1630418934792 implements MigrationInterface {
//     name = 'SeedSuperUser1630418934792'

//     public async up(queryRunner: QueryRunner): Promise<void> {
//         await queryRunner.query(`
//         INSERT INTO users 
//             (first_name, last_name, email, role, id)
//         VALUES 
//             ('Harry', 'Black', '${SUPER_USER_EMAIL}', 'super_admins', '${SUPER_USER_ID}');
//         `);
//     }

//     public async down(queryRunner: QueryRunner): Promise<void> {
//         await queryRunner.query(`DELETE FROM users u WHERE u.id = '${SUPER_USER_ID}';`);
//     }

// }

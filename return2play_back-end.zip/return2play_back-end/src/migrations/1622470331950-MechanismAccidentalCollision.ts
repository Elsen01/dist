import {MigrationInterface, QueryRunner} from "typeorm";

export class MechanismAccidentalCollision1622470331950 implements MigrationInterface {

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`UPDATE "injury_mechanisms" SET "name" = 'Accidental collision' WHERE "name" = 'Collision'`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`UPDATE "injury_mechanisms" SET "name" = 'Collision' WHERE "name" = 'Accidental collision'`);
    }

}

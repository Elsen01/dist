import {MigrationInterface, QueryRunner} from "typeorm";

export class PlayerChange1622726394463 implements MigrationInterface {
    name = 'PlayerChange1622726394463'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "players" ALTER COLUMN "year_group" SET DEFAULT 'N/A'`);
        await queryRunner.query(`ALTER TABLE "players" ALTER COLUMN "play_status" SET DEFAULT 'Safe to play'`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "players" ALTER COLUMN "play_status" SET DEFAULT 'Not safe to play'`);
        await queryRunner.query(`ALTER TABLE "players" ALTER COLUMN "year_group" DROP DEFAULT`);
    }

}

import {MigrationInterface, QueryRunner} from "typeorm";

export class DropNotNullOtherInjuryType1624455013743 implements MigrationInterface {
    name = 'DropNotNullOtherInjuryType1624455013743'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "other_injuries" ALTER COLUMN "type" DROP NOT NULL`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "other_injuries" ALTER COLUMN "type" SET NOT NULL`);
    }

}

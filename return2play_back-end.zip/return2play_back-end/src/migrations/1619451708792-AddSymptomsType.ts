import {MigrationInterface, QueryRunner} from "typeorm";

export class AddSymptomsType1619451708792 implements MigrationInterface {
    name = 'AddSymptomsType1619451708792'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "binary_symptoms" ADD "type" character varying(255)`);
        await queryRunner.query(`ALTER TABLE "other_symptoms" ADD "type" character varying(255)`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "other_symptoms" DROP COLUMN "type"`);
        await queryRunner.query(`ALTER TABLE "binary_symptoms" DROP COLUMN "type"`);
    }

}

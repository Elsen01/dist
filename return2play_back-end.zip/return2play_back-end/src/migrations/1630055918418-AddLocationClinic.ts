import {MigrationInterface, QueryRunner} from "typeorm";

export class AddLocationClinic1630055918418 implements MigrationInterface {
    name = 'AddLocationClinic1630055918418'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "doctor_clinic_schedule" ADD "location" character varying(255)`);
        await queryRunner.query(`ALTER TABLE "clinics" ADD "location" character varying(255)`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "clinics" DROP COLUMN "location"`);
        await queryRunner.query(`ALTER TABLE "doctor_clinic_schedule" DROP COLUMN "location"`);
    }

}

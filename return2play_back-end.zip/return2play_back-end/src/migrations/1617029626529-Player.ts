import { MigrationInterface, QueryRunner } from 'typeorm';

export class Player1617029626529 implements MigrationInterface {
  name = 'Player1617029626529';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TYPE "players_membership_enum" AS ENUM('Regular Member', 'School Member', 'Non-member')`
    );
    await queryRunner.query(
      `CREATE TABLE "players" ("user_id" character varying NOT NULL, "membership" "players_membership_enum" NOT NULL, "year_group" character varying NOT NULL, CONSTRAINT "REL_ba3575d2fbe71fab7155366235" UNIQUE ("user_id"), CONSTRAINT "PK_ba3575d2fbe71fab7155366235e" PRIMARY KEY ("user_id"))`
    );
    await queryRunner.query(
      `ALTER TABLE "players" ADD CONSTRAINT "FK_ba3575d2fbe71fab7155366235e" FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE NO ACTION`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "players" DROP CONSTRAINT "FK_ba3575d2fbe71fab7155366235e"`);
    await queryRunner.query(`DROP TABLE "players"`);
    await queryRunner.query(`DROP TYPE "players_membership_enum"`);
  }
}

import {MigrationInterface, QueryRunner} from "typeorm";

export class ScheduleOrganization1619624749621 implements MigrationInterface {
    name = 'ScheduleOrganization1619624749621'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`CREATE TABLE "schedule_organization" ("clinic_id" uuid NOT NULL, "organization_id" uuid NOT NULL, CONSTRAINT "PK_8614866c82d84e56f061e0401c6" PRIMARY KEY ("clinic_id", "organization_id"))`);
        await queryRunner.query(`CREATE INDEX "IDX_65293095e0919977bd7011fd15" ON "schedule_organization" ("clinic_id") `);
        await queryRunner.query(`CREATE INDEX "IDX_2f1cf125032a85c260f35ae3b6" ON "schedule_organization" ("organization_id") `);
        await queryRunner.query(`ALTER TABLE "schedule_organization" ADD CONSTRAINT "FK_65293095e0919977bd7011fd156" FOREIGN KEY ("clinic_id") REFERENCES "doctor_clinic_schedule"("id") ON DELETE CASCADE ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "schedule_organization" ADD CONSTRAINT "FK_2f1cf125032a85c260f35ae3b69" FOREIGN KEY ("organization_id") REFERENCES "organizations"("id") ON DELETE CASCADE ON UPDATE NO ACTION`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "schedule_organization" DROP CONSTRAINT "FK_2f1cf125032a85c260f35ae3b69"`);
        await queryRunner.query(`ALTER TABLE "schedule_organization" DROP CONSTRAINT "FK_65293095e0919977bd7011fd156"`);
        await queryRunner.query(`DROP INDEX "IDX_2f1cf125032a85c260f35ae3b6"`);
        await queryRunner.query(`DROP INDEX "IDX_65293095e0919977bd7011fd15"`);
        await queryRunner.query(`DROP TABLE "schedule_organization"`);
    }

}

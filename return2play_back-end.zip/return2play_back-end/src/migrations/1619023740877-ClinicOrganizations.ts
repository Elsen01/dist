import {MigrationInterface, QueryRunner} from "typeorm";

export class ClinicOrganizations1619023740877 implements MigrationInterface {
    name = 'ClinicOrganizations1619023740877'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`CREATE TABLE "clinic_organization" ("clinic_id" uuid NOT NULL, "organization_id" uuid NOT NULL, CONSTRAINT "PK_34b821d0a0d54854fd4e7f8139d" PRIMARY KEY ("clinic_id", "organization_id"))`);
        await queryRunner.query(`CREATE INDEX "IDX_95e8f65cc2f1b8e801cd5e5ba2" ON "clinic_organization" ("clinic_id") `);
        await queryRunner.query(`CREATE INDEX "IDX_f006da0220eea355e03ea0f044" ON "clinic_organization" ("organization_id") `);
        await queryRunner.query(`ALTER TYPE "doctor_clinic_schedule_day_enum" RENAME TO "doctor_clinic_schedule_day_enum_old"`);
        await queryRunner.query(`CREATE TYPE "doctor_clinic_schedule_day_enum" AS ENUM('0', '1', '2', '3', '4')`);
        await queryRunner.query(`ALTER TABLE "doctor_clinic_schedule" ALTER COLUMN "day" TYPE "doctor_clinic_schedule_day_enum" USING "day"::"text"::"doctor_clinic_schedule_day_enum"`);
        await queryRunner.query(`DROP TYPE "doctor_clinic_schedule_day_enum_old"`);
        await queryRunner.query(`ALTER TABLE "clinic_organization" ADD CONSTRAINT "FK_95e8f65cc2f1b8e801cd5e5ba2d" FOREIGN KEY ("clinic_id") REFERENCES "clinics"("id") ON DELETE CASCADE ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "clinic_organization" ADD CONSTRAINT "FK_f006da0220eea355e03ea0f044d" FOREIGN KEY ("organization_id") REFERENCES "organizations"("id") ON DELETE CASCADE ON UPDATE NO ACTION`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "clinic_organization" DROP CONSTRAINT "FK_f006da0220eea355e03ea0f044d"`);
        await queryRunner.query(`ALTER TABLE "clinic_organization" DROP CONSTRAINT "FK_95e8f65cc2f1b8e801cd5e5ba2d"`);
        await queryRunner.query(`CREATE TYPE "doctor_clinic_schedule_day_enum_old" AS ENUM('Mon', 'Tue', 'Wed', 'Thur', 'Fri')`);
        await queryRunner.query(`ALTER TABLE "doctor_clinic_schedule" ALTER COLUMN "day" TYPE "doctor_clinic_schedule_day_enum_old" USING "day"::"text"::"doctor_clinic_schedule_day_enum_old"`);
        await queryRunner.query(`DROP TYPE "doctor_clinic_schedule_day_enum"`);
        await queryRunner.query(`ALTER TYPE "doctor_clinic_schedule_day_enum_old" RENAME TO "doctor_clinic_schedule_day_enum"`);
        await queryRunner.query(`DROP INDEX "IDX_f006da0220eea355e03ea0f044"`);
        await queryRunner.query(`DROP INDEX "IDX_95e8f65cc2f1b8e801cd5e5ba2"`);
        await queryRunner.query(`DROP TABLE "clinic_organization"`);
    }

}

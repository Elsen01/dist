import {MigrationInterface, QueryRunner} from "typeorm";

export class ChangeAssessments1620222258805 implements MigrationInterface {
    name = 'ChangeAssessments1620222258805'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "grtp" ADD "timetable_link" character varying`);
        await queryRunner.query(`ALTER TABLE "assessments" ALTER COLUMN "certificate_link" DROP NOT NULL`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "assessments" ALTER COLUMN "certificate_link" SET NOT NULL`);
        await queryRunner.query(`ALTER TABLE "grtp" DROP COLUMN "timetable_link"`);
    }

}

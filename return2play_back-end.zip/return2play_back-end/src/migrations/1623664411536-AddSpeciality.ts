import {MigrationInterface, QueryRunner} from "typeorm";

export class AddSpeciality1623664411536 implements MigrationInterface {
    name = 'AddSpeciality1623664411536'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "doctors" ADD "speciality" character varying(255)`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "doctors" DROP COLUMN "speciality"`);
    }

}

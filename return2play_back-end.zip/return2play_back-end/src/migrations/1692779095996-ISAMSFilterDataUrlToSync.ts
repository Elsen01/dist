import { MigrationInterface, QueryRunner } from 'typeorm';

export class ISAMSFilterDataUrlToSync1692779095996 implements MigrationInterface {
  name = 'ISAMSFilterDataUrlToSync1692779095996';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "isams_syncs" ADD "filters" text`);
    await queryRunner.query(`ALTER TABLE "isams_syncs" ADD "iSAMSDataUrl" character varying`);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "isams_syncs" DROP COLUMN "iSAMSDataUrl"`);
    await queryRunner.query(`ALTER TABLE "isams_syncs" DROP COLUMN "filters"`);
  }
}

import { MigrationInterface, QueryRunner } from 'typeorm';

export class HeadInjuryPossible1661861580134 implements MigrationInterface {
  name = 'HeadInjuryPossible1661861580134';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query("ALTER TYPE injuries_injury_group_enum ADD VALUE 'Head Injury (possible concussion)'");
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`CREATE TYPE "injuries_injury_group_enum_old" AS ENUM('Concussion', 'Other')`);
    await queryRunner.query(
      `ALTER TABLE "injuries" ALTER COLUMN "injury_group" TYPE "injuries_injury_group_enum_old" USING "injury_group"::"text"::"injuries_injury_group_enum_old"`
    );
    await queryRunner.query(`DROP TYPE "injuries_injury_group_enum"`);
    await queryRunner.query(`ALTER TYPE "injuries_injury_group_enum_old" RENAME TO "injuries_injury_group_enum"`);
  }
}

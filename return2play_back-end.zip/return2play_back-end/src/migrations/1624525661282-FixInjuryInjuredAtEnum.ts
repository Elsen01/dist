import {MigrationInterface, QueryRunner} from "typeorm";

export class FixInjuryInjuredAtEnum1624525661282 implements MigrationInterface {
    name = 'FixInjuryInjuredAtEnum1624525661282'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TYPE "injuries_injured_at_enum" RENAME TO "injuries_injured_at_enum_old"`);
        await queryRunner.query(`CREATE TYPE "injuries_injured_at_enum" AS ENUM('Home', 'School - Astro', 'School - Classroom', 'School - Corridor', 'School - Fields', 'School - Playground', 'School - Woods', 'Club', 'Other')`);
        await queryRunner.query(`ALTER TABLE "injuries" ALTER COLUMN "injured_at" TYPE "text"`);
        await queryRunner.query(`
        UPDATE injuries i
        SET injured_at = substring(i.injured_at, 2, length(i.injured_at))
        WHERE position(' ' in i.injured_at) = 1;`
        );
        await queryRunner.query(`ALTER TABLE "injuries" ALTER COLUMN "injured_at" TYPE "injuries_injured_at_enum" USING "injured_at"::"text"::"injuries_injured_at_enum"`);
        await queryRunner.query(`DROP TYPE "injuries_injured_at_enum_old"`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`CREATE TYPE "injuries_injured_at_enum_old" AS ENUM('Home', 'School - Astro', 'School - Classroom', 'School - Corridor', ' School - Fields', ' School - Playground', ' School - Woods', 'Club', 'Other')`);
        await queryRunner.query(`ALTER TABLE "injuries" ALTER COLUMN "injured_at" TYPE "text"`);
        await queryRunner.query(`
        UPDATE injuries i
        SET injured_at = CONCAT(' ', injured_at)
        WHERE injured_at IN ('School - Fields', 'School - Playground', 'School - Woods');`
        );
        await queryRunner.query(`ALTER TABLE "injuries" ALTER COLUMN "injured_at" TYPE "injuries_injured_at_enum_old" USING "injured_at"::"text"::"injuries_injured_at_enum_old"`);
        await queryRunner.query(`DROP TYPE "injuries_injured_at_enum"`);
        await queryRunner.query(`ALTER TYPE "injuries_injured_at_enum_old" RENAME TO "injuries_injured_at_enum"`);
    }

}

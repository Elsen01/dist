import {MigrationInterface, QueryRunner} from "typeorm";

export class SportInjuryMatchTrainingNullable1623081449546 implements MigrationInterface {
    name = 'SportInjuryMatchTrainingNullable1623081449546'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "sport_injuries" ALTER COLUMN "match_training" DROP NOT NULL`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "sport_injuries" ALTER COLUMN "match_training" SET NOT NULL`);
    }

}

import {MigrationInterface, QueryRunner} from "typeorm";

export class Fix1625656113174 implements MigrationInterface {
    name = 'Fix1625656113174'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "assessments" ADD "outcome_note" character varying(1000)`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "assessments" DROP COLUMN "outcome_note"`);
    }

}

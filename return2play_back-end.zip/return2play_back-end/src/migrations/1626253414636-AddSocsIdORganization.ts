import {MigrationInterface, QueryRunner} from "typeorm";

export class AddSocsIdORganization1626253414636 implements MigrationInterface {
    name = 'AddSocsIdORganization1626253414636'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "organizations" ADD "socs_id" character varying`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "organizations" DROP COLUMN "socs_id"`);
    }

}

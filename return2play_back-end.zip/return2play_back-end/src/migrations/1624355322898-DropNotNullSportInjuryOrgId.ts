import {MigrationInterface, QueryRunner} from "typeorm";

export class DropNotNullSportInjuryOrgId1624355322898 implements MigrationInterface {
    name = 'DropNotNullSportInjuryOrgId1624355322898'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "sport_injuries" DROP CONSTRAINT "FK_0cfe91f6a4cd7ba8550997db08c"`);
        await queryRunner.query(`ALTER TABLE "sport_injuries" ALTER COLUMN "organization_id" DROP NOT NULL`);
        await queryRunner.query(`ALTER TABLE "sport_injuries" ADD CONSTRAINT "FK_0cfe91f6a4cd7ba8550997db08c" FOREIGN KEY ("organization_id") REFERENCES "organizations"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "sport_injuries" DROP CONSTRAINT "FK_0cfe91f6a4cd7ba8550997db08c"`);
        await queryRunner.query(`ALTER TABLE "sport_injuries" ALTER COLUMN "organization_id" SET NOT NULL`);
        await queryRunner.query(`ALTER TABLE "sport_injuries" ADD CONSTRAINT "FK_0cfe91f6a4cd7ba8550997db08c" FOREIGN KEY ("organization_id") REFERENCES "organizations"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
    }

}

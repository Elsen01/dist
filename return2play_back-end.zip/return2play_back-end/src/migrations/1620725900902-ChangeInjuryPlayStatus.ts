import {MigrationInterface, QueryRunner} from "typeorm";

export class ChangeInjuryPlayStatus1620725900902 implements MigrationInterface {
    name = 'ChangeInjuryPlayStatus1620725900902'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TYPE "players_play_status_enum" RENAME TO "players_play_status_enum_old"`);
        await queryRunner.query(`CREATE TYPE "player_play_status_enum" AS ENUM('Cleared', 'Safe to play', 'Reduced level of activity', 'Not safe to play')`);
        await queryRunner.query(`ALTER TABLE "players" ALTER COLUMN "play_status" DROP DEFAULT`);
        await queryRunner.query(`ALTER TABLE "players" ALTER COLUMN "play_status" TYPE "player_play_status_enum" USING "play_status"::"text"::"player_play_status_enum"`);
        await queryRunner.query(`ALTER TABLE "players" ALTER COLUMN "play_status" SET DEFAULT 'Not safe to play'`);
        await queryRunner.query(`DROP TYPE "players_play_status_enum_old"`);
        await queryRunner.query(`ALTER TYPE "injuries_play_status_enum" RENAME TO "injuries_play_status_enum_old"`);
        await queryRunner.query(`CREATE TYPE "injury_play_status_enum" AS ENUM('Cleared', 'Safe to play', 'Reduced level of activity', 'Not safe to play')`);
        await queryRunner.query(`ALTER TABLE "injuries" ALTER COLUMN "play_status" DROP DEFAULT`);
        await queryRunner.query(`ALTER TABLE "injuries" ALTER COLUMN "play_status" TYPE "injury_play_status_enum" USING "play_status"::"text"::"injury_play_status_enum"`);
        await queryRunner.query(`ALTER TABLE "injuries" ALTER COLUMN "play_status" SET DEFAULT 'Not safe to play'`);
        await queryRunner.query(`DROP TYPE "injuries_play_status_enum_old"`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`CREATE TYPE "injuries_play_status_enum_old" AS ENUM('Safe to play', 'Reduced level of activity', 'Not safe to play', 'Cleared')`);
        await queryRunner.query(`ALTER TABLE "injuries" ALTER COLUMN "play_status" DROP DEFAULT`);
        await queryRunner.query(`ALTER TABLE "injuries" ALTER COLUMN "play_status" TYPE "injuries_play_status_enum_old" USING "play_status"::"text"::"injuries_play_status_enum_old"`);
        await queryRunner.query(`ALTER TABLE "injuries" ALTER COLUMN "play_status" SET DEFAULT 'Not safe to play'`);
        await queryRunner.query(`DROP TYPE "injury_play_status_enum"`);
        await queryRunner.query(`ALTER TYPE "injuries_play_status_enum_old" RENAME TO "injuries_play_status_enum"`);
        await queryRunner.query(`CREATE TYPE "players_play_status_enum_old" AS ENUM('Safe to play', 'Reduced level of activity', 'Not safe to play', 'Cleared')`);
        await queryRunner.query(`ALTER TABLE "players" ALTER COLUMN "play_status" DROP DEFAULT`);
        await queryRunner.query(`ALTER TABLE "players" ALTER COLUMN "play_status" TYPE "players_play_status_enum_old" USING "play_status"::"text"::"players_play_status_enum_old"`);
        await queryRunner.query(`ALTER TABLE "players" ALTER COLUMN "play_status" SET DEFAULT 'Not safe to play'`);
        await queryRunner.query(`DROP TYPE "player_play_status_enum"`);
        await queryRunner.query(`ALTER TYPE "players_play_status_enum_old" RENAME TO "players_play_status_enum"`);
    }

}

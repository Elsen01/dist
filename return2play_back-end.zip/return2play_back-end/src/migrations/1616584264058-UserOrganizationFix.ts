import { MigrationInterface, QueryRunner } from 'typeorm';

export class UserOrganizationFix1616584264058 implements MigrationInterface {
  name = 'UserOrganizationFix1616584264058';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "organizations_users" DROP CONSTRAINT "FK_c00bc2922da6310512964d28729"`);
    await queryRunner.query(`ALTER TABLE "organizations_users" DROP CONSTRAINT "FK_b5aa17c39b722cb9bc25a3d139d"`);
    await queryRunner.query(`DROP INDEX "IDX_b5aa17c39b722cb9bc25a3d139"`);
    await queryRunner.query(`DROP INDEX "IDX_c00bc2922da6310512964d2872"`);
    await queryRunner.query(`ALTER TABLE "organizations_users" DROP CONSTRAINT "PK_da93ab06ae4af19e3a142813950"`);
    await queryRunner.query(
      `ALTER TABLE "organizations_users" ADD CONSTRAINT "PK_b5aa17c39b722cb9bc25a3d139d" PRIMARY KEY ("usersId")`
    );
    await queryRunner.query(`ALTER TABLE "organizations_users" DROP COLUMN "organizationsId"`);
    await queryRunner.query(`ALTER TABLE "organizations_users" DROP CONSTRAINT "PK_b5aa17c39b722cb9bc25a3d139d"`);
    await queryRunner.query(`ALTER TABLE "organizations_users" DROP COLUMN "usersId"`);
    await queryRunner.query(`ALTER TABLE "organizations_users" ADD "organization_id" uuid NOT NULL`);
    await queryRunner.query(
      `ALTER TABLE "organizations_users" ADD CONSTRAINT "PK_e0e76d9c419e1d6c6608fc481b6" PRIMARY KEY ("organization_id")`
    );
    await queryRunner.query(`ALTER TABLE "organizations_users" ADD "user_id" character varying NOT NULL`);
    await queryRunner.query(`ALTER TABLE "organizations_users" DROP CONSTRAINT "PK_e0e76d9c419e1d6c6608fc481b6"`);
    await queryRunner.query(
      `ALTER TABLE "organizations_users" ADD CONSTRAINT "PK_82c6ea56610629d9e11b98900e9" PRIMARY KEY ("organization_id", "user_id")`
    );
    await queryRunner.query(
      `CREATE INDEX "IDX_e0e76d9c419e1d6c6608fc481b" ON "organizations_users" ("organization_id") `
    );
    await queryRunner.query(`CREATE INDEX "IDX_2988713747e3b69e9522901f26" ON "organizations_users" ("user_id") `);
    await queryRunner.query(
      `ALTER TABLE "organizations_users" ADD CONSTRAINT "FK_e0e76d9c419e1d6c6608fc481b6" FOREIGN KEY ("organization_id") REFERENCES "organizations"("id") ON DELETE CASCADE ON UPDATE NO ACTION`
    );
    await queryRunner.query(
      `ALTER TABLE "organizations_users" ADD CONSTRAINT "FK_2988713747e3b69e9522901f267" FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE NO ACTION`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "organizations_users" DROP CONSTRAINT "FK_2988713747e3b69e9522901f267"`);
    await queryRunner.query(`ALTER TABLE "organizations_users" DROP CONSTRAINT "FK_e0e76d9c419e1d6c6608fc481b6"`);
    await queryRunner.query(`DROP INDEX "IDX_2988713747e3b69e9522901f26"`);
    await queryRunner.query(`DROP INDEX "IDX_e0e76d9c419e1d6c6608fc481b"`);
    await queryRunner.query(`ALTER TABLE "organizations_users" DROP CONSTRAINT "PK_82c6ea56610629d9e11b98900e9"`);
    await queryRunner.query(
      `ALTER TABLE "organizations_users" ADD CONSTRAINT "PK_e0e76d9c419e1d6c6608fc481b6" PRIMARY KEY ("organization_id")`
    );
    await queryRunner.query(`ALTER TABLE "organizations_users" DROP COLUMN "user_id"`);
    await queryRunner.query(`ALTER TABLE "organizations_users" DROP CONSTRAINT "PK_e0e76d9c419e1d6c6608fc481b6"`);
    await queryRunner.query(`ALTER TABLE "organizations_users" DROP COLUMN "organization_id"`);
    await queryRunner.query(`ALTER TABLE "organizations_users" ADD "usersId" character varying NOT NULL`);
    await queryRunner.query(
      `ALTER TABLE "organizations_users" ADD CONSTRAINT "PK_b5aa17c39b722cb9bc25a3d139d" PRIMARY KEY ("usersId")`
    );
    await queryRunner.query(`ALTER TABLE "organizations_users" ADD "organizationsId" uuid NOT NULL`);
    await queryRunner.query(`ALTER TABLE "organizations_users" DROP CONSTRAINT "PK_b5aa17c39b722cb9bc25a3d139d"`);
    await queryRunner.query(
      `ALTER TABLE "organizations_users" ADD CONSTRAINT "PK_da93ab06ae4af19e3a142813950" PRIMARY KEY ("organizationsId", "usersId")`
    );
    await queryRunner.query(
      `CREATE INDEX "IDX_c00bc2922da6310512964d2872" ON "organizations_users" ("organizationsId") `
    );
    await queryRunner.query(`CREATE INDEX "IDX_b5aa17c39b722cb9bc25a3d139" ON "organizations_users" ("usersId") `);
    await queryRunner.query(
      `ALTER TABLE "organizations_users" ADD CONSTRAINT "FK_b5aa17c39b722cb9bc25a3d139d" FOREIGN KEY ("usersId") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE NO ACTION`
    );
    await queryRunner.query(
      `ALTER TABLE "organizations_users" ADD CONSTRAINT "FK_c00bc2922da6310512964d28729" FOREIGN KEY ("organizationsId") REFERENCES "organizations"("id") ON DELETE CASCADE ON UPDATE NO ACTION`
    );
  }
}

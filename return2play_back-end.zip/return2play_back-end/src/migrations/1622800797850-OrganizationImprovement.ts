import {MigrationInterface, QueryRunner} from "typeorm";

export class OrganizationImprovement1622800797850 implements MigrationInterface {
    name = 'OrganizationImprovement1622800797850'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`CREATE TYPE "organizations_schooltype_enum" AS ENUM('Boarding School', 'Day School')`);
        await queryRunner.query(`ALTER TABLE "organizations" ADD "schoolType" "organizations_schooltype_enum"`);
        await queryRunner.query(`ALTER TABLE "organizations" ADD "key_contact_name" character varying(255)`);
        await queryRunner.query(`ALTER TABLE "organizations" ADD "key_contact_email" character varying(255)`);
        await queryRunner.query(`ALTER TABLE "organizations" ADD "key_contact_role" character varying(255)`);
        await queryRunner.query(`ALTER TABLE "tags" DROP CONSTRAINT "FK_8f8033a570b04520455cc93ed3d"`);
        await queryRunner.query(`ALTER TABLE "tags" DROP CONSTRAINT "UQ_b3fd0b26c4e8d043bdf0d1bfab8"`);
        await queryRunner.query(`ALTER TABLE "tags" ALTER COLUMN "organization_id" DROP NOT NULL`);
        await queryRunner.query(`ALTER TABLE "tags" ADD CONSTRAINT "UQ_b3fd0b26c4e8d043bdf0d1bfab8" UNIQUE ("name", "organization_id")`);
        await queryRunner.query(`ALTER TABLE "tags" ADD CONSTRAINT "FK_8f8033a570b04520455cc93ed3d" FOREIGN KEY ("organization_id") REFERENCES "organizations"("id") ON DELETE CASCADE ON UPDATE NO ACTION`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "tags" DROP CONSTRAINT "FK_8f8033a570b04520455cc93ed3d"`);
        await queryRunner.query(`ALTER TABLE "tags" DROP CONSTRAINT "UQ_b3fd0b26c4e8d043bdf0d1bfab8"`);
        await queryRunner.query(`ALTER TABLE "tags" ALTER COLUMN "organization_id" SET NOT NULL`);
        await queryRunner.query(`ALTER TABLE "tags" ADD CONSTRAINT "UQ_b3fd0b26c4e8d043bdf0d1bfab8" UNIQUE ("name", "organization_id")`);
        await queryRunner.query(`ALTER TABLE "tags" ADD CONSTRAINT "FK_8f8033a570b04520455cc93ed3d" FOREIGN KEY ("organization_id") REFERENCES "organizations"("id") ON DELETE CASCADE ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "organizations" DROP COLUMN "key_contact_role"`);
        await queryRunner.query(`ALTER TABLE "organizations" DROP COLUMN "key_contact_email"`);
        await queryRunner.query(`ALTER TABLE "organizations" DROP COLUMN "key_contact_name"`);
        await queryRunner.query(`ALTER TABLE "organizations" DROP COLUMN "schoolType"`);
        await queryRunner.query(`DROP TYPE "organizations_schooltype_enum"`);
    }

}

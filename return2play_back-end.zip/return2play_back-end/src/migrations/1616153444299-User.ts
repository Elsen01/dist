import { MigrationInterface, QueryRunner } from 'typeorm';

export class User1616153444299 implements MigrationInterface {
  name = 'User1616153444299';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`CREATE TYPE "users_gender_enum" AS ENUM('Female', 'Male')`);
    await queryRunner.query(
      `CREATE TYPE "users_role_enum" AS ENUM('super_admins', 'players', 'parents', 'staff_users', 'organization_admins', 'doctors')`
    );
    await queryRunner.query(`CREATE TYPE "users_status_enum" AS ENUM('Active', 'Inactive', 'Deleted')`);
    await queryRunner.query(
      `CREATE TABLE "users" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "first_name" character varying(100) NOT NULL, "last_name" character varying(100) NOT NULL, "email" character varying(255) NOT NULL, "mobile_phone" character varying(255) NOT NULL, "home_phone" character varying(255), "gender" "users_gender_enum" NOT NULL, "role" "users_role_enum" NOT NULL, "birthday" date NOT NULL, "status" "users_status_enum" NOT NULL, "created_at" TIMESTAMP NOT NULL DEFAULT now(), CONSTRAINT "PK_a3ffb1c0c8416b9fc6f907b7433" PRIMARY KEY ("id"))`
    );
    await queryRunner.query(
      `CREATE TABLE "organizations_users" ("organizationsId" uuid NOT NULL, "usersId" uuid NOT NULL, CONSTRAINT "PK_da93ab06ae4af19e3a142813950" PRIMARY KEY ("organizationsId", "usersId"))`
    );
    await queryRunner.query(
      `CREATE INDEX "IDX_c00bc2922da6310512964d2872" ON "organizations_users" ("organizationsId") `
    );
    await queryRunner.query(`CREATE INDEX "IDX_b5aa17c39b722cb9bc25a3d139" ON "organizations_users" ("usersId") `);
    await queryRunner.query(
      `ALTER TABLE "organizations_users" ADD CONSTRAINT "FK_c00bc2922da6310512964d28729" FOREIGN KEY ("organizationsId") REFERENCES "organizations"("id") ON DELETE CASCADE ON UPDATE NO ACTION`
    );
    await queryRunner.query(
      `ALTER TABLE "organizations_users" ADD CONSTRAINT "FK_b5aa17c39b722cb9bc25a3d139d" FOREIGN KEY ("usersId") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE NO ACTION`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "organizations_users" DROP CONSTRAINT "FK_b5aa17c39b722cb9bc25a3d139d"`);
    await queryRunner.query(`ALTER TABLE "organizations_users" DROP CONSTRAINT "FK_c00bc2922da6310512964d28729"`);
    await queryRunner.query(`DROP INDEX "IDX_b5aa17c39b722cb9bc25a3d139"`);
    await queryRunner.query(`DROP INDEX "IDX_c00bc2922da6310512964d2872"`);
    await queryRunner.query(`DROP TABLE "organizations_users"`);
    await queryRunner.query(`DROP TABLE "users"`);
    await queryRunner.query(`DROP TYPE "users_status_enum"`);
    await queryRunner.query(`DROP TYPE "users_role_enum"`);
    await queryRunner.query(`DROP TYPE "users_gender_enum"`);
  }
}

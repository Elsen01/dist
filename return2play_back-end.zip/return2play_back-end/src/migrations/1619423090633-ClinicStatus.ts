import {MigrationInterface, QueryRunner} from "typeorm";

export class ClinicStatus1619423090633 implements MigrationInterface {
    name = 'ClinicStatus1619423090633'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`CREATE TYPE "clinics_status_enum" AS ENUM('Active', 'Inactive')`);
        await queryRunner.query(`ALTER TABLE "clinics" ADD "status" "clinics_status_enum" NOT NULL DEFAULT 'Active'`);
        await queryRunner.query(`ALTER TYPE "doctor_clinic_schedule_status_enum" RENAME TO "doctor_clinic_schedule_status_enum_old"`);
        await queryRunner.query(`CREATE TYPE "doctor_clinic_schedule_status_enum" AS ENUM('Active', 'Inactive')`);
        await queryRunner.query(`ALTER TABLE "doctor_clinic_schedule" ALTER COLUMN "status" DROP DEFAULT`);
        await queryRunner.query(`ALTER TABLE "doctor_clinic_schedule" ALTER COLUMN "status" TYPE "doctor_clinic_schedule_status_enum" USING "status"::"text"::"doctor_clinic_schedule_status_enum"`);
        await queryRunner.query(`ALTER TABLE "doctor_clinic_schedule" ALTER COLUMN "status" SET DEFAULT 'Active'`);
        await queryRunner.query(`DROP TYPE "doctor_clinic_schedule_status_enum_old"`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`CREATE TYPE "doctor_clinic_schedule_status_enum_old" AS ENUM('active', 'inactive')`);
        await queryRunner.query(`ALTER TABLE "doctor_clinic_schedule" ALTER COLUMN "status" DROP DEFAULT`);
        await queryRunner.query(`ALTER TABLE "doctor_clinic_schedule" ALTER COLUMN "status" TYPE "doctor_clinic_schedule_status_enum_old" USING "status"::"text"::"doctor_clinic_schedule_status_enum_old"`);
        await queryRunner.query(`ALTER TABLE "doctor_clinic_schedule" ALTER COLUMN "status" SET DEFAULT 'active'`);
        await queryRunner.query(`DROP TYPE "doctor_clinic_schedule_status_enum"`);
        await queryRunner.query(`ALTER TYPE "doctor_clinic_schedule_status_enum_old" RENAME TO "doctor_clinic_schedule_status_enum"`);
        await queryRunner.query(`ALTER TABLE "clinics" DROP COLUMN "status"`);
        await queryRunner.query(`DROP TYPE "clinics_status_enum"`);
    }

}

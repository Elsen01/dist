import {MigrationInterface, QueryRunner} from "typeorm";

export class AddPlayStatus1618390813008 implements MigrationInterface {
    name = 'AddPlayStatus1618390813008'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`CREATE TYPE "injuries_play_status_enum" AS ENUM('Safe to play', 'Reduced level of activity', 'Not safe to play')`);
        await queryRunner.query(`ALTER TABLE "injuries" ADD "play_status" "injuries_play_status_enum" NOT NULL DEFAULT 'Not safe to play'`);
        await queryRunner.query(`CREATE TYPE "players_play_status_enum" AS ENUM('Safe to play', 'Reduced level of activity', 'Not safe to play')`);
        await queryRunner.query(`ALTER TABLE "players" ADD "play_status" "players_play_status_enum" NOT NULL DEFAULT 'Not safe to play'`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "players" DROP COLUMN "play_status"`);
        await queryRunner.query(`DROP TYPE "players_play_status_enum"`);
        await queryRunner.query(`ALTER TABLE "injuries" DROP COLUMN "play_status"`);
        await queryRunner.query(`DROP TYPE "injuries_play_status_enum"`);
    }

}
